/*    */ package EasyShop.util;
/*    */ 
/*    */ import com.google.firebase.database.DataSnapshot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CategoryData
/*    */ {
/*    */   private String id;
/* 16 */   private String imgURL = "https://firebasestorage.googleapis.com/v0/b/easyshop-fe4c7.appspot.com/o/Images%2Fezimg.png?alt=media&token=d05b165c-4c6c-48ea-97db-349109902621";
/*    */   private String imgid;
/*    */   private String name;
/*    */   private String shop_id;
/* 20 */   private String showinapp = "1";
/*    */   private String description;
/*    */   
/*    */   public CategoryData(String id, String imgid, String name, String shop_id, String description, String url) {
/* 24 */     this.id = id;
/* 25 */     this.imgid = imgid;
/* 26 */     this.name = name;
/* 27 */     this.shop_id = shop_id;
/* 28 */     this.description = description;
/* 29 */     if (!url.isEmpty())
/* 30 */       this.imgURL = url; 
/*    */   }
/*    */   
/*    */   public CategoryData() {}
/*    */   
/*    */   public CategoryData(DataSnapshot d) {
/* 36 */     System.out.println("Into cat const");
/* 37 */     this.id = d.child("id").getValue().toString();
/* 38 */     this.imgURL = d.child("imgURL").getValue().toString();
/* 39 */     this.imgid = d.child("imgid").getValue().toString();
/* 40 */     this.name = d.child("name").getValue().toString();
/* 41 */     this.shop_id = d.child("shop_id").getValue().toString();
/* 42 */     this.description = d.child("description").getValue().toString();
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 46 */     return this.description;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 50 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setID(String id) {
/* 54 */     this.id = id;
/*    */   }
/*    */   
/*    */   public String getImgURL() {
/* 58 */     return this.imgURL;
/*    */   }
/*    */   
/*    */   public String getImgid() {
/* 62 */     return this.imgid;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 66 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getShop_id() {
/* 70 */     return this.shop_id;
/*    */   }
/*    */   
/*    */   public void setShop_id(String s) {
/* 74 */     this.shop_id = s;
/*    */   }
/*    */   
/*    */   public String getShowinapp() {
/* 78 */     return this.showinapp;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     return "CatagoryData{\nid=" + this.id + ", \nimgURL=" + this.imgURL + ", \nimgid=" + this.imgid + ", \nname=" + this.name + ", \nshop_id=" + this.shop_id + '}';
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\CategoryData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */