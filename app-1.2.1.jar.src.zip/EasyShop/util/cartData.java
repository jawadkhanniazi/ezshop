/*    */ package EasyShop.util;
/*    */ 
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class cartData
/*    */ {
/*    */   String cat_id;
/*    */   String unitPrice;
/*    */   String name;
/*    */   int count;
/*    */   String barcode;
/*    */   ImageIcon icon;
/*    */   
/*    */   public String getCat_id() {
/* 23 */     return this.cat_id;
/*    */   }
/*    */   
/*    */   public String getUnitPrice() {
/* 27 */     return this.unitPrice;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 31 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getCount() {
/* 35 */     return this.count;
/*    */   }
/*    */   
/*    */   public void setCount(int val) {
/* 39 */     this.count = val;
/*    */   }
/*    */   
/*    */   public String getBarcode() {
/* 43 */     return this.barcode;
/*    */   }
/*    */   
/*    */   public ImageIcon getIcon() {
/* 47 */     return this.icon;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public cartData() {}
/*    */ 
/*    */   
/*    */   public cartData(String cat_id, String unitPrice, String name, int count, String barcode) {
/* 56 */     this.cat_id = cat_id;
/* 57 */     this.unitPrice = unitPrice;
/* 58 */     this.name = name;
/* 59 */     this.count = count;
/* 60 */     this.barcode = barcode;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return "cartData{\n         imgurl=" + this.cat_id + "\n         unitPrice=" + this.unitPrice + "\n         name=" + this.name + "\n         count=" + this.count + "\n         barcode=" + this.barcode + "  }";
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\cartData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */