/*     */ package EasyShop.util;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Printable;
/*     */ import java.awt.print.PrinterException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedList;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrintBill
/*     */   implements Printable
/*     */ {
/*     */   private int bill;
/*     */   private int amount;
/*  31 */   private LinkedList<cartData> det = new LinkedList<>();
/*     */   public PrintBill(LinkedList<cartData> l, int amount, int bill) {
/*  33 */     this.det = l;
/*  34 */     this.amount = amount;
/*  35 */     this.bill = bill;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
/*  41 */     int r = this.det.size();
/*  42 */     ImageIcon icon = new ImageIcon("bin/user.png");
/*  43 */     int result = 1;
/*  44 */     if (pageIndex == 0) {
/*     */       
/*  46 */       Graphics2D g2d = (Graphics2D)graphics;
/*  47 */       double width = pageFormat.getImageableWidth();
/*  48 */       g2d.translate((int)pageFormat.getImageableX(), (int)pageFormat.getImageableY());
/*     */       try {
/*  50 */         int y = 5;
/*  51 */         int yShift = 6;
/*     */         
/*  53 */         g2d.setFont(new Font("Monospaced", 0, 8));
/*  54 */         String sName = "";
/*     */         try {
/*  56 */           BufferedReader reader = new BufferedReader(new FileReader("bin/Creds/shopName.txt"));
/*     */           
/*  58 */           sName = reader.readLine();
/*  59 */           sName = sName.trim();
/*  60 */         } catch (FileNotFoundException ex) {
/*  61 */           JOptionPane.showMessageDialog(null, "Error while reading shop name.\nYou can create one in settings.");
/*  62 */         } catch (IOException ex) {
/*  63 */           JOptionPane.showMessageDialog(null, "Error while reading shop name.\nYou can create one in settings.");
/*     */         } 
/*  65 */         int len = 180 - sName.length();
/*  66 */         len /= 2;
/*  67 */         g2d.drawString(sName, len, y); y += yShift;
/*  68 */         g2d.drawString(" Item Name                  Price   ", 10, y); y += yShift;
/*  69 */         g2d.drawString("-------------------------------------", 10, y); y += 10;
/*     */         
/*  71 */         for (int s = 0; s < r; s++) {
/*  72 */           cartData d = this.det.get(s);
/*  73 */           String name = d.getName();
/*  74 */           int quant = d.getCount();
/*  75 */           int price = Integer.parseInt(d.getUnitPrice());
/*  76 */           g2d.drawString(name + "                             ", 10, y); y += yShift;
/*  77 */           g2d.drawString("         " + quant + " * " + price, 25, y);
/*  78 */           g2d.drawString("" + (quant * price), 150, y); y += yShift;
/*     */         } 
/*     */ 
/*     */         
/*  82 */         g2d.drawString("-------------------------------------", 10, y); y += yShift;
/*  83 */         g2d.drawString(" Total amount:               " + this.bill + "   ", 10, y); y += yShift;
/*  84 */         g2d.drawString("-------------------------------------", 10, y); y += yShift;
/*  85 */         g2d.drawString(" Cash      :                 " + this.amount + "   ", 10, y); y += yShift;
/*  86 */         g2d.drawString("-------------------------------------", 10, y); y += yShift;
/*  87 */         g2d.drawString(" Balance   :                 " + (this.amount - this.bill) + "   ", 10, y); y += yShift;
/*     */         
/*  89 */         g2d.drawString("*************************************", 10, y); y += yShift;
/*  90 */         g2d.drawString("       THANK YOU COME AGAIN            ", 10, y); y += yShift;
/*  91 */         g2d.drawString("*************************************", 10, y); y += yShift;
/*  92 */         g2d.setFont(new Font("Monospaced", 0, 6));
/*  93 */         g2d.drawString("SOFTWARE BY:Jawad Khan", 62, y); y += yShift;
/*  94 */         g2d.drawString("CONTACT: +92-306-6364644       ", 59, y);
/*     */       }
/*  96 */       catch (NumberFormatException e) {
/*  97 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 100 */       result = 0;
/*     */     } 
/* 102 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\PrintBill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */