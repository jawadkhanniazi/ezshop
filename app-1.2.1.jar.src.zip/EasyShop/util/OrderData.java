/*    */ package EasyShop.util;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrderData
/*    */ {
/*    */   public String orderId;
/*    */   public String productname;
/*    */   public String price;
/*    */   public String orderP;
/*    */   public String quantity;
/*    */   public String shopid;
/*    */   public String ordercomplete;
/*    */   public String sizeoforder;
/*    */   public String pid;
/*    */   public boolean hasMore;
/* 19 */   public LinkedList<OrderData> nextOrders = new LinkedList<>();
/* 20 */   public LinkedList<String> orderIDs = new LinkedList<>();
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 25 */     return "orderData{\n\torderId=" + this.orderId + ", \n\tproductname=" + this.productname + ", \n\tTotalPrice=" + this.price + ", \n\tquantity=" + this.quantity + ", \n\tshopId=" + this.shopid + ", \n\tordercomplete=" + this.ordercomplete + ", \n\tsizeoforder=" + this.sizeoforder + ", \n\thasMore=" + this.hasMore + ", \n\tnextOrder=" + this.nextOrders.toString() + "}\n\n";
/*    */   }
/*    */   
/*    */   public String getOrderP() {
/* 29 */     return this.orderP;
/*    */   }
/*    */   
/*    */   public void setOrderP(String orderP) {
/* 33 */     this.orderP = orderP;
/*    */   }
/*    */   
/*    */   public OrderData() {}
/*    */   
/*    */   public OrderData(String orderId, String productname, String pid, String TotalPrice, String quant, String shopId, String size) {
/* 39 */     this.orderId = orderId;
/* 40 */     this.productname = productname;
/* 41 */     this.price = TotalPrice;
/* 42 */     this.quantity = quant;
/* 43 */     this.shopid = shopId;
/* 44 */     this.ordercomplete = "0";
/* 45 */     this.sizeoforder = size;
/* 46 */     this.pid = pid;
/*    */   }
/*    */   public String getOrderId() {
/* 49 */     return this.orderId;
/*    */   }
/*    */   public String getProductname() {
/* 52 */     return this.productname;
/*    */   }
/*    */   public String getPrice() {
/* 55 */     return this.price;
/*    */   }
/*    */   public String getQuantity() {
/* 58 */     return this.quantity;
/*    */   }
/*    */   public String getShopid() {
/* 61 */     return this.shopid;
/*    */   }
/*    */   public String getOrdercomplete() {
/* 64 */     return this.ordercomplete;
/*    */   }
/*    */   public String getSizeoforder() {
/* 67 */     return this.sizeoforder;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\OrderData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */