/*    */ package EasyShop.util;
/*    */ 
/*    */ import com.google.firebase.database.DataSnapshot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubCatData
/*    */ {
/*    */   String id;
/*    */   String category_id;
/*    */   String description;
/*    */   String imageId;
/* 19 */   String imgURL = "https://firebasestorage.googleapis.com/v0/b/easyshop-fe4c7.appspot.com/o/Images%2Fezimg.png?alt=media&token=d05b165c-4c6c-48ea-97db-349109902621";
/*    */   String name;
/*    */   String shopid;
/* 22 */   String showinapp = "1";
/*    */   
/*    */   public SubCatData(DataSnapshot d) {
/* 25 */     System.out.println("Into ds");
/* 26 */     this.id = d.child("id").getValue().toString();
/* 27 */     this.category_id = d.child("category_id").getValue().toString();
/* 28 */     this.description = d.child("description").getValue().toString();
/* 29 */     this.imageId = d.child("imageId").getValue().toString();
/* 30 */     this.imgURL = d.child("imgURL").getValue().toString();
/* 31 */     this.name = d.child("name").getValue().toString();
/* 32 */     this.shopid = d.child("shopid").getValue().toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public SubCatData() {}
/*    */ 
/*    */   
/*    */   public SubCatData(String id, String category_id, String description, String imageId, String name, String shopid, String imgURL) {
/* 40 */     this.id = id;
/* 41 */     this.category_id = category_id;
/* 42 */     this.description = description;
/* 43 */     this.imageId = imageId;
/* 44 */     this.name = name;
/* 45 */     this.shopid = shopid;
/* 46 */     if (!imgURL.isEmpty()) {
/* 47 */       this.imgURL = imgURL;
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString() {
/* 52 */     return "SubCatData{\nid=" + this.id + ", \ncategory_id=" + this.category_id + ", \ndescription=" + this.description + ", \nimageId=" + this.imageId + ", \nimgURL=" + this.imgURL + ", \nname=" + this.name + ", \nshopid=" + this.shopid + '}';
/*    */   }
/*    */   
/*    */   public void setShopid(String shopid) {
/* 56 */     this.shopid = shopid;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 60 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(String id) {
/* 64 */     this.id = id;
/*    */   }
/*    */   public void setcatId(String id) {
/* 67 */     this.category_id = id;
/*    */   }
/*    */   
/*    */   public String getCategory_id() {
/* 71 */     return this.category_id;
/*    */   }
/*    */   
/*    */   public String getDescription() {
/* 75 */     return this.description;
/*    */   }
/*    */   
/*    */   public String getImageId() {
/* 79 */     return this.imageId;
/*    */   }
/*    */   
/*    */   public String getImgURL() {
/* 83 */     return this.imgURL;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 87 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getShopid() {
/* 91 */     return this.shopid;
/*    */   }
/*    */   
/*    */   public String getShowinapp() {
/* 95 */     return this.showinapp;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\SubCatData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */