/*    */ package EasyShop.util;
/*    */ 
/*    */ import com.google.firebase.database.DataSnapshot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ShopData
/*    */ {
/*    */   private String address;
/*    */   private String bikerID;
/*    */   private String bikerSubId;
/*    */   private String name;
/*    */   private String ownerId;
/*    */   private String subscriptionId;
/*    */   
/*    */   public ShopData(DataSnapshot d) {
/* 23 */     this.address = d.child("address").getValue().toString();
/* 24 */     this.bikerID = d.child("address").getValue().toString();
/* 25 */     this.bikerSubId = d.child("address").getValue().toString();
/* 26 */     this.name = d.child("address").getValue().toString();
/* 27 */     this.ownerId = d.child("address").getValue().toString();
/* 28 */     this.subscriptionId = d.child("address").getValue().toString();
/*    */   }
/*    */   
/*    */   public String getAddress() {
/* 32 */     return this.address;
/*    */   }
/*    */   
/*    */   public String getBikerID() {
/* 36 */     return this.bikerID;
/*    */   }
/*    */   
/*    */   public String getBikerSubId() {
/* 40 */     return this.bikerSubId;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 44 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getOwnerId() {
/* 48 */     return this.ownerId;
/*    */   }
/*    */   
/*    */   public String getSubscriptionId() {
/* 52 */     return this.subscriptionId;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\ShopData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */