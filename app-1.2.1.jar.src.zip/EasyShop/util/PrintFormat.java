/*    */ package EasyShop.util;
/*    */ 
/*    */ import java.awt.print.PageFormat;
/*    */ import java.awt.print.Paper;
/*    */ import java.awt.print.PrinterJob;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrintFormat
/*    */ {
/*    */   public PageFormat getPageFormat(PrinterJob pj) {
/* 18 */     PageFormat pf = pj.defaultPage();
/* 19 */     Paper paper = pf.getPaper();
/*    */     
/* 21 */     double bodyHeight = 1.0D;
/* 22 */     double headerHeight = 5.0D;
/* 23 */     double footerHeight = 5.0D;
/* 24 */     double width = cm_to_pp(14.0D);
/* 25 */     double height = cm_to_pp(headerHeight + bodyHeight + footerHeight);
/* 26 */     paper.setSize(width, height);
/* 27 */     paper.setImageableArea(0.0D, 10.0D, width, height - cm_to_pp(1.0D));
/*    */     
/* 29 */     pf.setOrientation(1);
/* 30 */     pf.setPaper(paper);
/*    */     
/* 32 */     return pf;
/*    */   }
/*    */   
/*    */   protected static double cm_to_pp(double cm) {
/* 36 */     return toPPI(cm * 0.393600787D);
/*    */   }
/*    */ 
/*    */   
/*    */   protected static double toPPI(double inch) {
/* 41 */     return inch * 72.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\PrintFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */