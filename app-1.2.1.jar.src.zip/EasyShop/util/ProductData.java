/*     */ package EasyShop.util;
/*     */ 
/*     */ import com.google.firebase.database.DataSnapshot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProductData
/*     */ {
/*     */   private String name;
/*     */   private String barcode;
/*     */   private String cat_id;
/*     */   private String id;
/*     */   private String companyName;
/*     */   private String sub_category_id;
/*     */   private String shop_id;
/*     */   private String size;
/*     */   private int quantity;
/*     */   private String price;
/*     */   private String salesprice;
/*  26 */   private String soldItems = "0";
/*  27 */   private String showinapp = "1";
/*  28 */   private String imgURL = "https://firebasestorage.googleapis.com/v0/b/easyshop-fe4c7.appspot.com/o/Images%2Fezimg.png?alt=media&token=d05b165c-4c6c-48ea-97db-349109902621";
/*  29 */   private String imgid = "";
/*     */ 
/*     */   
/*     */   public ProductData(String name, String barcode, String cat_id, String id, String companyName, String shop_id, int quantity, String price, String salesPrice, String sub_catagory_id, String imgid, String url, String si, String size) {
/*  33 */     this.soldItems = si;
/*  34 */     this.name = name;
/*  35 */     this.salesprice = salesPrice;
/*  36 */     this.barcode = barcode;
/*  37 */     this.cat_id = cat_id;
/*  38 */     this.id = id;
/*  39 */     this.companyName = companyName;
/*  40 */     this.shop_id = shop_id;
/*  41 */     this.quantity = quantity;
/*  42 */     this.price = price;
/*  43 */     this.sub_category_id = sub_catagory_id;
/*  44 */     this.imgid = imgid;
/*  45 */     this.size = size;
/*  46 */     if (!url.isEmpty()) {
/*  47 */       this.imgURL = url;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ProductData() {}
/*     */   
/*     */   public String getImgURL() {
/*  55 */     return this.imgURL;
/*     */   }
/*     */   
/*     */   public String getImgid() {
/*  59 */     return this.imgid;
/*     */   }
/*     */   
/*     */   public ProductData(DataSnapshot d) {
/*  63 */     this.id = d.child("id").getValue().toString();
/*  64 */     this.name = d.child("name").getValue().toString();
/*  65 */     this.barcode = d.child("barcode").getValue().toString();
/*  66 */     this.cat_id = d.child("cat_id").getValue().toString();
/*  67 */     this.sub_category_id = d.child("sub_category_id").getValue().toString();
/*  68 */     this.shop_id = d.child("shop_id").getValue().toString();
/*  69 */     this.price = d.child("price").getValue().toString();
/*  70 */     this.salesprice = d.child("salesprice").getValue().toString();
/*  71 */     this.quantity = Integer.parseInt(d.child("quantity").getValue().toString());
/*     */   }
/*     */   
/*     */   public String getSoldItems() {
/*  75 */     return this.soldItems;
/*     */   }
/*     */   
/*     */   public String getSalesprice() {
/*  79 */     return this.salesprice;
/*     */   }
/*     */   
/*     */   public String getId() {
/*  83 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getSize() {
/*  87 */     return this.size;
/*     */   }
/*     */   
/*     */   public void setSize(String size) {
/*  91 */     this.size = size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     return "ProductData{\nname=" + this.name + ", \ncat_id=" + this.cat_id + ", \nid=" + this.id + ", \nsub_category_id=" + this.sub_category_id + ", \nshop_id=" + this.shop_id + '}';
/*     */   }
/*     */   
/*     */   public String getCompanyName() {
/* 102 */     return this.companyName;
/*     */   }
/*     */   
/*     */   public String getSub_category_id() {
/* 106 */     return this.sub_category_id;
/*     */   }
/*     */   
/*     */   public String getShowinapp() {
/* 110 */     return this.showinapp;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 114 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getBarcode() {
/* 118 */     return this.barcode;
/*     */   }
/*     */   
/*     */   public String getCat_id() {
/* 122 */     return this.cat_id;
/*     */   }
/*     */   
/*     */   public String getShop_id() {
/* 126 */     return this.shop_id;
/*     */   }
/*     */   
/*     */   public int getQuantity() {
/* 130 */     return this.quantity;
/*     */   }
/*     */   
/*     */   public String getPrice() {
/* 134 */     return this.price;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\ProductData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */