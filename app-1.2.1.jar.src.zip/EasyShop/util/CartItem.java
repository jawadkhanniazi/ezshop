/*     */ package EasyShop.util;
/*     */ 
/*     */ import com.google.firebase.database.DataSnapshot;
/*     */ import com.google.firebase.database.DatabaseError;
/*     */ import com.google.firebase.database.DatabaseReference;
/*     */ import com.google.firebase.database.FirebaseDatabase;
/*     */ import com.google.firebase.database.ValueEventListener;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.TextField;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.LinkedList;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CartItem
/*     */ {
/*     */   private TextField f;
/*     */   private JLabel prod1_img;
/*     */   private JLabel prod1_lbl;
/*     */   private JTextField prod1_count;
/*     */   private JLabel prod1_x;
/*     */   private JLabel prod2_img;
/*     */   private JLabel prod2_lbl;
/*     */   private JTextField prod2_count;
/*     */   private JLabel prod2_x;
/*     */   private JLabel prod3_img;
/*     */   private JLabel prod3_lbl;
/*     */   private JTextField prod3_count;
/*     */   private JLabel prod3_x;
/*     */   private JLabel prod8_img;
/*     */   private JLabel prod8_lbl;
/*     */   private JTextField prod8_count;
/*     */   private JLabel prod8_x;
/*     */   private JLabel prod4_img;
/*     */   private JLabel prod4_lbl;
/*     */   private JTextField prod4_count;
/*     */   private JLabel prod4_x;
/*     */   private JLabel prod5_img;
/*     */   private JLabel prod5_lbl;
/*     */   private JTextField prod5_count;
/*     */   private JLabel prod5_x;
/*     */   private JLabel prod6_img;
/*     */   private JLabel prod6_lbl;
/*     */   private JTextField prod6_count;
/*     */   private JLabel prod6_x;
/*     */   private JLabel prod7_img;
/*     */   private JLabel prod7_lbl;
/*     */   private JTextField prod7_count;
/*     */   private JLabel prod7_x;
/*     */   private boolean isout = false;
/*  68 */   private int showCountg = 0;
/*     */   
/*     */   private Connection con;
/*     */   
/*  72 */   private LinkedList<cartData> allProducts = new LinkedList<>();
/*     */   public LinkedList<cartData> getAllProds() {
/*  74 */     return this.allProducts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CartItem(Connection c, TextField f, JLabel prod1_img, JLabel prod1_lbl, JTextField prod1_count, JLabel prod1_x, JLabel prod2_img, JLabel prod2_lbl, JTextField prod2_count, JLabel prod2_x, JLabel prod3_img, JLabel prod3_lbl, JTextField prod3_count, JLabel prod3_x, JLabel prod8_img, JLabel prod8_lbl, JTextField prod8_count, JLabel prod8_x, JLabel prod4_img, JLabel prod4_lbl, JTextField prod4_count, JLabel prod4_x, JLabel prod5_img, JLabel prod5_lbl, JTextField prod5_count, JLabel prod5_x, JLabel prod6_img, JLabel prod6_lbl, JTextField prod6_count, JLabel prod6_x, JLabel prod7_img, JLabel prod7_lbl, JTextField prod7_count, JLabel prod7_x) {
/*  84 */     this.con = c;
/*     */     
/*  86 */     this.f = f;
/*  87 */     this.prod1_img = prod1_img;
/*  88 */     this.prod1_lbl = prod1_lbl;
/*  89 */     this.prod1_count = prod1_count;
/*  90 */     this.prod1_x = prod1_x;
/*  91 */     this.prod2_img = prod2_img;
/*  92 */     this.prod2_lbl = prod2_lbl;
/*  93 */     this.prod2_count = prod2_count;
/*  94 */     this.prod2_x = prod2_x;
/*  95 */     this.prod3_img = prod3_img;
/*  96 */     this.prod3_lbl = prod3_lbl;
/*  97 */     this.prod3_count = prod3_count;
/*  98 */     this.prod3_x = prod3_x;
/*  99 */     this.prod8_img = prod8_img;
/* 100 */     this.prod8_lbl = prod8_lbl;
/* 101 */     this.prod8_count = prod8_count;
/* 102 */     this.prod8_x = prod8_x;
/* 103 */     this.prod4_img = prod4_img;
/* 104 */     this.prod4_lbl = prod4_lbl;
/* 105 */     this.prod4_count = prod4_count;
/* 106 */     this.prod4_x = prod4_x;
/* 107 */     this.prod5_img = prod5_img;
/* 108 */     this.prod5_lbl = prod5_lbl;
/* 109 */     this.prod5_count = prod5_count;
/* 110 */     this.prod5_x = prod5_x;
/* 111 */     this.prod6_img = prod6_img;
/* 112 */     this.prod6_lbl = prod6_lbl;
/* 113 */     this.prod6_count = prod6_count;
/* 114 */     this.prod6_x = prod6_x;
/* 115 */     this.prod7_img = prod7_img;
/* 116 */     this.prod7_lbl = prod7_lbl;
/* 117 */     this.prod7_count = prod7_count;
/* 118 */     this.prod7_x = prod7_x;
/*     */   }
/*     */   public CartItem() {
/* 121 */     Common.initFirebase();
/*     */   }
/*     */   
/*     */   public LinkedList<cartData> getItems() {
/* 125 */     return this.allProducts;
/*     */   }
/*     */   
/*     */   public void clearAllItems() {
/* 129 */     this.allProducts.clear();
/*     */   }
/*     */   
/*     */   public void updateCount(int val, int index) {
/* 133 */     cartData d = this.allProducts.get(index);
/* 134 */     d.setCount(val);
/* 135 */     this.allProducts.remove(index);
/* 136 */     this.allProducts.add(index, d);
/*     */   }
/*     */ 
/*     */   
/*     */   public void retriveProductbarcode(String barcode) {
/* 141 */     int count = 0;
/*     */     try {
/* 143 */       PreparedStatement ps = this.con.prepareStatement("Select * from cartInfo where barcode = '" + barcode + "'");
/* 144 */       ResultSet rs = ps.executeQuery();
/* 145 */       if (rs.next()) {
/* 146 */         count = rs.getInt(5);
/*     */       }
/* 148 */     } catch (SQLException sQLException) {}
/*     */ 
/*     */     
/* 151 */     int val = checkExisting(barcode, count);
/* 152 */     switch (val) {
/*     */       case 0:
/* 154 */         this.f.setText("");
/*     */         return;
/*     */       case -1:
/* 157 */         JOptionPane.showMessageDialog(null, "Max limit is 8 items");
/* 158 */         this.f.setText("");
/*     */         return;
/*     */     } 
/*     */     try {
/* 162 */       PreparedStatement ps = this.con.prepareStatement("Select * from cartInfo where barcode = '" + barcode + "'");
/* 163 */       ResultSet rs = ps.executeQuery();
/* 164 */       if (rs.next()) {
/* 165 */         count = rs.getInt(5);
/* 166 */         if (count > 0) {
/* 167 */           parseNShow(val, 0, rs, barcode);
/*     */         } else {
/* 169 */           JOptionPane.showMessageDialog(null, "No more Products Available");
/*     */         } 
/*     */       } else {
/*     */         
/* 173 */         JOptionPane.showMessageDialog(null, "Product not found Add to inventory first");
/* 174 */         this.f.setText("");
/* 175 */         this.f.requestFocus();
/*     */       } 
/* 177 */     } catch (SQLException ex) {
/* 178 */       JOptionPane.showMessageDialog(null, "Error while adding to the cart.\nRestart the app.");
/* 179 */       System.out.println("ERROR while adding item to cart");
/* 180 */       System.out.println("Error code " + ex.getErrorCode());
/* 181 */       System.out.println("Error cause " + ex.getCause());
/* 182 */       System.out.println("Error detatis " + ex.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int checkExisting(String barcode, int count) {
/* 189 */     if (this.prod1_img.isVisible()) {
/* 190 */       cartData d = this.allProducts.get(0);
/* 191 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 192 */         if (d.getCount() < count) {
/* 193 */           d.count++;
/* 194 */           this.allProducts.remove(0);
/* 195 */           this.allProducts.add(0, d);
/* 196 */           this.prod1_count.setText("" + d.count);
/*     */         } else {
/* 198 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 200 */         return 0;
/*     */       } 
/*     */     } else {
/* 203 */       return 1;
/*     */     } 
/*     */     
/* 206 */     if (this.prod2_img.isVisible()) {
/* 207 */       cartData d = this.allProducts.get(1);
/* 208 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 209 */         if (d.getCount() < count) {
/* 210 */           d.count++;
/* 211 */           this.allProducts.remove(1);
/* 212 */           this.allProducts.add(1, d);
/* 213 */           this.prod2_count.setText("" + d.count);
/*     */         } else {
/* 215 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 217 */         return 0;
/*     */       } 
/*     */     } else {
/* 220 */       return 2;
/*     */     } 
/*     */     
/* 223 */     if (this.prod3_img.isVisible()) {
/* 224 */       cartData d = this.allProducts.get(2);
/* 225 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 226 */         if (d.getCount() < count) {
/* 227 */           d.count++;
/* 228 */           this.allProducts.remove(2);
/* 229 */           this.allProducts.add(2, d);
/* 230 */           this.prod3_count.setText("" + d.count);
/*     */         } else {
/* 232 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 234 */         return 0;
/*     */       } 
/*     */     } else {
/* 237 */       return 3;
/*     */     } 
/* 239 */     if (this.prod4_img.isVisible()) {
/* 240 */       cartData d = this.allProducts.get(3);
/* 241 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 242 */         if (d.getCount() < count) {
/* 243 */           d.count++;
/* 244 */           this.allProducts.remove(3);
/* 245 */           this.allProducts.add(3, d);
/* 246 */           this.prod4_count.setText("" + d.count);
/*     */         } else {
/* 248 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 250 */         return 0;
/*     */       } 
/*     */     } else {
/* 253 */       return 4;
/*     */     } 
/* 255 */     if (this.prod5_img.isVisible()) {
/* 256 */       cartData d = this.allProducts.get(4);
/* 257 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 258 */         if (d.getCount() < count) {
/* 259 */           d.count++;
/* 260 */           this.allProducts.remove(4);
/* 261 */           this.allProducts.add(4, d);
/* 262 */           this.prod5_count.setText("" + d.count);
/*     */         } else {
/* 264 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 266 */         return 0;
/*     */       } 
/*     */     } else {
/* 269 */       return 5;
/*     */     } 
/* 271 */     if (this.prod6_img.isVisible()) {
/* 272 */       cartData d = this.allProducts.get(5);
/* 273 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 274 */         if (d.getCount() < count) {
/* 275 */           d.count++;
/* 276 */           this.allProducts.remove(5);
/* 277 */           this.allProducts.add(5, d);
/* 278 */           this.prod6_count.setText("" + d.count);
/*     */         } else {
/* 280 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 282 */         return 0;
/*     */       } 
/*     */     } else {
/* 285 */       return 6;
/*     */     } 
/* 287 */     if (this.prod7_img.isVisible()) {
/* 288 */       cartData d = this.allProducts.get(6);
/* 289 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 290 */         if (d.getCount() < count) {
/* 291 */           d.count++;
/* 292 */           this.allProducts.remove(6);
/* 293 */           this.allProducts.add(6, d);
/* 294 */           this.prod7_count.setText("" + d.count);
/*     */         } else {
/* 296 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 298 */         return 0;
/*     */       } 
/*     */     } else {
/* 301 */       return 7;
/*     */     } 
/* 303 */     if (this.prod8_img.isVisible()) {
/* 304 */       cartData d = this.allProducts.get(7);
/* 305 */       if (d.barcode.toLowerCase().equals(barcode.toLowerCase())) {
/* 306 */         if (d.getCount() < count) {
/* 307 */           d.count++;
/* 308 */           this.allProducts.remove(7);
/* 309 */           this.allProducts.add(7, d);
/* 310 */           this.prod8_count.setText("" + d.count);
/*     */         } else {
/* 312 */           JOptionPane.showMessageDialog(null, "No more products Exist");
/*     */         } 
/* 314 */         return 0;
/*     */       } 
/*     */     } else {
/* 317 */       return 8;
/*     */     } 
/* 319 */     return -1;
/*     */   }
/*     */   
/*     */   private void parseNShow(int id, int mode, ResultSet rs, String barcode) {
/* 323 */     switch (id) {
/*     */       case 1:
/* 325 */         update(id, barcode, mode, rs, this.prod1_lbl, this.prod1_count, this.prod1_img, this.prod1_x);
/*     */         break;
/*     */       case 2:
/* 328 */         update(id, barcode, mode, rs, this.prod2_lbl, this.prod2_count, this.prod2_img, this.prod2_x);
/*     */         break;
/*     */       case 3:
/* 331 */         update(id, barcode, mode, rs, this.prod3_lbl, this.prod3_count, this.prod3_img, this.prod3_x);
/*     */         break;
/*     */       case 4:
/* 334 */         update(id, barcode, mode, rs, this.prod4_lbl, this.prod4_count, this.prod4_img, this.prod4_x);
/*     */         break;
/*     */       case 5:
/* 337 */         update(id, barcode, mode, rs, this.prod5_lbl, this.prod5_count, this.prod5_img, this.prod5_x);
/*     */         break;
/*     */       case 6:
/* 340 */         update(id, barcode, mode, rs, this.prod6_lbl, this.prod6_count, this.prod6_img, this.prod6_x);
/*     */         break;
/*     */       case 7:
/* 343 */         update(id, barcode, mode, rs, this.prod7_lbl, this.prod7_count, this.prod7_img, this.prod7_x);
/*     */         break;
/*     */       case 8:
/* 346 */         update(id, barcode, mode, rs, this.prod8_lbl, this.prod8_count, this.prod8_img, this.prod8_x);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void update(int id, String barcode, int mode, ResultSet rs, JLabel prod_lbl, JTextField prod_count, JLabel prod_img, JLabel prod_x) {
/*     */     cartData data;
/* 354 */     switch (barcode) {
/*     */       case "remove 1":
/* 356 */         data = this.allProducts.get(id - 1);
/* 357 */         data.count--;
/* 358 */         if (data.count > 0) {
/* 359 */           this.allProducts.remove(id - 1);
/* 360 */           this.allProducts.add(id - 1, data);
/* 361 */           prod_count.setText("" + data.count);
/*     */         } else {
/* 363 */           completRemove(id);
/*     */         } 
/*     */         return;
/*     */       case "remove All":
/* 367 */         completRemove(id);
/*     */         return;
/*     */     } 
/* 370 */     if (mode == 0) {
/* 371 */       updateView(rs, barcode, prod_lbl, prod_count, prod_img, prod_x);
/*     */     } else {
/* 373 */       updateViewOnline(barcode, prod_lbl, prod_count, prod_img, prod_x);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateView(ResultSet rs, String barcode, JLabel name, JTextField count, JLabel img, JLabel x) {
/*     */     
/* 380 */     try { cartData data = new cartData();
/* 381 */       data.barcode = rs.getString(1);
/* 382 */       data.unitPrice = rs.getString(2);
/* 383 */       data.name = rs.getString(3);
/* 384 */       data.count = 1;
/* 385 */       PreparedStatement ps = this.con.prepareStatement("select img from imageTable where cartID='" + rs.getString(4) + "'");
/* 386 */       ResultSet r = ps.executeQuery();
/* 387 */       if (r.next())
/* 388 */       { if ((new File("bin/Icons/" + r.getString(1))).exists()) {
/* 389 */           data.icon = new ImageIcon("bin/Icons/" + r.getString(1));
/*     */         } else {
/* 391 */           data.icon = new ImageIcon("bin/Icons/imgnotfound.jpg");
/*     */         }  }
/* 393 */       else { data.icon = new ImageIcon("bin/Icons/imgnotfound.jpg"); }
/*     */       
/* 395 */       this.allProducts.add(data);
/* 396 */       name.setText(data.name);
/* 397 */       count.setText("" + data.count);
/* 398 */       img.setIcon(data.icon);
/* 399 */       name.setVisible(true);
/* 400 */       count.setVisible(true);
/* 401 */       img.setVisible(true);
/* 402 */       x.setVisible(true);
/* 403 */       this.f.setText(""); }
/* 404 */     catch (SQLException sQLException) {  }
/* 405 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateViewOnline(final String barcode, final JLabel name, final JTextField count, final JLabel img, final JLabel x) {
/* 410 */     final cartData data = new cartData();
/* 411 */     FirebaseDatabase db = FirebaseDatabase.getInstance();
/* 412 */     DatabaseReference ref = db.getReference("ProductsItems");
/* 413 */     ref.addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/* 416 */             for (DataSnapshot d : ds.getChildren()) {
/* 417 */               if (barcode.toLowerCase().equals(d.child("barcode").getValue().toString().toLowerCase())) {
/* 418 */                 data.barcode = barcode;
/* 419 */                 data.name = d.child("name").getValue().toString();
/* 420 */                 name.setText(d.child("name").getValue().toString());
/* 421 */                 name.setVisible(true);
/* 422 */                 data.count = 1;
/* 423 */                 count.setText("1");
/* 424 */                 count.setVisible(true);
/* 425 */                 x.setVisible(true);
/* 426 */                 CartItem.this.retriveCatImage(d.child("cat_id").getValue().toString(), img, x, data);
/*     */                 break;
/*     */               } 
/*     */             } 
/* 430 */             CartItem.this.allProducts.add(data);
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 436 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void retriveCatImage(String ID, final JLabel img, final JLabel x, final cartData data) {
/* 442 */     FirebaseDatabase db = FirebaseDatabase.getInstance();
/* 443 */     DatabaseReference ref = db.getReference("CategoryItems/" + ID);
/* 444 */     ref.addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/*     */             
/* 448 */             try { URL url = new URL(ds.child("imgURL").getValue().toString());
/* 449 */               BufferedImage image = ImageIO.read(url);
/* 450 */               Image dimg = image.getScaledInstance(145, 150, 4);
/* 451 */               data.icon = new ImageIcon(dimg);
/* 452 */               CartItem.this.allProducts.add(data);
/* 453 */               img.setIcon(new ImageIcon(dimg));
/* 454 */               img.setVisible(true);
/* 455 */               x.setVisible(true);
/* 456 */               CartItem.this.f.setText("");
/* 457 */               Toolkit.getDefaultToolkit().beep(); }
/* 458 */             catch (MalformedURLException malformedURLException) {  }
/* 459 */             catch (IOException ex)
/* 460 */             { data.icon = new ImageIcon("bin/Icons/sale.png");
/* 461 */               img.setIcon(new ImageIcon("bin/Icons/sale.png"));
/* 462 */               img.setVisible(true);
/* 463 */               x.setVisible(true);
/* 464 */               CartItem.this.f.setText("");
/* 465 */               Toolkit.getDefaultToolkit().beep(); }
/* 466 */             catch (Exception exception) {}
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 473 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public void show_hide(int cardtid, boolean state) {
/* 479 */     switch (cardtid) {
/*     */       case 1:
/* 481 */         toggleCart1(state, this.prod1_img, this.prod1_lbl, this.prod1_count, this.prod1_x);
/*     */         break;
/*     */       case 2:
/* 484 */         toggleCart1(state, this.prod2_img, this.prod2_lbl, this.prod2_count, this.prod2_x);
/*     */         break;
/*     */       case 3:
/* 487 */         toggleCart1(state, this.prod3_img, this.prod3_lbl, this.prod3_count, this.prod3_x);
/*     */         break;
/*     */       case 4:
/* 490 */         toggleCart1(state, this.prod4_img, this.prod4_lbl, this.prod4_count, this.prod4_x);
/*     */         break;
/*     */       case 5:
/* 493 */         toggleCart1(state, this.prod5_img, this.prod5_lbl, this.prod5_count, this.prod5_x);
/*     */         break;
/*     */       case 6:
/* 496 */         toggleCart1(state, this.prod6_img, this.prod6_lbl, this.prod6_count, this.prod6_x);
/*     */         break;
/*     */       case 7:
/* 499 */         toggleCart1(state, this.prod7_img, this.prod7_lbl, this.prod7_count, this.prod7_x);
/*     */         break;
/*     */       case 8:
/* 502 */         toggleCart1(state, this.prod8_img, this.prod8_lbl, this.prod8_count, this.prod8_x);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void toggleCart1(boolean state, JLabel cart_prod, JLabel cartLabel, JTextField cartcount, JLabel cartx) {
/* 508 */     cart_prod.setVisible(state);
/* 509 */     cartLabel.setVisible(state);
/* 510 */     cartcount.setVisible(state);
/* 511 */     cartx.setVisible(state);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeItem(int id) {
/* 517 */     Object[] options = { "Reduce by one", "Remove All", "Cancle" };
/*     */ 
/*     */     
/* 520 */     int n = JOptionPane.showOptionDialog(null, "How many items to remove ?", "", 1, 3, null, options, options[2]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 528 */     if (n != 2) {
/* 529 */       String option = (n == 0) ? "remove 1" : "remove All";
/* 530 */       ResultSet r = null;
/* 531 */       parseNShow(id, -1, r, option);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void completRemove(int id) {
/* 536 */     this.allProducts.remove(id - 1);
/* 537 */     for (int i = 0; i < 8; i++) {
/* 538 */       if (i < this.allProducts.size()) {
/* 539 */         moveNext(this.allProducts.get(i), i + 1);
/*     */       } else {
/* 541 */         show_hide(i + 1, false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void moveNext(cartData d, int id) {
/* 548 */     switch (id) {
/*     */       case 1:
/* 550 */         draw(this.prod1_lbl, this.prod1_count, this.prod1_img, this.prod1_x, d);
/*     */         break;
/*     */       case 2:
/* 553 */         draw(this.prod2_lbl, this.prod2_count, this.prod2_img, this.prod2_x, d);
/*     */         break;
/*     */       case 3:
/* 556 */         draw(this.prod3_lbl, this.prod3_count, this.prod3_img, this.prod3_x, d);
/*     */         break;
/*     */       case 4:
/* 559 */         draw(this.prod4_lbl, this.prod4_count, this.prod4_img, this.prod4_x, d);
/*     */         break;
/*     */       case 5:
/* 562 */         draw(this.prod5_lbl, this.prod5_count, this.prod5_img, this.prod5_x, d);
/*     */         break;
/*     */       case 6:
/* 565 */         draw(this.prod6_lbl, this.prod6_count, this.prod6_img, this.prod6_x, d);
/*     */         break;
/*     */       case 7:
/* 568 */         draw(this.prod7_lbl, this.prod7_count, this.prod7_img, this.prod7_x, d);
/*     */         break;
/*     */       case 8:
/* 571 */         draw(this.prod8_lbl, this.prod8_count, this.prod8_img, this.prod8_x, d);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void draw(JLabel prod_lbl, JTextField prod_count, JLabel prod_img, JLabel prod_x, cartData d) {
/* 580 */     prod_lbl.setText(d.name);
/* 581 */     prod_count.setText("" + d.count);
/* 582 */     prod_img.setIcon(d.icon);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void downloadProducts() {
/* 588 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
/* 589 */     ref.child("ProductsItems").addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/* 592 */             int i = 0;
/* 593 */             for (DataSnapshot d : ds.getChildren()) {
/*     */               try {
/* 595 */                 String unitprice = d.child("salesprice").getValue().toString();
/* 596 */                 String name = d.child("name").getValue().toString();
/* 597 */                 String barcode = d.child("barcode").getValue().toString();
/* 598 */                 String catid = d.child("cat_id").getValue().toString();
/* 599 */                 PreparedStatement p = CartItem.this.con.prepareStatement("insert OR replace into cartInfo VALUES('" + barcode + "','" + unitprice + "','" + name + "','" + catid + "');");
/*     */                 
/* 601 */                 p.execute();
/* 602 */                 p.close();
/* 603 */                 i++;
/* 604 */               } catch (SQLException sQLException) {}
/*     */             } 
/* 606 */             JOptionPane.showMessageDialog(null, "All Products Downloaded");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 612 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void downloadCats() {
/* 619 */     DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference();
/* 620 */     ref1.child("CategoryItems").addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/* 623 */             for (DataSnapshot d : ds.getChildren()) {
/*     */               try {
/* 625 */                 String img = d.child("imgid").getValue().toString();
/* 626 */                 String cat = d.getKey().toString();
/* 627 */                 String sql = "insert OR replace into imageTable VALUES('" + img + "','" + cat + "');";
/* 628 */                 PreparedStatement ps = CartItem.this.con.prepareStatement(sql);
/* 629 */                 ps.execute();
/* 630 */                 ps.close();
/* 631 */                 URL url = new URL(d.child("imgURL").getValue().toString());
/* 632 */                 BufferedImage image = ImageIO.read(url);
/* 633 */                 Image dimg = image.getScaledInstance(145, 150, 4);
/* 634 */                 String extension = "";
/* 635 */                 int i = img.lastIndexOf('.');
/* 636 */                 if (i > 0) {
/* 637 */                   extension = img.substring(i + 1);
/*     */                 }
/* 639 */                 ImageIO.write(CartItem.this.toBufferedImage(dimg), extension, new File("bin/" + d.child("imgid").getValue().toString()));
/* 640 */               } catch (SQLException ex) {
/* 641 */                 System.out.println("Download localDB Cat Exceptionn code = " + ex.getErrorCode());
/* 642 */                 System.out.println("Cause = " + ex.getCause());
/* 643 */                 System.out.println(ex.toString());
/* 644 */                 System.out.println(ex.getSQLState());
/* 645 */               } catch (MalformedURLException ex) {
/* 646 */                 System.out.println("Download localDB Error: URL Fault");
/* 647 */                 System.out.println(ex.getCause());
/* 648 */               } catch (IOException ex) {
/* 649 */                 System.out.println("Cart Error: IO EX");
/* 650 */                 System.out.println(ex.getCause());
/* 651 */                 System.out.println(ex.toString());
/*     */               } 
/* 653 */             }  JOptionPane.showMessageDialog(null, "All Cats Downloaded");
/*     */           }
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 657 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private BufferedImage toBufferedImage(Image img) {
/* 664 */     if (img instanceof BufferedImage)
/* 665 */       return (BufferedImage)img; 
/* 666 */     BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), 2);
/* 667 */     Graphics2D bGr = bimage.createGraphics();
/* 668 */     bGr.drawImage(img, 0, 0, (ImageObserver)null);
/* 669 */     bGr.dispose();
/* 670 */     return bimage;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\CartItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */