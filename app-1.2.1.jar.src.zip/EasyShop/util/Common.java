/*    */ package EasyShop.util;
/*    */ 
/*    */ import com.google.auth.oauth2.GoogleCredentials;
/*    */ import com.google.firebase.FirebaseApp;
/*    */ import com.google.firebase.FirebaseOptions;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ public class Common
/*    */ {
/*    */   public static void initFirebase() {
/* 16 */     FileInputStream refFile = null;
/*    */     try {
/* 18 */       refFile = new FileInputStream("bin/Creds/credentials.json");
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 23 */       FirebaseOptions options = (new FirebaseOptions.Builder()).setCredentials(GoogleCredentials.fromStream(refFile)).setDatabaseUrl("https://easyshop-fe4c7.firebaseio.com/").setStorageBucket("easyshop-fe4c7.appspot.com").build();
/* 24 */       FirebaseApp.initializeApp(options);
/* 25 */     } catch (FileNotFoundException ex) {
/* 26 */       System.out.println("initFirebase Error: Creds not Found");
/* 27 */     } catch (IOException ex) {
/* 28 */       System.out.println("initFirebase Error: IO Exception");
/*    */     } finally {
/*    */       try {
/* 31 */         refFile.close();
/* 32 */       } catch (IOException ex) {
/* 33 */         System.out.println("initFirebase Error: File Closing");
/* 34 */         Logger.getLogger(Common.class.getName()).log(Level.SEVERE, (String)null, ex);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasySho\\util\Common.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */