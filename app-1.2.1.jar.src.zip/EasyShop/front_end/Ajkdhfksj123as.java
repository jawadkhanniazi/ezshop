/*     */ package EasyShop.front_end;
/*     */ import EasyShop.util.PrintBill;
/*     */ import EasyShop.util.PrintFormat;
/*     */ import EasyShop.util.cartData;
/*     */ import com.google.firebase.database.DataSnapshot;
/*     */ import com.google.firebase.database.DatabaseError;
/*     */ import com.google.firebase.database.DatabaseReference;
/*     */ import com.google.firebase.database.FirebaseDatabase;
/*     */ import com.google.firebase.database.ValueEventListener;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.HeadlessException;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.awt.print.Printable;
/*     */ import java.awt.print.PrinterException;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.LinkedList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ 
/*     */ public class Ajkdhfksj123as extends JFrame {
/*  39 */   private LinkedList<cartData> det = new LinkedList<>(); private Connection con; private String shopId;
/*     */   private void init() {
/*  41 */     this.dsfjhkds.setVisible(false);
/*  42 */     this.dsfsjkd.setVisible(false);
/*  43 */     this.sdfhskjdh23.setVisible(false);
/*  44 */     this.akjh12hgc.setVisible(false);
/*  45 */     this.akjhds12.setVisible(false);
/*  46 */     this.n67sdf.setVisible(false);
/*  47 */     this.jskad12.setVisible(false);
/*  48 */     this.asdj12cx.setVisible(false);
/*  49 */     setDefaultCloseOperation(2);
/*     */   }
/*     */   private void jhty56fc(int index, cartData val) {
/*  52 */     int price = 0;
/*  53 */     switch (index) {
/*     */       case 0:
/*  55 */         this.pn1.setText(val.getName());
/*  56 */         this.q1.setText(val.getCount() + "x" + val.getUnitPrice());
/*  57 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/*  58 */         this.t1.setText("" + price);
/*  59 */         this.dsfjhkds.setVisible(true);
/*     */         break;
/*     */       case 1:
/*  62 */         this.pn2.setText(val.getName());
/*  63 */         this.q2.setText(val.getCount() + "x" + val.getUnitPrice());
/*  64 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/*  65 */         this.t2.setText("" + price);
/*  66 */         this.dsfsjkd.setVisible(true);
/*     */         break;
/*     */       case 2:
/*  69 */         this.pn3.setText(val.getName());
/*  70 */         this.q3.setText(val.getCount() + "x" + val.getUnitPrice());
/*  71 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/*  72 */         this.t3.setText("" + price);
/*  73 */         this.sdfhskjdh23.setVisible(true);
/*     */         break;
/*     */       case 3:
/*  76 */         this.pn4.setText(val.getName());
/*  77 */         this.q4.setText(val.getCount() + "x" + val.getUnitPrice());
/*  78 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/*  79 */         this.t4.setText("" + price);
/*  80 */         this.akjh12hgc.setVisible(true);
/*     */         break;
/*     */       case 4:
/*  83 */         this.pn5.setText(val.getName());
/*  84 */         this.q5.setText(val.getCount() + "x" + val.getUnitPrice());
/*  85 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/*  86 */         this.t5.setText("" + price);
/*  87 */         this.akjhds12.setVisible(true);
/*     */         break;
/*     */       case 5:
/*  90 */         this.pn6.setText(val.getName());
/*  91 */         this.q6.setText(val.getCount() + "x" + val.getUnitPrice());
/*  92 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/*  93 */         this.t6.setText("" + price);
/*  94 */         this.n67sdf.setVisible(true);
/*     */         break;
/*     */       case 6:
/*  97 */         this.pn7.setText(val.getName());
/*  98 */         this.q7.setText(val.getCount() + "x" + val.getUnitPrice());
/*  99 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/* 100 */         this.t7.setText("" + price);
/* 101 */         this.jskad12.setVisible(true);
/*     */         break;
/*     */       case 7:
/* 104 */         this.pn8.setText(val.getName());
/* 105 */         this.q8.setText(val.getCount() + "x" + val.getUnitPrice());
/* 106 */         price = val.getCount() * Integer.parseInt(val.getUnitPrice());
/* 107 */         this.t8.setText("" + price);
/* 108 */         this.asdj12cx.setVisible(true);
/*     */         break;
/*     */     } 
/* 111 */     price += Integer.parseInt(this.Gtotal.getText());
/* 112 */     this.Gtotal.setText("" + price);
/*     */   }
/*     */ 
/*     */   
/* 116 */   private int xMouse = 0; private JLabel Gtotal; private JLabel X; private JPanel akjh12hgc; private JPanel akjhds12; private JPanel asdj12cx; private JPanel djkfsh3e; private JButton djskfhs12jkhkds; private JPanel dsfjhkds; private JPanel dsfsjkd; private JLabel jLabel1; private JLabel jLabel2; private JLabel jLabel3;
/* 117 */   private int yMouse = 0; private JLabel jLabel4; private JButton jkdfhs; private JPanel jkdsfh23jk; private JPanel jklrte; private JPanel jsdfh342kjsd; private JPanel jskad12; private JButton jskfdh; private JLabel jskhd12adsf; private JPanel n67sdf; private JLabel pn1; private JLabel pn2;
/*     */   public Ajkdhfksj123as(Connection c, LinkedList<cartData> l, String shopId) {
/* 119 */     this.con = c;
/* 120 */     this.shopId = shopId;
/* 121 */     for (cartData data : l) {
/* 122 */       this.det.add(data);
/*     */     }
/*     */     
/* 125 */     setUndecorated(true);
/* 126 */     initComponents();
/* 127 */     setLocationRelativeTo(null);
/* 128 */     init();
/* 129 */     for (int i = 0; i < l.size(); i++)
/* 130 */       jhty56fc(i, l.get(i)); 
/*     */   }
/*     */   private JLabel pn3; private JLabel pn4; private JLabel pn5; private JLabel pn6; private JLabel pn7; private JLabel pn8; private JLabel q1; private JLabel q2; private JLabel q3; private JLabel q4; private JLabel q5; private JLabel q6; private JLabel q7; private JLabel q8; private JPanel sdfhskjdh23; private JLabel t1; private JLabel t2; private JLabel t3; private JLabel t4; private JLabel t5;
/*     */   private JLabel t6;
/*     */   private JLabel t7;
/*     */   private JLabel t8;
/*     */   private JTextField w64ash;
/*     */   
/*     */   private void initComponents() {
/* 139 */     this.jkdsfh23jk = new JPanel();
/* 140 */     this.djkfsh3e = new JPanel();
/* 141 */     this.X = new JLabel();
/* 142 */     this.jsdfh342kjsd = new JPanel();
/* 143 */     this.jLabel1 = new JLabel();
/* 144 */     this.jLabel2 = new JLabel();
/* 145 */     this.jLabel3 = new JLabel();
/* 146 */     this.dsfjhkds = new JPanel();
/* 147 */     this.pn1 = new JLabel();
/* 148 */     this.q1 = new JLabel();
/* 149 */     this.t1 = new JLabel();
/* 150 */     this.dsfsjkd = new JPanel();
/* 151 */     this.pn2 = new JLabel();
/* 152 */     this.q2 = new JLabel();
/* 153 */     this.t2 = new JLabel();
/* 154 */     this.sdfhskjdh23 = new JPanel();
/* 155 */     this.pn3 = new JLabel();
/* 156 */     this.q3 = new JLabel();
/* 157 */     this.t3 = new JLabel();
/* 158 */     this.akjh12hgc = new JPanel();
/* 159 */     this.pn4 = new JLabel();
/* 160 */     this.q4 = new JLabel();
/* 161 */     this.t4 = new JLabel();
/* 162 */     this.akjhds12 = new JPanel();
/* 163 */     this.pn5 = new JLabel();
/* 164 */     this.q5 = new JLabel();
/* 165 */     this.t5 = new JLabel();
/* 166 */     this.n67sdf = new JPanel();
/* 167 */     this.pn6 = new JLabel();
/* 168 */     this.q6 = new JLabel();
/* 169 */     this.t6 = new JLabel();
/* 170 */     this.jskad12 = new JPanel();
/* 171 */     this.pn7 = new JLabel();
/* 172 */     this.q7 = new JLabel();
/* 173 */     this.t7 = new JLabel();
/* 174 */     this.asdj12cx = new JPanel();
/* 175 */     this.pn8 = new JLabel();
/* 176 */     this.q8 = new JLabel();
/* 177 */     this.t8 = new JLabel();
/* 178 */     this.jklrte = new JPanel();
/* 179 */     this.djskfhs12jkhkds = new JButton();
/* 180 */     this.jskfdh = new JButton();
/* 181 */     this.jkdfhs = new JButton();
/* 182 */     this.jLabel4 = new JLabel();
/* 183 */     this.w64ash = new JTextField();
/* 184 */     this.Gtotal = new JLabel();
/* 185 */     this.jskhd12adsf = new JLabel();
/*     */     
/* 187 */     setDefaultCloseOperation(3);
/*     */     
/* 189 */     this.jkdsfh23jk.setBackground(new Color(255, 255, 255));
/* 190 */     this.jkdsfh23jk.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */     
/* 192 */     this.djkfsh3e.setBackground(new Color(0, 0, 0));
/* 193 */     this.djkfsh3e.addMouseMotionListener(new MouseMotionAdapter() {
/*     */           public void mouseDragged(MouseEvent evt) {
/* 195 */             Ajkdhfksj123as.this.djkfsh3eMouseDragged(evt);
/*     */           }
/*     */         });
/* 198 */     this.djkfsh3e.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 200 */             Ajkdhfksj123as.this.djkfsh3eMouseClicked(evt);
/*     */           }
/*     */           public void mousePressed(MouseEvent evt) {
/* 203 */             Ajkdhfksj123as.this.djkfsh3eMousePressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 207 */     this.X.setFont(new Font("Tahoma", 0, 14));
/* 208 */     this.X.setForeground(new Color(255, 255, 255));
/* 209 */     this.X.setText("X");
/* 210 */     this.X.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 212 */             Ajkdhfksj123as.this.XMouseClicked(evt);
/*     */           }
/*     */           public void mouseEntered(MouseEvent evt) {
/* 215 */             Ajkdhfksj123as.this.XMouseEntered(evt);
/*     */           }
/*     */           public void mouseExited(MouseEvent evt) {
/* 218 */             Ajkdhfksj123as.this.XMouseExited(evt);
/*     */           }
/*     */         });
/*     */     
/* 222 */     GroupLayout djkfsh3eLayout = new GroupLayout(this.djkfsh3e);
/* 223 */     this.djkfsh3e.setLayout(djkfsh3eLayout);
/* 224 */     djkfsh3eLayout.setHorizontalGroup(djkfsh3eLayout
/* 225 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 226 */         .addGroup(GroupLayout.Alignment.TRAILING, djkfsh3eLayout.createSequentialGroup()
/* 227 */           .addContainerGap(-1, 32767)
/* 228 */           .addComponent(this.X)
/* 229 */           .addContainerGap()));
/*     */     
/* 231 */     djkfsh3eLayout.setVerticalGroup(djkfsh3eLayout
/* 232 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 233 */         .addGroup(djkfsh3eLayout.createSequentialGroup()
/* 234 */           .addContainerGap()
/* 235 */           .addComponent(this.X)
/* 236 */           .addContainerGap(-1, 32767)));
/*     */ 
/*     */     
/* 239 */     this.jLabel1.setFont(new Font("Tahoma", 0, 18));
/* 240 */     this.jLabel1.setText("Product Name");
/*     */     
/* 242 */     this.jLabel2.setFont(new Font("Tahoma", 0, 18));
/* 243 */     this.jLabel2.setText("Quantity");
/*     */     
/* 245 */     this.jLabel3.setFont(new Font("Tahoma", 0, 18));
/* 246 */     this.jLabel3.setText("Total");
/*     */     
/* 248 */     GroupLayout jsdfh342kjsdLayout = new GroupLayout(this.jsdfh342kjsd);
/* 249 */     this.jsdfh342kjsd.setLayout(jsdfh342kjsdLayout);
/* 250 */     jsdfh342kjsdLayout.setHorizontalGroup(jsdfh342kjsdLayout
/* 251 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 252 */         .addGroup(jsdfh342kjsdLayout.createSequentialGroup()
/* 253 */           .addContainerGap()
/* 254 */           .addComponent(this.jLabel1)
/* 255 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 256 */           .addComponent(this.jLabel2)
/* 257 */           .addGap(70, 70, 70)
/* 258 */           .addComponent(this.jLabel3, -2, 48, -2)
/* 259 */           .addGap(29, 29, 29)));
/*     */     
/* 261 */     jsdfh342kjsdLayout.setVerticalGroup(jsdfh342kjsdLayout
/* 262 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 263 */         .addGroup(jsdfh342kjsdLayout.createSequentialGroup()
/* 264 */           .addContainerGap()
/* 265 */           .addGroup(jsdfh342kjsdLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 266 */             .addComponent(this.jLabel1)
/* 267 */             .addComponent(this.jLabel2)
/* 268 */             .addComponent(this.jLabel3))
/* 269 */           .addContainerGap(-1, 32767)));
/*     */ 
/*     */     
/* 272 */     this.pn1.setFont(new Font("Tahoma", 0, 14));
/* 273 */     this.pn1.setText("jLabel4");
/*     */     
/* 275 */     this.q1.setFont(new Font("Tahoma", 0, 14));
/* 276 */     this.q1.setText("jLabel5");
/*     */     
/* 278 */     this.t1.setFont(new Font("Tahoma", 0, 14));
/* 279 */     this.t1.setText("jLabel6");
/*     */     
/* 281 */     GroupLayout dsfjhkdsLayout = new GroupLayout(this.dsfjhkds);
/* 282 */     this.dsfjhkds.setLayout(dsfjhkdsLayout);
/* 283 */     dsfjhkdsLayout.setHorizontalGroup(dsfjhkdsLayout
/* 284 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 285 */         .addGroup(dsfjhkdsLayout.createSequentialGroup()
/* 286 */           .addContainerGap()
/* 287 */           .addComponent(this.pn1, -2, 130, -2)
/* 288 */           .addGap(18, 18, 18)
/* 289 */           .addComponent(this.q1, -2, 71, -2)
/* 290 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 291 */           .addComponent(this.t1, -2, 44, -2)
/* 292 */           .addGap(31, 31, 31)));
/*     */     
/* 294 */     dsfjhkdsLayout.setVerticalGroup(dsfjhkdsLayout
/* 295 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 296 */         .addGroup(dsfjhkdsLayout.createSequentialGroup()
/* 297 */           .addContainerGap()
/* 298 */           .addGroup(dsfjhkdsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 299 */             .addGroup(dsfjhkdsLayout.createSequentialGroup()
/* 300 */               .addGap(4, 4, 4)
/* 301 */               .addComponent(this.q1, -1, 19, 32767))
/* 302 */             .addComponent(this.pn1, -1, -1, 32767)
/* 303 */             .addComponent(this.t1, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 304 */           .addContainerGap()));
/*     */ 
/*     */     
/* 307 */     this.pn2.setFont(new Font("Tahoma", 0, 14));
/* 308 */     this.pn2.setText("jLabel4");
/*     */     
/* 310 */     this.q2.setFont(new Font("Tahoma", 0, 14));
/* 311 */     this.q2.setText("jLabel5");
/*     */     
/* 313 */     this.t2.setFont(new Font("Tahoma", 0, 14));
/* 314 */     this.t2.setText("jLabel6");
/*     */     
/* 316 */     GroupLayout dsfsjkdLayout = new GroupLayout(this.dsfsjkd);
/* 317 */     this.dsfsjkd.setLayout(dsfsjkdLayout);
/* 318 */     dsfsjkdLayout.setHorizontalGroup(dsfsjkdLayout
/* 319 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 320 */         .addGroup(dsfsjkdLayout.createSequentialGroup()
/* 321 */           .addContainerGap()
/* 322 */           .addComponent(this.pn2, -2, 130, -2)
/* 323 */           .addGap(18, 18, 18)
/* 324 */           .addComponent(this.q2, -2, 71, -2)
/* 325 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 326 */           .addComponent(this.t2, -2, 44, -2)
/* 327 */           .addGap(31, 31, 31)));
/*     */     
/* 329 */     dsfsjkdLayout.setVerticalGroup(dsfsjkdLayout
/* 330 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 331 */         .addGroup(dsfsjkdLayout.createSequentialGroup()
/* 332 */           .addContainerGap()
/* 333 */           .addGroup(dsfsjkdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 334 */             .addGroup(dsfsjkdLayout.createSequentialGroup()
/* 335 */               .addGap(4, 4, 4)
/* 336 */               .addComponent(this.q2, -1, 19, 32767))
/* 337 */             .addComponent(this.pn2, -1, -1, 32767)
/* 338 */             .addComponent(this.t2, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 339 */           .addContainerGap()));
/*     */ 
/*     */     
/* 342 */     this.pn3.setFont(new Font("Tahoma", 0, 14));
/* 343 */     this.pn3.setText("jLabel4");
/*     */     
/* 345 */     this.q3.setFont(new Font("Tahoma", 0, 14));
/* 346 */     this.q3.setText("jLabel5");
/*     */     
/* 348 */     this.t3.setFont(new Font("Tahoma", 0, 14));
/* 349 */     this.t3.setText("jLabel6");
/*     */     
/* 351 */     GroupLayout sdfhskjdh23Layout = new GroupLayout(this.sdfhskjdh23);
/* 352 */     this.sdfhskjdh23.setLayout(sdfhskjdh23Layout);
/* 353 */     sdfhskjdh23Layout.setHorizontalGroup(sdfhskjdh23Layout
/* 354 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 355 */         .addGroup(sdfhskjdh23Layout.createSequentialGroup()
/* 356 */           .addContainerGap()
/* 357 */           .addComponent(this.pn3, -2, 130, -2)
/* 358 */           .addGap(18, 18, 18)
/* 359 */           .addComponent(this.q3, -2, 71, -2)
/* 360 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 361 */           .addComponent(this.t3, -2, 44, -2)
/* 362 */           .addGap(31, 31, 31)));
/*     */     
/* 364 */     sdfhskjdh23Layout.setVerticalGroup(sdfhskjdh23Layout
/* 365 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 366 */         .addGroup(sdfhskjdh23Layout.createSequentialGroup()
/* 367 */           .addContainerGap()
/* 368 */           .addGroup(sdfhskjdh23Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 369 */             .addGroup(sdfhskjdh23Layout.createSequentialGroup()
/* 370 */               .addGap(4, 4, 4)
/* 371 */               .addComponent(this.q3, -1, 19, 32767))
/* 372 */             .addComponent(this.pn3, -1, -1, 32767)
/* 373 */             .addComponent(this.t3, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 374 */           .addContainerGap()));
/*     */ 
/*     */     
/* 377 */     this.pn4.setFont(new Font("Tahoma", 0, 14));
/* 378 */     this.pn4.setText("jLabel4");
/*     */     
/* 380 */     this.q4.setFont(new Font("Tahoma", 0, 14));
/* 381 */     this.q4.setText("jLabel5");
/*     */     
/* 383 */     this.t4.setFont(new Font("Tahoma", 0, 14));
/* 384 */     this.t4.setText("jLabel6");
/*     */     
/* 386 */     GroupLayout akjh12hgcLayout = new GroupLayout(this.akjh12hgc);
/* 387 */     this.akjh12hgc.setLayout(akjh12hgcLayout);
/* 388 */     akjh12hgcLayout.setHorizontalGroup(akjh12hgcLayout
/* 389 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 390 */         .addGroup(akjh12hgcLayout.createSequentialGroup()
/* 391 */           .addContainerGap()
/* 392 */           .addComponent(this.pn4, -2, 130, -2)
/* 393 */           .addGap(18, 18, 18)
/* 394 */           .addComponent(this.q4, -2, 71, -2)
/* 395 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 396 */           .addComponent(this.t4, -2, 44, -2)
/* 397 */           .addGap(29, 29, 29)));
/*     */     
/* 399 */     akjh12hgcLayout.setVerticalGroup(akjh12hgcLayout
/* 400 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 401 */         .addGroup(akjh12hgcLayout.createSequentialGroup()
/* 402 */           .addContainerGap()
/* 403 */           .addGroup(akjh12hgcLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 404 */             .addGroup(akjh12hgcLayout.createSequentialGroup()
/* 405 */               .addGap(4, 4, 4)
/* 406 */               .addComponent(this.q4, -1, 19, 32767))
/* 407 */             .addComponent(this.pn4, -1, -1, 32767)
/* 408 */             .addComponent(this.t4, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 409 */           .addContainerGap()));
/*     */ 
/*     */     
/* 412 */     this.pn5.setFont(new Font("Tahoma", 0, 14));
/* 413 */     this.pn5.setText("jLabel4");
/*     */     
/* 415 */     this.q5.setFont(new Font("Tahoma", 0, 14));
/* 416 */     this.q5.setText("jLabel5");
/*     */     
/* 418 */     this.t5.setFont(new Font("Tahoma", 0, 14));
/* 419 */     this.t5.setText("jLabel6");
/*     */     
/* 421 */     GroupLayout akjhds12Layout = new GroupLayout(this.akjhds12);
/* 422 */     this.akjhds12.setLayout(akjhds12Layout);
/* 423 */     akjhds12Layout.setHorizontalGroup(akjhds12Layout
/* 424 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 425 */         .addGroup(akjhds12Layout.createSequentialGroup()
/* 426 */           .addContainerGap()
/* 427 */           .addComponent(this.pn5, -2, 130, -2)
/* 428 */           .addGap(18, 18, 18)
/* 429 */           .addComponent(this.q5, -2, 71, -2)
/* 430 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 431 */           .addComponent(this.t5, -2, 44, -2)
/* 432 */           .addGap(31, 31, 31)));
/*     */     
/* 434 */     akjhds12Layout.setVerticalGroup(akjhds12Layout
/* 435 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 436 */         .addGroup(akjhds12Layout.createSequentialGroup()
/* 437 */           .addContainerGap()
/* 438 */           .addGroup(akjhds12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 439 */             .addGroup(akjhds12Layout.createSequentialGroup()
/* 440 */               .addGap(4, 4, 4)
/* 441 */               .addComponent(this.q5, -1, 19, 32767))
/* 442 */             .addComponent(this.pn5, -1, -1, 32767)
/* 443 */             .addComponent(this.t5, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 444 */           .addContainerGap()));
/*     */ 
/*     */     
/* 447 */     this.pn6.setFont(new Font("Tahoma", 0, 14));
/* 448 */     this.pn6.setText("jLabel4");
/*     */     
/* 450 */     this.q6.setFont(new Font("Tahoma", 0, 14));
/* 451 */     this.q6.setText("jLabel5");
/*     */     
/* 453 */     this.t6.setFont(new Font("Tahoma", 0, 14));
/* 454 */     this.t6.setText("jLabel6");
/*     */     
/* 456 */     GroupLayout n67sdfLayout = new GroupLayout(this.n67sdf);
/* 457 */     this.n67sdf.setLayout(n67sdfLayout);
/* 458 */     n67sdfLayout.setHorizontalGroup(n67sdfLayout
/* 459 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 460 */         .addGroup(n67sdfLayout.createSequentialGroup()
/* 461 */           .addContainerGap()
/* 462 */           .addComponent(this.pn6, -2, 130, -2)
/* 463 */           .addGap(18, 18, 18)
/* 464 */           .addComponent(this.q6, -2, 71, -2)
/* 465 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 466 */           .addComponent(this.t6, -2, 44, -2)
/* 467 */           .addGap(31, 31, 31)));
/*     */     
/* 469 */     n67sdfLayout.setVerticalGroup(n67sdfLayout
/* 470 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 471 */         .addGroup(n67sdfLayout.createSequentialGroup()
/* 472 */           .addContainerGap()
/* 473 */           .addGroup(n67sdfLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 474 */             .addGroup(n67sdfLayout.createSequentialGroup()
/* 475 */               .addGap(4, 4, 4)
/* 476 */               .addComponent(this.q6, -1, 19, 32767))
/* 477 */             .addComponent(this.pn6, -1, -1, 32767)
/* 478 */             .addComponent(this.t6, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 479 */           .addContainerGap()));
/*     */ 
/*     */     
/* 482 */     this.pn7.setFont(new Font("Tahoma", 0, 14));
/* 483 */     this.pn7.setText("jLabel4");
/*     */     
/* 485 */     this.q7.setFont(new Font("Tahoma", 0, 14));
/* 486 */     this.q7.setText("jLabel5");
/*     */     
/* 488 */     this.t7.setFont(new Font("Tahoma", 0, 14));
/* 489 */     this.t7.setText("jLabel6");
/*     */     
/* 491 */     GroupLayout jskad12Layout = new GroupLayout(this.jskad12);
/* 492 */     this.jskad12.setLayout(jskad12Layout);
/* 493 */     jskad12Layout.setHorizontalGroup(jskad12Layout
/* 494 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 495 */         .addGroup(jskad12Layout.createSequentialGroup()
/* 496 */           .addContainerGap()
/* 497 */           .addComponent(this.pn7, -2, 130, -2)
/* 498 */           .addGap(18, 18, 18)
/* 499 */           .addComponent(this.q7, -2, 71, -2)
/* 500 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 501 */           .addComponent(this.t7, -2, 44, -2)
/* 502 */           .addGap(31, 31, 31)));
/*     */     
/* 504 */     jskad12Layout.setVerticalGroup(jskad12Layout
/* 505 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 506 */         .addGroup(jskad12Layout.createSequentialGroup()
/* 507 */           .addContainerGap()
/* 508 */           .addGroup(jskad12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 509 */             .addGroup(jskad12Layout.createSequentialGroup()
/* 510 */               .addGap(4, 4, 4)
/* 511 */               .addComponent(this.q7, -1, 19, 32767))
/* 512 */             .addComponent(this.pn7, -1, -1, 32767)
/* 513 */             .addComponent(this.t7, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 514 */           .addContainerGap()));
/*     */ 
/*     */     
/* 517 */     this.pn8.setFont(new Font("Tahoma", 0, 14));
/* 518 */     this.pn8.setText("jLabel4");
/*     */     
/* 520 */     this.q8.setFont(new Font("Tahoma", 0, 14));
/* 521 */     this.q8.setText("jLabel5");
/*     */     
/* 523 */     this.t8.setFont(new Font("Tahoma", 0, 14));
/* 524 */     this.t8.setText("jLabel6");
/*     */     
/* 526 */     GroupLayout asdj12cxLayout = new GroupLayout(this.asdj12cx);
/* 527 */     this.asdj12cx.setLayout(asdj12cxLayout);
/* 528 */     asdj12cxLayout.setHorizontalGroup(asdj12cxLayout
/* 529 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 530 */         .addGroup(asdj12cxLayout.createSequentialGroup()
/* 531 */           .addContainerGap()
/* 532 */           .addComponent(this.pn8, -2, 130, -2)
/* 533 */           .addGap(18, 18, 18)
/* 534 */           .addComponent(this.q8, -2, 71, -2)
/* 535 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 536 */           .addComponent(this.t8, -2, 44, -2)
/* 537 */           .addGap(29, 29, 29)));
/*     */     
/* 539 */     asdj12cxLayout.setVerticalGroup(asdj12cxLayout
/* 540 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 541 */         .addGroup(asdj12cxLayout.createSequentialGroup()
/* 542 */           .addContainerGap()
/* 543 */           .addGroup(asdj12cxLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 544 */             .addGroup(asdj12cxLayout.createSequentialGroup()
/* 545 */               .addGap(4, 4, 4)
/* 546 */               .addComponent(this.q8, -1, 19, 32767))
/* 547 */             .addComponent(this.pn8, -1, -1, 32767)
/* 548 */             .addComponent(this.t8, GroupLayout.Alignment.TRAILING, -1, -1, 32767))
/* 549 */           .addContainerGap()));
/*     */ 
/*     */     
/* 552 */     this.jklrte.setBackground(new Color(255, 255, 255));
/*     */     
/* 554 */     this.djskfhs12jkhkds.setText("Print Bill");
/* 555 */     this.djskfhs12jkhkds.setNextFocusableComponent(this.jskfdh);
/* 556 */     this.djskfhs12jkhkds.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 558 */             Ajkdhfksj123as.this.djskfhs12jkhkdsMouseClicked(evt);
/*     */           }
/*     */         });
/* 561 */     this.djskfhs12jkhkds.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 563 */             Ajkdhfksj123as.this.djskfhs12jkhkdsKeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 567 */     this.jskfdh.setText("Loan");
/* 568 */     this.jskfdh.setNextFocusableComponent(this.jkdfhs);
/* 569 */     this.jskfdh.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 571 */             Ajkdhfksj123as.this.jskfdhMouseClicked(evt);
/*     */           }
/*     */         });
/* 574 */     this.jskfdh.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 576 */             Ajkdhfksj123as.this.jskfdhKeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 580 */     this.jkdfhs.setText("Ok");
/* 581 */     this.jkdfhs.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 583 */             Ajkdhfksj123as.this.jkdfhsMouseClicked(evt);
/*     */           }
/*     */         });
/* 586 */     this.jkdfhs.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 588 */             Ajkdhfksj123as.this.jkdfhsKeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 592 */     this.jLabel4.setText("Net Ammount");
/*     */     
/* 594 */     this.w64ash.setFont(new Font("Tahoma", 0, 14));
/* 595 */     this.w64ash.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 596 */     this.w64ash.setNextFocusableComponent(this.djskfhs12jkhkds);
/* 597 */     this.w64ash.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 599 */             Ajkdhfksj123as.this.w64ashKeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 603 */     this.Gtotal.setFont(new Font("Tahoma", 0, 14));
/* 604 */     this.Gtotal.setHorizontalAlignment(11);
/* 605 */     this.Gtotal.setText("0");
/*     */     
/* 607 */     this.jskhd12adsf.setFont(new Font("Tahoma", 0, 14));
/* 608 */     this.jskhd12adsf.setForeground(new Color(255, 0, 0));
/*     */     
/* 610 */     GroupLayout jklrteLayout = new GroupLayout(this.jklrte);
/* 611 */     this.jklrte.setLayout(jklrteLayout);
/* 612 */     jklrteLayout.setHorizontalGroup(jklrteLayout
/* 613 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 614 */         .addGroup(GroupLayout.Alignment.TRAILING, jklrteLayout.createSequentialGroup()
/* 615 */           .addContainerGap()
/* 616 */           .addComponent(this.jskfdh, -2, 88, -2)
/* 617 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 45, 32767)
/* 618 */           .addComponent(this.jkdfhs, -2, 81, -2)
/* 619 */           .addGap(29, 29, 29)
/* 620 */           .addComponent(this.djskfhs12jkhkds, -2, 87, -2)
/* 621 */           .addGap(27, 27, 27))
/* 622 */         .addGroup(GroupLayout.Alignment.TRAILING, jklrteLayout.createSequentialGroup()
/* 623 */           .addContainerGap(-1, 32767)
/* 624 */           .addComponent(this.w64ash, -2, 75, -2)
/* 625 */           .addGap(42, 42, 42)
/* 626 */           .addComponent(this.jskhd12adsf, -2, 61, -2)
/* 627 */           .addGap(5, 5, 5)
/* 628 */           .addComponent(this.Gtotal, -2, 75, -2)
/* 629 */           .addContainerGap())
/* 630 */         .addGroup(jklrteLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 631 */           .addGroup(jklrteLayout.createSequentialGroup()
/* 632 */             .addContainerGap()
/* 633 */             .addComponent(this.jLabel4)
/* 634 */             .addContainerGap(292, 32767))));
/*     */     
/* 636 */     jklrteLayout.setVerticalGroup(jklrteLayout
/* 637 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 638 */         .addGroup(GroupLayout.Alignment.TRAILING, jklrteLayout.createSequentialGroup()
/* 639 */           .addContainerGap()
/* 640 */           .addGroup(jklrteLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 641 */             .addGroup(jklrteLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 642 */               .addComponent(this.w64ash, -1, 24, 32767)
/* 643 */               .addComponent(this.jskhd12adsf, -1, -1, 32767))
/* 644 */             .addComponent(this.Gtotal, -2, 26, -2))
/* 645 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 23, 32767)
/* 646 */           .addGroup(jklrteLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 647 */             .addComponent(this.djskfhs12jkhkds)
/* 648 */             .addComponent(this.jskfdh)
/* 649 */             .addComponent(this.jkdfhs))
/* 650 */           .addContainerGap())
/* 651 */         .addGroup(jklrteLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 652 */           .addGroup(jklrteLayout.createSequentialGroup()
/* 653 */             .addContainerGap()
/* 654 */             .addComponent(this.jLabel4, -1, 26, 32767)
/* 655 */             .addGap(55, 55, 55))));
/*     */ 
/*     */     
/* 658 */     GroupLayout jkdsfh23jkLayout = new GroupLayout(this.jkdsfh23jk);
/* 659 */     this.jkdsfh23jk.setLayout(jkdsfh23jkLayout);
/* 660 */     jkdsfh23jkLayout.setHorizontalGroup(jkdsfh23jkLayout
/* 661 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 662 */         .addComponent(this.djkfsh3e, -1, -1, 32767)
/* 663 */         .addGroup(GroupLayout.Alignment.TRAILING, jkdsfh23jkLayout.createSequentialGroup()
/* 664 */           .addContainerGap(24, 32767)
/* 665 */           .addGroup(jkdsfh23jkLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 666 */             .addComponent(this.dsfjhkds, -1, -1, 32767)
/* 667 */             .addComponent(this.jsdfh342kjsd, -1, -1, 32767)
/* 668 */             .addComponent(this.dsfsjkd, -1, -1, 32767)
/* 669 */             .addComponent(this.sdfhskjdh23, -1, -1, 32767)
/* 670 */             .addComponent(this.akjh12hgc, -1, -1, 32767)
/* 671 */             .addComponent(this.akjhds12, -1, -1, 32767)
/* 672 */             .addComponent(this.n67sdf, -1, -1, 32767)
/* 673 */             .addComponent(this.jskad12, -1, -1, 32767)
/* 674 */             .addComponent(this.asdj12cx, -1, -1, 32767)
/* 675 */             .addComponent(this.jklrte, -1, -1, -2))
/* 676 */           .addGap(24, 24, 24)));
/*     */     
/* 678 */     jkdsfh23jkLayout.setVerticalGroup(jkdsfh23jkLayout
/* 679 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 680 */         .addGroup(jkdsfh23jkLayout.createSequentialGroup()
/* 681 */           .addComponent(this.djkfsh3e, -2, -1, -2)
/* 682 */           .addGap(18, 18, 18)
/* 683 */           .addComponent(this.jsdfh342kjsd, -2, -1, -2)
/* 684 */           .addGap(18, 18, 18)
/* 685 */           .addComponent(this.dsfjhkds, -2, -1, -2)
/* 686 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 687 */           .addComponent(this.dsfsjkd, -2, -1, -2)
/* 688 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 689 */           .addComponent(this.sdfhskjdh23, -2, -1, -2)
/* 690 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 691 */           .addComponent(this.akjh12hgc, -2, -1, -2)
/* 692 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 693 */           .addComponent(this.akjhds12, -2, -1, -2)
/* 694 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 695 */           .addComponent(this.n67sdf, -2, -1, -2)
/* 696 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 697 */           .addComponent(this.jskad12, -2, -1, -2)
/* 698 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 699 */           .addComponent(this.asdj12cx, -2, -1, -2)
/* 700 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 701 */           .addComponent(this.jklrte, -2, -1, -2)
/* 702 */           .addContainerGap(-1, 32767)));
/*     */ 
/*     */     
/* 705 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 706 */     getContentPane().setLayout(layout);
/* 707 */     layout.setHorizontalGroup(layout
/* 708 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 709 */         .addComponent(this.jkdsfh23jk, -1, -1, 32767));
/*     */     
/* 711 */     layout.setVerticalGroup(layout
/* 712 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 713 */         .addGroup(layout.createSequentialGroup()
/* 714 */           .addComponent(this.jkdsfh23jk, -1, -1, 32767)
/* 715 */           .addGap(0, 0, 0)));
/*     */ 
/*     */     
/* 718 */     pack();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jkdfhsMouseClicked(MouseEvent evt) {
/* 723 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jskfdhMouseClicked(MouseEvent evt) {
/* 728 */     wer43qty56frt34();
/* 729 */     (new afqr0(this.shopId)).setVisible(true);
/* 730 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void XMouseExited(MouseEvent evt) {
/* 735 */     this.X.setForeground(Color.WHITE);
/*     */   }
/*     */ 
/*     */   
/*     */   private void XMouseEntered(MouseEvent evt) {
/* 740 */     this.X.setForeground(Color.red);
/*     */   }
/*     */ 
/*     */   
/*     */   private void XMouseClicked(MouseEvent evt) {
/* 745 */     dispose();
/*     */   }
/*     */   
/*     */   private void djskfhs12jkhkdsMouseClicked(MouseEvent evt) {
/* 749 */     jhty56frt34();
/* 750 */     dispose();
/*     */   }
/*     */   
/*     */   private void jhty56frt34() {
/* 754 */     String amount = this.w64ash.getText();
/* 755 */     if (!amount.isEmpty())
/* 756 */     { int a = Integer.parseInt(amount);
/* 757 */       int gt = Integer.parseInt(this.Gtotal.getText());
/* 758 */       if (a >= gt) {
/* 759 */         PrinterJob pj = PrinterJob.getPrinterJob();
/* 760 */         pj.setPrintable((Printable)new PrintBill(this.det, a, gt), (new PrintFormat()).getPageFormat(pj));
/*     */         try {
/* 762 */           pj.print();
/* 763 */           wer43qty56frt34();
/*     */         }
/* 765 */         catch (PrinterException ex) {
/* 766 */           JOptionPane.showMessageDialog(this, "Printer out of Service");
/* 767 */           ex.printStackTrace();
/*     */         } 
/*     */       } else {
/* 770 */         JOptionPane.showMessageDialog(this, "Please Correct Balence amount");
/*     */       }  }
/* 772 */     else { JOptionPane.showMessageDialog(this, "Please Enter Balence amount"); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private void djskfhs12jkhkdsKeyPressed(KeyEvent evt) {
/* 778 */     switch (evt.getKeyCode()) {
/*     */       case 10:
/* 780 */         jhty56frt34();
/* 781 */         dispose();
/*     */         break;
/*     */       case 39:
/* 784 */         this.jskfdh.requestFocus();
/*     */         break;
/*     */       case 37:
/* 787 */         this.jkdfhs.requestFocus();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void jskfdhKeyPressed(KeyEvent evt) {
/* 795 */     switch (evt.getKeyCode()) {
/*     */       case 10:
/* 797 */         wer43qty56frt34();
/* 798 */         (new afqr0(this.shopId)).setVisible(true);
/* 799 */         dispose();
/*     */         break;
/*     */       case 39:
/* 802 */         this.jkdfhs.requestFocus();
/*     */         break;
/*     */       case 37:
/* 805 */         this.djskfhs12jkhkds.requestFocus();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void jkdfhsKeyPressed(KeyEvent evt) {
/* 812 */     switch (evt.getKeyCode()) {
/*     */       case 10:
/* 814 */         wer43qty56frt34();
/* 815 */         dispose();
/*     */         break;
/*     */       case 39:
/* 818 */         this.djskfhs12jkhkds.requestFocus();
/*     */         break;
/*     */       case 37:
/* 821 */         this.jskfdh.requestFocus();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void w64ashKeyPressed(KeyEvent evt) {
/* 828 */     if (evt.getKeyCode() == 10) {
/*     */       try {
/* 830 */         int amt1 = Integer.parseInt(this.w64ash.getText());
/* 831 */         int amt2 = Integer.parseInt(this.Gtotal.getText());
/* 832 */         if (amt1 - amt2 >= 0) {
/* 833 */           this.jskhd12adsf.setText("" + (amt1 - amt2));
/* 834 */           this.jkdfhs.requestFocus();
/*     */         } else {
/* 836 */           JOptionPane.showMessageDialog(null, "Please Enter correct ammount");
/* 837 */           this.w64ash.setText("");
/* 838 */           this.w64ash.requestFocus();
/*     */         } 
/* 840 */       } catch (HeadlessException|NumberFormatException e) {
/* 841 */         JOptionPane.showMessageDialog(null, "Please Enter correct ammount");
/* 842 */         this.w64ash.setText("");
/* 843 */         this.w64ash.requestFocus();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void djkfsh3eMouseClicked(MouseEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void djkfsh3eMouseDragged(MouseEvent evt) {
/* 855 */     int x = evt.getXOnScreen();
/* 856 */     int y = evt.getYOnScreen();
/* 857 */     setLocation(x - this.xMouse, y - this.yMouse);
/*     */   }
/*     */ 
/*     */   
/*     */   private void djkfsh3eMousePressed(MouseEvent evt) {
/* 862 */     this.xMouse = evt.getX();
/* 863 */     this.yMouse = evt.getY();
/*     */   }
/*     */   
/*     */   private void wer43qty56frt34() {
/*     */     try {
/* 868 */       for (cartData data : this.det) {
/* 869 */         PreparedStatement p = this.con.prepareStatement("Select quantity from cartInfo where barcode = '" + data.getBarcode() + "'");
/* 870 */         ResultSet r = p.executeQuery();
/* 871 */         int val = r.getInt(1);
/* 872 */         p.close();
/* 873 */         p = this.con.prepareStatement("Update cartInfo set quantity = '" + (val - data.getCount()) + "' where barcode = '" + data.getBarcode() + "'");
/* 874 */         p.executeUpdate();
/*     */       } 
/* 876 */     } catch (SQLException ex) {
/* 877 */       Logger.getLogger(Ajkdhfksj123as.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/* 879 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 880 */     ref.orderByChild("shop_id").equalTo(this.shopId).addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/* 883 */             DatabaseReference refi = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 884 */             LinkedList<String> allName = new LinkedList<>();
/* 885 */             for (int i = 0; i < Ajkdhfksj123as.this.det.size(); i++)
/* 886 */               allName.add(((cartData)Ajkdhfksj123as.this.det.get(i)).getBarcode().toLowerCase()); 
/* 887 */             for (DataSnapshot d : ds.getChildren()) {
/* 888 */               if (d.hasChild("salesprice")) {
/* 889 */                 String name = d.child("barcode").getValue().toString();
/* 890 */                 int j = allName.indexOf(name.toLowerCase());
/* 891 */                 if (j >= 0) {
/* 892 */                   allName.remove(j);
/* 893 */                   int csquant = 0;
/* 894 */                   if (d.hasChild("soldItems"))
/* 895 */                     csquant = Integer.parseInt(d.child("soldItems").getValue().toString()); 
/* 896 */                   int nsquant = ((cartData)Ajkdhfksj123as.this.det.get(j)).getCount();
/* 897 */                   int aquant = Integer.parseInt(d.child("quantity").getValue().toString());
/* 898 */                   refi.child(d.getKey() + "/soldItems").setValueAsync(Integer.valueOf(csquant + nsquant));
/* 899 */                   refi.child(d.getKey() + "/quantity").setValueAsync(Integer.valueOf(aquant - nsquant));
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 907 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*     */           }
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\Ajkdhfksj123as.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */