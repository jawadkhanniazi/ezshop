/*     */ package EasyShop.front_end;
/*     */ import EasyShop.util.OrderData;
/*     */ import com.google.firebase.database.DataSnapshot;
/*     */ import com.google.firebase.database.DatabaseError;
/*     */ import com.google.firebase.database.DatabaseReference;
/*     */ import com.google.firebase.database.FirebaseDatabase;
/*     */ import com.google.firebase.database.ValueEventListener;
/*     */ import com.google.firebase.messaging.FirebaseMessaging;
/*     */ import com.google.firebase.messaging.Message;
/*     */ import com.google.firebase.messaging.Notification;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.util.Iterator;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ public class jkhadfkj extends JFrame {
/*     */   private OrderData order;
/*     */   hjklout678 p;
/*  28 */   private int xMouse = 0;
/*  29 */   private int yMouse = 0; private JLabel exit; private JTable hjgfjh;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   
/*     */   public jkhadfkj() {
/*  34 */     setUndecorated(true);
/*  35 */     initComponents();
/*  36 */     setLocationRelativeTo(this);
/*     */   }
/*     */   private JPanel jPanel1; private JPanel jPanel2; private JScrollPane jScrollPane1; private JButton jhgjghjg; private JLabel jkh76dfg;
/*     */   public jkhadfkj(OrderData od, hjklout678 pn) {
/*  40 */     this.p = pn;
/*  41 */     this.order = od;
/*  42 */     initComponents();
/*  43 */     setLocationRelativeTo(this);
/*  44 */     this.jkh76dfg.setText(od.getOrderId());
/*  45 */     DefaultTableModel model = (DefaultTableModel)this.hjgfjh.getModel();
/*  46 */     model.setRowCount(0);
/*  47 */     Object[] o = { od.getProductname(), od.getQuantity(), od.getPrice() };
/*  48 */     model.addRow(o);
/*  49 */     for (OrderData no : od.nextOrders) {
/*  50 */       Object[] o1 = { no.getProductname(), no.getQuantity(), no.getPrice() };
/*  51 */       model.addRow(o1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  65 */     this.jPanel1 = new JPanel();
/*  66 */     this.jPanel2 = new JPanel();
/*  67 */     this.exit = new JLabel();
/*  68 */     this.jScrollPane1 = new JScrollPane();
/*  69 */     this.hjgfjh = new JTable();
/*  70 */     this.jLabel1 = new JLabel();
/*  71 */     this.jLabel2 = new JLabel();
/*  72 */     this.jkh76dfg = new JLabel();
/*  73 */     this.jhgjghjg = new JButton();
/*     */     
/*  75 */     setDefaultCloseOperation(2);
/*  76 */     setBackground(new Color(255, 255, 255));
/*     */     
/*  78 */     this.jPanel1.setBackground(new Color(255, 255, 255));
/*     */     
/*  80 */     this.jPanel2.setBackground(new Color(0, 0, 0));
/*  81 */     this.jPanel2.addMouseMotionListener(new MouseMotionAdapter() {
/*     */           public void mouseDragged(MouseEvent evt) {
/*  83 */             jkhadfkj.this.jPanel2MouseDragged(evt);
/*     */           }
/*     */         });
/*  86 */     this.jPanel2.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  88 */             jkhadfkj.this.jPanel2MouseClicked(evt);
/*     */           }
/*     */           public void mousePressed(MouseEvent evt) {
/*  91 */             jkhadfkj.this.jPanel2MousePressed(evt);
/*     */           }
/*     */         });
/*     */     
/*  95 */     this.exit.setFont(new Font("Tahoma", 0, 14));
/*  96 */     this.exit.setForeground(new Color(255, 255, 255));
/*  97 */     this.exit.setText("X");
/*  98 */     this.exit.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 100 */             jkhadfkj.this.exitMouseClicked(evt);
/*     */           }
/*     */           public void mouseEntered(MouseEvent evt) {
/* 103 */             jkhadfkj.this.exitMouseEntered(evt);
/*     */           }
/*     */           public void mouseExited(MouseEvent evt) {
/* 106 */             jkhadfkj.this.exitMouseExited(evt);
/*     */           }
/*     */         });
/*     */     
/* 110 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 111 */     this.jPanel2.setLayout(jPanel2Layout);
/* 112 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout
/* 113 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 114 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
/* 115 */           .addGap(0, 0, 32767)
/* 116 */           .addComponent(this.exit, -2, 16, -2)));
/*     */     
/* 118 */     jPanel2Layout.setVerticalGroup(jPanel2Layout
/* 119 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 120 */         .addComponent(this.exit, -1, 39, 32767));
/*     */ 
/*     */     
/* 123 */     this.hjgfjh.setModel(new DefaultTableModel(new Object[][] { { null, null, null }, , { null, null, null }, , { null, null, null }, , { null, null, null },  }, (Object[])new String[] { "Product Name", "Quantity", "Price" })
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 134 */           Class[] types = new Class[] { String.class, String.class, String.class };
/*     */ 
/*     */           
/* 137 */           boolean[] canEdit = new boolean[] { false, false, false };
/*     */ 
/*     */ 
/*     */           
/*     */           public Class getColumnClass(int columnIndex) {
/* 142 */             return this.types[columnIndex];
/*     */           }
/*     */           
/*     */           public boolean isCellEditable(int rowIndex, int columnIndex) {
/* 146 */             return this.canEdit[columnIndex];
/*     */           }
/*     */         });
/* 149 */     this.hjgfjh.setGridColor(new Color(255, 255, 255));
/* 150 */     this.jScrollPane1.setViewportView(this.hjgfjh);
/* 151 */     if (this.hjgfjh.getColumnModel().getColumnCount() > 0) {
/* 152 */       this.hjgfjh.getColumnModel().getColumn(0).setPreferredWidth(150);
/*     */     }
/*     */     
/* 155 */     this.jLabel1.setFont(new Font("Tahoma", 0, 18));
/* 156 */     this.jLabel1.setText("Order Information");
/*     */     
/* 158 */     this.jLabel2.setFont(new Font("Tahoma", 0, 14));
/* 159 */     this.jLabel2.setText("Order ID");
/*     */     
/* 161 */     this.jkh76dfg.setFont(new Font("Tahoma", 0, 14));
/*     */     
/* 163 */     this.jhgjghjg.setText("Mark Complete");
/* 164 */     this.jhgjghjg.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 166 */             jkhadfkj.this.jhgjghjgActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 170 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 171 */     this.jPanel1.setLayout(jPanel1Layout);
/* 172 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout
/* 173 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 174 */         .addComponent(this.jPanel2, -1, -1, 32767)
/* 175 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 176 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 177 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 178 */               .addContainerGap()
/* 179 */               .addComponent(this.jLabel1))
/* 180 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 181 */               .addGap(39, 39, 39)
/* 182 */               .addComponent(this.jScrollPane1, -2, 524, -2))
/* 183 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 184 */               .addContainerGap()
/* 185 */               .addComponent(this.jLabel2)
/* 186 */               .addGap(18, 18, 18)
/* 187 */               .addComponent(this.jkh76dfg, -2, 179, -2))
/* 188 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 189 */               .addGap(178, 178, 178)
/* 190 */               .addComponent(this.jhgjghjg, -2, 242, -2)))
/* 191 */           .addContainerGap(76, 32767)));
/*     */     
/* 193 */     jPanel1Layout.setVerticalGroup(jPanel1Layout
/* 194 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 195 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 196 */           .addComponent(this.jPanel2, -2, -1, -2)
/* 197 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 198 */           .addComponent(this.jLabel1)
/* 199 */           .addGap(32, 32, 32)
/* 200 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 201 */             .addComponent(this.jLabel2)
/* 202 */             .addComponent(this.jkh76dfg, -2, 17, -2))
/* 203 */           .addGap(33, 33, 33)
/* 204 */           .addComponent(this.jScrollPane1, -2, 209, -2)
/* 205 */           .addGap(29, 29, 29)
/* 206 */           .addComponent(this.jhgjghjg)
/* 207 */           .addGap(0, 69, 32767)));
/*     */ 
/*     */     
/* 210 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 211 */     getContentPane().setLayout(layout);
/* 212 */     layout.setHorizontalGroup(layout
/* 213 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 214 */         .addComponent(this.jPanel1, -1, -1, 32767));
/*     */     
/* 216 */     layout.setVerticalGroup(layout
/* 217 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 218 */         .addComponent(this.jPanel1, -1, -1, 32767));
/*     */ 
/*     */     
/* 221 */     pack();
/*     */   }
/*     */   
/*     */   private void moveToRider(final OrderData o) {
/* 225 */     final DatabaseReference reforder = FirebaseDatabase.getInstance().getReference("Order/" + o.shopid + "/Products");
/* 226 */     final DatabaseReference refrider = FirebaseDatabase.getInstance().getReference("OrderBiker/");
/* 227 */     reforder.addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/* 230 */             for (int i = 0; i < o.orderIDs.size(); i++) {
/* 231 */               refrider.child(o.shopid + "/Products/" + (String)o.orderIDs.get(i)).setValueAsync(ds.child(o.orderIDs.get(i)).getValue());
/* 232 */               reforder.child((String)o.orderIDs.get(i) + "/ordercomplete").setValueAsync("1");
/* 233 */               jkhadfkj.this.ju887(i, reforder, o);
/*     */             } 
/* 235 */             JOptionPane.showMessageDialog(null, "Moved to rider");
/* 236 */             int index = jkhadfkj.this.p.getOnlineOrders().indexOf(jkhadfkj.this.order);
/* 237 */             jkhadfkj.this.p.getOnlineOrders().remove(index);
/* 238 */             jkhadfkj.this.p.reDraw();
/*     */           }
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 243 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void ju887(final int val, final DatabaseReference reforder, final OrderData o) {
/* 249 */     DatabaseReference refBiker = FirebaseDatabase.getInstance().getReference("Biker/");
/* 250 */     refBiker.orderByChild("shopId").equalTo(o.shopid)
/* 251 */       .limitToFirst(1).addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/* 254 */             Iterator<DataSnapshot> iterator = ds.getChildren().iterator(); if (iterator.hasNext()) { DataSnapshot d = iterator.next();
/* 255 */               reforder.child((String)o.orderIDs.get(val) + "/bikeplate").setValueAsync(d.child("bikeNumber").getValue().toString());
/* 256 */               reforder.child((String)o.orderIDs.get(val) + "/bikerphn").setValueAsync(d.child("phone").getValue().toString());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 263 */                 Message m = Message.builder().putData("New Order placed", "").setNotification(new Notification("New Order Placed", "Please reach your shop.")).setTopic(d.child("subscriptionid").getValue().toString()).build();
/* 264 */                 String str = FirebaseMessaging.getInstance().send(m);
/*     */               }
/* 266 */               catch (Exception ex) {
/* 267 */                 ex.printStackTrace();
/*     */               }  }
/*     */           
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 276 */             throw new UnsupportedOperationException("Not supported yet.");
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private void jhgjghjgActionPerformed(ActionEvent evt) {
/* 283 */     moveToRider(this.order);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void jPanel2MouseDragged(MouseEvent evt) {
/* 289 */     int x = evt.getXOnScreen();
/* 290 */     int y = evt.getYOnScreen();
/* 291 */     setLocation(x - this.xMouse, y - this.yMouse);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void jPanel2MouseClicked(MouseEvent evt) {}
/*     */ 
/*     */   
/*     */   private void exitMouseEntered(MouseEvent evt) {
/* 300 */     this.exit.setForeground(Color.red);
/*     */   }
/*     */ 
/*     */   
/*     */   private void exitMouseExited(MouseEvent evt) {
/* 305 */     this.exit.setForeground(Color.WHITE);
/*     */   }
/*     */ 
/*     */   
/*     */   private void exitMouseClicked(MouseEvent evt) {
/* 310 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jPanel2MousePressed(MouseEvent evt) {
/* 315 */     this.xMouse = evt.getX();
/* 316 */     this.yMouse = evt.getY();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\jkhadfkj.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */