/*    */ package EasyShop.front_end;
/*    */ 
/*    */ import com.google.auth.oauth2.GoogleCredentials;
/*    */ import com.google.firebase.FirebaseApp;
/*    */ import com.google.firebase.FirebaseOptions;
/*    */ import com.google.firebase.database.DatabaseReference;
/*    */ import com.google.firebase.database.FirebaseDatabase;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class sjdkf12
/*    */ {
/*    */   public DatabaseReference ref;
/*    */   
/*    */   public sjdkf12() {
/* 23 */     FileInputStream refFile = null;
/*    */     try {
/* 25 */       refFile = new FileInputStream("bin/Icons/test");
/*    */ 
/*    */ 
/*    */       
/* 29 */       FirebaseOptions options = (new FirebaseOptions.Builder()).setCredentials(GoogleCredentials.fromStream(refFile)).setDatabaseUrl("https://test-667dc.firebaseio.com/").build();
/* 30 */       FirebaseApp sec = FirebaseApp.initializeApp(options, "backup");
/* 31 */       this.ref = FirebaseDatabase.getInstance(sec).getReference();
/* 32 */     } catch (FileNotFoundException ex) {
/* 33 */       System.out.println("initFirebase Error: File not Found");
/* 34 */       System.exit(0);
/* 35 */     } catch (IOException ex) {
/* 36 */       System.out.println("initFirebase Error: IO Exception");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\sjdkf12.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */