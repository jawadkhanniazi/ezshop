/*     */ package EasyShop.front_end;
/*     */ import com.google.firebase.database.ChildEventListener;
/*     */ import com.google.firebase.database.DataSnapshot;
/*     */ import com.google.firebase.database.DatabaseReference;
/*     */ import com.google.firebase.database.FirebaseDatabase;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.TableRowSorter;
/*     */ 
/*     */ public class afqr0 extends JFrame {
/*  25 */   private String name = "";
/*  26 */   private String add = "";
/*  27 */   private String ph = "";
/*  28 */   private String _loan = ""; private String id; private DefaultTableModel model; private TableRowSorter<DefaultTableModel> tr;
/*     */   private JTable djkf12;
/*     */   private JTextField dsfj23;
/*     */   private JLabel jLabel1;
/*     */   
/*     */   private void aqfr() {
/*  34 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Loan/" + this.id);
/*  35 */     this.model.setRowCount(0);
/*  36 */     ref.addChildEventListener(new ChildEventListener()
/*     */         {
/*     */           public void onChildAdded(DataSnapshot ds, String string) {
/*  39 */             String name = ds.child("name").getValue().toString().toLowerCase();
/*  40 */             String bcd = ds.child("address").getValue().toString().toLowerCase();
/*  41 */             String sid = ds.child("contact").getValue().toString().toLowerCase();
/*  42 */             String l = ds.child("amount").getValue().toString().toLowerCase();
/*  43 */             Object[] row = { name, bcd, sid, l };
/*  44 */             afqr0.this.model.addRow(row);
/*     */           }
/*     */ 
/*     */           
/*     */           public void onChildChanged(DataSnapshot ds, String string) {
/*  49 */             throw new UnsupportedOperationException("Not supported yet.");
/*     */           }
/*     */ 
/*     */           
/*     */           public void onChildRemoved(DataSnapshot ds) {
/*  54 */             throw new UnsupportedOperationException("Not supported yet.");
/*     */           }
/*     */ 
/*     */           
/*     */           public void onChildMoved(DataSnapshot ds, String string) {
/*  59 */             throw new UnsupportedOperationException("Not supported yet.");
/*     */           }
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/*  64 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*     */           }
/*     */         });
/*     */   }
/*     */   private JLabel jLabel29; private JLabel jLabel54; private JScrollPane jScrollPane2; private JPanel loan; private JTextField sfdjk2; private JButton sjdf21;
/*     */   private void aqfr1(String query) {
/*  70 */     this.tr.setRowFilter(RowFilter.regexFilter(query, new int[0]));
/*     */   }
/*     */   
/*     */   public afqr0(String id) {
/*  74 */     initComponents();
/*  75 */     this.id = id;
/*  76 */     this.model = (DefaultTableModel)this.djkf12.getModel();
/*  77 */     this.tr = new TableRowSorter<>(this.model);
/*  78 */     this.djkf12.setRowSorter((RowSorter)this.tr);
/*  79 */     setLocationRelativeTo(this);
/*  80 */     this.model = (DefaultTableModel)this.djkf12.getModel();
/*  81 */     aqfr();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  93 */     this.loan = new JPanel();
/*  94 */     this.jLabel29 = new JLabel();
/*  95 */     this.jLabel54 = new JLabel();
/*  96 */     this.dsfj23 = new JTextField();
/*  97 */     this.jScrollPane2 = new JScrollPane();
/*  98 */     this.djkf12 = new JTable();
/*  99 */     this.sfdjk2 = new JTextField();
/* 100 */     this.jLabel1 = new JLabel();
/* 101 */     this.sjdf21 = new JButton();
/*     */     
/* 103 */     setDefaultCloseOperation(2);
/*     */     
/* 105 */     this.loan.setBackground(new Color(255, 255, 255));
/*     */     
/* 107 */     this.jLabel29.setFont(new Font("Tahoma", 0, 24));
/* 108 */     this.jLabel29.setText("Loan Information");
/*     */     
/* 110 */     this.jLabel54.setFont(new Font("Tahoma", 0, 14));
/* 111 */     this.jLabel54.setText("Enter Query");
/*     */     
/* 113 */     this.dsfj23.setForeground(new Color(102, 102, 102));
/* 114 */     this.dsfj23.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(102, 102, 102)));
/* 115 */     this.dsfj23.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 117 */             afqr0.this.dsfj23MouseClicked(evt);
/*     */           }
/*     */         });
/* 120 */     this.dsfj23.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 122 */             afqr0.this.dsfj23KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 125 */             afqr0.this.dsfj23KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 129 */     this.jScrollPane2.setBackground(new Color(255, 255, 255));
/* 130 */     this.jScrollPane2.setBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)));
/*     */     
/* 132 */     this.djkf12.setFont(new Font("Segoe UI", 0, 14));
/* 133 */     this.djkf12.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "Name", "Address", "PhNo", "Loan" })
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 141 */           Class[] types = new Class[] { String.class, String.class, String.class, String.class };
/*     */ 
/*     */           
/* 144 */           boolean[] canEdit = new boolean[] { false, false, false, true };
/*     */ 
/*     */ 
/*     */           
/*     */           public Class getColumnClass(int columnIndex) {
/* 149 */             return this.types[columnIndex];
/*     */           }
/*     */           
/*     */           public boolean isCellEditable(int rowIndex, int columnIndex) {
/* 153 */             return this.canEdit[columnIndex];
/*     */           }
/*     */         });
/* 156 */     this.djkf12.setCellSelectionEnabled(true);
/* 157 */     this.djkf12.setGridColor(new Color(204, 204, 204));
/* 158 */     this.djkf12.setOpaque(false);
/* 159 */     this.djkf12.setRowHeight(20);
/* 160 */     this.djkf12.getTableHeader().setReorderingAllowed(false);
/* 161 */     this.djkf12.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 163 */             afqr0.this.djkf12MouseClicked(evt);
/*     */           }
/*     */         });
/* 166 */     this.jScrollPane2.setViewportView(this.djkf12);
/* 167 */     this.djkf12.getColumnModel().getSelectionModel().setSelectionMode(1);
/*     */     
/* 169 */     this.sfdjk2.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 170 */     this.sfdjk2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 172 */             afqr0.this.sfdjk2KeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 176 */     this.jLabel1.setFont(new Font("Tahoma", 0, 14));
/* 177 */     this.jLabel1.setText("Amount");
/*     */     
/* 179 */     this.sjdf21.setText("New Loan");
/* 180 */     this.sjdf21.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 182 */             afqr0.this.sjdf21MouseClicked(evt);
/*     */           }
/*     */         });
/*     */     
/* 186 */     GroupLayout loanLayout = new GroupLayout(this.loan);
/* 187 */     this.loan.setLayout(loanLayout);
/* 188 */     loanLayout.setHorizontalGroup(loanLayout
/* 189 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 190 */         .addGroup(loanLayout.createSequentialGroup()
/* 191 */           .addGroup(loanLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 192 */             .addComponent(this.jLabel29)
/* 193 */             .addGroup(loanLayout.createSequentialGroup()
/* 194 */               .addGap(44, 44, 44)
/* 195 */               .addGroup(loanLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 196 */                 .addGroup(loanLayout.createSequentialGroup()
/* 197 */                   .addComponent(this.jScrollPane2, -2, 648, -2)
/* 198 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 199 */                   .addGroup(loanLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 200 */                     .addGroup(loanLayout.createSequentialGroup()
/* 201 */                       .addComponent(this.jLabel1, -2, 75, -2)
/* 202 */                       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 203 */                       .addComponent(this.sfdjk2, -2, 94, -2))
/* 204 */                     .addComponent(this.sjdf21, -1, -1, 32767)))
/* 205 */                 .addGroup(loanLayout.createSequentialGroup()
/* 206 */                   .addComponent(this.jLabel54, -2, 87, -2)
/* 207 */                   .addGap(18, 18, 18)
/* 208 */                   .addComponent(this.dsfj23, -2, 405, -2)))))
/* 209 */           .addContainerGap(112, 32767)));
/*     */     
/* 211 */     loanLayout.setVerticalGroup(loanLayout
/* 212 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 213 */         .addGroup(loanLayout.createSequentialGroup()
/* 214 */           .addComponent(this.jLabel29)
/* 215 */           .addGap(50, 50, 50)
/* 216 */           .addGroup(loanLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 217 */             .addComponent(this.jLabel54, -2, 31, -2)
/* 218 */             .addComponent(this.dsfj23, -2, 31, -2))
/* 219 */           .addGroup(loanLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 220 */             .addGroup(loanLayout.createSequentialGroup()
/* 221 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 222 */               .addComponent(this.jScrollPane2, -2, 305, -2))
/* 223 */             .addGroup(loanLayout.createSequentialGroup()
/* 224 */               .addGap(18, 18, 18)
/* 225 */               .addGroup(loanLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 226 */                 .addComponent(this.sfdjk2, -2, 35, -2)
/* 227 */                 .addComponent(this.jLabel1, -2, 35, -2))
/* 228 */               .addGap(18, 18, 18)
/* 229 */               .addComponent(this.sjdf21)))
/* 230 */           .addContainerGap(126, 32767)));
/*     */ 
/*     */     
/* 233 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 234 */     getContentPane().setLayout(layout);
/* 235 */     layout.setHorizontalGroup(layout
/* 236 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 237 */         .addComponent(this.loan, -1, -1, 32767));
/*     */     
/* 239 */     layout.setVerticalGroup(layout
/* 240 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 241 */         .addComponent(this.loan, -1, -1, 32767));
/*     */ 
/*     */     
/* 244 */     pack();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void dsfj23MouseClicked(MouseEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void dsfj23KeyPressed(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void dsfj23KeyReleased(KeyEvent evt) {
/* 258 */     if (evt.getKeyCode() != 27) {
/* 259 */       aqfr1(this.dsfj23.getText().toLowerCase());
/*     */     }
/*     */   }
/*     */   
/*     */   private void sfdjk2KeyPressed(KeyEvent evt) {
/* 264 */     if (evt.getKeyCode() == 10) {
/*     */       try {
/* 266 */         int a = Integer.parseInt(this.sfdjk2.getText());
/* 267 */         if (!this.sfdjk2.getText().isEmpty()) {
/* 268 */           if (this.name.isEmpty() || this.add.isEmpty() || this.ph.isEmpty() || this._loan.isEmpty()) {
/* 269 */             JOptionPane.showMessageDialog(this, "Select a record First");
/*     */           } else {
/* 271 */             DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Loan/" + this.id + "/" + this.name + "-" + this.ph);
/* 272 */             int ploan = Integer.parseInt(this._loan.trim());
/* 273 */             ref.child("amount").setValueAsync("" + (ploan + a));
/* 274 */             this.name = "";
/* 275 */             this.add = "";
/* 276 */             this.ph = "";
/* 277 */             this._loan = "";
/* 278 */             this.model.setValueAt("" + (ploan + a), this.djkf12.convertRowIndexToModel(this.djkf12.getSelectedRow()), 3);
/* 279 */             this.sfdjk2.setText("");
/* 280 */             this.dsfj23.requestFocus();
/* 281 */             JOptionPane.showMessageDialog(this, "Loan updated.");
/*     */           } 
/*     */         } else {
/* 284 */           JOptionPane.showMessageDialog(this, "Enter Loan ammount First");
/*     */         } 
/* 286 */       } catch (HeadlessException|NumberFormatException e) {
/* 287 */         JOptionPane.showMessageDialog(this, "Enter a valid Loan ammount");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void djkf12MouseClicked(MouseEvent evt) {
/* 294 */     int index = this.djkf12.convertRowIndexToModel(this.djkf12.getSelectedRow());
/* 295 */     this.name = this.model.getValueAt(index, 0).toString();
/* 296 */     this.add = this.model.getValueAt(index, 1).toString();
/* 297 */     this.ph = this.model.getValueAt(index, 2).toString();
/* 298 */     this._loan = this.model.getValueAt(index, 3).toString();
/*     */     
/* 300 */     this.sfdjk2.setText("");
/* 301 */     this.sfdjk2.requestFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   private void sjdf21MouseClicked(MouseEvent evt) {
/* 306 */     (new qwxcero(this.id)).setVisible(true);
/* 307 */     dispose();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\afqr0.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */