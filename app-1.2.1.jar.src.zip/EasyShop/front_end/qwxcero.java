/*     */ package EasyShop.front_end;
/*     */ import com.google.firebase.database.DatabaseReference;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ 
/*     */ public class qwxcero extends JFrame {
/*     */   String id;
/*  25 */   int xMouse = 0;
/*  26 */   int yMouse = 0; private JLabel X; private JTextField ash1; private JButton dskjf21; private JLabel jLabel1; private JLabel jLabel2; private JLabel jLabel3; private JLabel jLabel4;
/*     */   public qwxcero(String id) {
/*  28 */     setUndecorated(true);
/*  29 */     this.id = id;
/*  30 */     initComponents();
/*  31 */     setLocationRelativeTo(this);
/*     */   }
/*     */   private JLabel jLabel5; private JLabel jLabel6; private JPanel jPanel2; private JTextField jdskf23; private JPanel jsfh123j; private JTextField sadufy12; private JTextField shda21;
/*     */   
/*     */   private void aqfr() {
/*  36 */     String pname = this.sadufy12.getText().toLowerCase();
/*  37 */     String pn = this.shda21.getText();
/*  38 */     String add = this.ash1.getText();
/*  39 */     String am = "";
/*     */     try {
/*  41 */       am = Integer.parseInt(this.jdskf23.getText()) + "";
/*  42 */       if (pname.isEmpty() || pn.isEmpty() || add.isEmpty() || am.isEmpty()) {
/*  43 */         JOptionPane.showMessageDialog(this, "Fill all fields.");
/*     */       } else {
/*  45 */         DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Loan/" + this.id + "/" + pname + "-" + pn);
/*  46 */         ref.child("name").setValueAsync(pname);
/*  47 */         ref.child("amount").setValueAsync(am);
/*  48 */         ref.child("address").setValueAsync(add);
/*  49 */         ref.child("contact").setValueAsync(pn);
/*  50 */         JOptionPane.showMessageDialog(this, "Saved");
/*     */       } 
/*  52 */     } catch (NumberFormatException e) {
/*  53 */       JOptionPane.showMessageDialog(this, "Amount must be a number.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  67 */     this.jLabel5 = new JLabel();
/*  68 */     this.jsfh123j = new JPanel();
/*  69 */     this.jPanel2 = new JPanel();
/*  70 */     this.X = new JLabel();
/*  71 */     this.jLabel1 = new JLabel();
/*  72 */     this.sadufy12 = new JTextField();
/*  73 */     this.jLabel2 = new JLabel();
/*  74 */     this.shda21 = new JTextField();
/*  75 */     this.jLabel3 = new JLabel();
/*  76 */     this.jLabel4 = new JLabel();
/*  77 */     this.dskjf21 = new JButton();
/*  78 */     this.jLabel6 = new JLabel();
/*  79 */     this.ash1 = new JTextField();
/*  80 */     this.jdskf23 = new JTextField();
/*     */     
/*  82 */     this.jLabel5.setText("jLabel5");
/*     */     
/*  84 */     setDefaultCloseOperation(2);
/*     */     
/*  86 */     this.jsfh123j.setBackground(new Color(255, 255, 255));
/*  87 */     this.jsfh123j.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */     
/*  89 */     this.jPanel2.setBackground(new Color(0, 0, 0));
/*  90 */     this.jPanel2.addMouseMotionListener(new MouseMotionAdapter() {
/*     */           public void mouseDragged(MouseEvent evt) {
/*  92 */             qwxcero.this.jPanel2MouseDragged(evt);
/*     */           }
/*     */         });
/*  95 */     this.jPanel2.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  97 */             qwxcero.this.jPanel2MouseClicked(evt);
/*     */           }
/*     */           public void mousePressed(MouseEvent evt) {
/* 100 */             qwxcero.this.jPanel2MousePressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 104 */     this.X.setFont(new Font("Tahoma", 0, 14));
/* 105 */     this.X.setForeground(new Color(255, 255, 255));
/* 106 */     this.X.setText("X");
/* 107 */     this.X.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 109 */             qwxcero.this.XMouseClicked(evt);
/*     */           }
/*     */           public void mouseEntered(MouseEvent evt) {
/* 112 */             qwxcero.this.XMouseEntered(evt);
/*     */           }
/*     */           public void mouseExited(MouseEvent evt) {
/* 115 */             qwxcero.this.XMouseExited(evt);
/*     */           }
/*     */         });
/*     */     
/* 119 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 120 */     this.jPanel2.setLayout(jPanel2Layout);
/* 121 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout
/* 122 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 123 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
/* 124 */           .addContainerGap(-1, 32767)
/* 125 */           .addComponent(this.X)
/* 126 */           .addContainerGap()));
/*     */     
/* 128 */     jPanel2Layout.setVerticalGroup(jPanel2Layout
/* 129 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 130 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
/* 131 */           .addContainerGap(-1, 32767)
/* 132 */           .addComponent(this.X)
/* 133 */           .addContainerGap()));
/*     */ 
/*     */     
/* 136 */     this.jLabel1.setFont(new Font("Tahoma", 0, 14));
/* 137 */     this.jLabel1.setText("Name");
/*     */     
/* 139 */     this.sadufy12.setFont(new Font("Tahoma", 0, 14));
/* 140 */     this.sadufy12.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/*     */     
/* 142 */     this.jLabel2.setFont(new Font("Tahoma", 0, 14));
/* 143 */     this.jLabel2.setText("Ph #");
/*     */     
/* 145 */     this.shda21.setFont(new Font("Tahoma", 0, 14));
/* 146 */     this.shda21.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/*     */     
/* 148 */     this.jLabel3.setFont(new Font("Tahoma", 0, 18));
/* 149 */     this.jLabel3.setText("New Loan Entery");
/*     */     
/* 151 */     this.jLabel4.setFont(new Font("Tahoma", 0, 14));
/* 152 */     this.jLabel4.setText("Amount");
/*     */     
/* 154 */     this.dskjf21.setText("ADD");
/* 155 */     this.dskjf21.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 157 */             qwxcero.this.dskjf21MouseClicked(evt);
/*     */           }
/*     */         });
/* 160 */     this.dskjf21.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 162 */             qwxcero.this.dskjf21ActionPerformed(evt);
/*     */           }
/*     */         });
/* 165 */     this.dskjf21.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 167 */             qwxcero.this.dskjf21KeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 171 */     this.jLabel6.setFont(new Font("Tahoma", 0, 14));
/* 172 */     this.jLabel6.setText("Address");
/*     */     
/* 174 */     this.ash1.setFont(new Font("Tahoma", 0, 14));
/* 175 */     this.ash1.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/*     */     
/* 177 */     this.jdskf23.setFont(new Font("Tahoma", 0, 14));
/* 178 */     this.jdskf23.setHorizontalAlignment(11);
/* 179 */     this.jdskf23.setText("0");
/* 180 */     this.jdskf23.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 181 */     this.jdskf23.addFocusListener(new FocusAdapter() {
/*     */           public void focusGained(FocusEvent evt) {
/* 183 */             qwxcero.this.jdskf23FocusGained(evt);
/*     */           }
/*     */         });
/*     */     
/* 187 */     GroupLayout jsfh123jLayout = new GroupLayout(this.jsfh123j);
/* 188 */     this.jsfh123j.setLayout(jsfh123jLayout);
/* 189 */     jsfh123jLayout.setHorizontalGroup(jsfh123jLayout
/* 190 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 191 */         .addComponent(this.jPanel2, -1, -1, 32767)
/* 192 */         .addGroup(jsfh123jLayout.createSequentialGroup()
/* 193 */           .addGroup(jsfh123jLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 194 */             .addGroup(jsfh123jLayout.createSequentialGroup()
/* 195 */               .addContainerGap()
/* 196 */               .addComponent(this.jLabel3, -2, 208, -2))
/* 197 */             .addGroup(jsfh123jLayout.createSequentialGroup()
/* 198 */               .addGap(58, 58, 58)
/* 199 */               .addComponent(this.dskjf21, -2, 255, -2)))
/* 200 */           .addContainerGap(70, 32767))
/* 201 */         .addGroup(jsfh123jLayout.createSequentialGroup()
/* 202 */           .addGap(21, 21, 21)
/* 203 */           .addGroup(jsfh123jLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 204 */             .addComponent(this.jLabel1, -2, 46, -2)
/* 205 */             .addComponent(this.jLabel2)
/* 206 */             .addComponent(this.jLabel6)
/* 207 */             .addComponent(this.jLabel4, -2, 58, -2))
/* 208 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 26, 32767)
/* 209 */           .addGroup(jsfh123jLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 210 */             .addGroup(jsfh123jLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 211 */               .addComponent(this.sadufy12)
/* 212 */               .addComponent(this.shda21, -1, 242, 32767)
/* 213 */               .addComponent(this.ash1))
/* 214 */             .addComponent(this.jdskf23, -2, 89, -2))
/* 215 */           .addGap(36, 36, 36)));
/*     */     
/* 217 */     jsfh123jLayout.setVerticalGroup(jsfh123jLayout
/* 218 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 219 */         .addGroup(jsfh123jLayout.createSequentialGroup()
/* 220 */           .addComponent(this.jPanel2, -2, -1, -2)
/* 221 */           .addGap(18, 18, 18)
/* 222 */           .addComponent(this.jLabel3, -2, 32, -2)
/* 223 */           .addGap(31, 31, 31)
/* 224 */           .addGroup(jsfh123jLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 225 */             .addGroup(jsfh123jLayout.createSequentialGroup()
/* 226 */               .addComponent(this.sadufy12, -2, 27, -2)
/* 227 */               .addGap(31, 31, 31)
/* 228 */               .addComponent(this.shda21, -2, 27, -2))
/* 229 */             .addGroup(GroupLayout.Alignment.TRAILING, jsfh123jLayout.createSequentialGroup()
/* 230 */               .addComponent(this.jLabel1, -1, -1, 32767)
/* 231 */               .addGap(31, 31, 31)
/* 232 */               .addComponent(this.jLabel2)))
/* 233 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, 32767)
/* 234 */           .addGroup(jsfh123jLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 235 */             .addComponent(this.ash1, -2, 27, -2)
/* 236 */             .addGroup(GroupLayout.Alignment.TRAILING, jsfh123jLayout.createSequentialGroup()
/* 237 */               .addGap(10, 10, 10)
/* 238 */               .addComponent(this.jLabel6)))
/* 239 */           .addGap(18, 18, 18)
/* 240 */           .addGroup(jsfh123jLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 241 */             .addComponent(this.jLabel4, -1, 28, 32767)
/* 242 */             .addComponent(this.jdskf23))
/* 243 */           .addGap(36, 36, 36)
/* 244 */           .addComponent(this.dskjf21, -2, 34, -2)
/* 245 */           .addGap(19, 19, 19)));
/*     */ 
/*     */     
/* 248 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 249 */     getContentPane().setLayout(layout);
/* 250 */     layout.setHorizontalGroup(layout
/* 251 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 252 */         .addComponent(this.jsfh123j, -1, -1, 32767));
/*     */     
/* 254 */     layout.setVerticalGroup(layout
/* 255 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 256 */         .addComponent(this.jsfh123j, -1, -1, 32767));
/*     */ 
/*     */     
/* 259 */     pack();
/*     */   }
/*     */ 
/*     */   
/*     */   private void dskjf21MouseClicked(MouseEvent evt) {
/* 264 */     aqfr();
/*     */   }
/*     */ 
/*     */   
/*     */   private void XMouseClicked(MouseEvent evt) {
/* 269 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void XMouseEntered(MouseEvent evt) {
/* 274 */     this.X.setForeground(Color.red);
/*     */   }
/*     */ 
/*     */   
/*     */   private void XMouseExited(MouseEvent evt) {
/* 279 */     this.X.setForeground(Color.WHITE);
/*     */   }
/*     */ 
/*     */   
/*     */   private void dskjf21KeyPressed(KeyEvent evt) {
/* 284 */     if (evt.getKeyCode() == 10) {
/* 285 */       aqfr();
/*     */     }
/*     */   }
/*     */   
/*     */   private void dskjf21ActionPerformed(ActionEvent evt) {
/* 290 */     aqfr();
/* 291 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jdskf23FocusGained(FocusEvent evt) {
/* 296 */     this.jdskf23.setText("");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void jPanel2MouseClicked(MouseEvent evt) {}
/*     */ 
/*     */   
/*     */   private void jPanel2MouseDragged(MouseEvent evt) {
/* 305 */     int x = evt.getXOnScreen();
/* 306 */     int y = evt.getYOnScreen();
/* 307 */     setLocation(x - this.xMouse, y - this.yMouse);
/*     */   }
/*     */ 
/*     */   
/*     */   private void jPanel2MousePressed(MouseEvent evt) {
/* 312 */     this.xMouse = evt.getX();
/* 313 */     this.yMouse = evt.getY();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\qwxcero.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */