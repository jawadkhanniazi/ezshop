/*      */ package EasyShop.front_end;
/*      */ import EasyShop.util.CategoryData;
/*      */ import EasyShop.util.OrderData;
/*      */ import EasyShop.util.ProductData;
/*      */ import EasyShop.util.SubCatData;
/*      */ import EasyShop.util.cartData;
/*      */ import com.google.firebase.database.ChildEventListener;
/*      */ import com.google.firebase.database.DataSnapshot;
/*      */ import com.google.firebase.database.DatabaseError;
/*      */ import com.google.firebase.database.DatabaseReference;
/*      */ import com.google.firebase.database.FirebaseDatabase;
/*      */ import com.google.firebase.database.ValueEventListener;
/*      */ import com.google.firebase.messaging.Message;
/*      */ import com.sbix.jnotify.NPosition;
/*      */ import com.sbix.jnotify.NoticeType;
/*      */ import com.sbix.jnotify.NoticeWindow;
/*      */ import java.awt.CardLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Image;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.FocusAdapter;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.KeyAdapter;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.TextEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Map;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.LayoutStyle;
/*      */ import javax.swing.SwingWorker;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.table.DefaultTableModel;
/*      */ import javax.swing.table.TableRowSorter;
/*      */ 
/*      */ public class hjklout678 extends JFrame {
/*      */   private ek e;
/*      */   private kl kk;
/*   69 */   private int currentPage = 0;
/*   70 */   private int hjt5676 = 0;
/*      */   private int mode;
/*   72 */   private int skip = 0;
/*      */   private static Connection con;
/*      */   
/*   75 */   private class Lookup { LinkedList<String> id = new LinkedList<>();
/*   76 */     LinkedList<Integer> index = new LinkedList<>();
/*      */ 
/*      */     
/*      */     public String toString() {
/*   80 */       return "Lookup{\nid=" + this.id + ",\nindex=" + this.index + '}';
/*      */     }
/*      */     
/*      */     private Lookup() {} }
/*      */   
/*   85 */   private LinkedList<ProductData> gio90 = new LinkedList<>();
/*   86 */   private LinkedList<OrderData> g3 = new LinkedList<>();
/*   87 */   private Lookup lookup = new Lookup();
/*      */   
/*      */   public LinkedList<OrderData> getOnlineOrders() {
/*   90 */     return this.g3;
/*      */   }
/*      */   
/*      */   private void jklop23yju() {
/*   94 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Order/" + this.hjkouyth.getText() + "/Products");
/*   95 */     ref.addChildEventListener(new ChildEventListener()
/*      */         {
/*      */           public void onChildAdded(DataSnapshot order, String string) {
/*   98 */             if (order.child("ordercomplete").getValue().toString().equalsIgnoreCase("0")) {
/*   99 */               String pname = order.child("productname").getValue().toString();
/*  100 */               Integer orderSize = new Integer(order.child("sizeoforder").getValue().toString());
/*  101 */               String oid = order.child("orderId").getValue().toString();
/*  102 */               String Tprice = order.child("price").getValue().toString();
/*  103 */               String Tquant = order.child("quantity").getValue().toString();
/*  104 */               String sid = order.child("shopid").getValue().toString();
/*  105 */               String pid = order.child("productid").getValue().toString();
/*  106 */               OrderData od = new OrderData(oid, pname, pid, Tprice, Tquant, sid, "" + orderSize);
/*  107 */               od.orderIDs.add(order.getKey());
/*  108 */               od.setOrderP(order.child("price").getValue().toString());
/*  109 */               if (hjklout678.this.skip == 0) {
/*  110 */                 if (orderSize.intValue() > 1) {
/*  111 */                   hjklout678.this.skip = orderSize.intValue() - 1;
/*  112 */                   od.hasMore = true;
/*      */                 } 
/*  114 */                 hjklout678.this.g3.add(od);
/*      */               } else {
/*  116 */                 hjklout678.this.skip--;
/*  117 */                 OrderData o = hjklout678.this.g3.getLast();
/*  118 */                 int cp = Integer.parseInt(o.getOrderP());
/*  119 */                 int np = Integer.parseInt(od.getPrice());
/*  120 */                 o.setOrderP("" + (cp + np));
/*  121 */                 o.orderIDs.add(order.getKey());
/*  122 */                 o.nextOrders.add(od);
/*  123 */                 hjklout678.this.g3.removeLast();
/*  124 */                 hjklout678.this.g3.add(o);
/*      */               } 
/*  126 */               hjklout678.this.hjk65890(hjklout678.this.g3.getLast(), hjklout678.this.g3.size());
/*  127 */               hjklout678.this.lookup.id.add(order.getKey());
/*  128 */               hjklout678.this.lookup.index.add(Integer.valueOf(hjklout678.this.g3.size() - 1));
/*  129 */               new NoticeWindow(NoticeType.SUCCESS_NOTIFICATION, "New Order Placed", 4000, NPosition.BOTTOM_LEFT);
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildChanged(DataSnapshot order, String string) {
/*  136 */             if (order.child("ordercomplete").getValue().toString().equalsIgnoreCase("0")) {
/*  137 */               String pname = order.child("productname").getValue().toString();
/*  138 */               Integer orderSize = new Integer(order.child("sizeoforder").getValue().toString());
/*  139 */               String oid = order.child("orderId").getValue().toString();
/*  140 */               String Tprice = order.child("price").getValue().toString();
/*  141 */               String Tquant = order.child("quantity").getValue().toString();
/*  142 */               String sid = order.child("shopid").getValue().toString();
/*  143 */               String pid = order.child("shopid").getValue().toString();
/*  144 */               OrderData od = new OrderData(oid, pname, pid, Tprice, Tquant, sid, "" + orderSize);
/*  145 */               od.orderIDs.add(order.getKey());
/*  146 */               int index = hjklout678.this.lookup.id.indexOf(order.getKey());
/*  147 */               if (index >= 0) {
/*  148 */                 int allorder_index = ((Integer)hjklout678.this.lookup.index.get(index)).intValue();
/*  149 */                 OrderData o = hjklout678.this.g3.get(allorder_index);
/*  150 */                 index = o.orderIDs.indexOf(order.getKey());
/*  151 */                 if (index == 0) {
/*  152 */                   o.orderId = od.orderId;
/*  153 */                   o.price = od.price;
/*  154 */                   o.shopid = od.shopid;
/*  155 */                   o.productname = od.productname;
/*  156 */                   o.quantity = od.quantity;
/*      */                 } else {
/*  158 */                   o.nextOrders.add(index, od);
/*      */                 } 
/*  160 */                 hjklout678.this.g3.remove(allorder_index);
/*  161 */                 hjklout678.this.g3.add(allorder_index, o);
/*      */               } else {
/*  163 */                 hjklout678.this.g3.add(od);
/*  164 */                 new NoticeWindow(NoticeType.SUCCESS_NOTIFICATION, "New Order Placed", 10000, NPosition.BOTTOM_LEFT);
/*  165 */                 hjklout678.this.reDraw();
/*  166 */                 hjklout678.this.lookup.id.add(order.getKey());
/*  167 */                 hjklout678.this.lookup.index.add(Integer.valueOf(hjklout678.this.g3.size()));
/*      */               } 
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public void onChildRemoved(DataSnapshot ds) {
/*  174 */             new NoticeWindow(NoticeType.SUCCESS_NOTIFICATION, "New Order Placed", 4000, NPosition.BOTTOM_LEFT);
/*      */           }
/*      */ 
/*      */           
/*      */           public void onChildMoved(DataSnapshot ds, String string) {
/*  179 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/*  184 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void hjk65890(OrderData od, int num) {
/*  190 */     switch (num) {
/*      */       case 1:
/*  192 */         hjk65899(this.o1_id, this.o1_p, od, this.ytyg);
/*      */         break;
/*      */       case 2:
/*  195 */         hjk65899(this.o1_id1, this.o1_p1, od, this.gtytfhgyg);
/*      */         break;
/*      */       case 3:
/*  198 */         hjk65899(this.o1_id2, this.o1_p2, od, this.yutuytfjhgy);
/*      */         break;
/*      */       case 4:
/*  201 */         hjk65899(this.o1_id3, this.o1_p3, od, this.sdfhyiuwae348628sdh);
/*      */         break;
/*      */       case 5:
/*  204 */         hjk65899(this.aA, this.o1_p4, od, this.o_u5);
/*      */         break;
/*      */       case 6:
/*  207 */         hjk65899(this.o1_id5, this.o1_p5, od, this.aB);
/*      */         break;
/*      */       case 7:
/*  210 */         hjk65899(this.o1_id6, this.o1_p6, od, this.Au);
/*      */         break;
/*      */       case 8:
/*  213 */         hjk65899(this.o1_id17, this.o1_p17, od, this.Al);
/*      */         break;
/*      */       case 9:
/*  216 */         hjk65899(this.o1_id18, this.o1_p18, od, this.Ak);
/*      */         break;
/*      */       case 10:
/*  219 */         hjk65899(this.o1_id19, this.o1_p19, od, this.AKLJ);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  228 */   LinkedList<String> uto890 = new LinkedList<>();
/*  229 */   LinkedList<String> uto899 = new LinkedList<>();
/*  230 */   LinkedList<String> nto899 = new LinkedList<>();
/*  231 */   LinkedList<String> nto890 = new LinkedList<>();
/*  232 */   private String imageFileName = "";
/*  233 */   private String nto8 = "";
/*  234 */   private String sub_nto8 = "";
/*  235 */   private String nto898u78file = "";
/*  236 */   private String nto898u78URL = "";
/*      */   private boolean subcat_found = false;
/*      */   private boolean catsaveInProgress = false;
/*      */   private boolean subcatsaveInProgress = false;
/*  240 */   private String nto8_path = "";
/*  241 */   private String sub_nto8_path = "";
/*  242 */   private String nto898u78file_path = "";
/*      */   
/*      */   private void yt65Cat() {
/*  245 */     String name = this.Amklop.getText();
/*  246 */     String desc = this.xdfj12.getText();
/*  247 */     if (name.isEmpty() || this.sub_nto8.isEmpty()) {
/*  248 */       JOptionPane.showMessageDialog(this, "Fill all fields");
/*  249 */       this.subcatsaveInProgress = false;
/*      */     } else {
/*  251 */       String url = "";
/*      */       try {
/*  253 */         url = jju685AS4drfg("SubCatImages/" + this.sub_nto8, this.sub_nto8_path);
/*      */       }
/*  255 */       catch (FileNotFoundException ex) {
/*  256 */         JOptionPane.showMessageDialog(null, "Error while uploading images");
/*      */       } 
/*  258 */       SubCatData sc = new SubCatData("", "", desc, this.sub_nto8, name, "", url);
/*  259 */       yt65Cat(sc);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void yt65ckly76() {
/*  264 */     this.subcatsaveInProgress = false;
/*  265 */     this.Amklop.setText("");
/*  266 */     this.xdfj12.setText("Description");
/*  267 */     this.sub_nto8 = "";
/*  268 */     this.sdfjho90.setIcon((Icon)null);
/*      */   }
/*      */   
/*      */   private void yt65ckly76pyt6() {
/*  272 */     if (this.Adrtfgh.getText().isEmpty() || this.hjy65449.getText().isEmpty() || this.nto898u78file.isEmpty()) {
/*  273 */       JOptionPane.showMessageDialog(this, "ProductName & Barcode & image are mandatory");
/*  274 */       this.save_in_progress = false;
/*      */     } else {
/*  276 */       final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
/*  277 */       ref.child("ProductsItems")
/*  278 */         .orderByChild("barcode")
/*  279 */         .equalTo(this.Adrtfgh.getText())
/*  280 */         .addListenerForSingleValueEvent(new ValueEventListener()
/*      */           {
/*      */             public void onDataChange(DataSnapshot ds) {
/*  283 */               boolean found = false;
/*  284 */               for (DataSnapshot d : ds.getChildren()) {
/*  285 */                 if (d.child("shop_id").getValue().toString().equalsIgnoreCase(hjklout678.this.hjkouyth.getText())) {
/*  286 */                   found = true;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*  290 */               if (!found) {
/*      */                 try {
/*  292 */                   hjklout678.this.nto898u78URL = hjklout678.this.jju685AS4drfg("ProductsImages/" + hjklout678.this.nto898u78file, hjklout678.this.nto898u78file_path);
/*      */                 }
/*  294 */                 catch (FileNotFoundException ex) {
/*  295 */                   hjklout678.this.e; ek.kl("File not found Error while uploading");
/*  296 */                   JOptionPane.showMessageDialog(null, "Error while uploading images");
/*      */                 } 
/*  298 */                 hjklout678.this.vcfrt45676(ref);
/*      */               } else {
/*  300 */                 JOptionPane.showMessageDialog(null, "Product Already Exists.");
/*  301 */                 hjklout678.this.save_in_progress = false;
/*      */               } 
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public void onCancelled(DatabaseError de) {}
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  314 */   private String catID = "";
/*      */   
/*      */   private void vcfrt45676(final DatabaseReference ref) {
/*  317 */     ref.child("CategoryItems").orderByChild("name")
/*  318 */       .equalTo(this.hjyt.getSelectedItem().toString())
/*  319 */       .addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/*  322 */             hjklout678.this.catID = ref.child("CategoryItems").push().getKey();
/*  323 */             boolean found = false;
/*  324 */             DataSnapshot data = null;
/*  325 */             for (DataSnapshot d : ds.getChildren()) {
/*  326 */               data = d;
/*  327 */               if (d.child("shop_id").getValue().toString().equalsIgnoreCase(hjklout678.this.hjkouyth.getText())) {
/*  328 */                 found = true;
/*  329 */                 hjklout678.this.catID = d.child("id").getValue().toString();
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/*  334 */             if (found) {
/*  335 */               hjklout678.this.vscfrt45676(ref, hjklout678.this.catID);
/*      */             } else {
/*  337 */               final Integer avaiableUnits = Integer.valueOf(Integer.parseInt(hjklout678.this.asdew.getText()));
/*  338 */               final CategoryData cat = new CategoryData(data);
/*  339 */               final String sid = ref.child("SubCategoryItems").push().getKey();
/*  340 */               final String pID = ref.child("ProductsItems").push().getKey();
/*  341 */               cat.setID(hjklout678.this.catID);
/*  342 */               cat.setShop_id(hjklout678.this.hjkouyth.getText());
/*  343 */               ref.child("SubCategoryItems/" + (String)hjklout678.this.uto899.get(hjklout678.this.hyt57fg.getSelectedIndex()))
/*  344 */                 .addListenerForSingleValueEvent(new ValueEventListener()
/*      */                   {
/*      */                     public void onDataChange(DataSnapshot ds) {
/*  347 */                       SubCatData s = new SubCatData(ds);
/*  348 */                       s.setShopid(hjklout678.this.hjkouyth.getText());
/*  349 */                       s.setId(sid);
/*  350 */                       s.setcatId(hjklout678.this.catID);
/*      */ 
/*      */                       
/*  353 */                       ProductData pd = new ProductData(hjklout678.this.hjy65449.getText(), hjklout678.this.Adrtfgh.getText(), hjklout678.this.catID, pID, hjklout678.this.Wasdf.getText(), hjklout678.this.hjkouyth.getText(), avaiableUnits.intValue(), hjklout678.this.WWa.getText(), hjklout678.this.WWEQSD.getText(), sid, hjklout678.this.nto898u78file, hjklout678.this.nto898u78URL, "0", hjklout678.this.Wad.getText());
/*  354 */                       ref.child("CategoryItems/" + hjklout678.this.catID).setValueAsync(cat);
/*  355 */                       ref.child("SubCategoryItems/" + sid).setValueAsync(s);
/*  356 */                       ref.child("ProductsItems/" + pID).setValueAsync(pd);
/*  357 */                       hjklout678.this.hjAQ34();
/*  358 */                       JOptionPane.showMessageDialog(null, "Product saved Successfuly");
/*  359 */                       hjklout678.this.nto898u78file = "";
/*  360 */                       hjklout678.this.save_in_progress = false;
/*      */                     }
/*      */ 
/*      */                     
/*      */                     public void onCancelled(DatabaseError de) {
/*  365 */                       JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*      */                     }
/*      */                   });
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/*  374 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void vscfrt45676(final DatabaseReference ref, String catId) {
/*  381 */     ref.child("SubCategoryItems").orderByChild("name")
/*  382 */       .equalTo(this.hyt57fg.getSelectedItem().toString())
/*  383 */       .addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/*  386 */             String sid = ref.child("SubCategoryItems").push().getKey();
/*  387 */             String pID = ref.child("ProductsItems").push().getKey();
/*  388 */             boolean found = false;
/*  389 */             DataSnapshot data = null;
/*  390 */             for (DataSnapshot d : ds.getChildren()) {
/*  391 */               data = d;
/*  392 */               if (d.child("shopid").getValue().toString().equalsIgnoreCase(hjklout678.this.hjkouyth.getText())) {
/*  393 */                 found = true;
/*  394 */                 sid = d.child("id").getValue().toString();
/*      */                 break;
/*      */               } 
/*      */             } 
/*  398 */             if (found) {
/*      */ 
/*      */               
/*  401 */               ProductData pd = new ProductData(hjklout678.this.hjy65449.getText(), hjklout678.this.Adrtfgh.getText(), hjklout678.this.catID, pID, hjklout678.this.Wasdf.getText(), hjklout678.this.hjkouyth.getText(), Integer.parseInt(hjklout678.this.asdew.getText()), hjklout678.this.WWa.getText(), hjklout678.this.WWEQSD.getText(), sid, hjklout678.this.nto898u78file, hjklout678.this.nto898u78URL, "0", hjklout678.this.Wad.getText());
/*  402 */               ref.child("ProductsItems/" + pID).setValueAsync(pd);
/*      */             } else {
/*  404 */               SubCatData s = new SubCatData(data);
/*  405 */               s.setId(sid);
/*  406 */               s.setcatId(hjklout678.this.catID);
/*  407 */               s.setShopid(hjklout678.this.hjkouyth.getText());
/*      */ 
/*      */               
/*  410 */               ProductData pd = new ProductData(hjklout678.this.hjy65449.getText(), hjklout678.this.Adrtfgh.getText(), hjklout678.this.catID, pID, hjklout678.this.Wasdf.getText(), hjklout678.this.hjkouyth.getText(), Integer.parseInt(hjklout678.this.asdew.getText()), hjklout678.this.WWa.getText(), hjklout678.this.WWEQSD.getText(), sid, hjklout678.this.nto898u78file, hjklout678.this.nto898u78URL, "0", hjklout678.this.Wad.getText());
/*  411 */               ref.child("SubCategoryItems/" + sid).setValueAsync(s);
/*  412 */               ref.child("ProductsItems/" + pID).setValueAsync(pd);
/*      */             } 
/*      */             
/*  415 */             hjklout678.this.hjAQ34();
/*  416 */             hjklout678.this.nto898u78file = "";
/*  417 */             hjklout678.this.save_in_progress = false;
/*  418 */             JOptionPane.showMessageDialog(null, "Product saved Successfuly");
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/*  423 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private String jju685AS4drfg(String name, String path) throws FileNotFoundException {
/*      */     try {
/*  430 */       Bucket b = StorageClient.getInstance().bucket();
/*  431 */       Storage storage = (Storage)StorageOptions.newBuilder().build().getService();
/*  432 */       BlobId blobId = BlobId.of(b.getName(), name);
/*  433 */       BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType("image/jpg").build();
/*  434 */       Blob blob = storage.create(blobInfo, new FileInputStream(path), new Storage.BlobWriteOption[0]);
/*  435 */       return "https://firebasestorage.googleapis.com/v0" + blob.getMediaLink().split("/v1")[1];
/*  436 */     } catch (Exception ex) {
/*  437 */       kl.ek("Error while uploading image");
/*  438 */       ek.kl(ex.toString());
/*      */       
/*  440 */       return "";
/*      */     } 
/*      */   }
/*  443 */   private String updateimgURL = ""; private CartItem ca65;
/*      */   
/*      */   private void suki6754() {
/*  446 */     this.JHYULOP.setText("");
/*  447 */     this.klopas234.setText("");
/*  448 */     this.Nmklobvg.setText("");
/*  449 */     this.JKlopwr.setText("");
/*  450 */     this.Jkiop90875sad.setText("");
/*  451 */     this.JKLOPas1234.setIcon((Icon)null);
/*  452 */     this.aJKIy786g.setText("");
/*  453 */     this.Ajklou12.setText("");
/*  454 */     this.Nkiopgty67i.setText("");
/*  455 */     this.jklOPhsklop.setText("");
/*  456 */     this.Ajklo.setText("");
/*      */   }
/*      */   
/*      */   private void sdklo9082() {
/*  460 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
/*  461 */     ref.child("ProductsItems")
/*  462 */       .orderByChild(this.sdjlop.getSelectedItem().toString())
/*  463 */       .equalTo(this.Ajklou12.getText())
/*  464 */       .addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/*  467 */             boolean found = false;
/*  468 */             for (DataSnapshot d : ds.getChildren()) {
/*  469 */               if (hjklout678.this.hjkouyth.getText().equalsIgnoreCase(d.child("shop_id").getValue().toString())) {
/*  470 */                 found = true;
/*  471 */                 String id = d.getKey();
/*  472 */                 String name = hjklout678.this.Jkiop90875sad.getText();
/*  473 */                 String barcode = hjklout678.this.JKlopwr.getText();
/*  474 */                 String cname = hjklout678.this.Nmklobvg.getText();
/*  475 */                 String price = hjklout678.this.Nkiopgty67i.getText();
/*  476 */                 String sprice = hjklout678.this.aJKIy786g.getText();
/*  477 */                 Integer quantity = Integer.valueOf(Integer.parseInt(hjklout678.this.JHYULOP.getText()));
/*  478 */                 String url = d.child("imgURL").getValue().toString();
/*  479 */                 if (!hjklout678.this.updateimgURL.isEmpty()) {
/*      */                   try {
/*  481 */                     url = hjklout678.this.jju685AS4drfg("ProductsImages/" + Math.random() + ".jpg", hjklout678.this.updateimgURL);
/*  482 */                   } catch (FileNotFoundException ex) {
/*  483 */                     hjklout678.this.e; ek.kl("Error while updating image");
/*      */                   } 
/*      */                 }
/*  486 */                 hjklout678.this.updateimgURL = "";
/*  487 */                 DatabaseReference refi = FirebaseDatabase.getInstance().getReference();
/*      */ 
/*      */ 
/*      */                 
/*  491 */                 ProductData data = new ProductData(name, barcode, d.child("cat_id").getValue().toString(), id, cname, hjklout678.this.hjkouyth.getText(), quantity.intValue(), price, sprice, d.child("sub_category_id").getValue().toString(), "", url, d.child("soldItems").getValue().toString(), hjklout678.this.jklOPhsklop.getText());
/*  492 */                 refi.child("ProductsItems/" + id).setValueAsync(data); break;
/*      */               } 
/*      */             } 
/*  495 */             if (found) {
/*  496 */               JOptionPane.showMessageDialog(null, "Updated Successfully");
/*      */             } else {
/*  498 */               JOptionPane.showMessageDialog(null, "No Product found for update");
/*  499 */             }  hjklout678.this.suki6754();
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/*  504 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  512 */   int p = 0;
/*      */   
/*      */   private class pl {
/*      */     String name;
/*      */     String barcode;
/*      */     String shop_id;
/*      */     int prof;
/*      */     
/*      */     public pl(String name, String barcode, String shop_id, int prof) {
/*  521 */       this.name = name;
/*  522 */       this.barcode = barcode;
/*  523 */       this.shop_id = shop_id;
/*  524 */       this.prof = prof;
/*      */     }
/*      */     
/*      */     public pl(DataSnapshot ds) {
/*  528 */       this.name = ds.child("name").getValue().toString().toLowerCase();
/*  529 */       this.barcode = ds.child("barcode").getValue().toString().toLowerCase();
/*  530 */       this.shop_id = ds.child("shop_id").getValue().toString().toLowerCase();
/*  531 */       int sp = Integer.parseInt(ds.child("salesprice").getValue().toString());
/*  532 */       int price = Integer.parseInt(ds.child("price").getValue().toString());
/*  533 */       int sli = 0;
/*  534 */       if (ds.hasChild("soldItems")) {
/*  535 */         sli = Integer.parseInt(ds.child("soldItems").getValue().toString());
/*      */       }
/*  537 */       this.prof = (sp - price) * sli;
/*      */     }
/*      */   }
/*      */   
/*  541 */   LinkedList<pl> k9 = new LinkedList<>();
/*      */   
/*  543 */   LinkedList<String> kh245dggh = new LinkedList<>();
/*      */   
/*      */   private void u90() {
/*  546 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/*  547 */     final DefaultTableModel model = (DefaultTableModel)this.Al09.getModel();
/*  548 */     ref.orderByChild("shop_id").equalTo(this.hjkouyth.getText()).addChildEventListener(new ChildEventListener()
/*      */         {
/*      */           public void onChildAdded(DataSnapshot ds, String string) {
/*  551 */             String name = ds.child("name").getValue().toString().toLowerCase();
/*  552 */             String bcd = ds.child("barcode").getValue().toString().toLowerCase();
/*  553 */             String sid = ds.child("shop_id").getValue().toString().toLowerCase();
/*  554 */             int price = Integer.parseInt(ds.child("price").getValue().toString().toLowerCase());
/*  555 */             int sp = Integer.parseInt(ds.child("salesprice").getValue().toString());
/*  556 */             int sli = 0;
/*  557 */             if (ds.hasChild("soldItems")) {
/*  558 */               sli = Integer.parseInt(ds.child("soldItems").getValue().toString());
/*      */             }
/*  560 */             hjklout678.this.k9.add(new hjklout678.pl(ds));
/*  561 */             hjklout678.this.kh245dggh.add(name + "-" + bcd + "-" + sid);
/*  562 */             hjklout678.this.p += sli * (sp - price);
/*  563 */             hjklout678.this.Alm89.setText("" + hjklout678.this.p);
/*  564 */             Object[] row = { name, bcd, sid, Integer.valueOf(sli * (sp - price)) };
/*  565 */             model.addRow(row);
/*      */           }
/*      */ 
/*      */           
/*      */           public void onChildChanged(DataSnapshot ds, String string) {
/*  570 */             String name = ds.child("name").getValue().toString().toLowerCase();
/*  571 */             String bcd = ds.child("barcode").getValue().toString().toLowerCase();
/*  572 */             String sid = ds.child("shop_id").getValue().toString().toLowerCase();
/*  573 */             int sp = Integer.parseInt(ds.child("salesprice").getValue().toString());
/*  574 */             int sli = 0;
/*  575 */             if (ds.hasChild("soldItems")) {
/*  576 */               sli = Integer.parseInt(ds.child("soldItems").getValue().toString());
/*      */             }
/*  578 */             int index = hjklout678.this.kh245dggh.indexOf(name + "-" + bcd + "-" + sid);
/*  579 */             if (index >= 0) {
/*  580 */               hjklout678.this.p = 0;
/*  581 */               hjklout678.this.k9.remove(index);
/*  582 */               hjklout678.this.k9.add(index, new hjklout678.pl(ds));
/*  583 */               DefaultTableModel model = (DefaultTableModel)hjklout678.this.Al09.getModel();
/*  584 */               model.setRowCount(0);
/*  585 */               for (hjklout678.pl plist : hjklout678.this.k9) {
/*  586 */                 Object[] row = { plist.name, plist.barcode, plist.shop_id, Integer.valueOf(plist.prof) };
/*  587 */                 model.addRow(row);
/*  588 */                 hjklout678.this.p += plist.prof;
/*  589 */                 hjklout678.this.Alm89.setText("" + hjklout678.this.p);
/*      */               } 
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildRemoved(DataSnapshot ds) {
/*  598 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */ 
/*      */           
/*      */           public void onChildMoved(DataSnapshot ds, String string) {
/*  603 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/*  608 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void filter(String query) {
/*  614 */     DefaultTableModel model = (DefaultTableModel)this.Al09.getModel();
/*  615 */     TableRowSorter<DefaultTableModel> tr = new TableRowSorter<>(model);
/*  616 */     this.Al09.setRowSorter((RowSorter)tr);
/*  617 */     tr.setRowFilter(RowFilter.regexFilter(query, new int[0]));
/*  618 */     int sum = 0;
/*  619 */     for (int i = 0; i < this.Al09.getRowCount(); i++) {
/*  620 */       sum += Integer.parseInt(this.Al09.getValueAt(i, 3).toString().trim());
/*      */     }
/*  622 */     this.Alm89.setText("" + sum);
/*      */   }
/*      */   
/*      */   private void u9(boolean b) {
/*  626 */     this.add_salesman_name.setVisible(b);
/*  627 */     this.jdsfkh123.setVisible(b);
/*  628 */     this.dd4.setVisible(b);
/*  629 */     this.add_salesman_cont.setVisible(b);
/*  630 */     this.ds23.setVisible(b);
/*  631 */     this.add_salesman_comp.setVisible(b);
/*  632 */     this.aslkol.setVisible(b);
/*      */   }
/*      */   
/*  635 */   sjdkf12 bref = new sjdkf12();
/*      */ 
/*      */   
/*      */   private CardLayout cardlayout;
/*      */ 
/*      */   
/*      */   private boolean wide = true;
/*      */   
/*      */   boolean initAdd = true;
/*      */ 
/*      */   
/*      */   private void initComponents() {
/*  647 */     this.klop7876 = new JPanel();
/*  648 */     this.hj760 = new JPanel();
/*  649 */     this.jLabel6 = new JLabel();
/*  650 */     this.setting_icon = new JLabel();
/*  651 */     this.menu_icon = new JLabel();
/*  652 */     this.internet_Icon = new JLabel();
/*  653 */     this.oo_icon = new JLabel();
/*  654 */     this.jk90 = new JPanel();
/*  655 */     this.rtrexxgfd88 = new JLabel();
/*  656 */     this.ytyfytrf = new JLabel();
/*  657 */     this.hjgfdrdtfgyg = new JLabel();
/*  658 */     this.hgfdesSS = new JLabel();
/*  659 */     this.ftfrtrs = new JLabel();
/*  660 */     this.ytyrtrdfy = new JLabel();
/*  661 */     this.ohgft = new JLabel();
/*  662 */     this.jhjgfgdgghggy = new JLabel();
/*  663 */     this.sawdwaQEW = new JLabel();
/*  664 */     this.klo09812j = new JPanel();
/*  665 */     this.jklop = new JPanel();
/*  666 */     this.jLabel1 = new JLabel();
/*  667 */     this.hgh7tyyg8 = new JTextField();
/*  668 */     this.jLabel36 = new JLabel();
/*  669 */     this.uuhhhu767tygu = new JLabel();
/*  670 */     this.jLabel38 = new JLabel();
/*  671 */     this.kjhjhghjjh979 = new JLabel();
/*  672 */     this.jLabel40 = new JLabel();
/*  673 */     this.yuyftuyg7657g = new JLabel();
/*  674 */     this.jLabel42 = new JLabel();
/*  675 */     this.rtee4w56 = new JLabel();
/*  676 */     this.jLabel44 = new JLabel();
/*  677 */     this.tyr56eytr6rdfdy = new JLabel();
/*  678 */     this.jLabel46 = new JLabel();
/*  679 */     this.tree4wet6e = new JLabel();
/*  680 */     this.jButton26 = new JButton();
/*  681 */     this.re4w35e = new JComboBox<>();
/*  682 */     this.DEL_KEY = new JLabel();
/*  683 */     this.del_shopid = new JLabel();
/*  684 */     this.kloup = new JPanel();
/*  685 */     this.header = new JPanel();
/*  686 */     this.jLabel19 = new JLabel();
/*  687 */     this.jLabel24 = new JLabel();
/*  688 */     this.jPanel2 = new JPanel();
/*  689 */     this.search_order_icon = new JLabel();
/*  690 */     this.Au = new JPanel();
/*  691 */     this.o1_id6 = new JLabel();
/*  692 */     this.o1_p6 = new JLabel();
/*  693 */     this.jButton10 = new JButton();
/*  694 */     this.jButton20 = new JButton();
/*  695 */     this.aB = new JPanel();
/*  696 */     this.o1_id5 = new JLabel();
/*  697 */     this.o1_p5 = new JLabel();
/*  698 */     this.jButton9 = new JButton();
/*  699 */     this.jButton19 = new JButton();
/*  700 */     this.o_u5 = new JPanel();
/*  701 */     this.aA = new JLabel();
/*  702 */     this.o1_p4 = new JLabel();
/*  703 */     this.jButton8 = new JButton();
/*  704 */     this.jButton18 = new JButton();
/*  705 */     this.sdfhyiuwae348628sdh = new JPanel();
/*  706 */     this.o1_id3 = new JLabel();
/*  707 */     this.o1_p3 = new JLabel();
/*  708 */     this.jButton7 = new JButton();
/*  709 */     this.jButton17 = new JButton();
/*  710 */     this.yutuytfjhgy = new JPanel();
/*  711 */     this.o1_id2 = new JLabel();
/*  712 */     this.o1_p2 = new JLabel();
/*  713 */     this.jButton6 = new JButton();
/*  714 */     this.jButton13 = new JButton();
/*  715 */     this.gtytfhgyg = new JPanel();
/*  716 */     this.o1_id1 = new JLabel();
/*  717 */     this.o1_p1 = new JLabel();
/*  718 */     this.jButton5 = new JButton();
/*  719 */     this.jButton12 = new JButton();
/*  720 */     this.ytyg = new JPanel();
/*  721 */     this.o1_id = new JLabel();
/*  722 */     this.o1_p = new JLabel();
/*  723 */     this.jButton1 = new JButton();
/*  724 */     this.jButton2 = new JButton();
/*  725 */     this.Al = new JPanel();
/*  726 */     this.o1_id17 = new JLabel();
/*  727 */     this.o1_p17 = new JLabel();
/*  728 */     this.jButton21 = new JButton();
/*  729 */     this.jButton22 = new JButton();
/*  730 */     this.Ak = new JPanel();
/*  731 */     this.o1_id18 = new JLabel();
/*  732 */     this.o1_p18 = new JLabel();
/*  733 */     this.jButton23 = new JButton();
/*  734 */     this.jButton24 = new JButton();
/*  735 */     this.AKLJ = new JPanel();
/*  736 */     this.o1_id19 = new JLabel();
/*  737 */     this.o1_p19 = new JLabel();
/*  738 */     this.jButton25 = new JButton();
/*  739 */     this.jButton27 = new JButton();
/*  740 */     this.dlkop = new JPanel();
/*  741 */     this.KLO87 = new JButton();
/*  742 */     this.jButton16 = new JButton();
/*  743 */     this.jLabel39 = new JLabel();
/*  744 */     this.jButton15 = new JButton();
/*  745 */     this.jLabel41 = new JLabel();
/*  746 */     this.jLabel2 = new JLabel();
/*  747 */     this.jLabel15 = new JLabel();
/*  748 */     this.AK90 = new JTextField();
/*  749 */     this.jButton3 = new JButton();
/*  750 */     this.hjkouyth = new JLabel();
/*  751 */     this.jButton4 = new JButton();
/*  752 */     this.jButton29 = new JButton();
/*  753 */     this.jLabel16 = new JLabel();
/*  754 */     this.skldf821 = new JTextField();
/*  755 */     this.jButton30 = new JButton();
/*  756 */     this.jLabel29 = new JLabel();
/*  757 */     this.klopdfger67 = new JPanel();
/*  758 */     this.jButton14 = new JButton();
/*  759 */     this.Aa = new TextField();
/*  760 */     this.jPanel1 = new JPanel();
/*  761 */     this.dsfh2 = new JLabel();
/*  762 */     this.hhhyt56trt = new JLabel();
/*  763 */     this.cart_x1 = new JLabel();
/*  764 */     this.hju = new JTextField();
/*  765 */     this.jPanel4 = new JPanel();
/*  766 */     this.sye213a = new JLabel();
/*  767 */     this.w347edt = new JLabel();
/*  768 */     this.cart_x2 = new JLabel();
/*  769 */     this.z = new JTextField();
/*  770 */     this.jPanel5 = new JPanel();
/*  771 */     this.kjshd1235jk = new JLabel();
/*  772 */     this.gghyted67 = new JLabel();
/*  773 */     this.cart_x3 = new JLabel();
/*  774 */     this.k = new JTextField();
/*  775 */     this.jPanel6 = new JPanel();
/*  776 */     this.sdjkfh1287 = new JLabel();
/*  777 */     this.cart_lbl4 = new JLabel();
/*  778 */     this.cart_x4 = new JLabel();
/*  779 */     this.ghyrtioy = new JTextField();
/*  780 */     this.jPanel7 = new JPanel();
/*  781 */     this.dfsk980 = new JLabel();
/*  782 */     this.klopf56 = new JLabel();
/*  783 */     this.cart_x5 = new JLabel();
/*  784 */     this.ggsd579 = new JTextField();
/*  785 */     this.jPanel8 = new JPanel();
/*  786 */     this.dfskjO98 = new JLabel();
/*  787 */     this.ds214jasd3 = new JLabel();
/*  788 */     this.cart_x6 = new JLabel();
/*  789 */     this.cart_c6 = new JTextField();
/*  790 */     this.jPanel9 = new JPanel();
/*  791 */     this.sjkaA8 = new JLabel();
/*  792 */     this.dsh2348662 = new JLabel();
/*  793 */     this.cart_x7 = new JLabel();
/*  794 */     this.cart_c7 = new JTextField();
/*  795 */     this.jPanel10 = new JPanel();
/*  796 */     this.dsjhA9 = new JLabel();
/*  797 */     this.fhjg667865k = new JLabel();
/*  798 */     this.cart_x8 = new JLabel();
/*  799 */     this.ghjuyto90 = new JTextField();
/*  800 */     this.jdskfh132ds = new JPanel();
/*  801 */     this.jLabel4 = new JLabel();
/*  802 */     this.jLabel5 = new JLabel();
/*  803 */     this.hjyt = new JComboBox<>();
/*  804 */     this.jLabel8 = new JLabel();
/*  805 */     this.hyt57fg = new JComboBox<>();
/*  806 */     this.jLabel50 = new JLabel();
/*  807 */     this.jLabel51 = new JLabel();
/*  808 */     this.jLabel52 = new JLabel();
/*  809 */     this.jLabel53 = new JLabel();
/*  810 */     this.WWEQSD = new JTextField();
/*  811 */     this.asdew = new JTextField();
/*  812 */     this.Wad = new JTextField();
/*  813 */     this.Adrtfgh = new JTextField();
/*  814 */     this.dfsh34hsd = new JButton();
/*  815 */     this.sdfh129sd = new JTextField();
/*  816 */     this.ksdfh345_s = new JButton();
/*  817 */     this.jLabel11 = new JLabel();
/*  818 */     this.jLabel9 = new JLabel();
/*  819 */     this.WWa = new JTextField();
/*  820 */     this.Wasdf = new JTextField();
/*  821 */     this.hjy65449 = new JTextField();
/*  822 */     this.jButton11 = new JButton();
/*  823 */     this.sfdjkh12940 = new JLabel();
/*  824 */     this.jLabel14 = new JLabel();
/*  825 */     this.vbd = new JPanel();
/*  826 */     this.jLabel3 = new JLabel();
/*  827 */     this.sdfhk89076 = new JLabel();
/*  828 */     this.dsfljslKIOP = new JButton();
/*  829 */     this.jLabel25 = new JLabel();
/*  830 */     this.dslkfjA123 = new JTextField();
/*  831 */     this.dfhskj123456 = new JTextField();
/*  832 */     this.djskfLop = new JButton();
/*  833 */     this.asdlJklo = new JComboBox<>();
/*  834 */     this.jLabel7 = new JLabel();
/*  835 */     this.jLabel12 = new JLabel();
/*  836 */     this.jLabel13 = new JLabel();
/*  837 */     this.Amklop = new JTextField();
/*  838 */     this.xdfj12 = new JTextField();
/*  839 */     this.dsfklop = new JButton();
/*  840 */     this.fdshQo = new JButton();
/*  841 */     this.sdfjho90 = new JLabel();
/*  842 */     this.weiuyr78GHJ = new JPanel();
/*  843 */     this.Ajklou12 = new JTextField();
/*  844 */     this.jklOPhsklop = new JTextField();
/*  845 */     this.JKLOPas1234 = new JLabel();
/*  846 */     this.klopas234 = new JTextField();
/*  847 */     this.Nmklobvg = new JTextField();
/*  848 */     this.Nkiopgty67i = new JTextField();
/*  849 */     this.aJKIy786g = new JTextField();
/*  850 */     this.JHYULOP = new JTextField();
/*  851 */     this.AJKLOP = new JButton();
/*  852 */     this.AGHY = new JButton();
/*  853 */     this.XAa = new JButton();
/*  854 */     this.JKlopwr = new JTextField();
/*  855 */     this.jLabel30 = new JLabel();
/*  856 */     this.jLabel31 = new JLabel();
/*  857 */     this.jLabel32 = new JLabel();
/*  858 */     this.jLabel33 = new JLabel();
/*  859 */     this.jLabel34 = new JLabel();
/*  860 */     this.jLabel35 = new JLabel();
/*  861 */     this.jLabel18 = new JLabel();
/*  862 */     this.jLabel21 = new JLabel();
/*  863 */     this.jLabel47 = new JLabel();
/*  864 */     this.sdjlop = new JComboBox<>();
/*  865 */     this.jLabel10 = new JLabel();
/*  866 */     this.Jkiop90875sad = new JTextField();
/*  867 */     this.Ajklo = new JLabel();
/*  868 */     this.Aklop = new JPanel();
/*  869 */     this.sdfjkhl12jh4 = new JPanel();
/*  870 */     this.jklop0 = new JLabel();
/*  871 */     this.add_salesman_name = new JLabel();
/*  872 */     this.dd4 = new JTextField();
/*  873 */     this.add_salesman_cont = new JLabel();
/*  874 */     this.ds23 = new JTextField();
/*  875 */     this.add_salesman_comp = new JLabel();
/*  876 */     this.aslkol = new JTextField();
/*  877 */     this.jdsfkh123 = new JButton();
/*  878 */     this.jLabel22 = new JLabel();
/*  879 */     this.jLabel20 = new JLabel();
/*  880 */     this.AKLMH7896yh = new JComboBox<>();
/*  881 */     this.hjllop = new JTextField();
/*  882 */     this.jLabel26 = new JLabel();
/*  883 */     this.mn8 = new JLabel();
/*  884 */     this.jLabel28 = new JLabel();
/*  885 */     this.mk0 = new JLabel();
/*  886 */     this.jLabel49 = new JLabel();
/*  887 */     this.nk9 = new JLabel();
/*  888 */     this.alkop12 = new JPanel();
/*  889 */     this.jLabel27 = new JLabel();
/*  890 */     this.jLabel48 = new JLabel();
/*  891 */     this.sd9 = new JTextField();
/*  892 */     this.jScrollPane1 = new JScrollPane();
/*  893 */     this.Al09 = new JTable();
/*  894 */     this.jLabel23 = new JLabel();
/*  895 */     this.Alm89 = new JLabel();
/*  896 */     this.jButton28 = new JButton();
/*  897 */     this.QAs = new JPanel();
/*  898 */     this.header1 = new JPanel();
/*  899 */     this.jLabel37 = new JLabel();
/*  900 */     this.jLabel43 = new JLabel();
/*  901 */     this.prod_sort_icon = new JLabel();
/*  902 */     this.jLabel56 = new JLabel();
/*  903 */     this.search_order_icon1 = new JLabel();
/*  904 */     this.jLabel17 = new JLabel();
/*  905 */     this.o_u8 = new JPanel();
/*  906 */     this.o1_id7 = new JLabel();
/*  907 */     this.o1_on7 = new JLabel();
/*  908 */     this.o1_oq7 = new JLabel();
/*  909 */     this.o1_p7 = new JLabel();
/*  910 */     this.inv_pp7 = new JLabel();
/*  911 */     this.o_u9 = new JPanel();
/*  912 */     this.o1_id8 = new JLabel();
/*  913 */     this.o1_on8 = new JLabel();
/*  914 */     this.o1_oq8 = new JLabel();
/*  915 */     this.o1_p8 = new JLabel();
/*  916 */     this.inv_pp6 = new JLabel();
/*  917 */     this.o_u10 = new JPanel();
/*  918 */     this.o1_id9 = new JLabel();
/*  919 */     this.o1_on9 = new JLabel();
/*  920 */     this.o1_oq9 = new JLabel();
/*  921 */     this.o1_p9 = new JLabel();
/*  922 */     this.inv_pp5 = new JLabel();
/*  923 */     this.o_u11 = new JPanel();
/*  924 */     this.o1_id10 = new JLabel();
/*  925 */     this.o1_on10 = new JLabel();
/*  926 */     this.o1_oq10 = new JLabel();
/*  927 */     this.o1_p10 = new JLabel();
/*  928 */     this.inv_pp4 = new JLabel();
/*  929 */     this.o_u12 = new JPanel();
/*  930 */     this.o1_id11 = new JLabel();
/*  931 */     this.o1_on11 = new JLabel();
/*  932 */     this.o1_oq11 = new JLabel();
/*  933 */     this.o1_p11 = new JLabel();
/*  934 */     this.inv_pp3 = new JLabel();
/*  935 */     this.o_u13 = new JPanel();
/*  936 */     this.o1_id12 = new JLabel();
/*  937 */     this.o1_on12 = new JLabel();
/*  938 */     this.o1_oq12 = new JLabel();
/*  939 */     this.o1_p12 = new JLabel();
/*  940 */     this.inv_pp2 = new JLabel();
/*  941 */     this.o_u14 = new JPanel();
/*  942 */     this.o1_id13 = new JLabel();
/*  943 */     this.o1_on13 = new JLabel();
/*  944 */     this.o1_oq13 = new JLabel();
/*  945 */     this.o1_p13 = new JLabel();
/*  946 */     this.inv_pp1 = new JLabel();
/*  947 */     this.o_u15 = new JPanel();
/*  948 */     this.o1_id14 = new JLabel();
/*  949 */     this.o1_on14 = new JLabel();
/*  950 */     this.o1_oq14 = new JLabel();
/*  951 */     this.o1_p14 = new JLabel();
/*  952 */     this.inv_pp8 = new JLabel();
/*  953 */     this.o_u16 = new JPanel();
/*  954 */     this.o1_id15 = new JLabel();
/*  955 */     this.o1_on15 = new JLabel();
/*  956 */     this.o1_oq15 = new JLabel();
/*  957 */     this.o1_p15 = new JLabel();
/*  958 */     this.inv_pp9 = new JLabel();
/*  959 */     this.o_u17 = new JPanel();
/*  960 */     this.o1_id16 = new JLabel();
/*  961 */     this.o1_on16 = new JLabel();
/*  962 */     this.o1_oq16 = new JLabel();
/*  963 */     this.o1_p16 = new JLabel();
/*  964 */     this.inv_pp10 = new JLabel();
/*      */     
/*  966 */     setDefaultCloseOperation(3);
/*  967 */     setTitle("Easy Shop Managment System");
/*  968 */     setMinimumSize(new Dimension(1190, 695));
/*      */     
/*  970 */     this.klop7876.setBackground(new Color(255, 255, 255));
/*  971 */     this.klop7876.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/*  973 */     this.hj760.setBackground(new Color(102, 102, 102));
/*      */     
/*  975 */     this.jLabel6.setFont(new Font("Tahoma", 0, 24));
/*  976 */     this.jLabel6.setForeground(new Color(255, 255, 255));
/*  977 */     this.jLabel6.setText("EZ SHOP");
/*      */     
/*  979 */     this.setting_icon.setIcon(new ImageIcon("C:\\Users\\kaka\\Documents\\NetBeansProjects\\EasyShop\\bin\\Icons\\icons8-gear-50.png"));
/*  980 */     this.setting_icon.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*  982 */             hjklout678.this.setting_iconMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/*  986 */     this.menu_icon.setText("jLabel43");
/*  987 */     this.menu_icon.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*  989 */             hjklout678.this.menu_iconMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/*  993 */     this.internet_Icon.setIcon(new ImageIcon("C:\\Users\\kaka\\Documents\\NetBeansProjects\\EasyShop\\bin\\Icons\\nointernet.png"));
/*      */     
/*  995 */     this.oo_icon.setIcon(new ImageIcon("C:\\Users\\kaka\\Documents\\NetBeansProjects\\EasyShop\\bin\\Icons\\noonlineorder.png"));
/*      */     
/*  997 */     GroupLayout hj760Layout = new GroupLayout(this.hj760);
/*  998 */     this.hj760.setLayout(hj760Layout);
/*  999 */     hj760Layout.setHorizontalGroup(hj760Layout
/* 1000 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1001 */         .addGroup(hj760Layout.createSequentialGroup()
/* 1002 */           .addGroup(hj760Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1003 */             .addComponent(this.jLabel6, -2, 172, -2)
/* 1004 */             .addComponent(this.menu_icon, -2, 54, -2))
/* 1005 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 1006 */           .addComponent(this.oo_icon)
/* 1007 */           .addGap(18, 18, 18)
/* 1008 */           .addComponent(this.internet_Icon)
/* 1009 */           .addGap(18, 18, 18)
/* 1010 */           .addComponent(this.setting_icon)
/* 1011 */           .addGap(33, 33, 33)));
/*      */     
/* 1013 */     hj760Layout.setVerticalGroup(hj760Layout
/* 1014 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1015 */         .addGroup(hj760Layout.createSequentialGroup()
/* 1016 */           .addComponent(this.jLabel6, -2, 29, -2)
/* 1017 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1018 */           .addComponent(this.menu_icon)
/* 1019 */           .addContainerGap(-1, 32767))
/* 1020 */         .addGroup(GroupLayout.Alignment.TRAILING, hj760Layout.createSequentialGroup()
/* 1021 */           .addGap(0, 3, 32767)
/* 1022 */           .addGroup(hj760Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 1023 */             .addComponent(this.oo_icon)
/* 1024 */             .addGroup(hj760Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1025 */               .addComponent(this.setting_icon, -2, 44, -2)
/* 1026 */               .addComponent(this.internet_Icon, -2, 0, 32767)))
/* 1027 */           .addGap(33, 33, 33)));
/*      */ 
/*      */     
/* 1030 */     this.jk90.setBackground(new Color(102, 102, 102));
/*      */     
/* 1032 */     this.rtrexxgfd88.setBackground(new Color(255, 255, 255));
/* 1033 */     this.rtrexxgfd88.setFont(new Font("Tahoma", 0, 18));
/* 1034 */     this.rtrexxgfd88.setForeground(new Color(255, 255, 255));
/* 1035 */     this.rtrexxgfd88.setText(" DELETE ITEMS");
/* 1036 */     this.rtrexxgfd88.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1038 */             hjklout678.this.rtrexxgfd88MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1042 */     this.ytyfytrf.setBackground(new Color(255, 255, 255));
/* 1043 */     this.ytyfytrf.setFont(new Font("Tahoma", 0, 18));
/* 1044 */     this.ytyfytrf.setForeground(new Color(255, 255, 255));
/* 1045 */     this.ytyfytrf.setText(" SALES MANS");
/* 1046 */     this.ytyfytrf.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1048 */             hjklout678.this.ytyfytrfMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1052 */     this.hjgfdrdtfgyg.setBackground(new Color(255, 255, 255));
/* 1053 */     this.hjgfdrdtfgyg.setFont(new Font("Tahoma", 0, 18));
/* 1054 */     this.hjgfdrdtfgyg.setForeground(new Color(255, 255, 255));
/* 1055 */     this.hjgfdrdtfgyg.setText(" ADD ITEM");
/* 1056 */     this.hjgfdrdtfgyg.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1058 */             hjklout678.this.hjgfdrdtfgygMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1062 */     this.hgfdesSS.setBackground(new Color(255, 255, 255));
/* 1063 */     this.hgfdesSS.setFont(new Font("Tahoma", 0, 18));
/* 1064 */     this.hgfdesSS.setForeground(new Color(255, 255, 255));
/* 1065 */     this.hgfdesSS.setText(" UPDATE ITEMS");
/* 1066 */     this.hgfdesSS.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1068 */             hjklout678.this.hgfdesSSMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1072 */     this.ftfrtrs.setBackground(new Color(255, 255, 255));
/* 1073 */     this.ftfrtrs.setFont(new Font("Tahoma", 0, 18));
/* 1074 */     this.ftfrtrs.setForeground(new Color(255, 255, 255));
/* 1075 */     this.ftfrtrs.setText(" CART");
/* 1076 */     this.ftfrtrs.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1078 */             hjklout678.this.ftfrtrsMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1082 */     this.ytyrtrdfy.setFont(new Font("Tahoma", 0, 18));
/* 1083 */     this.ytyrtrdfy.setForeground(new Color(255, 255, 255));
/* 1084 */     this.ytyrtrdfy.setText(" PROFT/LOSS");
/* 1085 */     this.ytyrtrdfy.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1087 */             hjklout678.this.ytyrtrdfyMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1091 */     this.ohgft.setFont(new Font("Tahoma", 0, 18));
/* 1092 */     this.ohgft.setForeground(new Color(255, 255, 255));
/* 1093 */     this.ohgft.setText(" Online Orders");
/* 1094 */     this.ohgft.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1096 */             hjklout678.this.ohgftMouseClicked(evt);
/*      */           }
/*      */           public void mouseEntered(MouseEvent evt) {
/* 1099 */             hjklout678.this.ohgftMouseEntered(evt);
/*      */           }
/*      */           public void mouseExited(MouseEvent evt) {
/* 1102 */             hjklout678.this.ohgftMouseExited(evt);
/*      */           }
/*      */         });
/*      */     
/* 1106 */     this.jhjgfgdgghggy.setFont(new Font("Tahoma", 0, 18));
/* 1107 */     this.jhjgfgdgghggy.setForeground(new Color(255, 255, 255));
/* 1108 */     this.jhjgfgdgghggy.setText("  Inventory");
/* 1109 */     this.jhjgfgdgghggy.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1111 */             hjklout678.this.jhjgfgdgghggyMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1115 */     this.sawdwaQEW.setFont(new Font("Tahoma", 0, 18));
/* 1116 */     this.sawdwaQEW.setForeground(new Color(255, 255, 255));
/* 1117 */     this.sawdwaQEW.setText(" Loan ");
/* 1118 */     this.sawdwaQEW.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1120 */             hjklout678.this.sawdwaQEWMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1124 */     GroupLayout jk90Layout = new GroupLayout(this.jk90);
/* 1125 */     this.jk90.setLayout(jk90Layout);
/* 1126 */     jk90Layout.setHorizontalGroup(jk90Layout
/* 1127 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1128 */         .addComponent(this.hgfdesSS, -1, 198, 32767)
/* 1129 */         .addComponent(this.rtrexxgfd88, -1, -1, 32767)
/* 1130 */         .addComponent(this.ftfrtrs, -1, -1, 32767)
/* 1131 */         .addComponent(this.ytyfytrf, -1, -1, 32767)
/* 1132 */         .addComponent(this.ytyrtrdfy, -1, -1, 32767)
/* 1133 */         .addComponent(this.ohgft, -1, -1, 32767)
/* 1134 */         .addComponent(this.hjgfdrdtfgyg, -1, -1, 32767)
/* 1135 */         .addComponent(this.jhjgfgdgghggy, -1, -1, 32767)
/* 1136 */         .addComponent(this.sawdwaQEW, -1, -1, 32767));
/*      */     
/* 1138 */     jk90Layout.setVerticalGroup(jk90Layout
/* 1139 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1140 */         .addGroup(jk90Layout.createSequentialGroup()
/* 1141 */           .addGap(75, 75, 75)
/* 1142 */           .addComponent(this.ohgft, -2, 50, -2)
/* 1143 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1144 */           .addComponent(this.jhjgfgdgghggy)
/* 1145 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1146 */           .addComponent(this.hjgfdrdtfgyg, -2, 45, -2)
/* 1147 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1148 */           .addComponent(this.hgfdesSS, -2, 50, -2)
/* 1149 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1150 */           .addComponent(this.rtrexxgfd88, -2, 50, -2)
/* 1151 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1152 */           .addComponent(this.ftfrtrs, -2, 50, -2)
/* 1153 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1154 */           .addComponent(this.ytyfytrf, -2, 50, -2)
/* 1155 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1156 */           .addComponent(this.ytyrtrdfy, -2, 50, -2)
/* 1157 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1158 */           .addComponent(this.sawdwaQEW, -2, 52, -2)
/* 1159 */           .addContainerGap(-1, 32767)));
/*      */ 
/*      */     
/* 1162 */     this.klo09812j.setBackground(new Color(255, 255, 255));
/* 1163 */     this.klo09812j.setLayout(new CardLayout());
/*      */     
/* 1165 */     this.jklop.setBackground(new Color(255, 255, 255));
/*      */     
/* 1167 */     this.jLabel1.setBackground(new Color(255, 255, 255));
/* 1168 */     this.jLabel1.setFont(new Font("Tahoma", 0, 18));
/* 1169 */     this.jLabel1.setText("Search");
/*      */     
/* 1171 */     this.hgh7tyyg8.setFont(new Font("Tahoma", 0, 14));
/* 1172 */     this.hgh7tyyg8.setForeground(new Color(153, 153, 153));
/* 1173 */     this.hgh7tyyg8.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 1174 */     this.hgh7tyyg8.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1176 */             hjklout678.this.hgh7tyyg8MouseClicked(evt);
/*      */           }
/*      */         });
/* 1179 */     this.hgh7tyyg8.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1181 */             hjklout678.this.hgh7tyyg8KeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1185 */     this.jLabel36.setFont(new Font("Tahoma", 0, 14));
/* 1186 */     this.jLabel36.setText("Name");
/*      */     
/* 1188 */     this.uuhhhu767tygu.setFont(new Font("Tahoma", 0, 14));
/* 1189 */     this.uuhhhu767tygu.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*      */     
/* 1191 */     this.jLabel38.setFont(new Font("Tahoma", 0, 14));
/* 1192 */     this.jLabel38.setText("Price");
/*      */     
/* 1194 */     this.kjhjhghjjh979.setFont(new Font("Tahoma", 0, 14));
/* 1195 */     this.kjhjhghjjh979.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*      */     
/* 1197 */     this.jLabel40.setFont(new Font("Tahoma", 0, 14));
/* 1198 */     this.jLabel40.setText("Available Quant.");
/*      */     
/* 1200 */     this.yuyftuyg7657g.setFont(new Font("Tahoma", 0, 14));
/* 1201 */     this.yuyftuyg7657g.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*      */     
/* 1203 */     this.jLabel42.setFont(new Font("Tahoma", 0, 14));
/* 1204 */     this.jLabel42.setText("Category ");
/*      */     
/* 1206 */     this.rtee4w56.setFont(new Font("Tahoma", 0, 14));
/* 1207 */     this.rtee4w56.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*      */     
/* 1209 */     this.jLabel44.setFont(new Font("Tahoma", 0, 14));
/* 1210 */     this.jLabel44.setText("Barcode");
/*      */     
/* 1212 */     this.tyr56eytr6rdfdy.setFont(new Font("Tahoma", 0, 14));
/* 1213 */     this.tyr56eytr6rdfdy.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*      */     
/* 1215 */     this.jLabel46.setFont(new Font("Tahoma", 0, 14));
/* 1216 */     this.jLabel46.setText("Available At");
/*      */     
/* 1218 */     this.tree4wet6e.setFont(new Font("Tahoma", 0, 14));
/* 1219 */     this.tree4wet6e.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*      */     
/* 1221 */     this.jButton26.setText("Delete Product");
/* 1222 */     this.jButton26.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1224 */             hjklout678.this.jButton26MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1228 */     this.re4w35e.setModel(new DefaultComboBoxModel<>(new String[] { "By Barcode", "By Name" }));
/* 1229 */     this.re4w35e.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1231 */             hjklout678.this.re4w35eActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1235 */     GroupLayout jklopLayout = new GroupLayout(this.jklop);
/* 1236 */     this.jklop.setLayout(jklopLayout);
/* 1237 */     jklopLayout.setHorizontalGroup(jklopLayout
/* 1238 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1239 */         .addGroup(jklopLayout.createSequentialGroup()
/* 1240 */           .addGap(71, 71, 71)
/* 1241 */           .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 1242 */             .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1243 */               .addGroup(jklopLayout.createSequentialGroup()
/* 1244 */                 .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1245 */                   .addComponent(this.jLabel36, -2, 100, -2)
/* 1246 */                   .addComponent(this.jLabel38, -2, 100, -2)
/* 1247 */                   .addComponent(this.jLabel44, GroupLayout.Alignment.TRAILING, -2, 100, -2))
/* 1248 */                 .addGap(28, 28, 28)
/* 1249 */                 .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1250 */                   .addComponent(this.uuhhhu767tygu, -2, 159, -2)
/* 1251 */                   .addComponent(this.yuyftuyg7657g, -2, 159, -2)
/* 1252 */                   .addComponent(this.kjhjhghjjh979, -2, 159, -2))
/* 1253 */                 .addGap(35, 35, 35)
/* 1254 */                 .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1255 */                   .addComponent(this.jLabel42, -2, 100, -2)
/* 1256 */                   .addComponent(this.jLabel40, -2, 100, -2)
/* 1257 */                   .addComponent(this.jLabel46, -2, 100, -2))
/* 1258 */                 .addGap(35, 35, 35)
/* 1259 */                 .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1260 */                   .addComponent(this.rtee4w56, -2, 187, -2)
/* 1261 */                   .addComponent(this.tyr56eytr6rdfdy, -2, 187, -2)
/* 1262 */                   .addComponent(this.tree4wet6e, -2, 187, -2)))
/* 1263 */               .addGroup(jklopLayout.createSequentialGroup()
/* 1264 */                 .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1265 */                   .addComponent(this.DEL_KEY, -1, 169, 32767)
/* 1266 */                   .addComponent(this.del_shopid, -1, -1, 32767))
/* 1267 */                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 1268 */                 .addComponent(this.jButton26, -2, 187, -2)))
/* 1269 */             .addGroup(jklopLayout.createSequentialGroup()
/* 1270 */               .addComponent(this.jLabel1, -2, 70, -2)
/* 1271 */               .addGap(18, 18, 18)
/* 1272 */               .addComponent(this.re4w35e, -2, 163, -2)
/* 1273 */               .addGap(34, 34, 34)
/* 1274 */               .addComponent(this.hgh7tyyg8, -2, 367, -2)))
/* 1275 */           .addContainerGap(470, 32767)));
/*      */     
/* 1277 */     jklopLayout.setVerticalGroup(jklopLayout
/* 1278 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1279 */         .addGroup(jklopLayout.createSequentialGroup()
/* 1280 */           .addGap(58, 58, 58)
/* 1281 */           .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 1282 */             .addComponent(this.jLabel1)
/* 1283 */             .addComponent(this.hgh7tyyg8)
/* 1284 */             .addComponent(this.re4w35e, -1, 37, 32767))
/* 1285 */           .addGap(54, 54, 54)
/* 1286 */           .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1287 */             .addComponent(this.jLabel36, -2, 30, -2)
/* 1288 */             .addComponent(this.uuhhhu767tygu, -2, 30, -2)
/* 1289 */             .addComponent(this.jLabel42, -2, 30, -2)
/* 1290 */             .addComponent(this.rtee4w56, -2, 30, -2))
/* 1291 */           .addGap(46, 46, 46)
/* 1292 */           .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1293 */             .addComponent(this.jLabel38, -2, 30, -2)
/* 1294 */             .addComponent(this.yuyftuyg7657g, -2, 30, -2)
/* 1295 */             .addComponent(this.jLabel40, -2, 30, -2)
/* 1296 */             .addComponent(this.tyr56eytr6rdfdy, -2, 30, -2))
/* 1297 */           .addGap(47, 47, 47)
/* 1298 */           .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1299 */             .addComponent(this.jLabel44, -2, 30, -2)
/* 1300 */             .addComponent(this.kjhjhghjjh979, -2, 30, -2)
/* 1301 */             .addComponent(this.jLabel46, -2, 30, -2)
/* 1302 */             .addComponent(this.tree4wet6e, -2, 30, -2))
/* 1303 */           .addGap(41, 41, 41)
/* 1304 */           .addGroup(jklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1305 */             .addComponent(this.jButton26, -2, 30, -2)
/* 1306 */             .addComponent(this.DEL_KEY, -2, 30, -2))
/* 1307 */           .addGap(18, 18, 18)
/* 1308 */           .addComponent(this.del_shopid, -2, 33, -2)
/* 1309 */           .addContainerGap(120, 32767)));
/*      */ 
/*      */     
/* 1312 */     this.klo09812j.add(this.jklop, "searchNDel");
/*      */     
/* 1314 */     this.kloup.setBackground(new Color(255, 255, 255));
/* 1315 */     this.kloup.setFocusable(false);
/* 1316 */     this.kloup.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1318 */             hjklout678.this.kloupMouseClicked(evt);
/*      */           }
/*      */         });
/* 1321 */     this.kloup.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1323 */             hjklout678.this.kloupKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1327 */     this.jLabel19.setFont(new Font("Tahoma", 0, 16));
/* 1328 */     this.jLabel19.setText("Order ID");
/*      */     
/* 1330 */     this.jLabel24.setFont(new Font("Tahoma", 0, 16));
/* 1331 */     this.jLabel24.setText("Price");
/*      */     
/* 1333 */     this.search_order_icon.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1335 */             hjklout678.this.search_order_iconMouseClicked(evt);
/*      */           }
/*      */         });
/* 1338 */     this.search_order_icon.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 1340 */             hjklout678.this.search_order_iconKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1344 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 1345 */     this.jPanel2.setLayout(jPanel2Layout);
/* 1346 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout
/* 1347 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1348 */         .addGroup(jPanel2Layout.createSequentialGroup()
/* 1349 */           .addGap(31, 31, 31)
/* 1350 */           .addComponent(this.search_order_icon)
/* 1351 */           .addContainerGap(-1, 32767)));
/*      */     
/* 1353 */     jPanel2Layout.setVerticalGroup(jPanel2Layout
/* 1354 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1355 */         .addComponent(this.search_order_icon, -1, -1, 32767));
/*      */ 
/*      */     
/* 1358 */     GroupLayout headerLayout = new GroupLayout(this.header);
/* 1359 */     this.header.setLayout(headerLayout);
/* 1360 */     headerLayout.setHorizontalGroup(headerLayout
/* 1361 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1362 */         .addGroup(headerLayout.createSequentialGroup()
/* 1363 */           .addGap(20, 20, 20)
/* 1364 */           .addComponent(this.jLabel19, -2, 185, -2)
/* 1365 */           .addGap(110, 110, 110)
/* 1366 */           .addComponent(this.jLabel24, -2, 51, -2)
/* 1367 */           .addGap(334, 334, 334)
/* 1368 */           .addComponent(this.jPanel2, -2, -1, -2)
/* 1369 */           .addContainerGap(-1, 32767)));
/*      */     
/* 1371 */     headerLayout.setVerticalGroup(headerLayout
/* 1372 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1373 */         .addGroup(GroupLayout.Alignment.TRAILING, headerLayout.createSequentialGroup()
/* 1374 */           .addGroup(headerLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 1375 */             .addGroup(headerLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1376 */               .addComponent(this.jLabel24)
/* 1377 */               .addComponent(this.jLabel19, -1, -1, 32767))
/* 1378 */             .addComponent(this.jPanel2, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 1379 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1382 */     this.o1_id6.setFont(new Font("Tahoma", 0, 14));
/* 1383 */     this.o1_id6.setText("jLabel19");
/*      */     
/* 1385 */     this.o1_p6.setFont(new Font("Tahoma", 0, 14));
/* 1386 */     this.o1_p6.setText("jLabel25");
/*      */     
/* 1388 */     this.jButton10.setBackground(new Color(204, 204, 204));
/* 1389 */     this.jButton10.setText("Mark Done");
/* 1390 */     this.jButton10.setFocusPainted(false);
/* 1391 */     this.jButton10.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1393 */             hjklout678.this.jButton10ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1397 */     this.jButton20.setText("Open");
/* 1398 */     this.jButton20.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1400 */             hjklout678.this.jButton20ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1404 */     GroupLayout AuLayout = new GroupLayout(this.Au);
/* 1405 */     this.Au.setLayout(AuLayout);
/* 1406 */     AuLayout.setHorizontalGroup(AuLayout
/* 1407 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1408 */         .addGroup(AuLayout.createSequentialGroup()
/* 1409 */           .addGap(21, 21, 21)
/* 1410 */           .addComponent(this.o1_id6, -2, 184, -2)
/* 1411 */           .addGap(112, 112, 112)
/* 1412 */           .addComponent(this.o1_p6, -2, 62, -2)
/* 1413 */           .addGap(158, 158, 158)
/* 1414 */           .addComponent(this.jButton20, -2, 68, -2)
/* 1415 */           .addGap(143, 143, 143)
/* 1416 */           .addComponent(this.jButton10)
/* 1417 */           .addGap(29, 29, 29)));
/*      */     
/* 1419 */     AuLayout.setVerticalGroup(AuLayout
/* 1420 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1421 */         .addGroup(GroupLayout.Alignment.TRAILING, AuLayout.createSequentialGroup()
/* 1422 */           .addContainerGap()
/* 1423 */           .addGroup(AuLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1424 */             .addComponent(this.o1_id6, -1, -1, 32767)
/* 1425 */             .addComponent(this.o1_p6, -1, -1, 32767)
/* 1426 */             .addComponent(this.jButton10)
/* 1427 */             .addComponent(this.jButton20))
/* 1428 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1431 */     this.o1_id5.setFont(new Font("Tahoma", 0, 14));
/* 1432 */     this.o1_id5.setText("jLabel19");
/*      */     
/* 1434 */     this.o1_p5.setFont(new Font("Tahoma", 0, 14));
/* 1435 */     this.o1_p5.setText("jLabel25");
/*      */     
/* 1437 */     this.jButton9.setBackground(new Color(204, 204, 204));
/* 1438 */     this.jButton9.setText("Mark Done");
/* 1439 */     this.jButton9.setFocusPainted(false);
/* 1440 */     this.jButton9.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1442 */             hjklout678.this.jButton9ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1446 */     this.jButton19.setText("Open");
/* 1447 */     this.jButton19.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1449 */             hjklout678.this.jButton19ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1453 */     GroupLayout aBLayout = new GroupLayout(this.aB);
/* 1454 */     this.aB.setLayout(aBLayout);
/* 1455 */     aBLayout.setHorizontalGroup(aBLayout
/* 1456 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1457 */         .addGroup(aBLayout.createSequentialGroup()
/* 1458 */           .addGap(21, 21, 21)
/* 1459 */           .addComponent(this.o1_id5, -2, 184, -2)
/* 1460 */           .addGap(112, 112, 112)
/* 1461 */           .addComponent(this.o1_p5, -2, 62, -2)
/* 1462 */           .addGap(158, 158, 158)
/* 1463 */           .addComponent(this.jButton19, -2, 67, -2)
/* 1464 */           .addGap(143, 143, 143)
/* 1465 */           .addComponent(this.jButton9)
/* 1466 */           .addGap(29, 29, 29)));
/*      */     
/* 1468 */     aBLayout.setVerticalGroup(aBLayout
/* 1469 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1470 */         .addGroup(GroupLayout.Alignment.TRAILING, aBLayout.createSequentialGroup()
/* 1471 */           .addContainerGap()
/* 1472 */           .addGroup(aBLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1473 */             .addComponent(this.o1_id5, -1, -1, 32767)
/* 1474 */             .addComponent(this.o1_p5, -1, -1, 32767)
/* 1475 */             .addComponent(this.jButton9)
/* 1476 */             .addComponent(this.jButton19))
/* 1477 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1480 */     this.aA.setFont(new Font("Tahoma", 0, 14));
/* 1481 */     this.aA.setText("jLabel19");
/*      */     
/* 1483 */     this.o1_p4.setFont(new Font("Tahoma", 0, 14));
/* 1484 */     this.o1_p4.setText("jLabel25");
/*      */     
/* 1486 */     this.jButton8.setBackground(new Color(204, 204, 204));
/* 1487 */     this.jButton8.setText("Mark Done");
/* 1488 */     this.jButton8.setFocusPainted(false);
/* 1489 */     this.jButton8.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1491 */             hjklout678.this.jButton8ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1495 */     this.jButton18.setText("Open");
/* 1496 */     this.jButton18.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1498 */             hjklout678.this.jButton18ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1502 */     GroupLayout o_u5Layout = new GroupLayout(this.o_u5);
/* 1503 */     this.o_u5.setLayout(o_u5Layout);
/* 1504 */     o_u5Layout.setHorizontalGroup(o_u5Layout
/* 1505 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1506 */         .addGroup(o_u5Layout.createSequentialGroup()
/* 1507 */           .addGap(21, 21, 21)
/* 1508 */           .addComponent(this.aA, -2, 184, -2)
/* 1509 */           .addGap(112, 112, 112)
/* 1510 */           .addComponent(this.o1_p4, -2, 62, -2)
/* 1511 */           .addGap(158, 158, 158)
/* 1512 */           .addComponent(this.jButton18, -2, 67, -2)
/* 1513 */           .addGap(143, 143, 143)
/* 1514 */           .addComponent(this.jButton8)
/* 1515 */           .addGap(29, 29, 29)));
/*      */     
/* 1517 */     o_u5Layout.setVerticalGroup(o_u5Layout
/* 1518 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1519 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u5Layout.createSequentialGroup()
/* 1520 */           .addContainerGap()
/* 1521 */           .addGroup(o_u5Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1522 */             .addComponent(this.aA, -1, -1, 32767)
/* 1523 */             .addComponent(this.o1_p4, -1, -1, 32767)
/* 1524 */             .addComponent(this.jButton8)
/* 1525 */             .addComponent(this.jButton18))
/* 1526 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1529 */     this.o1_id3.setFont(new Font("Tahoma", 0, 14));
/* 1530 */     this.o1_id3.setText("jLabel19");
/*      */     
/* 1532 */     this.o1_p3.setFont(new Font("Tahoma", 0, 14));
/* 1533 */     this.o1_p3.setText("jLabel25");
/*      */     
/* 1535 */     this.jButton7.setBackground(new Color(204, 204, 204));
/* 1536 */     this.jButton7.setText("Mark Done");
/* 1537 */     this.jButton7.setFocusPainted(false);
/* 1538 */     this.jButton7.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1540 */             hjklout678.this.jButton7ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1544 */     this.jButton17.setText("Open");
/* 1545 */     this.jButton17.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1547 */             hjklout678.this.jButton17ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1551 */     GroupLayout sdfhyiuwae348628sdhLayout = new GroupLayout(this.sdfhyiuwae348628sdh);
/* 1552 */     this.sdfhyiuwae348628sdh.setLayout(sdfhyiuwae348628sdhLayout);
/* 1553 */     sdfhyiuwae348628sdhLayout.setHorizontalGroup(sdfhyiuwae348628sdhLayout
/* 1554 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1555 */         .addGroup(sdfhyiuwae348628sdhLayout.createSequentialGroup()
/* 1556 */           .addGap(21, 21, 21)
/* 1557 */           .addComponent(this.o1_id3, -2, 184, -2)
/* 1558 */           .addGap(112, 112, 112)
/* 1559 */           .addComponent(this.o1_p3, -2, 62, -2)
/* 1560 */           .addGap(158, 158, 158)
/* 1561 */           .addComponent(this.jButton17, -2, 68, -2)
/* 1562 */           .addGap(143, 143, 143)
/* 1563 */           .addComponent(this.jButton7)
/* 1564 */           .addGap(29, 29, 29)));
/*      */     
/* 1566 */     sdfhyiuwae348628sdhLayout.setVerticalGroup(sdfhyiuwae348628sdhLayout
/* 1567 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1568 */         .addGroup(GroupLayout.Alignment.TRAILING, sdfhyiuwae348628sdhLayout.createSequentialGroup()
/* 1569 */           .addContainerGap()
/* 1570 */           .addGroup(sdfhyiuwae348628sdhLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1571 */             .addComponent(this.o1_id3, -1, -1, 32767)
/* 1572 */             .addComponent(this.o1_p3, -1, -1, 32767)
/* 1573 */             .addComponent(this.jButton7)
/* 1574 */             .addComponent(this.jButton17))
/* 1575 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1578 */     this.o1_id2.setFont(new Font("Tahoma", 0, 14));
/* 1579 */     this.o1_id2.setText("jLabel19");
/*      */     
/* 1581 */     this.o1_p2.setFont(new Font("Tahoma", 0, 14));
/* 1582 */     this.o1_p2.setText("jLabel25");
/*      */     
/* 1584 */     this.jButton6.setBackground(new Color(204, 204, 204));
/* 1585 */     this.jButton6.setText("Mark Done");
/* 1586 */     this.jButton6.setFocusPainted(false);
/* 1587 */     this.jButton6.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1589 */             hjklout678.this.jButton6ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1593 */     this.jButton13.setText("Open");
/* 1594 */     this.jButton13.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1596 */             hjklout678.this.jButton13ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1600 */     GroupLayout yutuytfjhgyLayout = new GroupLayout(this.yutuytfjhgy);
/* 1601 */     this.yutuytfjhgy.setLayout(yutuytfjhgyLayout);
/* 1602 */     yutuytfjhgyLayout.setHorizontalGroup(yutuytfjhgyLayout
/* 1603 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1604 */         .addGroup(yutuytfjhgyLayout.createSequentialGroup()
/* 1605 */           .addGap(21, 21, 21)
/* 1606 */           .addComponent(this.o1_id2, -2, 184, -2)
/* 1607 */           .addGap(112, 112, 112)
/* 1608 */           .addComponent(this.o1_p2, -2, 62, -2)
/* 1609 */           .addGap(158, 158, 158)
/* 1610 */           .addComponent(this.jButton13, -2, 70, -2)
/* 1611 */           .addGap(143, 143, 143)
/* 1612 */           .addComponent(this.jButton6)
/* 1613 */           .addGap(29, 29, 29)));
/*      */     
/* 1615 */     yutuytfjhgyLayout.setVerticalGroup(yutuytfjhgyLayout
/* 1616 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1617 */         .addGroup(yutuytfjhgyLayout.createSequentialGroup()
/* 1618 */           .addContainerGap()
/* 1619 */           .addGroup(yutuytfjhgyLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1620 */             .addGroup(GroupLayout.Alignment.TRAILING, yutuytfjhgyLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1621 */               .addComponent(this.o1_id2, -1, -1, 32767)
/* 1622 */               .addComponent(this.jButton6)
/* 1623 */               .addComponent(this.jButton13))
/* 1624 */             .addComponent(this.o1_p2, -1, -1, 32767))
/* 1625 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1628 */     this.o1_id1.setFont(new Font("Tahoma", 0, 14));
/* 1629 */     this.o1_id1.setText("jLabel19");
/*      */     
/* 1631 */     this.o1_p1.setFont(new Font("Tahoma", 0, 14));
/* 1632 */     this.o1_p1.setText("jLabel25");
/*      */     
/* 1634 */     this.jButton5.setBackground(new Color(204, 204, 204));
/* 1635 */     this.jButton5.setText("Mark Done");
/* 1636 */     this.jButton5.setFocusPainted(false);
/* 1637 */     this.jButton5.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1639 */             hjklout678.this.jButton5ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1643 */     this.jButton12.setText("Open");
/* 1644 */     this.jButton12.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1646 */             hjklout678.this.jButton12ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1650 */     GroupLayout gtytfhgygLayout = new GroupLayout(this.gtytfhgyg);
/* 1651 */     this.gtytfhgyg.setLayout(gtytfhgygLayout);
/* 1652 */     gtytfhgygLayout.setHorizontalGroup(gtytfhgygLayout
/* 1653 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1654 */         .addGroup(gtytfhgygLayout.createSequentialGroup()
/* 1655 */           .addGap(21, 21, 21)
/* 1656 */           .addComponent(this.o1_id1, -2, 184, -2)
/* 1657 */           .addGap(112, 112, 112)
/* 1658 */           .addComponent(this.o1_p1, -2, 62, -2)
/* 1659 */           .addGap(158, 158, 158)
/* 1660 */           .addComponent(this.jButton12, -2, 72, -2)
/* 1661 */           .addGap(143, 143, 143)
/* 1662 */           .addComponent(this.jButton5)
/* 1663 */           .addGap(29, 29, 29)));
/*      */     
/* 1665 */     gtytfhgygLayout.setVerticalGroup(gtytfhgygLayout
/* 1666 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1667 */         .addGroup(gtytfhgygLayout.createSequentialGroup()
/* 1668 */           .addContainerGap()
/* 1669 */           .addGroup(gtytfhgygLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1670 */             .addComponent(this.o1_id1, -1, -1, 32767)
/* 1671 */             .addComponent(this.o1_p1, -1, -1, 32767)
/* 1672 */             .addComponent(this.jButton5)
/* 1673 */             .addComponent(this.jButton12))
/* 1674 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1677 */     this.o1_id.setFont(new Font("Tahoma", 0, 14));
/* 1678 */     this.o1_id.setText("jLabel19");
/*      */     
/* 1680 */     this.o1_p.setFont(new Font("Tahoma", 0, 14));
/* 1681 */     this.o1_p.setText("jLabel25");
/*      */     
/* 1683 */     this.jButton1.setBackground(new Color(204, 204, 204));
/* 1684 */     this.jButton1.setText("Mark Done");
/* 1685 */     this.jButton1.setFocusPainted(false);
/* 1686 */     this.jButton1.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1688 */             hjklout678.this.jButton1ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1692 */     this.jButton2.setText("Open");
/* 1693 */     this.jButton2.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 1695 */             hjklout678.this.jButton2MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 1699 */     GroupLayout ytygLayout = new GroupLayout(this.ytyg);
/* 1700 */     this.ytyg.setLayout(ytygLayout);
/* 1701 */     ytygLayout.setHorizontalGroup(ytygLayout
/* 1702 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1703 */         .addGroup(ytygLayout.createSequentialGroup()
/* 1704 */           .addGap(21, 21, 21)
/* 1705 */           .addComponent(this.o1_id, -2, 184, -2)
/* 1706 */           .addGap(112, 112, 112)
/* 1707 */           .addComponent(this.o1_p, -2, 62, -2)
/* 1708 */           .addGap(158, 158, 158)
/* 1709 */           .addComponent(this.jButton2, -2, 73, -2)
/* 1710 */           .addGap(138, 138, 138)
/* 1711 */           .addComponent(this.jButton1)
/* 1712 */           .addGap(10, 10, 10)));
/*      */     
/* 1714 */     ytygLayout.setVerticalGroup(ytygLayout
/* 1715 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1716 */         .addGroup(GroupLayout.Alignment.TRAILING, ytygLayout.createSequentialGroup()
/* 1717 */           .addContainerGap()
/* 1718 */           .addGroup(ytygLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1719 */             .addComponent(this.o1_id, -1, -1, 32767)
/* 1720 */             .addComponent(this.o1_p, -1, -1, 32767)
/* 1721 */             .addComponent(this.jButton1)
/* 1722 */             .addComponent(this.jButton2))
/* 1723 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1726 */     this.o1_id17.setFont(new Font("Tahoma", 0, 14));
/* 1727 */     this.o1_id17.setText("jLabel19");
/*      */     
/* 1729 */     this.o1_p17.setFont(new Font("Tahoma", 0, 14));
/* 1730 */     this.o1_p17.setText("jLabel25");
/*      */     
/* 1732 */     this.jButton21.setBackground(new Color(204, 204, 204));
/* 1733 */     this.jButton21.setText("Mark Done");
/* 1734 */     this.jButton21.setFocusPainted(false);
/* 1735 */     this.jButton21.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1737 */             hjklout678.this.jButton21ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1741 */     this.jButton22.setText("Open");
/* 1742 */     this.jButton22.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1744 */             hjklout678.this.jButton22ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1748 */     GroupLayout AlLayout = new GroupLayout(this.Al);
/* 1749 */     this.Al.setLayout(AlLayout);
/* 1750 */     AlLayout.setHorizontalGroup(AlLayout
/* 1751 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1752 */         .addGroup(AlLayout.createSequentialGroup()
/* 1753 */           .addGap(21, 21, 21)
/* 1754 */           .addComponent(this.o1_id17, -2, 184, -2)
/* 1755 */           .addGap(112, 112, 112)
/* 1756 */           .addComponent(this.o1_p17, -2, 62, -2)
/* 1757 */           .addGap(158, 158, 158)
/* 1758 */           .addComponent(this.jButton22, -2, 68, -2)
/* 1759 */           .addGap(143, 143, 143)
/* 1760 */           .addComponent(this.jButton21)
/* 1761 */           .addGap(29, 29, 29)));
/*      */     
/* 1763 */     AlLayout.setVerticalGroup(AlLayout
/* 1764 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1765 */         .addGroup(GroupLayout.Alignment.TRAILING, AlLayout.createSequentialGroup()
/* 1766 */           .addContainerGap()
/* 1767 */           .addGroup(AlLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1768 */             .addComponent(this.o1_id17, -1, -1, 32767)
/* 1769 */             .addComponent(this.o1_p17, -1, -1, 32767)
/* 1770 */             .addComponent(this.jButton21)
/* 1771 */             .addComponent(this.jButton22))
/* 1772 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1775 */     this.o1_id18.setFont(new Font("Tahoma", 0, 14));
/* 1776 */     this.o1_id18.setText("jLabel19");
/*      */     
/* 1778 */     this.o1_p18.setFont(new Font("Tahoma", 0, 14));
/* 1779 */     this.o1_p18.setText("jLabel25");
/*      */     
/* 1781 */     this.jButton23.setBackground(new Color(204, 204, 204));
/* 1782 */     this.jButton23.setText("Mark Done");
/* 1783 */     this.jButton23.setFocusPainted(false);
/* 1784 */     this.jButton23.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1786 */             hjklout678.this.jButton23ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1790 */     this.jButton24.setText("Open");
/* 1791 */     this.jButton24.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1793 */             hjklout678.this.jButton24ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1797 */     GroupLayout AkLayout = new GroupLayout(this.Ak);
/* 1798 */     this.Ak.setLayout(AkLayout);
/* 1799 */     AkLayout.setHorizontalGroup(AkLayout
/* 1800 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1801 */         .addGroup(AkLayout.createSequentialGroup()
/* 1802 */           .addGap(21, 21, 21)
/* 1803 */           .addComponent(this.o1_id18, -2, 184, -2)
/* 1804 */           .addGap(112, 112, 112)
/* 1805 */           .addComponent(this.o1_p18, -2, 62, -2)
/* 1806 */           .addGap(158, 158, 158)
/* 1807 */           .addComponent(this.jButton24, -2, 68, -2)
/* 1808 */           .addGap(143, 143, 143)
/* 1809 */           .addComponent(this.jButton23)
/* 1810 */           .addGap(29, 29, 29)));
/*      */     
/* 1812 */     AkLayout.setVerticalGroup(AkLayout
/* 1813 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1814 */         .addGroup(GroupLayout.Alignment.TRAILING, AkLayout.createSequentialGroup()
/* 1815 */           .addContainerGap()
/* 1816 */           .addGroup(AkLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1817 */             .addComponent(this.o1_id18, -1, -1, 32767)
/* 1818 */             .addComponent(this.o1_p18, -1, -1, 32767)
/* 1819 */             .addComponent(this.jButton23)
/* 1820 */             .addComponent(this.jButton24))
/* 1821 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1824 */     this.o1_id19.setFont(new Font("Tahoma", 0, 14));
/* 1825 */     this.o1_id19.setText("jLabel19");
/*      */     
/* 1827 */     this.o1_p19.setFont(new Font("Tahoma", 0, 14));
/* 1828 */     this.o1_p19.setText("jLabel25");
/*      */     
/* 1830 */     this.jButton25.setBackground(new Color(204, 204, 204));
/* 1831 */     this.jButton25.setText("Mark Done");
/* 1832 */     this.jButton25.setFocusPainted(false);
/* 1833 */     this.jButton25.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1835 */             hjklout678.this.jButton25ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1839 */     this.jButton27.setText("Open");
/* 1840 */     this.jButton27.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1842 */             hjklout678.this.jButton27ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1846 */     GroupLayout AKLJLayout = new GroupLayout(this.AKLJ);
/* 1847 */     this.AKLJ.setLayout(AKLJLayout);
/* 1848 */     AKLJLayout.setHorizontalGroup(AKLJLayout
/* 1849 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1850 */         .addGroup(AKLJLayout.createSequentialGroup()
/* 1851 */           .addGap(21, 21, 21)
/* 1852 */           .addComponent(this.o1_id19, -2, 184, -2)
/* 1853 */           .addGap(112, 112, 112)
/* 1854 */           .addComponent(this.o1_p19, -2, 62, -2)
/* 1855 */           .addGap(158, 158, 158)
/* 1856 */           .addComponent(this.jButton27, -2, 68, -2)
/* 1857 */           .addGap(143, 143, 143)
/* 1858 */           .addComponent(this.jButton25)
/* 1859 */           .addContainerGap(-1, 32767)));
/*      */     
/* 1861 */     AKLJLayout.setVerticalGroup(AKLJLayout
/* 1862 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1863 */         .addGroup(GroupLayout.Alignment.TRAILING, AKLJLayout.createSequentialGroup()
/* 1864 */           .addContainerGap()
/* 1865 */           .addGroup(AKLJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 1866 */             .addComponent(this.o1_id19, -1, -1, 32767)
/* 1867 */             .addComponent(this.o1_p19, -1, -1, 32767)
/* 1868 */             .addComponent(this.jButton25)
/* 1869 */             .addComponent(this.jButton27))
/* 1870 */           .addContainerGap()));
/*      */ 
/*      */     
/* 1873 */     GroupLayout kloupLayout = new GroupLayout(this.kloup);
/* 1874 */     this.kloup.setLayout(kloupLayout);
/* 1875 */     kloupLayout.setHorizontalGroup(kloupLayout
/* 1876 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1877 */         .addGroup(GroupLayout.Alignment.TRAILING, kloupLayout.createSequentialGroup()
/* 1878 */           .addContainerGap(158, 32767)
/* 1879 */           .addGroup(kloupLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 1880 */             .addComponent(this.AKLJ, GroupLayout.Alignment.TRAILING, -1, -1, 32767)
/* 1881 */             .addComponent(this.gtytfhgyg, -1, -1, 32767)
/* 1882 */             .addComponent(this.yutuytfjhgy, -1, -1, 32767)
/* 1883 */             .addComponent(this.sdfhyiuwae348628sdh, -1, -1, 32767)
/* 1884 */             .addComponent(this.aB, -1, -1, 32767)
/* 1885 */             .addComponent(this.o_u5, -1, -1, 32767)
/* 1886 */             .addComponent(this.Au, -1, -1, 32767)
/* 1887 */             .addComponent(this.Al, -1, -1, 32767)
/* 1888 */             .addComponent(this.Ak, GroupLayout.Alignment.TRAILING, -1, -1, 32767)
/* 1889 */             .addComponent(this.header, -1, -1, 32767)
/* 1890 */             .addComponent(this.ytyg, -1, -1, 32767))
/* 1891 */           .addContainerGap(171, 32767)));
/*      */     
/* 1893 */     kloupLayout.setVerticalGroup(kloupLayout
/* 1894 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1895 */         .addGroup(kloupLayout.createSequentialGroup()
/* 1896 */           .addGap(30, 30, 30)
/* 1897 */           .addComponent(this.header, -2, -1, -2)
/* 1898 */           .addGap(18, 18, 18)
/* 1899 */           .addComponent(this.ytyg, -2, 39, -2)
/* 1900 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1901 */           .addComponent(this.gtytfhgyg, -2, 39, -2)
/* 1902 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1903 */           .addComponent(this.yutuytfjhgy, -2, 39, -2)
/* 1904 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1905 */           .addComponent(this.sdfhyiuwae348628sdh, -2, 39, -2)
/* 1906 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1907 */           .addComponent(this.o_u5, -2, 39, -2)
/* 1908 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1909 */           .addComponent(this.aB, -2, 39, -2)
/* 1910 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1911 */           .addComponent(this.Au, -2, 39, -2)
/* 1912 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1913 */           .addComponent(this.Al, -2, 39, -2)
/* 1914 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 1915 */           .addComponent(this.Ak, -2, 39, -2)
/* 1916 */           .addGap(6, 6, 6)
/* 1917 */           .addComponent(this.AKLJ, -2, 39, -2)
/* 1918 */           .addContainerGap(-1, 32767)));
/*      */ 
/*      */     
/* 1921 */     this.klo09812j.add(this.kloup, "OnlineOrder");
/*      */     
/* 1923 */     this.dlkop.setBackground(new Color(255, 255, 255));
/*      */     
/* 1925 */     this.KLO87.setText("Update Products");
/* 1926 */     this.KLO87.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1928 */             hjklout678.this.KLO87ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1932 */     this.jButton16.setText("Update images");
/* 1933 */     this.jButton16.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1935 */             hjklout678.this.jButton16ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1939 */     this.jLabel39.setFont(new Font("Tahoma", 0, 24));
/* 1940 */     this.jLabel39.setText("Local DataBase");
/*      */     
/* 1942 */     this.jButton15.setText("Reset Password");
/*      */     
/* 1944 */     this.jLabel41.setFont(new Font("Tahoma", 0, 24));
/* 1945 */     this.jLabel41.setText("User Managment");
/*      */     
/* 1947 */     this.jLabel2.setFont(new Font("Tahoma", 0, 24));
/* 1948 */     this.jLabel2.setText("Shop ID");
/*      */     
/* 1950 */     this.jLabel15.setFont(new Font("Tahoma", 0, 14));
/* 1951 */     this.jLabel15.setText("Enter Shop ID");
/*      */     
/* 1953 */     this.AK90.setFont(new Font("Tahoma", 0, 14));
/* 1954 */     this.AK90.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/*      */     
/* 1956 */     this.jButton3.setText("Save");
/* 1957 */     this.jButton3.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1959 */             hjklout678.this.jButton3ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1963 */     this.hjkouyth.setText("jLabel16");
/*      */     
/* 1965 */     this.jButton4.setText("Clear");
/* 1966 */     this.jButton4.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1968 */             hjklout678.this.jButton4ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1972 */     this.jButton29.setText("Clear Firebase");
/* 1973 */     this.jButton29.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1975 */             hjklout678.this.jButton29ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1979 */     this.jLabel16.setFont(new Font("Tahoma", 0, 14));
/* 1980 */     this.jLabel16.setText("Shop Name");
/*      */     
/* 1982 */     this.skldf821.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/*      */     
/* 1984 */     this.jButton30.setText("Save");
/* 1985 */     this.jButton30.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 1987 */             hjklout678.this.jButton30ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 1991 */     this.jLabel29.setFont(new Font("Tahoma", 0, 14));
/* 1992 */     this.jLabel29.setText("Current Id");
/*      */     
/* 1994 */     GroupLayout dlkopLayout = new GroupLayout(this.dlkop);
/* 1995 */     this.dlkop.setLayout(dlkopLayout);
/* 1996 */     dlkopLayout.setHorizontalGroup(dlkopLayout
/* 1997 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 1998 */         .addGroup(dlkopLayout.createSequentialGroup()
/* 1999 */           .addGap(23, 23, 23)
/* 2000 */           .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2001 */             .addComponent(this.jButton15, -2, 113, -2)
/* 2002 */             .addGroup(dlkopLayout.createSequentialGroup()
/* 2003 */               .addComponent(this.KLO87)
/* 2004 */               .addGap(38, 38, 38)
/* 2005 */               .addComponent(this.jButton16, -2, 113, -2)
/* 2006 */               .addGap(49, 49, 49)
/* 2007 */               .addComponent(this.jButton4, -2, 113, -2)
/* 2008 */               .addGap(64, 64, 64)
/* 2009 */               .addComponent(this.jButton29, -2, 110, -2))
/* 2010 */             .addComponent(this.jLabel39, -2, 248, -2)
/* 2011 */             .addComponent(this.jLabel2, -2, 159, -2)
/* 2012 */             .addComponent(this.jLabel41, -2, 157, -2)
/* 2013 */             .addGroup(dlkopLayout.createSequentialGroup()
/* 2014 */               .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2015 */                 .addComponent(this.jLabel15, -1, 113, 32767)
/* 2016 */                 .addComponent(this.jLabel16, -2, 103, -2)
/* 2017 */                 .addComponent(this.jLabel29, -1, -1, 32767))
/* 2018 */               .addGap(18, 18, 18)
/* 2019 */               .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2020 */                 .addComponent(this.hjkouyth, -1, -1, 32767)
/* 2021 */                 .addComponent(this.AK90, -1, 192, 32767)
/* 2022 */                 .addComponent(this.skldf821))
/* 2023 */               .addGap(37, 37, 37)
/* 2024 */               .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2025 */                 .addComponent(this.jButton3, -1, 113, 32767)
/* 2026 */                 .addComponent(this.jButton30, -1, -1, 32767))))
/* 2027 */           .addContainerGap(570, 32767)));
/*      */     
/* 2029 */     dlkopLayout.setVerticalGroup(dlkopLayout
/* 2030 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2031 */         .addGroup(GroupLayout.Alignment.TRAILING, dlkopLayout.createSequentialGroup()
/* 2032 */           .addGap(59, 59, 59)
/* 2033 */           .addComponent(this.jLabel2)
/* 2034 */           .addGap(18, 18, 18)
/* 2035 */           .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2036 */             .addComponent(this.jLabel16, -1, -1, 32767)
/* 2037 */             .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2038 */               .addComponent(this.skldf821, -1, 27, 32767)
/* 2039 */               .addComponent(this.jButton30)))
/* 2040 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2041 */           .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2042 */             .addComponent(this.jLabel15, -2, 28, -2)
/* 2043 */             .addComponent(this.AK90, -2, 28, -2)
/* 2044 */             .addComponent(this.jButton3, -1, -1, 32767))
/* 2045 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 2046 */           .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2047 */             .addComponent(this.hjkouyth, -2, 23, -2)
/* 2048 */             .addGroup(dlkopLayout.createSequentialGroup()
/* 2049 */               .addComponent(this.jLabel29, -1, 25, 32767)
/* 2050 */               .addGap(5, 5, 5)))
/* 2051 */           .addComponent(this.jLabel39, -2, 44, -2)
/* 2052 */           .addGap(18, 18, 18)
/* 2053 */           .addGroup(dlkopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2054 */             .addComponent(this.KLO87)
/* 2055 */             .addComponent(this.jButton16)
/* 2056 */             .addComponent(this.jButton4)
/* 2057 */             .addComponent(this.jButton29))
/* 2058 */           .addGap(18, 18, 18)
/* 2059 */           .addComponent(this.jLabel41, -2, 43, -2)
/* 2060 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 2061 */           .addComponent(this.jButton15)
/* 2062 */           .addContainerGap(138, 32767)));
/*      */ 
/*      */     
/* 2065 */     this.klo09812j.add(this.dlkop, "services");
/*      */     
/* 2067 */     this.klopdfger67.setBackground(new Color(255, 255, 255));
/* 2068 */     this.klopdfger67.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2070 */             hjklout678.this.klopdfger67MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2074 */     this.jButton14.setText("Check Out");
/* 2075 */     this.jButton14.setMargin(new Insets(0, 0, 0, 0));
/* 2076 */     this.jButton14.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2078 */             hjklout678.this.jButton14MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2082 */     this.Aa.setText("textField1");
/* 2083 */     this.Aa.addTextListener(new TextListener() {
/*      */           public void textValueChanged(TextEvent evt) {
/* 2085 */             hjklout678.this.AaTextValueChanged(evt);
/*      */           }
/*      */         });
/* 2088 */     this.Aa.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2090 */             hjklout678.this.AaKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2094 */     this.jPanel1.setBackground(new Color(255, 255, 255));
/* 2095 */     this.jPanel1.setOpaque(false);
/*      */     
/* 2097 */     this.dsfh2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2099 */     this.hhhyt56trt.setFont(new Font("Tahoma", 0, 16));
/* 2100 */     this.hhhyt56trt.setHorizontalAlignment(0);
/* 2101 */     this.hhhyt56trt.setText("li");
/*      */     
/* 2103 */     this.cart_x1.setForeground(new Color(255, 0, 51));
/* 2104 */     this.cart_x1.setText("X");
/* 2105 */     this.cart_x1.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2107 */             hjklout678.this.cart_x1MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2111 */     this.hju.setFont(new Font("Tahoma", 0, 14));
/* 2112 */     this.hju.setHorizontalAlignment(0);
/* 2113 */     this.hju.setText("C!");
/* 2114 */     this.hju.setBorder((Border)null);
/* 2115 */     this.hju.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2117 */             hjklout678.this.hjuKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2121 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 2122 */     this.jPanel1.setLayout(jPanel1Layout);
/* 2123 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout
/* 2124 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2125 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 2126 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2127 */             .addComponent(this.hju, GroupLayout.Alignment.LEADING)
/* 2128 */             .addComponent(this.hhhyt56trt, GroupLayout.Alignment.LEADING, -1, 150, 32767)
/* 2129 */             .addComponent(this.dsfh2, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 2130 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2131 */           .addComponent(this.cart_x1)
/* 2132 */           .addContainerGap(30, 32767)));
/*      */     
/* 2134 */     jPanel1Layout.setVerticalGroup(jPanel1Layout
/* 2135 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2136 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 2137 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2138 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 2139 */               .addContainerGap()
/* 2140 */               .addComponent(this.dsfh2, -2, 150, -2))
/* 2141 */             .addComponent(this.cart_x1))
/* 2142 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2143 */           .addComponent(this.hhhyt56trt, -2, 24, -2)
/* 2144 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2145 */           .addComponent(this.hju)));
/*      */ 
/*      */     
/* 2148 */     this.jPanel4.setBackground(new Color(255, 255, 255));
/* 2149 */     this.jPanel4.setOpaque(false);
/*      */     
/* 2151 */     this.sye213a.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2153 */     this.w347edt.setFont(new Font("Tahoma", 0, 16));
/* 2154 */     this.w347edt.setHorizontalAlignment(0);
/* 2155 */     this.w347edt.setText("li");
/*      */     
/* 2157 */     this.cart_x2.setForeground(new Color(255, 0, 51));
/* 2158 */     this.cart_x2.setText("X");
/* 2159 */     this.cart_x2.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2161 */             hjklout678.this.cart_x2MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2165 */     this.z.setFont(new Font("Tahoma", 0, 14));
/* 2166 */     this.z.setHorizontalAlignment(0);
/* 2167 */     this.z.setText("C!");
/* 2168 */     this.z.setBorder((Border)null);
/* 2169 */     this.z.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2171 */             hjklout678.this.zKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2175 */     GroupLayout jPanel4Layout = new GroupLayout(this.jPanel4);
/* 2176 */     this.jPanel4.setLayout(jPanel4Layout);
/* 2177 */     jPanel4Layout.setHorizontalGroup(jPanel4Layout
/* 2178 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2179 */         .addGroup(jPanel4Layout.createSequentialGroup()
/* 2180 */           .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2181 */             .addComponent(this.z, GroupLayout.Alignment.LEADING)
/* 2182 */             .addComponent(this.w347edt, GroupLayout.Alignment.LEADING, -1, 150, 32767)
/* 2183 */             .addComponent(this.sye213a, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 2184 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2185 */           .addComponent(this.cart_x2)
/* 2186 */           .addContainerGap(30, 32767)));
/*      */     
/* 2188 */     jPanel4Layout.setVerticalGroup(jPanel4Layout
/* 2189 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2190 */         .addGroup(jPanel4Layout.createSequentialGroup()
/* 2191 */           .addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2192 */             .addGroup(jPanel4Layout.createSequentialGroup()
/* 2193 */               .addContainerGap()
/* 2194 */               .addComponent(this.sye213a, -2, 150, -2))
/* 2195 */             .addComponent(this.cart_x2))
/* 2196 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2197 */           .addComponent(this.w347edt, -2, 24, -2)
/* 2198 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2199 */           .addComponent(this.z)));
/*      */ 
/*      */     
/* 2202 */     this.jPanel5.setBackground(new Color(255, 255, 255));
/* 2203 */     this.jPanel5.setOpaque(false);
/*      */     
/* 2205 */     this.kjshd1235jk.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2207 */     this.gghyted67.setFont(new Font("Tahoma", 0, 16));
/* 2208 */     this.gghyted67.setHorizontalAlignment(0);
/* 2209 */     this.gghyted67.setText("li");
/*      */     
/* 2211 */     this.cart_x3.setForeground(new Color(255, 0, 51));
/* 2212 */     this.cart_x3.setText("X");
/* 2213 */     this.cart_x3.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2215 */             hjklout678.this.cart_x3MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2219 */     this.k.setFont(new Font("Tahoma", 0, 14));
/* 2220 */     this.k.setHorizontalAlignment(0);
/* 2221 */     this.k.setText("C1");
/* 2222 */     this.k.setBorder((Border)null);
/* 2223 */     this.k.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2225 */             hjklout678.this.kKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2229 */     GroupLayout jPanel5Layout = new GroupLayout(this.jPanel5);
/* 2230 */     this.jPanel5.setLayout(jPanel5Layout);
/* 2231 */     jPanel5Layout.setHorizontalGroup(jPanel5Layout
/* 2232 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2233 */         .addGroup(jPanel5Layout.createSequentialGroup()
/* 2234 */           .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2235 */             .addComponent(this.k, GroupLayout.Alignment.LEADING)
/* 2236 */             .addComponent(this.gghyted67, GroupLayout.Alignment.LEADING, -1, 150, 32767)
/* 2237 */             .addComponent(this.kjshd1235jk, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 2238 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2239 */           .addComponent(this.cart_x3)
/* 2240 */           .addContainerGap(30, 32767)));
/*      */     
/* 2242 */     jPanel5Layout.setVerticalGroup(jPanel5Layout
/* 2243 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2244 */         .addGroup(jPanel5Layout.createSequentialGroup()
/* 2245 */           .addGroup(jPanel5Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2246 */             .addGroup(jPanel5Layout.createSequentialGroup()
/* 2247 */               .addContainerGap()
/* 2248 */               .addComponent(this.kjshd1235jk, -2, 150, -2))
/* 2249 */             .addComponent(this.cart_x3))
/* 2250 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2251 */           .addComponent(this.gghyted67, -2, 24, -2)
/* 2252 */           .addGap(0, 0, 0)
/* 2253 */           .addComponent(this.k)));
/*      */ 
/*      */     
/* 2256 */     this.jPanel6.setBackground(new Color(255, 255, 255));
/* 2257 */     this.jPanel6.setOpaque(false);
/*      */     
/* 2259 */     this.sdjkfh1287.setText("                                                 ");
/* 2260 */     this.sdjkfh1287.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2262 */     this.cart_lbl4.setFont(new Font("Tahoma", 0, 16));
/* 2263 */     this.cart_lbl4.setHorizontalAlignment(0);
/* 2264 */     this.cart_lbl4.setText("li");
/*      */     
/* 2266 */     this.cart_x4.setForeground(new Color(255, 0, 51));
/* 2267 */     this.cart_x4.setText("X");
/* 2268 */     this.cart_x4.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2270 */             hjklout678.this.cart_x4MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2274 */     this.ghyrtioy.setFont(new Font("Tahoma", 0, 14));
/* 2275 */     this.ghyrtioy.setHorizontalAlignment(0);
/* 2276 */     this.ghyrtioy.setText("C1");
/* 2277 */     this.ghyrtioy.setBorder((Border)null);
/* 2278 */     this.ghyrtioy.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2280 */             hjklout678.this.ghyrtioyKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2284 */     GroupLayout jPanel6Layout = new GroupLayout(this.jPanel6);
/* 2285 */     this.jPanel6.setLayout(jPanel6Layout);
/* 2286 */     jPanel6Layout.setHorizontalGroup(jPanel6Layout
/* 2287 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2288 */         .addGroup(jPanel6Layout.createSequentialGroup()
/* 2289 */           .addGroup(jPanel6Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2290 */             .addGroup(jPanel6Layout.createSequentialGroup()
/* 2291 */               .addGap(18, 18, 18)
/* 2292 */               .addGroup(jPanel6Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2293 */                 .addGroup(jPanel6Layout.createSequentialGroup()
/* 2294 */                   .addGap(10, 10, 10)
/* 2295 */                   .addComponent(this.ghyrtioy, -2, 95, -2))
/* 2296 */                 .addComponent(this.cart_lbl4, -2, 113, -2)))
/* 2297 */             .addComponent(this.sdjkfh1287, -2, 145, -2))
/* 2298 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 2299 */           .addComponent(this.cart_x4)
/* 2300 */           .addGap(31, 31, 31)));
/*      */     
/* 2302 */     jPanel6Layout.setVerticalGroup(jPanel6Layout
/* 2303 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2304 */         .addGroup(jPanel6Layout.createSequentialGroup()
/* 2305 */           .addGroup(jPanel6Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2306 */             .addGroup(jPanel6Layout.createSequentialGroup()
/* 2307 */               .addContainerGap()
/* 2308 */               .addComponent(this.sdjkfh1287, -2, 150, -2))
/* 2309 */             .addComponent(this.cart_x4))
/* 2310 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2311 */           .addComponent(this.cart_lbl4, -2, 24, -2)
/* 2312 */           .addGap(0, 0, 0)
/* 2313 */           .addComponent(this.ghyrtioy, -2, 31, -2)));
/*      */ 
/*      */     
/* 2316 */     this.jPanel7.setBackground(new Color(255, 255, 255));
/* 2317 */     this.jPanel7.setOpaque(false);
/*      */     
/* 2319 */     this.dfsk980.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2321 */     this.klopf56.setFont(new Font("Tahoma", 0, 16));
/* 2322 */     this.klopf56.setHorizontalAlignment(0);
/* 2323 */     this.klopf56.setText("li");
/*      */     
/* 2325 */     this.cart_x5.setForeground(new Color(255, 0, 51));
/* 2326 */     this.cart_x5.setText("X");
/* 2327 */     this.cart_x5.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2329 */             hjklout678.this.cart_x5MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2333 */     this.ggsd579.setFont(new Font("Tahoma", 0, 14));
/* 2334 */     this.ggsd579.setHorizontalAlignment(0);
/* 2335 */     this.ggsd579.setText("C1");
/* 2336 */     this.ggsd579.setBorder((Border)null);
/* 2337 */     this.ggsd579.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2339 */             hjklout678.this.ggsd579KeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2343 */     GroupLayout jPanel7Layout = new GroupLayout(this.jPanel7);
/* 2344 */     this.jPanel7.setLayout(jPanel7Layout);
/* 2345 */     jPanel7Layout.setHorizontalGroup(jPanel7Layout
/* 2346 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2347 */         .addGroup(jPanel7Layout.createSequentialGroup()
/* 2348 */           .addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2349 */             .addComponent(this.ggsd579, GroupLayout.Alignment.LEADING)
/* 2350 */             .addComponent(this.klopf56, GroupLayout.Alignment.LEADING, -1, 150, 32767)
/* 2351 */             .addComponent(this.dfsk980, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 2352 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2353 */           .addComponent(this.cart_x5)
/* 2354 */           .addContainerGap(30, 32767)));
/*      */     
/* 2356 */     jPanel7Layout.setVerticalGroup(jPanel7Layout
/* 2357 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2358 */         .addGroup(jPanel7Layout.createSequentialGroup()
/* 2359 */           .addGroup(jPanel7Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2360 */             .addGroup(jPanel7Layout.createSequentialGroup()
/* 2361 */               .addContainerGap()
/* 2362 */               .addComponent(this.dfsk980, -2, 150, -2))
/* 2363 */             .addComponent(this.cart_x5))
/* 2364 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2365 */           .addComponent(this.klopf56, -2, 24, -2)
/* 2366 */           .addGap(0, 0, 0)
/* 2367 */           .addComponent(this.ggsd579)));
/*      */ 
/*      */     
/* 2370 */     this.jPanel8.setBackground(new Color(255, 255, 255));
/* 2371 */     this.jPanel8.setOpaque(false);
/*      */     
/* 2373 */     this.dfskjO98.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2375 */     this.ds214jasd3.setFont(new Font("Tahoma", 0, 16));
/* 2376 */     this.ds214jasd3.setHorizontalAlignment(0);
/* 2377 */     this.ds214jasd3.setText("li");
/*      */     
/* 2379 */     this.cart_x6.setForeground(new Color(255, 0, 51));
/* 2380 */     this.cart_x6.setText("X");
/* 2381 */     this.cart_x6.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2383 */             hjklout678.this.cart_x6MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2387 */     this.cart_c6.setFont(new Font("Tahoma", 0, 14));
/* 2388 */     this.cart_c6.setHorizontalAlignment(0);
/* 2389 */     this.cart_c6.setText("C1");
/* 2390 */     this.cart_c6.setBorder((Border)null);
/* 2391 */     this.cart_c6.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2393 */             hjklout678.this.cart_c6KeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2397 */     GroupLayout jPanel8Layout = new GroupLayout(this.jPanel8);
/* 2398 */     this.jPanel8.setLayout(jPanel8Layout);
/* 2399 */     jPanel8Layout.setHorizontalGroup(jPanel8Layout
/* 2400 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2401 */         .addGroup(jPanel8Layout.createSequentialGroup()
/* 2402 */           .addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2403 */             .addComponent(this.cart_c6, GroupLayout.Alignment.LEADING)
/* 2404 */             .addComponent(this.ds214jasd3, GroupLayout.Alignment.LEADING, -1, 150, 32767)
/* 2405 */             .addComponent(this.dfskjO98, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 2406 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2407 */           .addComponent(this.cart_x6)
/* 2408 */           .addContainerGap(30, 32767)));
/*      */     
/* 2410 */     jPanel8Layout.setVerticalGroup(jPanel8Layout
/* 2411 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2412 */         .addGroup(jPanel8Layout.createSequentialGroup()
/* 2413 */           .addGroup(jPanel8Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2414 */             .addGroup(jPanel8Layout.createSequentialGroup()
/* 2415 */               .addContainerGap()
/* 2416 */               .addComponent(this.dfskjO98, -2, 150, -2))
/* 2417 */             .addComponent(this.cart_x6))
/* 2418 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2419 */           .addComponent(this.ds214jasd3, -2, 24, -2)
/* 2420 */           .addGap(0, 0, 0)
/* 2421 */           .addComponent(this.cart_c6)));
/*      */ 
/*      */     
/* 2424 */     this.jPanel9.setBackground(new Color(255, 255, 255));
/* 2425 */     this.jPanel9.setOpaque(false);
/*      */     
/* 2427 */     this.sjkaA8.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2429 */     this.dsh2348662.setFont(new Font("Tahoma", 0, 16));
/* 2430 */     this.dsh2348662.setHorizontalAlignment(0);
/* 2431 */     this.dsh2348662.setText("li");
/*      */     
/* 2433 */     this.cart_x7.setForeground(new Color(255, 0, 51));
/* 2434 */     this.cart_x7.setText("X");
/* 2435 */     this.cart_x7.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2437 */             hjklout678.this.cart_x7MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2441 */     this.cart_c7.setFont(new Font("Tahoma", 0, 14));
/* 2442 */     this.cart_c7.setHorizontalAlignment(0);
/* 2443 */     this.cart_c7.setText("C1");
/* 2444 */     this.cart_c7.setBorder((Border)null);
/* 2445 */     this.cart_c7.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2447 */             hjklout678.this.cart_c7KeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2451 */     GroupLayout jPanel9Layout = new GroupLayout(this.jPanel9);
/* 2452 */     this.jPanel9.setLayout(jPanel9Layout);
/* 2453 */     jPanel9Layout.setHorizontalGroup(jPanel9Layout
/* 2454 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2455 */         .addGroup(jPanel9Layout.createSequentialGroup()
/* 2456 */           .addGroup(jPanel9Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2457 */             .addComponent(this.cart_c7, GroupLayout.Alignment.LEADING)
/* 2458 */             .addComponent(this.dsh2348662, GroupLayout.Alignment.LEADING, -1, 150, 32767)
/* 2459 */             .addComponent(this.sjkaA8, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 2460 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2461 */           .addComponent(this.cart_x7)
/* 2462 */           .addContainerGap(30, 32767)));
/*      */     
/* 2464 */     jPanel9Layout.setVerticalGroup(jPanel9Layout
/* 2465 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2466 */         .addGroup(jPanel9Layout.createSequentialGroup()
/* 2467 */           .addGroup(jPanel9Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2468 */             .addGroup(jPanel9Layout.createSequentialGroup()
/* 2469 */               .addContainerGap()
/* 2470 */               .addComponent(this.sjkaA8, -2, 150, -2))
/* 2471 */             .addComponent(this.cart_x7))
/* 2472 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2473 */           .addComponent(this.dsh2348662, -2, 24, -2)
/* 2474 */           .addGap(0, 0, 0)
/* 2475 */           .addComponent(this.cart_c7, -1, 31, 32767)));
/*      */ 
/*      */     
/* 2478 */     this.jPanel10.setBackground(new Color(255, 255, 255));
/* 2479 */     this.jPanel10.setOpaque(false);
/*      */     
/* 2481 */     this.dsjhA9.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*      */     
/* 2483 */     this.fhjg667865k.setFont(new Font("Tahoma", 0, 16));
/* 2484 */     this.fhjg667865k.setHorizontalAlignment(0);
/* 2485 */     this.fhjg667865k.setText("li");
/*      */     
/* 2487 */     this.cart_x8.setForeground(new Color(255, 0, 51));
/* 2488 */     this.cart_x8.setText("X");
/* 2489 */     this.cart_x8.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2491 */             hjklout678.this.cart_x8MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2495 */     this.ghjuyto90.setFont(new Font("Tahoma", 0, 14));
/* 2496 */     this.ghjuyto90.setHorizontalAlignment(0);
/* 2497 */     this.ghjuyto90.setText("C1");
/* 2498 */     this.ghjuyto90.setBorder((Border)null);
/* 2499 */     this.ghjuyto90.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2501 */             hjklout678.this.ghjuyto90KeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2505 */     GroupLayout jPanel10Layout = new GroupLayout(this.jPanel10);
/* 2506 */     this.jPanel10.setLayout(jPanel10Layout);
/* 2507 */     jPanel10Layout.setHorizontalGroup(jPanel10Layout
/* 2508 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2509 */         .addGroup(jPanel10Layout.createSequentialGroup()
/* 2510 */           .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2511 */             .addComponent(this.ghjuyto90, GroupLayout.Alignment.LEADING, -1, 150, 32767)
/* 2512 */             .addComponent(this.fhjg667865k, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 2513 */             .addComponent(this.dsjhA9, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 2514 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2515 */           .addComponent(this.cart_x8)
/* 2516 */           .addContainerGap(-1, 32767)));
/*      */     
/* 2518 */     jPanel10Layout.setVerticalGroup(jPanel10Layout
/* 2519 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2520 */         .addGroup(jPanel10Layout.createSequentialGroup()
/* 2521 */           .addGroup(jPanel10Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2522 */             .addGroup(jPanel10Layout.createSequentialGroup()
/* 2523 */               .addContainerGap()
/* 2524 */               .addComponent(this.dsjhA9, -2, 150, -2))
/* 2525 */             .addComponent(this.cart_x8))
/* 2526 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2527 */           .addComponent(this.fhjg667865k, -2, 24, -2)
/* 2528 */           .addGap(0, 0, 0)
/* 2529 */           .addComponent(this.ghjuyto90)));
/*      */ 
/*      */     
/* 2532 */     GroupLayout klopdfger67Layout = new GroupLayout(this.klopdfger67);
/* 2533 */     this.klopdfger67.setLayout(klopdfger67Layout);
/* 2534 */     klopdfger67Layout.setHorizontalGroup(klopdfger67Layout
/* 2535 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2536 */         .addGroup(klopdfger67Layout.createSequentialGroup()
/* 2537 */           .addGap(42, 42, 42)
/* 2538 */           .addGroup(klopdfger67Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2539 */             .addComponent(this.jPanel1, -2, -1, -2)
/* 2540 */             .addComponent(this.jPanel7, -2, -1, -2))
/* 2541 */           .addGap(26, 26, 26)
/* 2542 */           .addGroup(klopdfger67Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2543 */             .addComponent(this.jPanel4, -2, -1, -2)
/* 2544 */             .addComponent(this.jPanel8, -2, -1, -2))
/* 2545 */           .addGap(39, 39, 39)
/* 2546 */           .addGroup(klopdfger67Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2547 */             .addComponent(this.jPanel5, -2, -1, -2)
/* 2548 */             .addComponent(this.jPanel9, -2, -1, -2))
/* 2549 */           .addGap(18, 18, 18)
/* 2550 */           .addGroup(klopdfger67Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2551 */             .addComponent(this.jPanel6, -1, -1, -2)
/* 2552 */             .addComponent(this.jPanel10, -1, -1, -2))
/* 2553 */           .addGap(0, 300, 32767))
/* 2554 */         .addGroup(GroupLayout.Alignment.TRAILING, klopdfger67Layout.createSequentialGroup()
/* 2555 */           .addContainerGap(-1, 32767)
/* 2556 */           .addComponent(this.Aa, -2, 86, -2)
/* 2557 */           .addGap(23, 23, 23)
/* 2558 */           .addComponent(this.jButton14, -2, 111, -2)));
/*      */     
/* 2560 */     klopdfger67Layout.setVerticalGroup(klopdfger67Layout
/* 2561 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2562 */         .addGroup(klopdfger67Layout.createSequentialGroup()
/* 2563 */           .addContainerGap()
/* 2564 */           .addGroup(klopdfger67Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 2565 */             .addComponent(this.jButton14, -2, 27, -2)
/* 2566 */             .addComponent(this.Aa, -2, -1, -2))
/* 2567 */           .addGap(40, 40, 40)
/* 2568 */           .addGroup(klopdfger67Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2569 */             .addComponent(this.jPanel1, -1, -1, 32767)
/* 2570 */             .addComponent(this.jPanel4, -1, -1, 32767)
/* 2571 */             .addComponent(this.jPanel5, -1, -1, 32767)
/* 2572 */             .addComponent(this.jPanel6, -1, -1, 32767))
/* 2573 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2574 */           .addGroup(klopdfger67Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2575 */             .addComponent(this.jPanel9, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 2576 */             .addComponent(this.jPanel8, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 2577 */             .addComponent(this.jPanel7, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 2578 */             .addComponent(this.jPanel10, -1, -1, 32767))
/* 2579 */           .addContainerGap(18, 32767)));
/*      */ 
/*      */     
/* 2582 */     this.klo09812j.add(this.klopdfger67, "cart");
/*      */     
/* 2584 */     this.jdskfh132ds.setBackground(new Color(255, 255, 255));
/*      */     
/* 2586 */     this.jLabel4.setFont(new Font("Tahoma", 0, 24));
/* 2587 */     this.jLabel4.setText("Add New Product");
/*      */     
/* 2589 */     this.jLabel5.setFont(new Font("Tahoma", 0, 18));
/* 2590 */     this.jLabel5.setText("Select Category");
/*      */     
/* 2592 */     this.hjyt.setModel(new DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
/* 2593 */     this.hjyt.addItemListener(new ItemListener() {
/*      */           public void itemStateChanged(ItemEvent evt) {
/* 2595 */             hjklout678.this.hjytItemStateChanged(evt);
/*      */           }
/*      */         });
/*      */     
/* 2599 */     this.jLabel8.setFont(new Font("Tahoma", 0, 18));
/* 2600 */     this.jLabel8.setText("Select SubCategory");
/*      */     
/* 2602 */     this.hyt57fg.setModel(new DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
/*      */     
/* 2604 */     this.jLabel50.setFont(new Font("Tahoma", 0, 18));
/* 2605 */     this.jLabel50.setText("Unit Price");
/*      */     
/* 2607 */     this.jLabel51.setFont(new Font("Tahoma", 0, 18));
/* 2608 */     this.jLabel51.setText("Sales Price");
/*      */     
/* 2610 */     this.jLabel52.setFont(new Font("Tahoma", 0, 18));
/* 2611 */     this.jLabel52.setText("Available Units");
/*      */     
/* 2613 */     this.jLabel53.setFont(new Font("Tahoma", 0, 18));
/* 2614 */     this.jLabel53.setText("Size");
/*      */     
/* 2616 */     this.WWEQSD.setFont(new Font("Tahoma", 0, 14));
/* 2617 */     this.WWEQSD.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2618 */     this.WWEQSD.setNextFocusableComponent(this.asdew);
/*      */     
/* 2620 */     this.asdew.setFont(new Font("Tahoma", 0, 14));
/* 2621 */     this.asdew.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2622 */     this.asdew.setNextFocusableComponent(this.Adrtfgh);
/*      */     
/* 2624 */     this.Wad.setFont(new Font("Tahoma", 0, 14));
/* 2625 */     this.Wad.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2626 */     this.Wad.setNextFocusableComponent(this.Wasdf);
/*      */     
/* 2628 */     this.Adrtfgh.setFont(new Font("Tahoma", 0, 14));
/* 2629 */     this.Adrtfgh.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2630 */     this.Adrtfgh.setNextFocusableComponent(this.dfsh34hsd);
/* 2631 */     this.Adrtfgh.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2633 */             hjklout678.this.AdrtfghKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2637 */     this.dfsh34hsd.setText("Load Image");
/* 2638 */     this.dfsh34hsd.setNextFocusableComponent(this.sdfh129sd);
/* 2639 */     this.dfsh34hsd.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2641 */             hjklout678.this.dfsh34hsdMouseClicked(evt);
/*      */           }
/*      */         });
/* 2644 */     this.dfsh34hsd.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2646 */             hjklout678.this.dfsh34hsdKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2650 */     this.sdfh129sd.setText("Description");
/* 2651 */     this.sdfh129sd.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2));
/* 2652 */     this.sdfh129sd.setNextFocusableComponent(this.ksdfh345_s);
/* 2653 */     this.sdfh129sd.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 2655 */             hjklout678.this.sdfh129sdFocusGained(evt);
/*      */           }
/*      */         });
/* 2658 */     this.sdfh129sd.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2660 */             hjklout678.this.sdfh129sdMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2664 */     this.ksdfh345_s.setText("Save Product");
/* 2665 */     this.ksdfh345_s.setNextFocusableComponent(this.hjy65449);
/* 2666 */     this.ksdfh345_s.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 2668 */             hjklout678.this.ksdfh345_sActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2672 */     this.jLabel11.setFont(new Font("Tahoma", 0, 18));
/* 2673 */     this.jLabel11.setText("Product Name");
/*      */     
/* 2675 */     this.jLabel9.setFont(new Font("Tahoma", 0, 18));
/* 2676 */     this.jLabel9.setText("Company Name");
/*      */     
/* 2678 */     this.WWa.setFont(new Font("Tahoma", 0, 14));
/* 2679 */     this.WWa.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2680 */     this.WWa.setNextFocusableComponent(this.WWEQSD);
/*      */     
/* 2682 */     this.Wasdf.setFont(new Font("Tahoma", 0, 14));
/* 2683 */     this.Wasdf.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2684 */     this.Wasdf.setNextFocusableComponent(this.WWa);
/*      */     
/* 2686 */     this.hjy65449.setFont(new Font("Tahoma", 0, 14));
/* 2687 */     this.hjy65449.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2688 */     this.hjy65449.setNextFocusableComponent(this.Wad);
/*      */     
/* 2690 */     this.jButton11.setText("New Cat");
/* 2691 */     this.jButton11.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 2693 */             hjklout678.this.jButton11ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2697 */     this.sfdjkh12940.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2));
/*      */     
/* 2699 */     this.jLabel14.setFont(new Font("Tahoma", 0, 18));
/* 2700 */     this.jLabel14.setText("Barcode");
/*      */     
/* 2702 */     GroupLayout jdskfh132dsLayout = new GroupLayout(this.jdskfh132ds);
/* 2703 */     this.jdskfh132ds.setLayout(jdskfh132dsLayout);
/* 2704 */     jdskfh132dsLayout.setHorizontalGroup(jdskfh132dsLayout
/* 2705 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2706 */         .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2707 */           .addGap(107, 107, 107)
/* 2708 */           .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2709 */             .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2710 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2711 */                 .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2712 */                   .addComponent(this.jLabel5, -2, 132, -2)
/* 2713 */                   .addGap(40, 40, 40))
/* 2714 */                 .addGroup(GroupLayout.Alignment.TRAILING, jdskfh132dsLayout.createSequentialGroup()
/* 2715 */                   .addComponent(this.jLabel8)
/* 2716 */                   .addGap(18, 18, 18)))
/* 2717 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2718 */                 .addComponent(this.hjyt, 0, 200, 32767)
/* 2719 */                 .addComponent(this.hyt57fg, 0, -1, 32767)))
/* 2720 */             .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2721 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2722 */                 .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2723 */                   .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2724 */                     .addComponent(this.jLabel14, -2, 88, -2)
/* 2725 */                     .addComponent(this.jLabel52))
/* 2726 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 2727 */                   .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2728 */                     .addComponent(this.asdew)
/* 2729 */                     .addComponent(this.Adrtfgh, -1, 139, 32767)))
/* 2730 */                 .addGroup(GroupLayout.Alignment.LEADING, jdskfh132dsLayout.createSequentialGroup()
/* 2731 */                   .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2732 */                     .addComponent(this.jLabel51, -2, 115, -2)
/* 2733 */                     .addComponent(this.jLabel50)
/* 2734 */                     .addComponent(this.jLabel11)
/* 2735 */                     .addComponent(this.jLabel9)
/* 2736 */                     .addComponent(this.jLabel53, -2, 111, -2))
/* 2737 */                   .addGap(47, 47, 47)
/* 2738 */                   .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2739 */                     .addComponent(this.Wad, -2, 139, -2)
/* 2740 */                     .addComponent(this.WWEQSD)
/* 2741 */                     .addComponent(this.WWa)
/* 2742 */                     .addComponent(this.Wasdf)
/* 2743 */                     .addComponent(this.hjy65449))))
/* 2744 */               .addGap(0, 0, 32767)))
/* 2745 */           .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2746 */             .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2747 */               .addGap(98, 98, 98)
/* 2748 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2749 */                 .addComponent(this.dfsh34hsd, -2, 156, -2)
/* 2750 */                 .addComponent(this.sfdjkh12940, -1, -1, 32767))
/* 2751 */               .addGap(15, 15, 15)
/* 2752 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2753 */                 .addComponent(this.sdfh129sd, -2, 156, -2)
/* 2754 */                 .addComponent(this.ksdfh345_s, -2, 156, -2)))
/* 2755 */             .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2756 */               .addGap(18, 18, 18)
/* 2757 */               .addComponent(this.jButton11)
/* 2758 */               .addGap(0, 0, 32767)))
/* 2759 */           .addContainerGap(289, 32767))
/* 2760 */         .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2761 */           .addComponent(this.jLabel4, -2, 251, -2)
/* 2762 */           .addContainerGap(-1, 32767)));
/*      */     
/* 2764 */     jdskfh132dsLayout.setVerticalGroup(jdskfh132dsLayout
/* 2765 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2766 */         .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2767 */           .addComponent(this.jLabel4, -2, 42, -2)
/* 2768 */           .addGap(52, 52, 52)
/* 2769 */           .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2770 */             .addComponent(this.jLabel5, -2, 25, -2)
/* 2771 */             .addComponent(this.hjyt, -2, 32, -2)
/* 2772 */             .addComponent(this.jButton11, -2, 32, -2))
/* 2773 */           .addGap(19, 19, 19)
/* 2774 */           .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 2775 */             .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2776 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 2777 */                 .addComponent(this.sdfh129sd, -2, 182, -2)
/* 2778 */                 .addComponent(this.sfdjkh12940, -1, -1, 32767))
/* 2779 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 2780 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2781 */                 .addComponent(this.dfsh34hsd)
/* 2782 */                 .addComponent(this.ksdfh345_s)))
/* 2783 */             .addGroup(jdskfh132dsLayout.createSequentialGroup()
/* 2784 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2785 */                 .addComponent(this.jLabel8, -2, 25, -2)
/* 2786 */                 .addComponent(this.hyt57fg, -2, 32, -2))
/* 2787 */               .addGap(41, 41, 41)
/* 2788 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2789 */                 .addComponent(this.jLabel11, -2, 22, -2)
/* 2790 */                 .addComponent(this.hjy65449, -2, 22, -2))
/* 2791 */               .addGap(18, 18, 18)
/* 2792 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 2793 */                 .addComponent(this.jLabel53)
/* 2794 */                 .addComponent(this.Wad, -2, 22, -2))
/* 2795 */               .addGap(14, 14, 14)
/* 2796 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2797 */                 .addComponent(this.jLabel9, -2, 22, -2)
/* 2798 */                 .addComponent(this.Wasdf, -2, 22, -2))
/* 2799 */               .addGap(18, 18, 18)
/* 2800 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 2801 */                 .addComponent(this.jLabel50)
/* 2802 */                 .addComponent(this.WWa, -2, 22, -2))
/* 2803 */               .addGap(18, 18, 18)
/* 2804 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2805 */                 .addComponent(this.jLabel51)
/* 2806 */                 .addComponent(this.WWEQSD, -2, 22, -2))
/* 2807 */               .addGap(18, 18, 18)
/* 2808 */               .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 2809 */                 .addComponent(this.asdew, -2, 22, -2)
/* 2810 */                 .addComponent(this.jLabel52))))
/* 2811 */           .addGap(8, 8, 8)
/* 2812 */           .addGroup(jdskfh132dsLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2813 */             .addComponent(this.jLabel14, -2, 33, -2)
/* 2814 */             .addComponent(this.Adrtfgh, -2, 22, -2))
/* 2815 */           .addContainerGap(97, 32767)));
/*      */ 
/*      */     
/* 2818 */     this.klo09812j.add(this.jdskfh132ds, "addItemMain");
/*      */     
/* 2820 */     this.vbd.setBackground(new Color(255, 255, 255));
/*      */     
/* 2822 */     this.jLabel3.setFont(new Font("Tahoma", 0, 24));
/* 2823 */     this.jLabel3.setText("  SubCategory Information");
/*      */     
/* 2825 */     this.sdfhk89076.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2));
/*      */     
/* 2827 */     this.dsfljslKIOP.setText("Load Image");
/* 2828 */     this.dsfljslKIOP.setNextFocusableComponent(this.djskfLop);
/* 2829 */     this.dsfljslKIOP.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2831 */             hjklout678.this.dsfljslKIOPMouseClicked(evt);
/*      */           }
/*      */         });
/* 2834 */     this.dsfljslKIOP.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 2836 */             hjklout678.this.dsfljslKIOPActionPerformed(evt);
/*      */           }
/*      */         });
/* 2839 */     this.dsfljslKIOP.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2841 */             hjklout678.this.dsfljslKIOPKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2845 */     this.jLabel25.setFont(new Font("Tahoma", 0, 14));
/* 2846 */     this.jLabel25.setText("Name");
/*      */     
/* 2848 */     this.dslkfjA123.setFont(new Font("Tahoma", 0, 14));
/* 2849 */     this.dslkfjA123.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2850 */     this.dslkfjA123.setNextFocusableComponent(this.dfhskj123456);
/*      */     
/* 2852 */     this.dfhskj123456.setText("Description");
/* 2853 */     this.dfhskj123456.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/* 2854 */     this.dfhskj123456.setNextFocusableComponent(this.dsfljslKIOP);
/* 2855 */     this.dfhskj123456.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 2857 */             hjklout678.this.dfhskj123456FocusGained(evt);
/*      */           }
/*      */         });
/* 2860 */     this.dfhskj123456.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2862 */             hjklout678.this.dfhskj123456MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2866 */     this.djskfLop.setText("Save Category");
/* 2867 */     this.djskfLop.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2869 */             hjklout678.this.djskfLopMouseClicked(evt);
/*      */           }
/*      */         });
/* 2872 */     this.djskfLop.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 2874 */             hjklout678.this.djskfLopActionPerformed(evt);
/*      */           }
/*      */         });
/* 2877 */     this.djskfLop.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2879 */             hjklout678.this.djskfLopKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2883 */     this.asdlJklo.setModel(new DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
/*      */     
/* 2885 */     this.jLabel7.setFont(new Font("Tahoma", 0, 24));
/* 2886 */     this.jLabel7.setText("  Category Information");
/*      */     
/* 2888 */     this.jLabel12.setFont(new Font("Tahoma", 0, 14));
/* 2889 */     this.jLabel12.setText("Category Name");
/*      */     
/* 2891 */     this.jLabel13.setFont(new Font("Tahoma", 0, 14));
/* 2892 */     this.jLabel13.setText("SubCat Name");
/*      */     
/* 2894 */     this.Amklop.setFont(new Font("Tahoma", 0, 14));
/* 2895 */     this.Amklop.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(204, 204, 204)));
/* 2896 */     this.Amklop.setNextFocusableComponent(this.xdfj12);
/*      */     
/* 2898 */     this.xdfj12.setText("Description");
/* 2899 */     this.xdfj12.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/* 2900 */     this.xdfj12.setNextFocusableComponent(this.dsfklop);
/* 2901 */     this.xdfj12.addFocusListener(new FocusAdapter() {
/*      */           public void focusGained(FocusEvent evt) {
/* 2903 */             hjklout678.this.xdfj12FocusGained(evt);
/*      */           }
/*      */         });
/* 2906 */     this.xdfj12.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2908 */             hjklout678.this.xdfj12MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 2912 */     this.dsfklop.setText("Load Image");
/* 2913 */     this.dsfklop.setNextFocusableComponent(this.fdshQo);
/* 2914 */     this.dsfklop.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2916 */             hjklout678.this.dsfklopMouseClicked(evt);
/*      */           }
/*      */         });
/* 2919 */     this.dsfklop.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 2921 */             hjklout678.this.dsfklopActionPerformed(evt);
/*      */           }
/*      */         });
/* 2924 */     this.dsfklop.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2926 */             hjklout678.this.dsfklopKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2930 */     this.fdshQo.setText("Save SubCat");
/* 2931 */     this.fdshQo.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 2933 */             hjklout678.this.fdshQoMouseClicked(evt);
/*      */           }
/*      */         });
/* 2936 */     this.fdshQo.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 2938 */             hjklout678.this.fdshQoActionPerformed(evt);
/*      */           }
/*      */         });
/* 2941 */     this.fdshQo.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 2943 */             hjklout678.this.fdshQoKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 2947 */     this.sdfjho90.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2));
/*      */     
/* 2949 */     GroupLayout vbdLayout = new GroupLayout(this.vbd);
/* 2950 */     this.vbd.setLayout(vbdLayout);
/* 2951 */     vbdLayout.setHorizontalGroup(vbdLayout
/* 2952 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2953 */         .addGroup(vbdLayout.createSequentialGroup()
/* 2954 */           .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2955 */             .addGroup(vbdLayout.createSequentialGroup()
/* 2956 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2957 */                 .addGroup(vbdLayout.createSequentialGroup()
/* 2958 */                   .addContainerGap()
/* 2959 */                   .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2960 */                     .addComponent(this.dfhskj123456)
/* 2961 */                     .addGroup(vbdLayout.createSequentialGroup()
/* 2962 */                       .addComponent(this.jLabel25, -2, 69, -2)
/* 2963 */                       .addGap(18, 18, 18)
/* 2964 */                       .addComponent(this.dslkfjA123, -2, 142, -2))))
/* 2965 */                 .addGroup(vbdLayout.createSequentialGroup()
/* 2966 */                   .addGap(32, 32, 32)
/* 2967 */                   .addComponent(this.djskfLop, -2, 156, -2)))
/* 2968 */               .addGap(27, 27, 27)
/* 2969 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2970 */                 .addComponent(this.dsfljslKIOP, -1, -1, 32767)
/* 2971 */                 .addComponent(this.sdfhk89076, GroupLayout.Alignment.TRAILING, -2, 156, -2)))
/* 2972 */             .addGroup(vbdLayout.createSequentialGroup()
/* 2973 */               .addContainerGap()
/* 2974 */               .addComponent(this.jLabel7, -2, 392, -2)))
/* 2975 */           .addGap(100, 100, 100)
/* 2976 */           .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2977 */             .addComponent(this.jLabel3, -2, 392, -2)
/* 2978 */             .addGroup(vbdLayout.createSequentialGroup()
/* 2979 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2980 */                 .addGroup(vbdLayout.createSequentialGroup()
/* 2981 */                   .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 2982 */                     .addComponent(this.jLabel12, -1, 100, 32767)
/* 2983 */                     .addComponent(this.jLabel13, -1, -1, 32767))
/* 2984 */                   .addGap(18, 18, 18)
/* 2985 */                   .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2986 */                     .addComponent(this.asdlJklo, -2, 143, -2)
/* 2987 */                     .addComponent(this.Amklop, -2, 143, -2)))
/* 2988 */                 .addComponent(this.xdfj12, -2, 260, -2)
/* 2989 */                 .addGroup(vbdLayout.createSequentialGroup()
/* 2990 */                   .addGap(37, 37, 37)
/* 2991 */                   .addComponent(this.fdshQo, -2, 156, -2)))
/* 2992 */               .addGap(18, 18, 18)
/* 2993 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 2994 */                 .addComponent(this.sdfjho90, -2, 156, -2)
/* 2995 */                 .addComponent(this.dsfklop, -2, 156, -2))))
/* 2996 */           .addGap(0, 236, 32767)));
/*      */     
/* 2998 */     vbdLayout.setVerticalGroup(vbdLayout
/* 2999 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3000 */         .addGroup(vbdLayout.createSequentialGroup()
/* 3001 */           .addGap(97, 97, 97)
/* 3002 */           .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3003 */             .addGroup(vbdLayout.createSequentialGroup()
/* 3004 */               .addComponent(this.jLabel7, -2, 55, -2)
/* 3005 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 3006 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 3007 */                 .addGroup(vbdLayout.createSequentialGroup()
/* 3008 */                   .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3009 */                     .addComponent(this.jLabel25, -2, 30, -2)
/* 3010 */                     .addComponent(this.dslkfjA123, -2, 30, -2))
/* 3011 */                   .addGap(18, 18, 18)
/* 3012 */                   .addComponent(this.dfhskj123456, -2, 122, -2))
/* 3013 */                 .addComponent(this.sdfhk89076, -2, 182, -2))
/* 3014 */               .addGap(18, 18, 18)
/* 3015 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3016 */                 .addComponent(this.dsfljslKIOP)
/* 3017 */                 .addComponent(this.djskfLop)))
/* 3018 */             .addGroup(vbdLayout.createSequentialGroup()
/* 3019 */               .addComponent(this.jLabel3, -2, 55, -2)
/* 3020 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 3021 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3022 */                 .addGroup(vbdLayout.createSequentialGroup()
/* 3023 */                   .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3024 */                     .addComponent(this.asdlJklo)
/* 3025 */                     .addComponent(this.jLabel12, -2, 32, -2))
/* 3026 */                   .addGap(18, 18, 18)
/* 3027 */                   .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3028 */                     .addComponent(this.jLabel13, -2, 33, -2)
/* 3029 */                     .addComponent(this.Amklop))
/* 3030 */                   .addGap(115, 115, 115))
/* 3031 */                 .addGroup(vbdLayout.createSequentialGroup()
/* 3032 */                   .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 3033 */                     .addGroup(vbdLayout.createSequentialGroup()
/* 3034 */                       .addComponent(this.xdfj12, -2, 86, -2)
/* 3035 */                       .addGap(2, 2, 2))
/* 3036 */                     .addComponent(this.sdfjho90, -2, 182, -2))
/* 3037 */                   .addGap(18, 18, 18)))
/* 3038 */               .addGroup(vbdLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3039 */                 .addComponent(this.dsfklop)
/* 3040 */                 .addComponent(this.fdshQo))))
/* 3041 */           .addContainerGap(193, 32767)));
/*      */ 
/*      */     
/* 3044 */     this.klo09812j.add(this.vbd, "AddItem");
/*      */     
/* 3046 */     this.weiuyr78GHJ.setBackground(new Color(255, 255, 255));
/*      */     
/* 3048 */     this.Ajklou12.setFont(new Font("Tahoma", 0, 14));
/* 3049 */     this.Ajklou12.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 3050 */     this.Ajklou12.setNextFocusableComponent(this.jklOPhsklop);
/* 3051 */     this.Ajklou12.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 3053 */             hjklout678.this.Ajklou12KeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3057 */     this.jklOPhsklop.setFont(new Font("Tahoma", 0, 14));
/* 3058 */     this.jklOPhsklop.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 3059 */     this.jklOPhsklop.setNextFocusableComponent(this.klopas234);
/* 3060 */     this.jklOPhsklop.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 3062 */             hjklout678.this.jklOPhsklopKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3066 */     this.JKLOPas1234.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2));
/*      */     
/* 3068 */     this.klopas234.setFont(new Font("Tahoma", 0, 14));
/* 3069 */     this.klopas234.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 3070 */     this.klopas234.setNextFocusableComponent(this.Nmklobvg);
/*      */     
/* 3072 */     this.Nmklobvg.setFont(new Font("Tahoma", 0, 14));
/* 3073 */     this.Nmklobvg.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 3074 */     this.Nmklobvg.setNextFocusableComponent(this.Nkiopgty67i);
/*      */     
/* 3076 */     this.Nkiopgty67i.setFont(new Font("Tahoma", 0, 14));
/* 3077 */     this.Nkiopgty67i.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 3078 */     this.Nkiopgty67i.setNextFocusableComponent(this.aJKIy786g);
/*      */     
/* 3080 */     this.aJKIy786g.setFont(new Font("Tahoma", 0, 14));
/* 3081 */     this.aJKIy786g.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 3082 */     this.aJKIy786g.setNextFocusableComponent(this.JHYULOP);
/*      */     
/* 3084 */     this.JHYULOP.setFont(new Font("Tahoma", 0, 14));
/* 3085 */     this.JHYULOP.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 3086 */     this.JHYULOP.setNextFocusableComponent(this.AJKLOP);
/*      */     
/* 3088 */     this.AJKLOP.setText("Load Image");
/* 3089 */     this.AJKLOP.setNextFocusableComponent(this.JKlopwr);
/* 3090 */     this.AJKLOP.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3092 */             hjklout678.this.AJKLOPMouseClicked(evt);
/*      */           }
/*      */         });
/* 3095 */     this.AJKLOP.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 3097 */             hjklout678.this.AJKLOPActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3101 */     this.AGHY.setText("Scan BarCode");
/* 3102 */     this.AGHY.setNextFocusableComponent(this.XAa);
/* 3103 */     this.AGHY.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3105 */             hjklout678.this.AGHYMouseClicked(evt);
/*      */           }
/*      */         });
/* 3108 */     this.AGHY.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 3110 */             hjklout678.this.AGHYActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3114 */     this.XAa.setText("Update Product");
/* 3115 */     this.XAa.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 3117 */             hjklout678.this.XAaActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3121 */     this.JKlopwr.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0), 2));
/* 3122 */     this.JKlopwr.setNextFocusableComponent(this.XAa);
/* 3123 */     this.JKlopwr.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 3125 */             hjklout678.this.JKlopwrKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3129 */     this.jLabel30.setFont(new Font("Tahoma", 0, 18));
/* 3130 */     this.jLabel30.setText("Product Size");
/*      */     
/* 3132 */     this.jLabel31.setFont(new Font("Tahoma", 0, 18));
/* 3133 */     this.jLabel31.setText("Available Units");
/*      */     
/* 3135 */     this.jLabel32.setFont(new Font("Tahoma", 0, 18));
/* 3136 */     this.jLabel32.setText("Unit Price");
/*      */     
/* 3138 */     this.jLabel33.setFont(new Font("Tahoma", 0, 18));
/* 3139 */     this.jLabel33.setText("Company Name");
/*      */     
/* 3141 */     this.jLabel34.setFont(new Font("Tahoma", 0, 18));
/* 3142 */     this.jLabel34.setText("Category Name");
/*      */     
/* 3144 */     this.jLabel35.setFont(new Font("Tahoma", 0, 24));
/* 3145 */     this.jLabel35.setText("Update Products ");
/*      */     
/* 3147 */     this.jLabel18.setForeground(new Color(255, 51, 0));
/* 3148 */     this.jLabel18.setText("* mandatory");
/*      */     
/* 3150 */     this.jLabel21.setForeground(new Color(255, 51, 0));
/* 3151 */     this.jLabel21.setText("*");
/*      */     
/* 3153 */     this.jLabel47.setFont(new Font("Tahoma", 0, 18));
/* 3154 */     this.jLabel47.setText("Sales Price");
/*      */     
/* 3156 */     this.sdjlop.setModel(new DefaultComboBoxModel<>(new String[] { "barcode", "name" }));
/*      */     
/* 3158 */     this.jLabel10.setFont(new Font("Tahoma", 0, 18));
/* 3159 */     this.jLabel10.setText("Name");
/*      */     
/* 3161 */     this.Jkiop90875sad.setFont(new Font("Tahoma", 0, 14));
/* 3162 */     this.Jkiop90875sad.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(204, 204, 204)));
/*      */     
/* 3164 */     this.Ajklo.setText("jLabel16");
/*      */     
/* 3166 */     GroupLayout weiuyr78GHJLayout = new GroupLayout(this.weiuyr78GHJ);
/* 3167 */     this.weiuyr78GHJ.setLayout(weiuyr78GHJLayout);
/* 3168 */     weiuyr78GHJLayout.setHorizontalGroup(weiuyr78GHJLayout
/* 3169 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3170 */         .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3171 */           .addGap(32, 32, 32)
/* 3172 */           .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3173 */             .addComponent(this.jLabel35)
/* 3174 */             .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3175 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3176 */                 .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3177 */                   .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3178 */                     .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3179 */                       .addComponent(this.sdjlop, -2, 107, -2)
/* 3180 */                       .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 3181 */                       .addComponent(this.jLabel21)
/* 3182 */                       .addGap(49, 49, 49)
/* 3183 */                       .addComponent(this.Ajklou12, -2, 139, -2))
/* 3184 */                     .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3185 */                       .addComponent(this.jLabel34)
/* 3186 */                       .addGap(51, 51, 51)
/* 3187 */                       .addComponent(this.klopas234))
/* 3188 */                     .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3189 */                       .addComponent(this.jLabel32)
/* 3190 */                       .addGap(97, 97, 97)
/* 3191 */                       .addComponent(this.Nkiopgty67i))
/* 3192 */                     .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3193 */                       .addComponent(this.jLabel33)
/* 3194 */                       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 3195 */                       .addComponent(this.Nmklobvg, -2, 139, -2))
/* 3196 */                     .addGroup(GroupLayout.Alignment.TRAILING, weiuyr78GHJLayout.createSequentialGroup()
/* 3197 */                       .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3198 */                         .addComponent(this.jLabel31)
/* 3199 */                         .addComponent(this.jLabel47))
/* 3200 */                       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 3201 */                       .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3202 */                         .addComponent(this.JHYULOP, -1, 139, 32767)
/* 3203 */                         .addComponent(this.aJKIy786g)))
/* 3204 */                     .addGroup(GroupLayout.Alignment.TRAILING, weiuyr78GHJLayout.createSequentialGroup()
/* 3205 */                       .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3206 */                         .addComponent(this.jLabel30)
/* 3207 */                         .addComponent(this.jLabel10, -2, 125, -2))
/* 3208 */                       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 3209 */                       .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3210 */                         .addComponent(this.jklOPhsklop, -1, 139, 32767)
/* 3211 */                         .addComponent(this.Jkiop90875sad)))
/* 3212 */                     .addComponent(this.jLabel18, -2, 166, -2))
/* 3213 */                   .addGap(91, 91, 91))
/* 3214 */                 .addGroup(GroupLayout.Alignment.TRAILING, weiuyr78GHJLayout.createSequentialGroup()
/* 3215 */                   .addComponent(this.Ajklo, -2, 265, -2)
/* 3216 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)))
/* 3217 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3218 */                 .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3219 */                   .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3220 */                     .addComponent(this.JKLOPas1234, -1, -1, 32767)
/* 3221 */                     .addComponent(this.AJKLOP, -2, 150, -2))
/* 3222 */                   .addGap(45, 45, 45)
/* 3223 */                   .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3224 */                     .addComponent(this.AGHY, -1, -1, 32767)
/* 3225 */                     .addComponent(this.JKlopwr, -2, 156, -2)))
/* 3226 */                 .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3227 */                   .addGap(99, 99, 99)
/* 3228 */                   .addComponent(this.XAa, -2, 156, -2)))))
/* 3229 */           .addContainerGap(408, 32767)));
/*      */     
/* 3231 */     weiuyr78GHJLayout.setVerticalGroup(weiuyr78GHJLayout
/* 3232 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3233 */         .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3234 */           .addGap(39, 39, 39)
/* 3235 */           .addComponent(this.jLabel35, -2, 55, -2)
/* 3236 */           .addGap(19, 19, 19)
/* 3237 */           .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 3238 */             .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3239 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3240 */                 .addComponent(this.Ajklou12, -2, 22, -2)
/* 3241 */                 .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3242 */                   .addComponent(this.jLabel21)
/* 3243 */                   .addComponent(this.sdjlop, -2, 30, -2)))
/* 3244 */               .addGap(30, 30, 30)
/* 3245 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3246 */                 .addComponent(this.jLabel10)
/* 3247 */                 .addComponent(this.Jkiop90875sad, -2, 22, -2))
/* 3248 */               .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 3249 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3250 */                 .addComponent(this.jLabel30)
/* 3251 */                 .addComponent(this.jklOPhsklop, -2, 22, -2))
/* 3252 */               .addGap(18, 18, 18)
/* 3253 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 3254 */                 .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3255 */                   .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3256 */                     .addComponent(this.jLabel34)
/* 3257 */                     .addComponent(this.klopas234, -2, 22, -2))
/* 3258 */                   .addGap(18, 18, 18)
/* 3259 */                   .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3260 */                     .addComponent(this.jLabel33)
/* 3261 */                     .addComponent(this.Nmklobvg, -2, 22, -2))
/* 3262 */                   .addGap(18, 18, 18)
/* 3263 */                   .addComponent(this.jLabel32))
/* 3264 */                 .addComponent(this.Nkiopgty67i, -2, 22, -2))
/* 3265 */               .addGap(18, 18, 18)
/* 3266 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3267 */                 .addComponent(this.jLabel47, -2, 18, -2)
/* 3268 */                 .addComponent(this.aJKIy786g, -2, 22, -2))
/* 3269 */               .addGap(18, 18, 18)
/* 3270 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3271 */                 .addComponent(this.jLabel31)
/* 3272 */                 .addComponent(this.JHYULOP, -2, 22, -2))
/* 3273 */               .addGap(18, 18, 18)
/* 3274 */               .addComponent(this.jLabel18))
/* 3275 */             .addGroup(weiuyr78GHJLayout.createSequentialGroup()
/* 3276 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3277 */                 .addComponent(this.JKLOPas1234, -2, 182, -2)
/* 3278 */                 .addComponent(this.JKlopwr, GroupLayout.Alignment.TRAILING, -2, 182, -2))
/* 3279 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 3280 */               .addGroup(weiuyr78GHJLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3281 */                 .addComponent(this.AJKLOP)
/* 3282 */                 .addComponent(this.AGHY))
/* 3283 */               .addGap(51, 51, 51)
/* 3284 */               .addComponent(this.XAa)))
/* 3285 */           .addGap(18, 18, 18)
/* 3286 */           .addComponent(this.Ajklo, -2, 25, -2)
/* 3287 */           .addContainerGap(65, 32767)));
/*      */ 
/*      */     
/* 3290 */     this.klo09812j.add(this.weiuyr78GHJ, "update");
/*      */     
/* 3292 */     this.Aklop.setBackground(new Color(255, 255, 255));
/*      */     
/* 3294 */     this.jklop0.setText("Expand");
/* 3295 */     this.jklop0.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3297 */             hjklout678.this.jklop0MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 3301 */     this.add_salesman_name.setText("Name");
/*      */     
/* 3303 */     this.dd4.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/* 3305 */             hjklout678.this.dd4ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3309 */     this.add_salesman_cont.setText("Contact");
/*      */     
/* 3311 */     this.add_salesman_comp.setText("Comp.");
/*      */     
/* 3313 */     this.jdsfkh123.setText("Save");
/* 3314 */     this.jdsfkh123.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3316 */             hjklout678.this.jdsfkh123MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 3320 */     GroupLayout sdfjkhl12jh4Layout = new GroupLayout(this.sdfjkhl12jh4);
/* 3321 */     this.sdfjkhl12jh4.setLayout(sdfjkhl12jh4Layout);
/* 3322 */     sdfjkhl12jh4Layout.setHorizontalGroup(sdfjkhl12jh4Layout
/* 3323 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3324 */         .addGroup(sdfjkhl12jh4Layout.createSequentialGroup()
/* 3325 */           .addContainerGap()
/* 3326 */           .addGroup(sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3327 */             .addComponent(this.jklop0)
/* 3328 */             .addGroup(GroupLayout.Alignment.TRAILING, sdfjkhl12jh4Layout.createSequentialGroup()
/* 3329 */               .addGap(0, 0, 32767)
/* 3330 */               .addGroup(sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3331 */                 .addGroup(GroupLayout.Alignment.TRAILING, sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3332 */                   .addGroup(sdfjkhl12jh4Layout.createSequentialGroup()
/* 3333 */                     .addComponent(this.add_salesman_name, -2, 69, -2)
/* 3334 */                     .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 3335 */                     .addComponent(this.dd4, -2, 136, -2))
/* 3336 */                   .addGroup(sdfjkhl12jh4Layout.createSequentialGroup()
/* 3337 */                     .addGroup(sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3338 */                       .addComponent(this.add_salesman_cont)
/* 3339 */                       .addComponent(this.add_salesman_comp))
/* 3340 */                     .addGap(34, 34, 34)
/* 3341 */                     .addGroup(sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3342 */                       .addComponent(this.ds23)
/* 3343 */                       .addComponent(this.aslkol, -1, 137, 32767))))
/* 3344 */                 .addComponent(this.jdsfkh123, GroupLayout.Alignment.TRAILING, -2, 137, -2))))
/* 3345 */           .addContainerGap()));
/*      */     
/* 3347 */     sdfjkhl12jh4Layout.setVerticalGroup(sdfjkhl12jh4Layout
/* 3348 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3349 */         .addGroup(sdfjkhl12jh4Layout.createSequentialGroup()
/* 3350 */           .addContainerGap()
/* 3351 */           .addComponent(this.jklop0)
/* 3352 */           .addGap(71, 71, 71)
/* 3353 */           .addGroup(sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3354 */             .addComponent(this.add_salesman_name)
/* 3355 */             .addComponent(this.dd4, -2, -1, -2))
/* 3356 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 3357 */           .addGroup(sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3358 */             .addComponent(this.add_salesman_cont)
/* 3359 */             .addComponent(this.ds23, -2, -1, -2))
/* 3360 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 3361 */           .addGroup(sdfjkhl12jh4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3362 */             .addComponent(this.add_salesman_comp, -2, 22, -2)
/* 3363 */             .addComponent(this.aslkol, -2, -1, -2))
/* 3364 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 3365 */           .addComponent(this.jdsfkh123)
/* 3366 */           .addGap(360, 360, 360)));
/*      */ 
/*      */     
/* 3369 */     this.jLabel22.setFont(new Font("Tahoma", 0, 18));
/* 3370 */     this.jLabel22.setText("SalesMan Details");
/*      */     
/* 3372 */     this.jLabel20.setFont(new Font("Tahoma", 0, 14));
/* 3373 */     this.jLabel20.setText("Search by");
/*      */     
/* 3375 */     this.AKLMH7896yh.setModel(new DefaultComboBoxModel<>(new String[] { "name", "contact", "company" }));
/*      */     
/* 3377 */     this.hjllop.setFont(new Font("Tahoma", 0, 14));
/* 3378 */     this.hjllop.setForeground(new Color(204, 204, 204));
/* 3379 */     this.hjllop.setText("press Enter To Search");
/* 3380 */     this.hjllop.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(102, 102, 102)));
/* 3381 */     this.hjllop.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3383 */             hjklout678.this.hjllopMouseClicked(evt);
/*      */           }
/*      */         });
/* 3386 */     this.hjllop.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 3388 */             hjklout678.this.hjllopKeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3392 */     this.jLabel26.setFont(new Font("Tahoma", 0, 14));
/* 3393 */     this.jLabel26.setText("NAme");
/*      */     
/* 3395 */     this.mn8.setFont(new Font("Tahoma", 0, 14));
/*      */     
/* 3397 */     this.jLabel28.setFont(new Font("Tahoma", 0, 14));
/* 3398 */     this.jLabel28.setText("Contact");
/*      */     
/* 3400 */     this.mk0.setFont(new Font("Tahoma", 0, 14));
/*      */     
/* 3402 */     this.jLabel49.setFont(new Font("Tahoma", 0, 14));
/* 3403 */     this.jLabel49.setText("Company");
/*      */     
/* 3405 */     this.nk9.setFont(new Font("Tahoma", 0, 14));
/*      */     
/* 3407 */     GroupLayout AklopLayout = new GroupLayout(this.Aklop);
/* 3408 */     this.Aklop.setLayout(AklopLayout);
/* 3409 */     AklopLayout.setHorizontalGroup(AklopLayout
/* 3410 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3411 */         .addGroup(AklopLayout.createSequentialGroup()
/* 3412 */           .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3413 */             .addGroup(AklopLayout.createSequentialGroup()
/* 3414 */               .addGap(22, 22, 22)
/* 3415 */               .addComponent(this.jLabel22, -2, 136, -2))
/* 3416 */             .addGroup(AklopLayout.createSequentialGroup()
/* 3417 */               .addGap(138, 138, 138)
/* 3418 */               .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3419 */                 .addGroup(AklopLayout.createSequentialGroup()
/* 3420 */                   .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3421 */                     .addComponent(this.jLabel49, -2, 100, -2)
/* 3422 */                     .addComponent(this.jLabel28, -2, 100, -2)
/* 3423 */                     .addComponent(this.jLabel26, -2, 100, -2))
/* 3424 */                   .addGap(44, 44, 44)
/* 3425 */                   .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3426 */                     .addComponent(this.mn8, -1, -1, 32767)
/* 3427 */                     .addComponent(this.mk0, -1, -1, 32767)
/* 3428 */                     .addComponent(this.nk9, -1, 247, 32767)))
/* 3429 */                 .addGroup(AklopLayout.createSequentialGroup()
/* 3430 */                   .addComponent(this.jLabel20, -2, 65, -2)
/* 3431 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 3432 */                   .addComponent(this.AKLMH7896yh, -2, 81, -2)
/* 3433 */                   .addGap(18, 18, 18)
/* 3434 */                   .addComponent(this.hjllop, -2, 217, -2)))))
/* 3435 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 435, 32767)
/* 3436 */           .addComponent(this.sdfjkhl12jh4, -2, -1, -2)));
/*      */     
/* 3438 */     AklopLayout.setVerticalGroup(AklopLayout
/* 3439 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3440 */         .addGroup(AklopLayout.createSequentialGroup()
/* 3441 */           .addContainerGap()
/* 3442 */           .addComponent(this.jLabel22, -2, 44, -2)
/* 3443 */           .addGap(50, 50, 50)
/* 3444 */           .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3445 */             .addComponent(this.jLabel20, -2, 23, -2)
/* 3446 */             .addComponent(this.AKLMH7896yh, -2, 23, -2)
/* 3447 */             .addComponent(this.hjllop, -2, 25, -2))
/* 3448 */           .addGap(55, 55, 55)
/* 3449 */           .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3450 */             .addComponent(this.jLabel26, -2, 22, -2)
/* 3451 */             .addComponent(this.mn8, -2, 22, -2))
/* 3452 */           .addGap(18, 18, 18)
/* 3453 */           .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3454 */             .addComponent(this.jLabel28, -2, 22, -2)
/* 3455 */             .addComponent(this.mk0, -2, 22, -2))
/* 3456 */           .addGap(18, 18, 18)
/* 3457 */           .addGroup(AklopLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3458 */             .addComponent(this.jLabel49, -2, 22, -2)
/* 3459 */             .addComponent(this.nk9, -2, 22, -2))
/* 3460 */           .addContainerGap(-1, 32767))
/* 3461 */         .addComponent(this.sdfjkhl12jh4, GroupLayout.Alignment.TRAILING, -1, -1, 32767));
/*      */ 
/*      */     
/* 3464 */     this.klo09812j.add(this.Aklop, "Salesman");
/*      */     
/* 3466 */     this.alkop12.setBackground(new Color(255, 255, 255));
/*      */     
/* 3468 */     this.jLabel27.setFont(new Font("Tahoma", 0, 24));
/* 3469 */     this.jLabel27.setText("Profit and Loss");
/*      */     
/* 3471 */     this.jLabel48.setFont(new Font("Tahoma", 0, 14));
/* 3472 */     this.jLabel48.setText("Search Query");
/*      */     
/* 3474 */     this.sd9.setForeground(new Color(102, 102, 102));
/* 3475 */     this.sd9.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(102, 102, 102)));
/* 3476 */     this.sd9.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3478 */             hjklout678.this.sd9MouseClicked(evt);
/*      */           }
/*      */         });
/* 3481 */     this.sd9.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 3483 */             hjklout678.this.sd9KeyPressed(evt);
/*      */           }
/*      */           public void keyReleased(KeyEvent evt) {
/* 3486 */             hjklout678.this.sd9KeyReleased(evt);
/*      */           }
/*      */         });
/*      */     
/* 3490 */     this.jScrollPane1.setBackground(new Color(255, 255, 255));
/* 3491 */     this.jScrollPane1.setBorder(BorderFactory.createLineBorder(new Color(204, 204, 204)));
/*      */     
/* 3493 */     this.Al09.setFont(new Font("Segoe UI", 0, 14));
/* 3494 */     this.Al09.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "Product Name", "Barcode", "ShopID", "Profit" })
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3502 */           boolean[] canEdit = new boolean[] { false, false, false, true };
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean isCellEditable(int rowIndex, int columnIndex) {
/* 3507 */             return this.canEdit[columnIndex];
/*      */           }
/*      */         });
/* 3510 */     this.Al09.setCellSelectionEnabled(true);
/* 3511 */     this.Al09.setGridColor(new Color(204, 204, 204));
/* 3512 */     this.Al09.setOpaque(false);
/* 3513 */     this.Al09.setRowHeight(20);
/* 3514 */     this.Al09.getTableHeader().setReorderingAllowed(false);
/* 3515 */     this.jScrollPane1.setViewportView(this.Al09);
/* 3516 */     this.Al09.getColumnModel().getSelectionModel().setSelectionMode(1);
/* 3517 */     if (this.Al09.getColumnModel().getColumnCount() > 0) {
/* 3518 */       this.Al09.getColumnModel().getColumn(0).setPreferredWidth(150);
/* 3519 */       this.Al09.getColumnModel().getColumn(1).setPreferredWidth(150);
/* 3520 */       this.Al09.getColumnModel().getColumn(2).setPreferredWidth(255);
/*      */     } 
/*      */     
/* 3523 */     this.jLabel23.setFont(new Font("Tahoma", 0, 14));
/* 3524 */     this.jLabel23.setText("Total Profit");
/*      */     
/* 3526 */     this.Alm89.setFont(new Font("Tahoma", 0, 14));
/* 3527 */     this.Alm89.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(204, 204, 204)));
/*      */     
/* 3529 */     this.jButton28.setText("Clear");
/* 3530 */     this.jButton28.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3532 */             hjklout678.this.jButton28MouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 3536 */     GroupLayout alkop12Layout = new GroupLayout(this.alkop12);
/* 3537 */     this.alkop12.setLayout(alkop12Layout);
/* 3538 */     alkop12Layout.setHorizontalGroup(alkop12Layout
/* 3539 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3540 */         .addGroup(alkop12Layout.createSequentialGroup()
/* 3541 */           .addComponent(this.jLabel27)
/* 3542 */           .addGap(0, 0, 32767))
/* 3543 */         .addGroup(alkop12Layout.createSequentialGroup()
/* 3544 */           .addContainerGap(266, 32767)
/* 3545 */           .addGroup(alkop12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3546 */             .addGroup(alkop12Layout.createSequentialGroup()
/* 3547 */               .addComponent(this.jLabel48, -2, 87, -2)
/* 3548 */               .addGap(18, 18, 18)
/* 3549 */               .addComponent(this.sd9, -2, 405, -2))
/* 3550 */             .addGroup(alkop12Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 3551 */               .addGroup(alkop12Layout.createSequentialGroup()
/* 3552 */                 .addComponent(this.jLabel23, -2, 105, -2)
/* 3553 */                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 3554 */                 .addComponent(this.Alm89, -2, 85, -2)
/* 3555 */                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 3556 */                 .addComponent(this.jButton28, -2, 82, -2))
/* 3557 */               .addComponent(this.jScrollPane1, -2, 648, -2)))
/* 3558 */           .addContainerGap(279, 32767)));
/*      */     
/* 3560 */     alkop12Layout.setVerticalGroup(alkop12Layout
/* 3561 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3562 */         .addGroup(alkop12Layout.createSequentialGroup()
/* 3563 */           .addGroup(alkop12Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 3564 */             .addComponent(this.jButton28)
/* 3565 */             .addGroup(alkop12Layout.createSequentialGroup()
/* 3566 */               .addComponent(this.jLabel27)
/* 3567 */               .addGap(50, 50, 50)
/* 3568 */               .addGroup(alkop12Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3569 */                 .addComponent(this.jLabel48, -2, 31, -2)
/* 3570 */                 .addComponent(this.sd9, -2, 31, -2))
/* 3571 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 3572 */               .addComponent(this.jScrollPane1, -2, 305, -2)
/* 3573 */               .addGap(18, 18, 18)
/* 3574 */               .addGroup(alkop12Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 3575 */                 .addComponent(this.Alm89, -1, -1, 32767)
/* 3576 */                 .addComponent(this.jLabel23, -1, 28, 32767))))
/* 3577 */           .addContainerGap(77, 32767)));
/*      */ 
/*      */     
/* 3580 */     this.klo09812j.add(this.alkop12, "profitloss");
/*      */     
/* 3582 */     this.QAs.setBackground(new Color(255, 255, 255));
/* 3583 */     this.QAs.setForeground(new Color(255, 255, 255));
/*      */     
/* 3585 */     this.jLabel37.setFont(new Font("Tahoma", 0, 16));
/* 3586 */     this.jLabel37.setText("Product Name");
/*      */     
/* 3588 */     this.jLabel43.setFont(new Font("Tahoma", 0, 16));
/* 3589 */     this.jLabel43.setText("Barcode");
/*      */     
/* 3591 */     this.prod_sort_icon.setFont(new Font("Tahoma", 0, 16));
/* 3592 */     this.prod_sort_icon.setText("Quantity");
/* 3593 */     this.prod_sort_icon.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3595 */             hjklout678.this.prod_sort_iconMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     
/* 3599 */     this.jLabel56.setFont(new Font("Tahoma", 0, 16));
/* 3600 */     this.jLabel56.setText("Sales Price");
/*      */     
/* 3602 */     this.search_order_icon1.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/* 3604 */             hjklout678.this.search_order_icon1MouseClicked(evt);
/*      */           }
/*      */         });
/* 3607 */     this.search_order_icon1.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/* 3609 */             hjklout678.this.search_order_icon1KeyPressed(evt);
/*      */           }
/*      */         });
/*      */     
/* 3613 */     this.jLabel17.setFont(new Font("Tahoma", 0, 16));
/* 3614 */     this.jLabel17.setText("Purchase Price");
/*      */     
/* 3616 */     GroupLayout header1Layout = new GroupLayout(this.header1);
/* 3617 */     this.header1.setLayout(header1Layout);
/* 3618 */     header1Layout.setHorizontalGroup(header1Layout
/* 3619 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3620 */         .addGroup(header1Layout.createSequentialGroup()
/* 3621 */           .addGap(20, 20, 20)
/* 3622 */           .addComponent(this.jLabel37, -2, 185, -2)
/* 3623 */           .addGap(37, 37, 37)
/* 3624 */           .addComponent(this.jLabel43, -2, 107, -2)
/* 3625 */           .addGap(74, 74, 74)
/* 3626 */           .addComponent(this.prod_sort_icon)
/* 3627 */           .addGap(62, 62, 62)
/* 3628 */           .addComponent(this.jLabel56, -2, 85, -2)
/* 3629 */           .addGap(40, 40, 40)
/* 3630 */           .addComponent(this.jLabel17)
/* 3631 */           .addGap(30, 30, 30)
/* 3632 */           .addComponent(this.search_order_icon1)
/* 3633 */           .addGap(12, 12, 12)));
/*      */     
/* 3635 */     header1Layout.setVerticalGroup(header1Layout
/* 3636 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3637 */         .addGroup(header1Layout.createSequentialGroup()
/* 3638 */           .addGroup(header1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3639 */             .addGroup(header1Layout.createSequentialGroup()
/* 3640 */               .addContainerGap()
/* 3641 */               .addGroup(header1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3642 */                 .addComponent(this.jLabel37, -1, -1, 32767)
/* 3643 */                 .addComponent(this.jLabel43)
/* 3644 */                 .addComponent(this.prod_sort_icon)
/* 3645 */                 .addComponent(this.jLabel56)
/* 3646 */                 .addComponent(this.jLabel17)))
/* 3647 */             .addComponent(this.search_order_icon1, -1, -1, 32767))
/* 3648 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3651 */     this.o1_id7.setFont(new Font("Tahoma", 0, 14));
/* 3652 */     this.o1_id7.setText("jLabel19");
/*      */     
/* 3654 */     this.o1_on7.setFont(new Font("Tahoma", 0, 14));
/* 3655 */     this.o1_on7.setText("jLabel19");
/*      */     
/* 3657 */     this.o1_oq7.setFont(new Font("Tahoma", 0, 14));
/* 3658 */     this.o1_oq7.setText("jLabel24");
/*      */     
/* 3660 */     this.o1_p7.setFont(new Font("Tahoma", 0, 14));
/* 3661 */     this.o1_p7.setText("jLabel25");
/*      */     
/* 3663 */     this.inv_pp7.setFont(new Font("Tahoma", 0, 14));
/* 3664 */     this.inv_pp7.setText("jLabel60");
/*      */     
/* 3666 */     GroupLayout o_u8Layout = new GroupLayout(this.o_u8);
/* 3667 */     this.o_u8.setLayout(o_u8Layout);
/* 3668 */     o_u8Layout.setHorizontalGroup(o_u8Layout
/* 3669 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3670 */         .addGroup(o_u8Layout.createSequentialGroup()
/* 3671 */           .addGap(21, 21, 21)
/* 3672 */           .addComponent(this.o1_id7, -2, 184, -2)
/* 3673 */           .addGap(37, 37, 37)
/* 3674 */           .addComponent(this.o1_on7, -2, 108, -2)
/* 3675 */           .addGap(101, 101, 101)
/* 3676 */           .addComponent(this.o1_oq7, -2, 53, -2)
/* 3677 */           .addGap(68, 68, 68)
/* 3678 */           .addComponent(this.o1_p7, -2, 70, -2)
/* 3679 */           .addGap(84, 84, 84)
/* 3680 */           .addComponent(this.inv_pp7, -1, -1, 32767)
/* 3681 */           .addContainerGap()));
/*      */     
/* 3683 */     o_u8Layout.setVerticalGroup(o_u8Layout
/* 3684 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3685 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u8Layout.createSequentialGroup()
/* 3686 */           .addContainerGap()
/* 3687 */           .addGroup(o_u8Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3688 */             .addComponent(this.o1_id7, -1, -1, 32767)
/* 3689 */             .addComponent(this.o1_on7)
/* 3690 */             .addComponent(this.o1_oq7, -1, -1, 32767)
/* 3691 */             .addComponent(this.o1_p7, -1, -1, 32767)
/* 3692 */             .addComponent(this.inv_pp7))
/* 3693 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3696 */     this.o1_id8.setFont(new Font("Tahoma", 0, 14));
/* 3697 */     this.o1_id8.setText("jLabel19");
/*      */     
/* 3699 */     this.o1_on8.setFont(new Font("Tahoma", 0, 14));
/* 3700 */     this.o1_on8.setText("jLabel19");
/*      */     
/* 3702 */     this.o1_oq8.setFont(new Font("Tahoma", 0, 14));
/* 3703 */     this.o1_oq8.setText("jLabel24");
/*      */     
/* 3705 */     this.o1_p8.setFont(new Font("Tahoma", 0, 14));
/* 3706 */     this.o1_p8.setText("jLabel25");
/*      */     
/* 3708 */     this.inv_pp6.setFont(new Font("Tahoma", 0, 14));
/* 3709 */     this.inv_pp6.setText("jLabel59");
/*      */     
/* 3711 */     GroupLayout o_u9Layout = new GroupLayout(this.o_u9);
/* 3712 */     this.o_u9.setLayout(o_u9Layout);
/* 3713 */     o_u9Layout.setHorizontalGroup(o_u9Layout
/* 3714 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3715 */         .addGroup(o_u9Layout.createSequentialGroup()
/* 3716 */           .addGap(21, 21, 21)
/* 3717 */           .addComponent(this.o1_id8, -2, 184, -2)
/* 3718 */           .addGap(36, 36, 36)
/* 3719 */           .addComponent(this.o1_on8, -2, 108, -2)
/* 3720 */           .addGap(101, 101, 101)
/* 3721 */           .addComponent(this.o1_oq8, -2, 53, -2)
/* 3722 */           .addGap(69, 69, 69)
/* 3723 */           .addComponent(this.o1_p8, -2, 70, -2)
/* 3724 */           .addGap(83, 83, 83)
/* 3725 */           .addComponent(this.inv_pp6, -1, -1, 32767)
/* 3726 */           .addContainerGap()));
/*      */     
/* 3728 */     o_u9Layout.setVerticalGroup(o_u9Layout
/* 3729 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3730 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u9Layout.createSequentialGroup()
/* 3731 */           .addContainerGap()
/* 3732 */           .addGroup(o_u9Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3733 */             .addComponent(this.o1_id8, -1, -1, 32767)
/* 3734 */             .addComponent(this.o1_on8)
/* 3735 */             .addComponent(this.o1_oq8, -1, -1, 32767)
/* 3736 */             .addComponent(this.o1_p8, -1, -1, 32767)
/* 3737 */             .addComponent(this.inv_pp6))
/* 3738 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3741 */     this.o1_id9.setFont(new Font("Tahoma", 0, 14));
/* 3742 */     this.o1_id9.setText("jLabel19");
/*      */     
/* 3744 */     this.o1_on9.setFont(new Font("Tahoma", 0, 14));
/* 3745 */     this.o1_on9.setText("jLabel19");
/*      */     
/* 3747 */     this.o1_oq9.setFont(new Font("Tahoma", 0, 14));
/* 3748 */     this.o1_oq9.setText("jLabel24");
/*      */     
/* 3750 */     this.o1_p9.setFont(new Font("Tahoma", 0, 14));
/* 3751 */     this.o1_p9.setText("jLabel25");
/*      */     
/* 3753 */     this.inv_pp5.setFont(new Font("Tahoma", 0, 14));
/* 3754 */     this.inv_pp5.setText("jLabel58");
/*      */     
/* 3756 */     GroupLayout o_u10Layout = new GroupLayout(this.o_u10);
/* 3757 */     this.o_u10.setLayout(o_u10Layout);
/* 3758 */     o_u10Layout.setHorizontalGroup(o_u10Layout
/* 3759 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3760 */         .addGroup(o_u10Layout.createSequentialGroup()
/* 3761 */           .addGap(21, 21, 21)
/* 3762 */           .addComponent(this.o1_id9, -2, 184, -2)
/* 3763 */           .addGap(36, 36, 36)
/* 3764 */           .addComponent(this.o1_on9, -2, 108, -2)
/* 3765 */           .addGap(101, 101, 101)
/* 3766 */           .addComponent(this.o1_oq9, -2, 53, -2)
/* 3767 */           .addGap(69, 69, 69)
/* 3768 */           .addComponent(this.o1_p9, -2, 70, -2)
/* 3769 */           .addGap(82, 82, 82)
/* 3770 */           .addComponent(this.inv_pp5, -1, -1, 32767)
/* 3771 */           .addContainerGap()));
/*      */     
/* 3773 */     o_u10Layout.setVerticalGroup(o_u10Layout
/* 3774 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3775 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u10Layout.createSequentialGroup()
/* 3776 */           .addContainerGap()
/* 3777 */           .addGroup(o_u10Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3778 */             .addComponent(this.o1_id9, -1, -1, 32767)
/* 3779 */             .addComponent(this.o1_on9)
/* 3780 */             .addComponent(this.o1_oq9, -1, -1, 32767)
/* 3781 */             .addComponent(this.o1_p9, -1, -1, 32767)
/* 3782 */             .addComponent(this.inv_pp5))
/* 3783 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3786 */     this.o1_id10.setFont(new Font("Tahoma", 0, 14));
/* 3787 */     this.o1_id10.setText("jLabel19");
/*      */     
/* 3789 */     this.o1_on10.setFont(new Font("Tahoma", 0, 14));
/* 3790 */     this.o1_on10.setText("jLabel19");
/*      */     
/* 3792 */     this.o1_oq10.setFont(new Font("Tahoma", 0, 14));
/* 3793 */     this.o1_oq10.setText("jLabel24");
/*      */     
/* 3795 */     this.o1_p10.setFont(new Font("Tahoma", 0, 14));
/* 3796 */     this.o1_p10.setText("jLabel25");
/*      */     
/* 3798 */     this.inv_pp4.setFont(new Font("Tahoma", 0, 14));
/* 3799 */     this.inv_pp4.setText("jLabel57");
/*      */     
/* 3801 */     GroupLayout o_u11Layout = new GroupLayout(this.o_u11);
/* 3802 */     this.o_u11.setLayout(o_u11Layout);
/* 3803 */     o_u11Layout.setHorizontalGroup(o_u11Layout
/* 3804 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3805 */         .addGroup(o_u11Layout.createSequentialGroup()
/* 3806 */           .addGap(21, 21, 21)
/* 3807 */           .addComponent(this.o1_id10, -2, 184, -2)
/* 3808 */           .addGap(36, 36, 36)
/* 3809 */           .addComponent(this.o1_on10, -2, 108, -2)
/* 3810 */           .addGap(101, 101, 101)
/* 3811 */           .addComponent(this.o1_oq10, -2, 53, -2)
/* 3812 */           .addGap(69, 69, 69)
/* 3813 */           .addComponent(this.o1_p10, -2, 70, -2)
/* 3814 */           .addGap(81, 81, 81)
/* 3815 */           .addComponent(this.inv_pp4, -1, -1, 32767)
/* 3816 */           .addContainerGap()));
/*      */     
/* 3818 */     o_u11Layout.setVerticalGroup(o_u11Layout
/* 3819 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3820 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u11Layout.createSequentialGroup()
/* 3821 */           .addContainerGap()
/* 3822 */           .addGroup(o_u11Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3823 */             .addComponent(this.o1_id10, -1, -1, 32767)
/* 3824 */             .addComponent(this.o1_on10)
/* 3825 */             .addComponent(this.o1_oq10, -1, -1, 32767)
/* 3826 */             .addComponent(this.o1_p10, -1, -1, 32767)
/* 3827 */             .addComponent(this.inv_pp4))
/* 3828 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3831 */     this.o1_id11.setFont(new Font("Tahoma", 0, 14));
/* 3832 */     this.o1_id11.setText("jLabel19");
/*      */     
/* 3834 */     this.o1_on11.setFont(new Font("Tahoma", 0, 14));
/* 3835 */     this.o1_on11.setText("jLabel19");
/*      */     
/* 3837 */     this.o1_oq11.setFont(new Font("Tahoma", 0, 14));
/* 3838 */     this.o1_oq11.setText("jLabel24");
/*      */     
/* 3840 */     this.o1_p11.setFont(new Font("Tahoma", 0, 14));
/* 3841 */     this.o1_p11.setText("jLabel25");
/*      */     
/* 3843 */     this.inv_pp3.setFont(new Font("Tahoma", 0, 14));
/* 3844 */     this.inv_pp3.setText("jLabel55");
/*      */     
/* 3846 */     GroupLayout o_u12Layout = new GroupLayout(this.o_u12);
/* 3847 */     this.o_u12.setLayout(o_u12Layout);
/* 3848 */     o_u12Layout.setHorizontalGroup(o_u12Layout
/* 3849 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3850 */         .addGroup(o_u12Layout.createSequentialGroup()
/* 3851 */           .addGap(21, 21, 21)
/* 3852 */           .addComponent(this.o1_id11, -2, 184, -2)
/* 3853 */           .addGap(34, 34, 34)
/* 3854 */           .addComponent(this.o1_on11, -2, 108, -2)
/* 3855 */           .addGap(102, 102, 102)
/* 3856 */           .addComponent(this.o1_oq11, -2, 53, -2)
/* 3857 */           .addGap(70, 70, 70)
/* 3858 */           .addComponent(this.o1_p11, -2, 70, -2)
/* 3859 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 3860 */           .addComponent(this.inv_pp3, -2, 160, -2)
/* 3861 */           .addContainerGap()));
/*      */     
/* 3863 */     o_u12Layout.setVerticalGroup(o_u12Layout
/* 3864 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3865 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u12Layout.createSequentialGroup()
/* 3866 */           .addContainerGap()
/* 3867 */           .addGroup(o_u12Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3868 */             .addComponent(this.o1_id11, -1, -1, 32767)
/* 3869 */             .addComponent(this.o1_on11)
/* 3870 */             .addComponent(this.o1_oq11, -1, -1, 32767)
/* 3871 */             .addComponent(this.o1_p11, -1, -1, 32767)
/* 3872 */             .addComponent(this.inv_pp3))
/* 3873 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3876 */     this.o1_id12.setFont(new Font("Tahoma", 0, 14));
/* 3877 */     this.o1_id12.setText("jLabel19");
/*      */     
/* 3879 */     this.o1_on12.setFont(new Font("Tahoma", 0, 14));
/* 3880 */     this.o1_on12.setText("jLabel19");
/*      */     
/* 3882 */     this.o1_oq12.setFont(new Font("Tahoma", 0, 14));
/* 3883 */     this.o1_oq12.setText("jLabel24");
/*      */     
/* 3885 */     this.o1_p12.setFont(new Font("Tahoma", 0, 14));
/* 3886 */     this.o1_p12.setText("jLabel25");
/*      */     
/* 3888 */     this.inv_pp2.setFont(new Font("Tahoma", 0, 14));
/* 3889 */     this.inv_pp2.setText("jLabel54");
/*      */     
/* 3891 */     GroupLayout o_u13Layout = new GroupLayout(this.o_u13);
/* 3892 */     this.o_u13.setLayout(o_u13Layout);
/* 3893 */     o_u13Layout.setHorizontalGroup(o_u13Layout
/* 3894 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3895 */         .addGroup(o_u13Layout.createSequentialGroup()
/* 3896 */           .addGap(21, 21, 21)
/* 3897 */           .addComponent(this.o1_id12, -2, 184, -2)
/* 3898 */           .addGap(34, 34, 34)
/* 3899 */           .addComponent(this.o1_on12, -2, 108, -2)
/* 3900 */           .addGap(101, 101, 101)
/* 3901 */           .addComponent(this.o1_oq12, -2, 53, -2)
/* 3902 */           .addGap(71, 71, 71)
/* 3903 */           .addComponent(this.o1_p12, -2, 70, -2)
/* 3904 */           .addGap(80, 80, 80)
/* 3905 */           .addComponent(this.inv_pp2, -1, 160, 32767)
/* 3906 */           .addContainerGap()));
/*      */     
/* 3908 */     o_u13Layout.setVerticalGroup(o_u13Layout
/* 3909 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3910 */         .addGroup(o_u13Layout.createSequentialGroup()
/* 3911 */           .addContainerGap()
/* 3912 */           .addGroup(o_u13Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3913 */             .addGroup(o_u13Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3914 */               .addComponent(this.o1_id12, -1, -1, 32767)
/* 3915 */               .addComponent(this.o1_oq12, -1, -1, 32767)
/* 3916 */               .addComponent(this.o1_p12, -1, -1, 32767)
/* 3917 */               .addComponent(this.inv_pp2))
/* 3918 */             .addGroup(GroupLayout.Alignment.TRAILING, o_u13Layout.createSequentialGroup()
/* 3919 */               .addGap(0, 4, 32767)
/* 3920 */               .addComponent(this.o1_on12)))
/* 3921 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3924 */     this.o1_id13.setFont(new Font("Tahoma", 0, 14));
/* 3925 */     this.o1_id13.setText("jLabel19");
/*      */     
/* 3927 */     this.o1_on13.setFont(new Font("Tahoma", 0, 14));
/* 3928 */     this.o1_on13.setText("jLabel19");
/*      */     
/* 3930 */     this.o1_oq13.setFont(new Font("Tahoma", 0, 14));
/* 3931 */     this.o1_oq13.setText("jLabel24");
/*      */     
/* 3933 */     this.o1_p13.setFont(new Font("Tahoma", 0, 14));
/* 3934 */     this.o1_p13.setText("jLabel25");
/*      */     
/* 3936 */     this.inv_pp1.setFont(new Font("Tahoma", 0, 14));
/* 3937 */     this.inv_pp1.setText("jLabel29");
/*      */     
/* 3939 */     GroupLayout o_u14Layout = new GroupLayout(this.o_u14);
/* 3940 */     this.o_u14.setLayout(o_u14Layout);
/* 3941 */     o_u14Layout.setHorizontalGroup(o_u14Layout
/* 3942 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3943 */         .addGroup(o_u14Layout.createSequentialGroup()
/* 3944 */           .addGap(21, 21, 21)
/* 3945 */           .addComponent(this.o1_id13, -2, 184, -2)
/* 3946 */           .addGap(31, 31, 31)
/* 3947 */           .addComponent(this.o1_on13, -2, 106, -2)
/* 3948 */           .addGap(106, 106, 106)
/* 3949 */           .addComponent(this.o1_oq13, -2, 52, -2)
/* 3950 */           .addGap(73, 73, 73)
/* 3951 */           .addComponent(this.o1_p13, -2, 70, -2)
/* 3952 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 3953 */           .addComponent(this.inv_pp1, -2, 160, -2)
/* 3954 */           .addContainerGap()));
/*      */     
/* 3956 */     o_u14Layout.setVerticalGroup(o_u14Layout
/* 3957 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3958 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u14Layout.createSequentialGroup()
/* 3959 */           .addContainerGap()
/* 3960 */           .addGroup(o_u14Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 3961 */             .addComponent(this.o1_id13, -1, -1, 32767)
/* 3962 */             .addComponent(this.o1_on13)
/* 3963 */             .addComponent(this.o1_oq13, -1, -1, 32767)
/* 3964 */             .addComponent(this.o1_p13, -1, -1, 32767)
/* 3965 */             .addComponent(this.inv_pp1))
/* 3966 */           .addContainerGap()));
/*      */ 
/*      */     
/* 3969 */     this.o1_id14.setFont(new Font("Tahoma", 0, 14));
/* 3970 */     this.o1_id14.setText("jLabel19");
/*      */     
/* 3972 */     this.o1_on14.setFont(new Font("Tahoma", 0, 14));
/* 3973 */     this.o1_on14.setText("jLabel19");
/*      */     
/* 3975 */     this.o1_oq14.setFont(new Font("Tahoma", 0, 14));
/* 3976 */     this.o1_oq14.setText("jLabel24");
/*      */     
/* 3978 */     this.o1_p14.setFont(new Font("Tahoma", 0, 14));
/* 3979 */     this.o1_p14.setText("jLabel25");
/*      */     
/* 3981 */     this.inv_pp8.setFont(new Font("Tahoma", 0, 14));
/* 3982 */     this.inv_pp8.setText("jLabel60");
/*      */     
/* 3984 */     GroupLayout o_u15Layout = new GroupLayout(this.o_u15);
/* 3985 */     this.o_u15.setLayout(o_u15Layout);
/* 3986 */     o_u15Layout.setHorizontalGroup(o_u15Layout
/* 3987 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 3988 */         .addGroup(o_u15Layout.createSequentialGroup()
/* 3989 */           .addGap(21, 21, 21)
/* 3990 */           .addComponent(this.o1_id14, -2, 184, -2)
/* 3991 */           .addGap(37, 37, 37)
/* 3992 */           .addComponent(this.o1_on14, -2, 108, -2)
/* 3993 */           .addGap(101, 101, 101)
/* 3994 */           .addComponent(this.o1_oq14, -2, 53, -2)
/* 3995 */           .addGap(68, 68, 68)
/* 3996 */           .addComponent(this.o1_p14, -2, 70, -2)
/* 3997 */           .addGap(84, 84, 84)
/* 3998 */           .addComponent(this.inv_pp8, -1, -1, 32767)
/* 3999 */           .addContainerGap()));
/*      */     
/* 4001 */     o_u15Layout.setVerticalGroup(o_u15Layout
/* 4002 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4003 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u15Layout.createSequentialGroup()
/* 4004 */           .addContainerGap()
/* 4005 */           .addGroup(o_u15Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 4006 */             .addComponent(this.o1_id14, -1, -1, 32767)
/* 4007 */             .addComponent(this.o1_on14)
/* 4008 */             .addComponent(this.o1_oq14, -1, -1, 32767)
/* 4009 */             .addComponent(this.o1_p14, -1, -1, 32767)
/* 4010 */             .addComponent(this.inv_pp8))
/* 4011 */           .addContainerGap()));
/*      */ 
/*      */     
/* 4014 */     this.o1_id15.setFont(new Font("Tahoma", 0, 14));
/* 4015 */     this.o1_id15.setText("jLabel19");
/*      */     
/* 4017 */     this.o1_on15.setFont(new Font("Tahoma", 0, 14));
/* 4018 */     this.o1_on15.setText("jLabel19");
/*      */     
/* 4020 */     this.o1_oq15.setFont(new Font("Tahoma", 0, 14));
/* 4021 */     this.o1_oq15.setText("jLabel24");
/*      */     
/* 4023 */     this.o1_p15.setFont(new Font("Tahoma", 0, 14));
/* 4024 */     this.o1_p15.setText("jLabel25");
/*      */     
/* 4026 */     this.inv_pp9.setFont(new Font("Tahoma", 0, 14));
/* 4027 */     this.inv_pp9.setText("jLabel59");
/*      */     
/* 4029 */     GroupLayout o_u16Layout = new GroupLayout(this.o_u16);
/* 4030 */     this.o_u16.setLayout(o_u16Layout);
/* 4031 */     o_u16Layout.setHorizontalGroup(o_u16Layout
/* 4032 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4033 */         .addGroup(o_u16Layout.createSequentialGroup()
/* 4034 */           .addGap(21, 21, 21)
/* 4035 */           .addComponent(this.o1_id15, -2, 184, -2)
/* 4036 */           .addGap(36, 36, 36)
/* 4037 */           .addComponent(this.o1_on15, -2, 108, -2)
/* 4038 */           .addGap(101, 101, 101)
/* 4039 */           .addComponent(this.o1_oq15, -2, 53, -2)
/* 4040 */           .addGap(69, 69, 69)
/* 4041 */           .addComponent(this.o1_p15, -2, 70, -2)
/* 4042 */           .addGap(83, 83, 83)
/* 4043 */           .addComponent(this.inv_pp9, -1, -1, 32767)
/* 4044 */           .addContainerGap()));
/*      */     
/* 4046 */     o_u16Layout.setVerticalGroup(o_u16Layout
/* 4047 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4048 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u16Layout.createSequentialGroup()
/* 4049 */           .addContainerGap()
/* 4050 */           .addGroup(o_u16Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 4051 */             .addComponent(this.o1_id15, -1, -1, 32767)
/* 4052 */             .addComponent(this.o1_on15)
/* 4053 */             .addComponent(this.o1_oq15, -1, -1, 32767)
/* 4054 */             .addComponent(this.o1_p15, -1, -1, 32767)
/* 4055 */             .addComponent(this.inv_pp9))
/* 4056 */           .addContainerGap()));
/*      */ 
/*      */     
/* 4059 */     this.o1_id16.setFont(new Font("Tahoma", 0, 14));
/* 4060 */     this.o1_id16.setText("jLabel19");
/*      */     
/* 4062 */     this.o1_on16.setFont(new Font("Tahoma", 0, 14));
/* 4063 */     this.o1_on16.setText("jLabel19");
/*      */     
/* 4065 */     this.o1_oq16.setFont(new Font("Tahoma", 0, 14));
/* 4066 */     this.o1_oq16.setText("jLabel24");
/*      */     
/* 4068 */     this.o1_p16.setFont(new Font("Tahoma", 0, 14));
/* 4069 */     this.o1_p16.setText("jLabel25");
/*      */     
/* 4071 */     this.inv_pp10.setFont(new Font("Tahoma", 0, 14));
/* 4072 */     this.inv_pp10.setText("jLabel60");
/*      */     
/* 4074 */     GroupLayout o_u17Layout = new GroupLayout(this.o_u17);
/* 4075 */     this.o_u17.setLayout(o_u17Layout);
/* 4076 */     o_u17Layout.setHorizontalGroup(o_u17Layout
/* 4077 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4078 */         .addGroup(o_u17Layout.createSequentialGroup()
/* 4079 */           .addGap(21, 21, 21)
/* 4080 */           .addComponent(this.o1_id16, -2, 184, -2)
/* 4081 */           .addGap(37, 37, 37)
/* 4082 */           .addComponent(this.o1_on16, -2, 108, -2)
/* 4083 */           .addGap(101, 101, 101)
/* 4084 */           .addComponent(this.o1_oq16, -2, 53, -2)
/* 4085 */           .addGap(68, 68, 68)
/* 4086 */           .addComponent(this.o1_p16, -2, 70, -2)
/* 4087 */           .addGap(84, 84, 84)
/* 4088 */           .addComponent(this.inv_pp10, -1, -1, 32767)
/* 4089 */           .addContainerGap()));
/*      */     
/* 4091 */     o_u17Layout.setVerticalGroup(o_u17Layout
/* 4092 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4093 */         .addGroup(GroupLayout.Alignment.TRAILING, o_u17Layout.createSequentialGroup()
/* 4094 */           .addContainerGap()
/* 4095 */           .addGroup(o_u17Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 4096 */             .addComponent(this.o1_id16, -1, -1, 32767)
/* 4097 */             .addComponent(this.o1_on16)
/* 4098 */             .addComponent(this.o1_oq16, -1, -1, 32767)
/* 4099 */             .addComponent(this.o1_p16, -1, -1, 32767)
/* 4100 */             .addComponent(this.inv_pp10))
/* 4101 */           .addContainerGap()));
/*      */ 
/*      */     
/* 4104 */     GroupLayout QAsLayout = new GroupLayout(this.QAs);
/* 4105 */     this.QAs.setLayout(QAsLayout);
/* 4106 */     QAsLayout.setHorizontalGroup(QAsLayout
/* 4107 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4108 */         .addGroup(QAsLayout.createSequentialGroup()
/* 4109 */           .addContainerGap(150, 32767)
/* 4110 */           .addGroup(QAsLayout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 4111 */             .addComponent(this.o_u13, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 4112 */             .addComponent(this.o_u12, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 4113 */             .addComponent(this.o_u11, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 4114 */             .addComponent(this.o_u9, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 4115 */             .addComponent(this.o_u10, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 4116 */             .addComponent(this.o_u8, GroupLayout.Alignment.LEADING, -1, -1, 32767)
/* 4117 */             .addComponent(this.header1, -1, -1, 32767)
/* 4118 */             .addComponent(this.o_u16, -1, -1, 32767)
/* 4119 */             .addComponent(this.o_u15, -1, -1, 32767)
/* 4120 */             .addComponent(this.o_u17, -1, -1, 32767)
/* 4121 */             .addComponent(this.o_u14, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 4122 */           .addContainerGap(151, 32767)));
/*      */     
/* 4124 */     QAsLayout.setVerticalGroup(QAsLayout
/* 4125 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4126 */         .addGroup(QAsLayout.createSequentialGroup()
/* 4127 */           .addGap(30, 30, 30)
/* 4128 */           .addComponent(this.header1, -2, -1, -2)
/* 4129 */           .addGap(18, 18, 18)
/* 4130 */           .addComponent(this.o_u14, -2, -1, -2)
/* 4131 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4132 */           .addComponent(this.o_u13, -2, -1, -2)
/* 4133 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4134 */           .addComponent(this.o_u12, -2, -1, -2)
/* 4135 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4136 */           .addComponent(this.o_u11, -2, -1, -2)
/* 4137 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4138 */           .addComponent(this.o_u10, -2, -1, -2)
/* 4139 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4140 */           .addComponent(this.o_u9, -2, -1, -2)
/* 4141 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4142 */           .addComponent(this.o_u8, -2, -1, -2)
/* 4143 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4144 */           .addComponent(this.o_u16, -2, -1, -2)
/* 4145 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4146 */           .addComponent(this.o_u15, -2, -1, -2)
/* 4147 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 4148 */           .addComponent(this.o_u17, -2, -1, -2)
/* 4149 */           .addContainerGap()));
/*      */ 
/*      */     
/* 4152 */     this.klo09812j.add(this.QAs, "allproducts");
/*      */     
/* 4154 */     GroupLayout klop7876Layout = new GroupLayout(this.klop7876);
/* 4155 */     this.klop7876.setLayout(klop7876Layout);
/* 4156 */     klop7876Layout.setHorizontalGroup(klop7876Layout
/* 4157 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4158 */         .addGroup(klop7876Layout.createSequentialGroup()
/* 4159 */           .addComponent(this.jk90, -2, -1, -2)
/* 4160 */           .addGap(4, 4, 4)
/* 4161 */           .addComponent(this.klo09812j, -1, -1, 32767))
/* 4162 */         .addComponent(this.hj760, -1, -1, 32767));
/*      */     
/* 4164 */     klop7876Layout.setVerticalGroup(klop7876Layout
/* 4165 */         .createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 4166 */         .addGroup(klop7876Layout.createSequentialGroup()
/* 4167 */           .addComponent(this.hj760, -2, -1, -2)
/* 4168 */           .addGap(0, 0, 0)
/* 4169 */           .addGroup(klop7876Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4170 */             .addGroup(klop7876Layout.createSequentialGroup()
/* 4171 */               .addGap(7, 7, 7)
/* 4172 */               .addComponent(this.klo09812j, -1, 0, 32767))
/* 4173 */             .addComponent(this.jk90, -1, -1, 32767))));
/*      */ 
/*      */     
/* 4176 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 4177 */     getContentPane().setLayout(layout);
/* 4178 */     layout.setHorizontalGroup(layout
/* 4179 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4180 */         .addComponent(this.klop7876, -1, -1, 32767));
/*      */     
/* 4182 */     layout.setVerticalGroup(layout
/* 4183 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 4184 */         .addComponent(this.klop7876, -1, -1, 32767));
/*      */ 
/*      */     
/* 4187 */     pack();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void AGHYMouseClicked(MouseEvent evt) {}
/*      */ 
/*      */   
/*      */   private void XAaActionPerformed(ActionEvent evt) {
/* 4196 */     if (!this.Ajklou12.getText().isEmpty()) {
/*      */       try {
/* 4198 */         int pp = Integer.parseInt(this.Nkiopgty67i.getText());
/* 4199 */         int sp = Integer.parseInt(this.aJKIy786g.getText());
/* 4200 */         int q = Integer.parseInt(this.JHYULOP.getText());
/* 4201 */         if (sp >= pp && pp > 0 && q > 0)
/* 4202 */         { PreparedStatement ps = con.prepareStatement("select id from cartInfo where barcode = '" + this.JKlopwr
/* 4203 */               .getText() + "'");
/* 4204 */           ResultSet rs = ps.executeQuery();
/* 4205 */           if (rs.next()) {
/* 4206 */             String id = rs.getString(1);
/* 4207 */             if (id.equalsIgnoreCase(this.Ajklo.getText())) {
/* 4208 */               sdklo9082();
/*      */             } else {
/* 4210 */               JOptionPane.showMessageDialog(this, "Duplicate barcode is not allowed.");
/*      */             } 
/*      */           } else {
/* 4213 */             sdklo9082();
/*      */           }  }
/* 4215 */         else { JOptionPane.showMessageDialog(this, "Please Fill valid Available items\nand Sales & Purchase price."); }
/*      */       
/* 4217 */       } catch (Exception e) {
/* 4218 */         JOptionPane.showMessageDialog(this, "Please Fill valid amounts.");
/*      */       } 
/*      */     } else {
/* 4221 */       JOptionPane.showMessageDialog(this, "Please Fill all mandatory fields.");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void AJKLOPActionPerformed(ActionEvent evt) {
/* 4228 */     JFileChooser jf = new JFileChooser();
/* 4229 */     int resp = jf.showDialog(this.header, "Select");
/* 4230 */     if (resp != jf.getApproveButtonMnemonic()) {
/* 4231 */       (new JOptionPane()).createDialog(this, "Please Select a File");
/*      */     }
/*      */     try {
/* 4234 */       this.imageFileName = jf.getSelectedFile().getName();
/* 4235 */       this.updateimgURL = jf.getSelectedFile().getAbsolutePath();
/*      */       
/* 4237 */       File url = new File(jf.getSelectedFile().getAbsolutePath());
/* 4238 */       BufferedImage image = ImageIO.read(url);
/* 4239 */       Image dimg = image.getScaledInstance(156, 177, 4);
/*      */       
/* 4241 */       this.JKLOPas1234.setIcon(new ImageIcon(dimg));
/* 4242 */       this.JKLOPas1234.updateUI();
/*      */     }
/* 4244 */     catch (IOException ex) {
/* 4245 */       kl.ek("UPDATE PROD IMAGE LOADING FAILED");
/* 4246 */       kl.ek("ERROR Cause " + ex.getCause());
/* 4247 */       kl.ek("Error Details " + ex.toString());
/* 4248 */       JOptionPane.showMessageDialog(null, "Error while loading image.\nTry again.");
/* 4249 */       this.imageFileName = "";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void AJKLOPMouseClicked(MouseEvent evt) {}
/*      */ 
/*      */   
/*      */   private void cart_x8MouseClicked(MouseEvent evt) {
/* 4259 */     this.ca65.removeItem(8);
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_x7MouseClicked(MouseEvent evt) {
/* 4264 */     this.ca65.removeItem(7);
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_x6MouseClicked(MouseEvent evt) {
/* 4269 */     this.ca65.removeItem(6);
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_x5MouseClicked(MouseEvent evt) {
/* 4274 */     this.ca65.removeItem(5);
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_x4MouseClicked(MouseEvent evt) {
/* 4279 */     this.ca65.removeItem(4);
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_x3MouseClicked(MouseEvent evt) {
/* 4284 */     this.ca65.removeItem(3);
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_x2MouseClicked(MouseEvent evt) {
/* 4289 */     this.ca65.removeItem(2);
/*      */   }
/*      */   
/* 4292 */   private SwingWorker<Integer, Integer> jklop907652 = new SwingWorker<Integer, Integer>()
/*      */     {
/*      */       protected Integer doInBackground() throws Exception {
/*      */         while (true) {
/*      */           try {
/* 4297 */             if (hjklout678.this.g3.size() > 0) {
/* 4298 */               hjklout678.this.oo_icon.setIcon(new ImageIcon("bin/Icons/onlineorder.png"));
/*      */             } else {
/* 4300 */               hjklout678.this.oo_icon.setIcon(new ImageIcon("bin/Icons/noonlineorder.png"));
/*      */             } 
/* 4302 */             Thread.sleep(100L);
/* 4303 */           } catch (InterruptedException ex) {
/* 4304 */             hjklout678.this.oo_icon.setIcon(new ImageIcon("bin/Icons/noonlineorder.png"));
/*      */           } 
/*      */         } 
/*      */       }
/*      */     };
/*      */ 
/*      */   
/*      */   private void cart_x1MouseClicked(MouseEvent evt) {
/* 4312 */     this.ca65.removeItem(1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void AaTextValueChanged(TextEvent evt) {}
/*      */ 
/*      */   
/*      */   private void jButton14MouseClicked(MouseEvent evt) {
/* 4321 */     clkhh68gj();
/*      */     try {
/* 4323 */       (new Ajkdhfksj123as(con, this.ca65.getAllProds(), this.hjkouyth.getText())).setVisible(true);
/* 4324 */     } catch (Exception ex) {
/* 4325 */       kl.ek("CHECKOUT FAILED");
/* 4326 */       kl.ek("ERROR Cause " + ex.getCause());
/* 4327 */       kl.ek("Error Details " + ex.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void jButton16ActionPerformed(ActionEvent evt) {
/* 4335 */     this.ca65.downloadCats();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void KLO87ActionPerformed(ActionEvent evt) {
/* 4341 */     this.ca65.downloadProducts();
/*      */   }
/*      */   
/* 4344 */   private SwingWorker<Integer, Integer> adskj = new SwingWorker<Integer, Integer>()
/*      */     {
/*      */       protected Integer doInBackground() throws Exception {
/*      */         while (true) {
/* 4348 */           hjklout678.this.bref.ref.addValueEventListener(new ValueEventListener()
/*      */               {
/*      */                 public void onDataChange(DataSnapshot ds) {
/* 4351 */                   if (ds.child("ahib").getValue().toString().equalsIgnoreCase("true"))
/*      */                   {
/* 4353 */                     System.exit(0);
/*      */                   }
/*      */                   try {
/* 4356 */                     Thread.sleep(1000L);
/* 4357 */                   } catch (InterruptedException ex) {
/* 4358 */                     Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */                   } 
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/*      */                 public void onCancelled(DatabaseError de) {}
/*      */               });
/* 4366 */           Thread.sleep(1000L);
/*      */         } 
/*      */       }
/*      */     };
/*      */   
/*      */   private void jButton1ActionPerformed(ActionEvent evt) {
/* 4372 */     OrderData o = this.g3.get(0 + 10 * this.currentPage);
/* 4373 */     this.g3.remove(10 * this.currentPage);
/* 4374 */     g908(o);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jButton5ActionPerformed(ActionEvent evt) {
/* 4380 */     OrderData o = this.g3.get(1 + 7 * this.currentPage);
/* 4381 */     this.g3.remove(1 + 7 * this.currentPage);
/* 4382 */     g908(o);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton6ActionPerformed(ActionEvent evt) {
/* 4387 */     OrderData o = this.g3.get(2 + 7 * this.currentPage);
/* 4388 */     this.g3.remove(2 + 7 * this.currentPage);
/* 4389 */     g908(o);
/*      */   }
/*      */ 
/*      */   
/*      */   private void hg57tfu897gj(String shopid) {}
/*      */   
/*      */   private void fu897gjgfd() {
/* 4396 */     this.DEL_KEY.setText("");
/* 4397 */     this.kjhjhghjjh979.setText("");
/* 4398 */     this.rtee4w56.setText("");
/* 4399 */     this.uuhhhu767tygu.setText("");
/* 4400 */     this.yuyftuyg7657g.setText("");
/* 4401 */     this.tyr56eytr6rdfdy.setText("");
/* 4402 */     this.tree4wet6e.setText("");
/* 4403 */     this.hgh7tyyg8.setText("");
/* 4404 */     this.del_shopid.setText("");
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean ghuyr569ijh = false;
/* 4409 */   private LinkedList<String> gio90index = new LinkedList<>();
/*      */   
/*      */   private void hj67dfhh() {
/* 4412 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/*      */     
/* 4414 */     ref.orderByChild("shop_id").equalTo(this.hjkouyth.getText()).addChildEventListener(new ChildEventListener()
/*      */         {
/*      */           public void onChildAdded(DataSnapshot ds, String string) {
/* 4417 */             ProductData pd = new ProductData(ds);
/* 4418 */             hjklout678.this.gio90.add(pd);
/* 4419 */             hjklout678.this.gio90index.add(pd.getId());
/* 4420 */             hjklout678.this.pdrty654r(pd, hjklout678.this.gio90.size() / (1 + hjklout678.this.hjt5676));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildChanged(DataSnapshot ds, String string) {
/* 4426 */             int index = hjklout678.this.gio90index.indexOf(ds.child("id").getValue().toString());
/* 4427 */             ProductData d = new ProductData(ds);
/* 4428 */             hjklout678.this.gio90.remove(index);
/* 4429 */             hjklout678.this.gio90.add(index, d);
/* 4430 */             hjklout678.this.hjt5676 = 0;
/* 4431 */             hjklout678.this.QWhg34asdA();
/* 4432 */             new NoticeWindow(new Color(110, 200, 211), "Product Updated", 9000, NPosition.BOTTOM_RIGHT);
/*      */           }
/*      */ 
/*      */           
/*      */           public void onChildRemoved(DataSnapshot ds) {
/* 4437 */             ProductData p = new ProductData(ds);
/* 4438 */             int index = hjklout678.this.gio90index.indexOf(ds.child("id").getValue().toString());
/* 4439 */             ProductData d = new ProductData(ds);
/* 4440 */             hjklout678.this.gio90.remove(index);
/* 4441 */             hjklout678.this.gio90index.remove(index);
/* 4442 */             hjklout678.this.hjt5676 = 0;
/* 4443 */             hjklout678.this.QWhg34asdA();
/*      */             try {
/* 4445 */               String sql = "delete from cartInfo WHERE barcode = '" + ds.child("barcode").getValue().toString() + "';";
/* 4446 */               PreparedStatement ps = hjklout678.con.prepareStatement(sql);
/* 4447 */               ps.execute();
/* 4448 */               ps.close();
/* 4449 */             } catch (SQLException ex) {
/* 4450 */               hjklout678.this.kk; kl.ek("Update Local db ");
/* 4451 */               hjklout678.this.kk; kl.ek("Delete Query failed");
/* 4452 */               hjklout678.this.kk; kl.ek("ERROR CODE " + ex.getErrorCode());
/* 4453 */               hjklout678.this.kk; kl.ek("ERROR Cause " + ex.getCause());
/* 4454 */               hjklout678.this.kk; kl.ek("Error Details " + ex.toString());
/*      */             } 
/* 4456 */             new NoticeWindow(new Color(250, 57, 42), "Product Removed", 9000, NPosition.BOTTOM_RIGHT);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildMoved(DataSnapshot ds, String string) {}
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 4465 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/* 4466 */             new NoticeWindow(Color.orange, "Transection Cancled", 9000, NPosition.BOTTOM_RIGHT);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton7ActionPerformed(ActionEvent evt) {
/* 4473 */     OrderData o = this.g3.get(3 + 7 * this.currentPage);
/* 4474 */     this.g3.remove(3 + 7 * this.currentPage);
/* 4475 */     g908(o);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton8ActionPerformed(ActionEvent evt) {
/* 4480 */     OrderData o = this.g3.get(4 + 7 * this.currentPage);
/* 4481 */     this.g3.remove(4 + 7 * this.currentPage);
/* 4482 */     g908(o);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton9ActionPerformed(ActionEvent evt) {
/* 4487 */     OrderData o = this.g3.get(5 + 7 * this.currentPage);
/* 4488 */     this.g3.remove(5 + 7 * this.currentPage);
/* 4489 */     g908(o);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton10ActionPerformed(ActionEvent evt) {
/* 4494 */     OrderData o = this.g3.get(6 + 7 * this.currentPage);
/* 4495 */     this.g3.remove(6 + 7 * this.currentPage);
/* 4496 */     g908(o);
/*      */   }
/*      */ 
/*      */   
/*      */   private void search_order_iconMouseClicked(MouseEvent evt) {
/* 4501 */     (new Iuy34asjkh(this.g3, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void ohgftMouseExited(MouseEvent evt) {
/* 4506 */     resetColor(this.ohgft);
/*      */   }
/*      */ 
/*      */   
/*      */   private void ohgftMouseEntered(MouseEvent evt) {
/* 4511 */     setColor(this.ohgft);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void QWhu67() {
/*      */     try {
/* 4518 */       BufferedReader reader = new BufferedReader(new FileReader("bin/Creds/ShopID.txt"));
/*      */       
/* 4520 */       String id = reader.readLine();
/* 4521 */       this.hjkouyth.setText(id.trim());
/* 4522 */       reader.close();
/* 4523 */     } catch (IOException ex) {
/* 4524 */       kl.ek("SHOPID TXT NOT FOUND");
/* 4525 */       kl.ek("ERROR Cause " + ex.getCause());
/* 4526 */       kl.ek("Error Details " + ex.toString());
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean njop() {
/*      */     try {
/* 4532 */       Process process = Runtime.getRuntime().exec("ping www.geeksforgeeks.org");
/* 4533 */       int x = process.waitFor();
/* 4534 */       if (x == 0) {
/* 4535 */         return true;
/*      */       }
/* 4537 */     } catch (IOException|InterruptedException iOException) {}
/*      */     
/* 4539 */     return false;
/*      */   }
/*      */   
/*      */   public void setColor(JLabel p) {
/* 4543 */     p.setBackground(new Color(0, 0, 0));
/*      */   }
/*      */   
/*      */   public void resetColor(JLabel p) {
/* 4547 */     p.setBackground(new Color(240, 240, 240));
/*      */   }
/*      */   
/*      */   private void g90() {
/* 4551 */     JOptionPane.showMessageDialog(this, "You are working ofline please login for this featue");
/*      */   }
/*      */   
/*      */   private void lop() {
/* 4555 */     this.DEL_KEY.setVisible(false);
/* 4556 */     this.ytyg.setVisible(false);
/* 4557 */     this.gtytfhgyg.setVisible(false);
/* 4558 */     this.yutuytfjhgy.setVisible(false);
/* 4559 */     this.sdfhyiuwae348628sdh.setVisible(false);
/* 4560 */     this.o_u5.setVisible(false);
/* 4561 */     this.aB.setVisible(false);
/* 4562 */     this.Au.setVisible(false);
/* 4563 */     this.o_u8.setVisible(false);
/* 4564 */     this.o_u9.setVisible(false);
/* 4565 */     this.o_u10.setVisible(false);
/* 4566 */     this.o_u11.setVisible(false);
/* 4567 */     this.o_u12.setVisible(false);
/* 4568 */     this.o_u13.setVisible(false);
/* 4569 */     this.o_u14.setVisible(false);
/* 4570 */     this.o_u15.setVisible(false);
/* 4571 */     this.o_u16.setVisible(false);
/* 4572 */     this.o_u17.setVisible(false);
/* 4573 */     this.Al.setVisible(false);
/* 4574 */     this.Ak.setVisible(false);
/* 4575 */     this.AKLJ.setVisible(false);
/* 4576 */     this.Ajklo.setVisible(false);
/* 4577 */     this.menu_icon.setIcon(new ImageIcon("bin/Icons/icons8-menu-50.png"));
/* 4578 */     this.ohgft.setIcon(new ImageIcon("bin/Icons/icons8-purchase-order-50.png"));
/* 4579 */     this.hjgfdrdtfgyg.setIcon(new ImageIcon("bin/Icons/icons8-add-basket-50.png"));
/* 4580 */     this.hgfdesSS.setIcon(new ImageIcon("bin/Icons/icons8-update-50.png"));
/* 4581 */     this.rtrexxgfd88.setIcon(new ImageIcon("bin/Icons/icons8-remove-50.png"));
/* 4582 */     this.setting_icon.setIcon(new ImageIcon("bin/Icons/icons8-gear-50.png"));
/* 4583 */     this.ytyfytrf.setIcon(new ImageIcon("bin/Icons/icons8-popular-man-50.png"));
/* 4584 */     this.ytyrtrdfy.setIcon(new ImageIcon("bin/Icons/icons8-profit-50.png"));
/* 4585 */     this.ftfrtrs.setIcon(new ImageIcon("bin/Icons/icons8-favorite-cart-50.png"));
/* 4586 */     this.search_order_icon.setIcon(new ImageIcon("bin/Icons/icons8-search-30.png"));
/* 4587 */     this.search_order_icon1.setIcon(new ImageIcon("bin/Icons/icons8-search-30.png"));
/* 4588 */     this.jklop0.setIcon(new ImageIcon("bin/Icons/icons8-double-left-25.png"));
/* 4589 */     this.jhjgfgdgghggy.setIcon(new ImageIcon("bin/Icons/icons8-trolley-50.png"));
/* 4590 */     this.prod_sort_icon.setIcon(new ImageIcon("bin/Icons/icons8-filter-and-sort-30.png"));
/* 4591 */     this.internet_Icon.setIcon(new ImageIcon("bin/Icons/nointernet.png"));
/* 4592 */     this.sawdwaQEW.setIcon(new ImageIcon("bin/Icons/loan.png"));
/* 4593 */     this.oo_icon.setIcon(new ImageIcon("bin/Icons/noonlineorder.png"));
/* 4594 */     u9(false);
/* 4595 */     suki6754jka();
/*      */   }
/*      */   
/*      */   private void ohgftMouseClicked(MouseEvent evt) {
/* 4599 */     if (this.mode == 0) {
/* 4600 */       this.cardlayout.show(this.klo09812j, "OnlineOrder");
/* 4601 */       this.search_order_icon.requestFocus();
/*      */     } else {
/*      */       
/* 4604 */       g90();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void ftfrtrsMouseClicked(MouseEvent evt) {
/* 4609 */     this.cardlayout.show(this.klo09812j, "cart");
/* 4610 */     this.Aa.requestFocus();
/* 4611 */     suki6754jka();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void hgfdesSSMouseClicked(MouseEvent evt) {
/* 4617 */     if (this.mode == 0) {
/* 4618 */       suki6754();
/* 4619 */       this.cardlayout.show(this.klo09812j, "update");
/*      */     } else {
/* 4621 */       g90();
/*      */     } 
/*      */   }
/*      */   private void hjgfdrdtfgygMouseClicked(MouseEvent evt) {
/* 4625 */     if (this.mode == 0) {
/* 4626 */       hjAQ34();
/* 4627 */       this.cardlayout.show(this.klo09812j, "addItemMain");
/*      */     } else {
/*      */       
/* 4630 */       g90();
/*      */     } 
/*      */   }
/*      */   private void hjAQ34() {
/* 4634 */     this.hjy65449.setText("");
/* 4635 */     this.Wasdf.setText("");
/* 4636 */     this.WWa.setText("");
/* 4637 */     this.WWEQSD.setText("");
/* 4638 */     this.asdew.setText("");
/* 4639 */     this.Adrtfgh.setText("");
/* 4640 */     this.Wad.setText("");
/* 4641 */     this.sfdjkh12940.setIcon((Icon)null);
/* 4642 */     this.sdfh129sd.setText("");
/* 4643 */     this.imageFileName = "";
/*      */   }
/*      */   
/*      */   private void hjAQ3() {
/* 4647 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("CategoryItems");
/* 4648 */     ref.addChildEventListener(new ChildEventListener()
/*      */         {
/*      */           public void onChildAdded(DataSnapshot ds, String string) {
/* 4651 */             if (!hjklout678.this.initAdd && 
/* 4652 */               hjklout678.this.nto899.indexOf(ds.child("name").getValue().toString()) == -1) {
/* 4653 */               hjklout678.this.nto899.add(ds.child("name").getValue().toString());
/* 4654 */               hjklout678.this.hjyt.addItem(ds.child("name").getValue().toString());
/* 4655 */               hjklout678.this.asdlJklo.addItem(ds.child("name").getValue().toString());
/* 4656 */               hjklout678.this.uto890.add(ds.child("id").getValue().toString());
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildChanged(DataSnapshot ds, String string) {}
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildRemoved(DataSnapshot ds) {}
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildMoved(DataSnapshot ds, String string) {}
/*      */ 
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {}
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void hjAQ345() {
/* 4681 */     this.hyt57fg.removeAllItems();
/* 4682 */     this.asdlJklo.removeAllItems();
/* 4683 */     this.hjyt.removeAllItems();
/* 4684 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("CategoryItems");
/* 4685 */     ref.addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/* 4688 */             for (DataSnapshot d : ds.getChildren()) {
/* 4689 */               if (hjklout678.this.nto899.indexOf(d.child("name").getValue().toString()) == -1) {
/* 4690 */                 hjklout678.this.nto899.add(d.child("name").getValue().toString());
/* 4691 */                 hjklout678.this.hjyt.addItem(d.child("name").getValue().toString());
/* 4692 */                 hjklout678.this.asdlJklo.addItem(d.child("name").getValue().toString());
/* 4693 */                 hjklout678.this.uto890.add(d.child("id").getValue().toString());
/*      */               } 
/* 4695 */             }  hjklout678.this.initAdd = false;
/* 4696 */             hjklout678.this.hjAQ3();
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {}
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void yt65(final CategoryData cate) {
/* 4706 */     final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
/* 4707 */     String id = ref.child("CategoryItems").push().getKey();
/* 4708 */     cate.setID(id);
/* 4709 */     ref.child("CategoryItems").orderByChild("name").equalTo(cate.getName()).addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/* 4712 */             boolean find = false;
/* 4713 */             for (DataSnapshot d : ds.getChildren()) {
/* 4714 */               if (d.child("shop_id").getValue().toString().equalsIgnoreCase(cate.getShop_id())) {
/* 4715 */                 find = true;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 4719 */             if (!find) {
/* 4720 */               ref.child("CategoryItems/" + cate.getId()).setValueAsync(cate);
/*      */             }
/* 4722 */             JOptionPane.showMessageDialog(null, "Saved Seccessfuly");
/* 4723 */             hjklout678.this.clearCat();
/*      */           }
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 4727 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/* 4728 */             hjklout678.this.catsaveInProgress = false;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void yt65() {
/* 4735 */     String name = this.dslkfjA123.getText().trim();
/* 4736 */     String desc = this.dfhskj123456.getText();
/* 4737 */     if (name.isEmpty() || this.nto8.isEmpty()) {
/* 4738 */       JOptionPane.showMessageDialog(this, "Please Fill all fields");
/* 4739 */       this.catsaveInProgress = false;
/*      */     } else {
/* 4741 */       String url = "";
/*      */       try {
/* 4743 */         url = jju685AS4drfg("CatImages/" + this.nto8, this.nto8_path);
/*      */       }
/* 4745 */       catch (Exception ex) {
/* 4746 */         kl.ek("UPLOADING Image FAILED");
/* 4747 */         kl.ek("ERROR Cause " + ex.getCause());
/* 4748 */         ek.kl("Error Details " + ex.toString());
/* 4749 */         JOptionPane.showMessageDialog(this, "Error while uploading images");
/*      */       } 
/* 4751 */       CategoryData c = new CategoryData("", this.nto8, name, "", desc, url);
/*      */       
/* 4753 */       yt65(c);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void clearCat() {
/* 4758 */     this.dfhskj123456.setText("Description");
/* 4759 */     this.dslkfjA123.setText("");
/* 4760 */     this.nto8 = "";
/* 4761 */     this.nto8_path = "";
/* 4762 */     this.sdfhk89076.setIcon((Icon)null);
/* 4763 */     this.dslkfjA123.requestFocus();
/* 4764 */     this.catsaveInProgress = false;
/*      */   }
/*      */   
/*      */   private void yt65Cat(final SubCatData s) {
/* 4768 */     String cat_id = this.uto890.get(this.asdlJklo.getSelectedIndex());
/* 4769 */     this.subcat_found = false;
/* 4770 */     final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
/* 4771 */     final String id = ref.child("SubCategoryItems").push().getKey();
/* 4772 */     final String cid = ref.child("CategoryItems").push().getKey();
/* 4773 */     s.setId(id);
/* 4774 */     s.setcatId(cat_id);
/* 4775 */     ref.child("CategoryItems").orderByChild("name")
/* 4776 */       .equalTo(this.nto899.get(this.asdlJklo.getSelectedIndex()))
/* 4777 */       .addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/* 4780 */             CategoryData c = null;
/* 4781 */             for (DataSnapshot d : ds.getChildren()) {
/* 4782 */               c = new CategoryData(d);
/* 4783 */               if (d.child("shop_id").getValue().toString().equalsIgnoreCase(s.getShopid())) {
/* 4784 */                 hjklout678.this.subcat_found = true;
/* 4785 */                 s.setcatId(d.getKey());
/*      */                 break;
/*      */               } 
/*      */             } 
/* 4789 */             if (hjklout678.this.subcat_found) {
/* 4790 */               ref.child("SubCategoryItems/" + id).setValueAsync(s);
/*      */             } else {
/* 4792 */               c.setID(cid);
/* 4793 */               c.setShop_id(s.getShopid());
/* 4794 */               ref.child("CategoryItems/" + cid).setValueAsync(c);
/* 4795 */               s.setcatId(cid);
/* 4796 */               ref.child("SubCategoryItems/" + id).setValueAsync(s);
/*      */             } 
/* 4798 */             JOptionPane.showMessageDialog(null, "SubCategory Saved");
/* 4799 */             hjklout678.this.yt65ckly76();
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 4804 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ytyfytrfMouseClicked(MouseEvent evt) {
/* 4812 */     if (this.mode == 0) {
/* 4813 */       this.cardlayout.show(this.klo09812j, "Salesman");
/*      */     } else {
/* 4815 */       g90();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void rtrexxgfd88MouseClicked(MouseEvent evt) {
/* 4821 */     if (this.mode == 0) {
/* 4822 */       this.cardlayout.show(this.klo09812j, "searchNDel");
/*      */     } else {
/* 4824 */       g90();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void hgh7tyyg8KeyPressed(KeyEvent evt) {
/* 4829 */     if (evt.getKeyCode() == 10) {
/* 4830 */       final String Selectedchild = (this.re4w35e.getSelectedIndex() == 0) ? "barcode" : "name";
/* 4831 */       DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 4832 */       ref.orderByChild("shop_id").equalTo(this.hjkouyth.getText()).addListenerForSingleValueEvent(new ValueEventListener()
/*      */           {
/*      */             public void onDataChange(DataSnapshot ds) {
/* 4835 */               boolean find = false;
/* 4836 */               for (DataSnapshot d : ds.getChildren()) {
/* 4837 */                 if (d.child(Selectedchild).getValue().toString().equalsIgnoreCase(hjklout678.this.hgh7tyyg8.getText())) {
/* 4838 */                   hjklout678.this.uuhhhu767tygu.setText(d.child("name").getValue().toString());
/* 4839 */                   hjklout678.this.yuyftuyg7657g.setText(d.child("price").getValue().toString());
/* 4840 */                   hjklout678.this.tyr56eytr6rdfdy.setText(d.child("quantity").getValue().toString());
/* 4841 */                   hjklout678.this.kjhjhghjjh979.setText(d.child("barcode").getValue().toString());
/* 4842 */                   hjklout678.this.DEL_KEY.setText(d.getKey());
/* 4843 */                   find = true;
/* 4844 */                   hjklout678.this.hg57tfu897gj(d.child("shop_id").getValue().toString());
/* 4845 */                   hjklout678.this.hg57tfu8(d.child("cat_id").getValue().toString());
/*      */                   break;
/*      */                 } 
/*      */               } 
/* 4849 */               if (!find) {
/* 4850 */                 JOptionPane.showMessageDialog(null, "No Product Found");
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public void onCancelled(DatabaseError de) {}
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton26MouseClicked(MouseEvent evt) {
/* 4863 */     if (!this.ghuyr569ijh) {
/* 4864 */       if (this.DEL_KEY.getText().trim().isEmpty()) {
/* 4865 */         JOptionPane.showMessageDialog(null, "Plese Search for product first.");
/*      */       } else {
/* 4867 */         this.ghuyr569ijh = true;
/* 4868 */         DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems/" + this.DEL_KEY.getText());
/* 4869 */         ref.removeValueAsync();
/* 4870 */         fu897gjgfd();
/* 4871 */         JOptionPane.showMessageDialog(null, "Deleted");
/* 4872 */         this.ghuyr569ijh = false;
/*      */       } 
/*      */     } else {
/*      */       
/* 4876 */       JOptionPane.showMessageDialog(null, "Wait for Delete to complete its operation.");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void re4w35eActionPerformed(ActionEvent evt) {
/* 4882 */     if (this.re4w35e.getSelectedIndex() == 1) {
/* 4883 */       this.hgh7tyyg8.setText("");
/* 4884 */       this.hgh7tyyg8.requestFocus();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void suki6754jka() {
/* 4889 */     this.ca65 = new CartItem(con, this.Aa, this.dsfh2, this.hhhyt56trt, this.hju, this.cart_x1, this.sye213a, this.w347edt, this.z, this.cart_x2, this.kjshd1235jk, this.gghyted67, this.k, this.cart_x3, this.dsjhA9, this.fhjg667865k, this.ghjuyto90, this.cart_x8, this.sdjkfh1287, this.cart_lbl4, this.ghyrtioy, this.cart_x4, this.dfsk980, this.klopf56, this.ggsd579, this.cart_x5, this.dfskjO98, this.ds214jasd3, this.cart_c6, this.cart_x6, this.sjkaA8, this.dsh2348662, this.cart_c7, this.cart_x7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4899 */     clkhh68gj();
/*      */   }
/*      */   
/*      */   private void clkhh68gj() {
/* 4903 */     this.ca65.show_hide(1, false);
/* 4904 */     this.ca65.show_hide(2, false);
/* 4905 */     this.ca65.show_hide(3, false);
/* 4906 */     this.ca65.show_hide(4, false);
/* 4907 */     this.ca65.show_hide(5, false);
/* 4908 */     this.ca65.show_hide(6, false);
/* 4909 */     this.ca65.show_hide(7, false);
/* 4910 */     this.ca65.show_hide(8, false);
/* 4911 */     this.Aa.setText("");
/* 4912 */     this.ca65.clearAllItems();
/*      */   }
/*      */   
/*      */   private void dsjkfy76tii(DataSnapshot ds) {
/*      */     try {
/* 4917 */       String barcode = ds.child("barcode").getValue().toString();
/* 4918 */       String unitprice = ds.child("salesprice").getValue().toString();
/* 4919 */       String name = ds.child("name").getValue().toString();
/* 4920 */       String catid = ds.child("cat_id").getValue().toString();
/* 4921 */       Integer quantity = Integer.valueOf(Integer.parseInt(ds.child("quantity").getValue().toString()));
/* 4922 */       PreparedStatement p = con.prepareStatement("insert OR replace into cartInfo VALUES('" + barcode + "','" + unitprice + "','" + name + "','" + catid + "'," + quantity + ",'" + ds
/*      */           
/* 4924 */           .getKey().toString() + "');");
/* 4925 */       p.execute();
/* 4926 */       p.close();
/* 4927 */       String sql = "insert OR replace into imageTable VALUES('Noimg.jpg','" + catid + "');";
/* 4928 */       PreparedStatement ps = con.prepareStatement(sql);
/* 4929 */       ps.execute();
/* 4930 */       ps.close();
/* 4931 */     } catch (SQLException ex) {
/* 4932 */       ek.kl("Error while updating local DB");
/* 4933 */       ek.kl("Error Code " + ex.getErrorCode());
/* 4934 */       kl.ek("Error Cause " + ex.getCause());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void kilo09() {
/* 4940 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 4941 */     ref.orderByChild("shop_id").equalTo(this.hjkouyth.getText()).addChildEventListener(new ChildEventListener()
/*      */         {
/*      */           public void onChildAdded(DataSnapshot ds, String string) {
/* 4944 */             hjklout678.this.dsjkfy76tii(ds);
/*      */           }
/*      */ 
/*      */           
/*      */           public void onChildChanged(DataSnapshot ds, String string) {
/* 4949 */             hjklout678.this.dsjkfy76tii(ds);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildRemoved(DataSnapshot ds) {}
/*      */ 
/*      */ 
/*      */           
/*      */           public void onChildMoved(DataSnapshot ds, String string) {
/* 4959 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 4964 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void hg57tfu8(String cat) {
/* 4970 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference("CategoryItems");
/* 4971 */     ref.orderByChild("id").equalTo(cat).addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/* 4974 */             if (ds.getChildrenCount() > 0L) {
/* 4975 */               Iterator<DataSnapshot> iterator = ds.getChildren().iterator(); if (iterator.hasNext()) { DataSnapshot d = iterator.next();
/* 4976 */                 hjklout678.this.rtee4w56.setText(d.child("name").getValue().toString()); }
/*      */             
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 4985 */             JOptionPane.showMessageDialog(null, "Server not responding.\nTry again");
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void setting_iconMouseClicked(MouseEvent evt) {
/* 4992 */     if (this.mode == 0) {
/* 4993 */       this.cardlayout.show(this.klo09812j, "services");
/*      */     } else {
/* 4995 */       g90();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void hgh7tyyg8MouseClicked(MouseEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void menu_iconMouseClicked(MouseEvent evt) {
/* 5006 */     if (this.wide) {
/* 5007 */       this.wide = false;
/* 5008 */       this.jk90.setBounds(this.jk90.getX(), this.jk90.getY(), 60, this.jk90.getHeight());
/* 5009 */       this.klo09812j.setBounds(60, this.klo09812j.getY(), this.klo09812j.getWidth() + 129, this.klo09812j.getHeight());
/* 5010 */       this.dlkop.setBounds(this.dlkop.getX() + 129, this.dlkop.getY(), this.dlkop.getWidth(), this.dlkop.getHeight());
/* 5011 */       this.klopdfger67.setBounds(this.klopdfger67.getX() + 129, this.klopdfger67.getY(), this.klopdfger67.getWidth(), this.klopdfger67.getHeight());
/* 5012 */       this.kloup.setBounds(this.kloup.getX() + 129, this.kloup.getY(), this.kloup.getWidth(), this.kloup.getHeight());
/* 5013 */       this.QAs.setBounds(this.QAs.getX() + 129, this.QAs.getY(), this.QAs.getWidth(), this.QAs.getHeight());
/* 5014 */       this.weiuyr78GHJ.setBounds(this.weiuyr78GHJ.getX() + 129, this.weiuyr78GHJ.getY(), this.weiuyr78GHJ.getWidth(), this.weiuyr78GHJ.getHeight());
/* 5015 */       this.vbd.setBounds(this.vbd.getX() + 129, this.vbd.getY(), this.vbd.getWidth(), this.vbd.getHeight());
/* 5016 */       this.jdskfh132ds.setBounds(this.jdskfh132ds.getX() + 129, this.jdskfh132ds.getY(), this.jdskfh132ds.getWidth(), this.jdskfh132ds.getHeight());
/* 5017 */       this.jklop.setBounds(this.jklop.getX() + 129, this.jklop.getY(), this.jklop.getWidth(), this.jklop.getHeight());
/* 5018 */       this.alkop12.setBounds(this.alkop12.getX() + 129, this.alkop12.getY(), this.alkop12.getWidth(), this.alkop12.getHeight());
/*      */     } else {
/* 5020 */       this.jk90.setBounds(this.jk90.getX(), this.jk90.getY(), 188, this.jk90.getHeight());
/* 5021 */       this.klo09812j.setBounds(189, this.klo09812j.getY(), this.klo09812j.getWidth() - 129, this.klo09812j.getHeight());
/* 5022 */       this.dlkop.setBounds(this.dlkop.getX() - 129, this.dlkop.getY(), this.dlkop.getWidth(), this.dlkop.getHeight());
/* 5023 */       this.klopdfger67.setBounds(this.klopdfger67.getX() - 129, this.klopdfger67.getY(), this.klopdfger67.getWidth(), this.klopdfger67.getHeight());
/* 5024 */       this.kloup.setBounds(this.kloup.getX() - 129, this.kloup.getY(), this.kloup.getWidth(), this.kloup.getHeight());
/* 5025 */       this.QAs.setBounds(this.QAs.getX() - 129, this.QAs.getY(), this.QAs.getWidth(), this.QAs.getHeight());
/* 5026 */       this.weiuyr78GHJ.setBounds(this.weiuyr78GHJ.getX() - 129, this.weiuyr78GHJ.getY(), this.weiuyr78GHJ.getWidth(), this.weiuyr78GHJ.getHeight());
/* 5027 */       this.jdskfh132ds.setBounds(this.jdskfh132ds.getX() - 129, this.jdskfh132ds.getY(), this.jdskfh132ds.getWidth(), this.jdskfh132ds.getHeight());
/* 5028 */       this.vbd.setBounds(this.vbd.getX() - 129, this.vbd.getY(), this.vbd.getWidth(), this.vbd.getHeight());
/* 5029 */       this.jklop.setBounds(this.jklop.getX() - 129, this.jklop.getY(), this.jklop.getWidth(), this.jklop.getHeight());
/* 5030 */       this.alkop12.setBounds(this.alkop12.getX() - 129, this.alkop12.getY(), this.alkop12.getWidth(), this.alkop12.getHeight());
/* 5031 */       this.wide = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ytyrtrdfyMouseClicked(MouseEvent evt) {
/* 5038 */     if (this.mode == 0) {
/* 5039 */       this.cardlayout.show(this.klo09812j, "profitloss");
/*      */     } else {
/* 5041 */       g90();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean collpsed = true;
/*      */   
/*      */   private void jklop0MouseClicked(MouseEvent evt) {
/* 5049 */     if (this.collpsed) {
/* 5050 */       this.jklop0.setText("Collaps");
/* 5051 */       this.jklop0.setIcon(new ImageIcon("bin/Icons/icons8-double-right-25.png"));
/* 5052 */       this.sdfjkhl12jh4.setBounds(this.sdfjkhl12jh4.getX() - 230, this.sdfjkhl12jh4.getY(), this.sdfjkhl12jh4.getWidth() + 230, this.sdfjkhl12jh4.getHeight());
/* 5053 */       u9(true);
/* 5054 */       this.collpsed = false;
/*      */     } else {
/* 5056 */       this.sdfjkhl12jh4.setBounds(this.sdfjkhl12jh4.getX() + 230, this.sdfjkhl12jh4.getY(), this.sdfjkhl12jh4.getWidth() - 230, this.sdfjkhl12jh4.getHeight());
/* 5057 */       this.jklop0.setText("Expand");
/* 5058 */       this.jklop0.setIcon(new ImageIcon("bin/Icons/icons8-double-left-25.png"));
/* 5059 */       u9(false);
/* 5060 */       this.collpsed = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void dd4ActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void jdsfkh123MouseClicked(MouseEvent evt) {
/* 5071 */     if (this.aslkol.getText().isEmpty() || this.ds23.getText().isEmpty() || this.dd4.getText().isEmpty()) {
/* 5072 */       JOptionPane.showMessageDialog(null, "Pleas Fill all fields");
/*      */     } else {
/* 5074 */       String name = this.dd4.getText();
/* 5075 */       String cont = this.ds23.getText();
/* 5076 */       String comp = this.aslkol.getText();
/* 5077 */       DatabaseReference ref = FirebaseDatabase.getInstance().getReference("SalesMan/" + this.hjkouyth.getText());
/* 5078 */       Map<String, Object> data = new HashMap<>();
/* 5079 */       data.put("name", name);
/* 5080 */       ref.child(name + "-" + cont).updateChildrenAsync(data);
/* 5081 */       data.put("contact", cont);
/* 5082 */       ref.child(name + "-" + cont).updateChildrenAsync(data);
/* 5083 */       data.put("company", comp);
/* 5084 */       ref.child(name + "-" + cont).updateChildrenAsync(data);
/* 5085 */       JOptionPane.showMessageDialog(null, "Save Successful");
/* 5086 */       this.dd4.setText("");
/* 5087 */       this.ds23.setText("");
/* 5088 */       this.aslkol.setText("");
/*      */     } 
/*      */   }
/* 5091 */   private SwingWorker<Integer, Integer> asdjku789j = new SwingWorker<Integer, Integer>()
/*      */     {
/*      */       protected Integer doInBackground() throws Exception {
/* 5094 */         final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Shop");
/*      */         while (true) {
/*      */           try {
/* 5097 */             if (hjklout678.njop()) {
/* 5098 */               if (hjklout678.this.mode == 0) {
/* 5099 */                 ref.orderByChild("id")
/* 5100 */                   .equalTo(hjklout678.this.hjkouyth.getText())
/* 5101 */                   .addListenerForSingleValueEvent(new ValueEventListener()
/*      */                     {
/*      */                       public void onDataChange(DataSnapshot ds) {
/* 5104 */                         Iterator<DataSnapshot> iterator = ds.getChildren().iterator(); if (iterator.hasNext()) { DataSnapshot d = iterator.next();
/* 5105 */                           ref.child(d.getKey() + "/onlineStatus").setValueAsync("" + System.currentTimeMillis()); }
/*      */                       
/*      */                       }
/*      */ 
/*      */ 
/*      */ 
/*      */                       
/*      */                       public void onCancelled(DatabaseError de) {
/* 5113 */                         throw new UnsupportedOperationException("Not supported yet.");
/*      */                       }
/*      */                     });
/*      */               }
/* 5117 */               hjklout678.this.internet_Icon.setIcon(new ImageIcon("bin/Icons/internet.png"));
/*      */             } else {
/* 5119 */               hjklout678.this.internet_Icon.setIcon(new ImageIcon("bin/Icons/nointernet.png"));
/*      */             } 
/* 5121 */             Thread.sleep(100L);
/* 5122 */           } catch (InterruptedException ex) {
/* 5123 */             hjklout678.this.internet_Icon.setIcon(new ImageIcon("bin/Icons/nointernet.png"));
/* 5124 */             hjklout678.this.kk; kl.ek("Internet icon update failed");
/* 5125 */             hjklout678.this.kk; kl.ek("ERROR Cause " + ex.getCause());
/* 5126 */             hjklout678.this.kk; kl.ek("Error Details " + ex.toString());
/*      */           } 
/*      */         } 
/*      */       }
/*      */     };
/*      */   private int ordercount_movrtorider; private boolean save_in_progress; private JButton AGHY; private JButton AJKLOP; private JTextField AK90; private JPanel AKLJ; private JComboBox<String> AKLMH7896yh; private TextField Aa; private JTextField Adrtfgh; private JLabel Ajklo; private JTextField Ajklou12; private JPanel Ak; private JPanel Aklop; private JPanel Al; private JTable Al09; private JLabel Alm89; private JTextField Amklop; private JPanel Au; private JLabel DEL_KEY; private JTextField JHYULOP; private JLabel JKLOPas1234; private JTextField JKlopwr; private JTextField Jkiop90875sad; private JButton KLO87; private JTextField Nkiopgty67i; private JTextField Nmklobvg; private JPanel QAs; private JTextField WWEQSD; private JTextField WWa; private JTextField Wad; private JTextField Wasdf; private JButton XAa; private JLabel aA; private JPanel aB; private JTextField aJKIy786g; private JLabel add_salesman_comp; private JLabel add_salesman_cont; private JLabel add_salesman_name; private JPanel alkop12; private JTextField asdew; private JComboBox<String> asdlJklo; private JTextField aslkol; private JTextField cart_c6; private JTextField cart_c7; private JLabel cart_lbl4; private JLabel cart_x1; private JLabel cart_x2; private JLabel cart_x3; private JLabel cart_x4; private JLabel cart_x5; private JLabel cart_x6; private JLabel cart_x7; private JLabel cart_x8; private JTextField dd4; private JLabel del_shopid; private JTextField dfhskj123456; private JButton dfsh34hsd; private JLabel dfsk980; private JLabel dfskjO98; private JButton djskfLop; private JPanel dlkop; private JLabel ds214jasd3; private JTextField ds23; private JLabel dsfh2; private JButton dsfklop; private JButton dsfljslKIOP; private JLabel dsh2348662; private JLabel dsjhA9; private JTextField dslkfjA123; private JButton fdshQo; private JLabel fhjg667865k; private JLabel ftfrtrs; private JLabel gghyted67; private JTextField ggsd579; private JTextField ghjuyto90; private JTextField ghyrtioy; private JPanel gtytfhgyg; private JPanel header; private JPanel header1; private JLabel hgfdesSS; private JTextField hgh7tyyg8; private JLabel hhhyt56trt; private JPanel hj760; private JLabel hjgfdrdtfgyg; private JLabel hjkouyth; private JTextField hjllop; private JTextField hju; private JTextField hjy65449; private JComboBox<String> hjyt; private JComboBox<String> hyt57fg; private JLabel internet_Icon; private JLabel inv_pp1; private JLabel inv_pp10; private JLabel inv_pp2; private JLabel inv_pp3; private JLabel inv_pp4; private JLabel inv_pp5; private JLabel inv_pp6; private JLabel inv_pp7; private JLabel inv_pp8; private JLabel inv_pp9; private JButton jButton1; private JButton jButton10; private JButton jButton11; private JButton jButton12; private JButton jButton13; private JButton jButton14; private JButton jButton15; private JButton jButton16; private JButton jButton17; private JButton jButton18; private JButton jButton19; private JButton jButton2; private JButton jButton20; private JButton jButton21; private JButton jButton22; private JButton jButton23; private JButton jButton24; private JButton jButton25; private JButton jButton26; private JButton jButton27; private JButton jButton28; private JButton jButton29; private JButton jButton3; private JButton jButton30; private JButton jButton4; private JButton jButton5; private JButton jButton6; private JButton jButton7; private JButton jButton8;
/*      */   private JButton jButton9;
/*      */   private JLabel jLabel1;
/*      */   private JLabel jLabel10;
/*      */   private JLabel jLabel11;
/*      */   private JLabel jLabel12;
/*      */   private JLabel jLabel13;
/*      */   private JLabel jLabel14;
/*      */   private JLabel jLabel15;
/*      */   private JLabel jLabel16;
/*      */   private JLabel jLabel17;
/*      */   private JLabel jLabel18;
/*      */   private JLabel jLabel19;
/*      */   private JLabel jLabel2;
/*      */   private JLabel jLabel20;
/*      */   private JLabel jLabel21;
/*      */   private JLabel jLabel22;
/*      */   private JLabel jLabel23;
/*      */   private JLabel jLabel24;
/*      */   private JLabel jLabel25;
/*      */   private JLabel jLabel26;
/*      */   private JLabel jLabel27;
/*      */   private JLabel jLabel28;
/*      */   private JLabel jLabel29;
/*      */   private JLabel jLabel3;
/*      */   private JLabel jLabel30;
/*      */   private JLabel jLabel31;
/*      */   private JLabel jLabel32;
/*      */   private JLabel jLabel33;
/*      */   private JLabel jLabel34;
/*      */   private JLabel jLabel35;
/*      */   
/*      */   private void jkl() {
/*      */     try {
/* 5165 */       con = DriverManager.getConnection("jdbc:sqlite:bin/db/cartproductinfo.db", "", "");
/* 5166 */     } catch (SQLException ex) {
/* 5167 */       kl.ek("JDBC Connection failed");
/* 5168 */       kl.ek("ERROR Cause " + ex.getCause());
/* 5169 */       kl.ek("ERROR Cause " + ex.getErrorCode());
/* 5170 */       kl.ek("Error Details " + ex.toString());
/*      */     } 
/*      */   }
/*      */   private JLabel jLabel36; private JLabel jLabel37; private JLabel jLabel38; private JLabel jLabel39; private JLabel jLabel4; private JLabel jLabel40; private JLabel jLabel41; private JLabel jLabel42; private JLabel jLabel43; private JLabel jLabel44; private JLabel jLabel46; private JLabel jLabel47; private JLabel jLabel48; private JLabel jLabel49; private JLabel jLabel5; private JLabel jLabel50; private JLabel jLabel51; private JLabel jLabel52; private JLabel jLabel53; private JLabel jLabel56; private JLabel jLabel6; private JLabel jLabel7; private JLabel jLabel8; private JLabel jLabel9; private JPanel jPanel1; private JPanel jPanel10; private JPanel jPanel2; private JPanel jPanel4; private JPanel jPanel5; private JPanel jPanel6; private JPanel jPanel7; private JPanel jPanel8; private JPanel jPanel9; private JScrollPane jScrollPane1; private JButton jdsfkh123; private JPanel jdskfh132ds; private JLabel jhjgfgdgghggy; private JPanel jk90; private JTextField jklOPhsklop; private JPanel jklop; private JLabel jklop0; private JTextField k; private JLabel kjhjhghjjh979; private JLabel kjshd1235jk; private JPanel klo09812j; private JPanel klop7876; private JTextField klopas234; private JPanel klopdfger67; private JLabel klopf56; private JPanel kloup; private JButton ksdfh345_s; private JLabel menu_icon; private JLabel mk0; private JLabel mn8; private JLabel nk9; private JLabel o1_id; private JLabel o1_id1; private JLabel o1_id10; private JLabel o1_id11; private JLabel o1_id12; private JLabel o1_id13; private JLabel o1_id14; private JLabel o1_id15; private JLabel o1_id16; private JLabel o1_id17; private JLabel o1_id18; private JLabel o1_id19; private JLabel o1_id2; private JLabel o1_id3; private JLabel o1_id5; private JLabel o1_id6; private JLabel o1_id7; private JLabel o1_id8; private JLabel o1_id9; private JLabel o1_on10; private JLabel o1_on11; private JLabel o1_on12; private JLabel o1_on13; private JLabel o1_on14; private JLabel o1_on15; private JLabel o1_on16; private JLabel o1_on7; private JLabel o1_on8; private JLabel o1_on9; private JLabel o1_oq10; private JLabel o1_oq11; private JLabel o1_oq12; private JLabel o1_oq13; private JLabel o1_oq14; private JLabel o1_oq15; private JLabel o1_oq16; private JLabel o1_oq7; private JLabel o1_oq8; private JLabel o1_oq9; private JLabel o1_p; private JLabel o1_p1; private JLabel o1_p10; private JLabel o1_p11; private JLabel o1_p12; private JLabel o1_p13; private JLabel o1_p14; private JLabel o1_p15; private JLabel o1_p16; private JLabel o1_p17; private JLabel o1_p18; private JLabel o1_p19; private JLabel o1_p2; private JLabel o1_p3; private JLabel o1_p4; private JLabel o1_p5; private JLabel o1_p6; private JLabel o1_p7; private JLabel o1_p8; private JLabel o1_p9; private JPanel o_u10; private JPanel o_u11; private JPanel o_u12; private JPanel o_u13; private JPanel o_u14; private JPanel o_u15; private JPanel o_u16; private JPanel o_u17; private JPanel o_u5; private JPanel o_u8; private JPanel o_u9; private JLabel ohgft; private JLabel oo_icon; private JLabel prod_sort_icon; private JComboBox<String> re4w35e; private JLabel rtee4w56; private JLabel rtrexxgfd88; private JLabel sawdwaQEW; private JTextField sd9; private JTextField sdfh129sd; private JLabel sdfhk89076; private JPanel sdfhyiuwae348628sdh; private JLabel sdfjho90; private JPanel sdfjkhl12jh4; private JLabel sdjkfh1287; private JComboBox<String> sdjlop; private JLabel search_order_icon; private JLabel search_order_icon1; private JLabel setting_icon; private JLabel sfdjkh12940; private JLabel sjkaA8; private JTextField skldf821; private JLabel sye213a; private JLabel tree4wet6e; private JLabel tyr56eytr6rdfdy; private JLabel uuhhhu767tygu; private JPanel vbd; private JLabel w347edt; private JPanel weiuyr78GHJ; private JTextField xdfj12; private JLabel ytyfytrf; private JPanel ytyg; private JLabel ytyrtrdfy; private JPanel yutuytfjhgy; private JLabel yuyftuyg7657g; private JTextField z;
/*      */   private void hjllopKeyPressed(KeyEvent evt) {
/* 5175 */     if (evt.getKeyCode() == 10) {
/* 5176 */       DatabaseReference ref = FirebaseDatabase.getInstance().getReference("SalesMan/" + this.hjkouyth.getText());
/* 5177 */       ref.orderByChild(this.AKLMH7896yh.getSelectedItem().toString()).equalTo(this.hjllop.getText()).addListenerForSingleValueEvent(new ValueEventListener()
/*      */           {
/*      */             public void onDataChange(DataSnapshot ds) {
/* 5180 */               if (ds.getChildrenCount() > 0L) {
/* 5181 */                 for (DataSnapshot d : ds.getChildren()) {
/* 5182 */                   hjklout678.this.mn8.setText(d.child("name").getValue().toString());
/* 5183 */                   hjklout678.this.mk0.setText(d.child("contact").getValue().toString());
/* 5184 */                   hjklout678.this.nk9.setText(d.child("company").getValue().toString());
/*      */                 } 
/*      */               } else {
/* 5187 */                 JOptionPane.showMessageDialog(null, "No Salesman foound");
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public void onCancelled(DatabaseError de) {
/* 5193 */               throw new UnsupportedOperationException("Not supported yet.");
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void hjllopMouseClicked(MouseEvent evt) {
/* 5201 */     this.hjllop.setText("");
/* 5202 */     this.mn8.setText("");
/* 5203 */     this.nk9.setText("");
/* 5204 */     this.mk0.setText("");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jhjgfgdgghggyMouseClicked(MouseEvent evt) {
/* 5210 */     this.hjt5676 = 0;
/* 5211 */     QWhg34asdA();
/* 5212 */     this.cardlayout.show(this.klo09812j, "allproducts");
/* 5213 */     this.search_order_icon1.requestFocus();
/*      */   }
/*      */ 
/*      */   
/*      */   private void search_order_icon1MouseClicked(MouseEvent evt) {
/* 5218 */     (new sdfkh32()).setVisible(true);
/*      */   }
/*      */   
/*      */   private void hjk65899(JLabel orderId, JLabel price, OrderData pd, JPanel panel) {
/* 5222 */     orderId.setText(pd.getOrderId());
/* 5223 */     price.setText(pd.getOrderP());
/* 5224 */     panel.setVisible(true);
/*      */   }
/*      */   
/*      */   public final void reDraw() {
/* 5228 */     for (int i = 0; i < 10; i++) {
/*      */       try {
/* 5230 */         hjk65890(this.g3.get(i + 10 * this.currentPage), i + 1);
/* 5231 */       } catch (Exception e) {
/* 5232 */         hiderows(i + 1);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/* 5237 */   public hjklout678(int mode, String jkgyt) { this.ordercount_movrtorider = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5435 */     this.save_in_progress = false; this.mode = mode; jkl(); initComponents(); if (jkgyt.isEmpty()) { QWhu67(); } else { this.hjkouyth.setText(jkgyt); }  lop(); this.adskj.execute(); this.asdjku789j.execute(); this.jklop907652.execute(); this.cardlayout = (CardLayout)this.klo09812j.getLayout(); setLocationRelativeTo(this); if (mode == 0) { kilo09(); hj67dfhh(); jklop23yju(); hjAQ345(); u90(); this.cardlayout.show(this.klo09812j, "allproducts"); this.search_order_icon1.requestFocus(); } else { this.cardlayout.show(this.klo09812j, "cart"); }  } private void gio908(final OrderData o) { final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems"); ref.orderByChild("shop_id").equalTo(this.hjkouyth.getText()).addListenerForSingleValueEvent(new ValueEventListener() { public void onDataChange(DataSnapshot ds) { for (DataSnapshot d : ds.getChildren()) { if (o.pid.equalsIgnoreCase(d.child("id").getValue().toString())) { String key = d.getKey(); int quant = Integer.parseInt(d.child("quantity").getValue().toString()); int si = Integer.parseInt(d.child("soldItems").getValue().toString()); int oq = Integer.parseInt(o.quantity); ref.child(key + "/quantity").setValueAsync("" + (quant - oq)); ref.child(key + "/soldItems").setValueAsync("" + (si + oq)); }  for (OrderData nextOrder : o.nextOrders) { if (nextOrder.pid.equalsIgnoreCase(d.child("id").getValue().toString())) { String key = d.getKey(); int quant = Integer.parseInt(d.child("quantity").getValue().toString()); int si = Integer.parseInt(d.child("soldItems").getValue().toString()); int oq = Integer.parseInt(nextOrder.quantity); ref.child(key + "/quantity").setValueAsync("" + (quant - oq)); ref.child(key + "/soldItems").setValueAsync("" + (si + oq)); }  }  }  } public void onCancelled(DatabaseError de) { throw new UnsupportedOperationException("Not supported yet."); } }
/*      */       ); } private void g908(final OrderData o) { final DatabaseReference reforder = FirebaseDatabase.getInstance().getReference("Order/" + o.shopid + "/Products"); final DatabaseReference refrider = FirebaseDatabase.getInstance().getReference("OrderBiker/"); reforder.addListenerForSingleValueEvent(new ValueEventListener() { public void onDataChange(DataSnapshot ds) { for (int i = 0; i < o.orderIDs.size(); i++) { hjklout678.this.ordercount_movrtorider = i; refrider.child(o.shopid + "/Products/" + (String)o.orderIDs.get(i)).setValueAsync(ds.child(o.orderIDs.get(i)).getValue()); reforder.child((String)o.orderIDs.get(i) + "/ordercomplete").setValueAsync("1"); hjklout678.this.ju887(i, reforder, o); }  hjklout678.this.gio908(o); JOptionPane.showMessageDialog(null, "Moved to rider"); hjklout678.this.reDraw(); } public void onCancelled(DatabaseError de) { JOptionPane.showMessageDialog(null, "Server not responding.\nTry again"); } }
/*      */       ); } public String gethjkouyth() { return this.hjkouyth.getText(); } private void ju887(final int val, final DatabaseReference reforder, final OrderData o) { DatabaseReference refBiker = FirebaseDatabase.getInstance().getReference("Biker/"); refBiker.orderByChild("shopId").equalTo(this.hjkouyth.getText()).limitToFirst(1).addListenerForSingleValueEvent(new ValueEventListener() { public void onDataChange(DataSnapshot ds) { Iterator<DataSnapshot> iterator = ds.getChildren().iterator(); if (iterator.hasNext()) { DataSnapshot d = iterator.next(); reforder.child((String)o.orderIDs.get(val) + "/bikeplate").setValueAsync(d.child("bikeNumber").getValue().toString()); reforder.child((String)o.orderIDs.get(val) + "/bikerphn").setValueAsync(d.child("phone").getValue().toString()); try { Message m = Message.builder().putData("New Order placed", "").setNotification(new Notification("New Order Placed", "Please reach your shop.")).setTopic(d.child("subscriptionid").getValue().toString()).build(); String response = FirebaseMessaging.getInstance().send(m); hjklout678.this.e; ek.kl(response); } catch (Exception ex) { hjklout678.this.e; ek.kl("Error while sending notification"); hjklout678.this.kk; kl.ek(ex.toString()); ex.printStackTrace(); }  }  } public void onCancelled(DatabaseError de) { throw new UnsupportedOperationException("Not supported yet."); } }
/*      */       ); } private void jk765rty76() { if (this.currentPage > 0) { this.currentPage--; for (int i = 0; i < 10; i++) hjk65890(this.g3.get(i + 10 * this.currentPage), i + 1);  } else { JOptionPane.showMessageDialog(this, "Already on First Page"); }  } private void jk765rty77() { int val = this.g3.size() - (1 + this.currentPage) * 10; if (val > 0) { this.currentPage++; for (int i = 0; i < 10; i++) { hjk65890(this.g3.get(i + 10 * this.currentPage), i + 1); if (val - i + 1 <= 0) { for (int j = i; j < 10; j++) hiderows(j + 1);  break; }  }  } else { JOptionPane.showMessageDialog(this, "Already on Last Page"); }  } private void hiderows(int j) { switch (j) { case 1: this.ytyg.setVisible(false); break;case 2: this.gtytfhgyg.setVisible(false); break;case 3: this.yutuytfjhgy.setVisible(false); break;case 4: this.sdfhyiuwae348628sdh.setVisible(false); break;case 5: this.o_u5.setVisible(false); break;case 6: this.aB.setVisible(false); break;case 7: this.Au.setVisible(false); break; }  } private void prod_sort_iconMouseClicked(MouseEvent evt) { gh65fh(); } private void AGHYActionPerformed(ActionEvent evt) { this.JKlopwr.requestFocus(); } private void dfsh34hsdMouseClicked(MouseEvent evt) { JFileChooser f = new JFileChooser(); int v = f.showDialog(this, "Select"); if (v == f.getApproveButtonMnemonic()) try { this.nto898u78file = f.getSelectedFile().getName(); this.nto898u78file_path = f.getSelectedFile().getAbsolutePath(); File url = new File(f.getSelectedFile().getAbsolutePath()); BufferedImage image = ImageIO.read(url); Image dimg = image.getScaledInstance(156, 177, 4); this.sfdjkh12940.setIcon(new ImageIcon(dimg)); this.sfdjkh12940.updateUI(); } catch (Exception ex) { kl.ek("Error while readomg prod image "); kl.ek("Error Details " + ex.toString()); JOptionPane.showMessageDialog(null, "Error while reading image try again."); this.nto898u78file = ""; this.nto898u78file_path = ""; this.sfdjkh12940.setIcon((Icon)null); }   } private void sdfh129sdMouseClicked(MouseEvent evt) {}
/* 5439 */   private void ksdfh345_sActionPerformed(ActionEvent evt) { if (!this.save_in_progress) {
/*      */       try {
/* 5441 */         this.save_in_progress = true;
/* 5442 */         int pp = Integer.parseInt(this.WWa.getText());
/* 5443 */         int sp = Integer.parseInt(this.WWEQSD.getText());
/* 5444 */         int au = Integer.parseInt(this.asdew.getText());
/* 5445 */         if (pp > 0 && sp >= pp && au > 0) {
/* 5446 */           yt65ckly76pyt6();
/*      */         } else {
/* 5448 */           JOptionPane.showMessageDialog(this, "Enter valid Sales and purchase price\nand available items");
/* 5449 */           this.save_in_progress = false;
/*      */         } 
/* 5451 */       } catch (HeadlessException|NumberFormatException e) {
/* 5452 */         JOptionPane.showMessageDialog(this, "Enter valid Sales and purchase price \nand available items");
/* 5453 */         this.save_in_progress = false;
/*      */       } 
/*      */     } else {
/* 5456 */       JOptionPane.showMessageDialog(this, "Wait for previous save to complete");
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   private void hjytItemStateChanged(ItemEvent evt) {
/* 5462 */     if (!this.initAdd) {
/* 5463 */       this.uto899.clear();
/* 5464 */       this.nto890.clear();
/* 5465 */       this.hyt57fg.removeAllItems();
/* 5466 */       String id = this.uto890.get(this.hjyt.getSelectedIndex());
/* 5467 */       DatabaseReference ref = FirebaseDatabase.getInstance().getReference("SubCategoryItems");
/* 5468 */       ref.orderByChild("category_id").equalTo(id).addListenerForSingleValueEvent(new ValueEventListener()
/*      */           {
/*      */             public void onDataChange(DataSnapshot ds) {
/* 5471 */               for (DataSnapshot d : ds.getChildren()) {
/* 5472 */                 if (hjklout678.this.nto890.indexOf(d.child("name").getValue().toString()) == -1) {
/* 5473 */                   hjklout678.this.nto890.add(d.child("name").getValue().toString());
/* 5474 */                   hjklout678.this.hyt57fg.addItem(d.child("name").getValue().toString());
/* 5475 */                   hjklout678.this.uto899.add(d.child("id").getValue().toString());
/*      */                 } 
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public void onCancelled(DatabaseError de) {
/* 5482 */               throw new UnsupportedOperationException("Not supported yet.");
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void sdfh129sdFocusGained(FocusEvent evt) {
/* 5490 */     this.sdfh129sd.setText("");
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton11ActionPerformed(ActionEvent evt) {
/* 5495 */     clearCat();
/* 5496 */     yt65ckly76();
/* 5497 */     this.cardlayout.show(this.klo09812j, "AddItem");
/*      */   }
/*      */ 
/*      */   
/*      */   private void AaKeyPressed(KeyEvent evt) {
/* 5502 */     if (evt.getKeyCode() == 10) {
/* 5503 */       if (!this.Aa.getText().isEmpty()) {
/* 5504 */         this.ca65.retriveProductbarcode(this.Aa.getText());
/*      */       }
/*      */       
/* 5507 */       this.Aa.requestFocus();
/* 5508 */     } else if (evt.getKeyCode() == 38) {
/*      */       try {
/* 5510 */         (new Ajkdhfksj123as(con, this.ca65.getAllProds(), this.hjkouyth.getText())).setVisible(true);
/* 5511 */       } catch (Exception ex) {
/* 5512 */         kl.ek("CHECKOUT FAILED");
/* 5513 */         kl.ek("ERROR Cause " + ex.getCause());
/* 5514 */         kl.ek("Error Details " + ex.toString());
/*      */       } 
/* 5516 */       clkhh68gj();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void Ajklou12KeyPressed(KeyEvent evt) {
/* 5522 */     if (evt.getKeyCode() == 10) {
/* 5523 */       if (!this.Ajklou12.getText().isEmpty()) {
/* 5524 */         DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 5525 */         ref.orderByChild(this.sdjlop.getSelectedItem().toString())
/* 5526 */           .equalTo(this.Ajklou12.getText())
/* 5527 */           .addListenerForSingleValueEvent(new ValueEventListener()
/*      */             {
/*      */               public void onDataChange(DataSnapshot ds) {
/* 5530 */                 boolean find = false;
/* 5531 */                 for (DataSnapshot d : ds.getChildren()) {
/* 5532 */                   if (d.child("shop_id").getValue().toString().equalsIgnoreCase(hjklout678.this.hjkouyth.getText())) {
/* 5533 */                     hjklout678.this.jklOPhsklop.setText(d.child("size").getValue().toString());
/* 5534 */                     hjklout678.this.Jkiop90875sad.setText(d.child("name").getValue().toString());
/* 5535 */                     hjklout678.this.Ajklo.setText(d.getKey());
/* 5536 */                     hjklout678.this.Nmklobvg.setText(d.child("companyName").getValue().toString());
/* 5537 */                     hjklout678.this.Nkiopgty67i.setText(d.child("price").getValue().toString());
/* 5538 */                     hjklout678.this.JHYULOP.setText(d.child("quantity").getValue().toString());
/* 5539 */                     hjklout678.this.JKlopwr.setText(d.child("barcode").getValue().toString());
/* 5540 */                     hjklout678.this.aJKIy786g.setText(d.child("salesprice").getValue().toString());
/* 5541 */                     String cat = d.child("cat_id").getValue().toString();
/* 5542 */                     DatabaseReference refi = FirebaseDatabase.getInstance().getReference();
/* 5543 */                     refi.child("CategoryItems/" + cat).addListenerForSingleValueEvent(new ValueEventListener()
/*      */                         {
/*      */                           public void onDataChange(DataSnapshot ds)
/*      */                           {
/* 5547 */                             hjklout678.this.klopas234.setText(ds.child("name").getValue().toString());
/*      */                           }
/*      */ 
/*      */                           
/*      */                           public void onCancelled(DatabaseError de) {
/* 5552 */                             throw new UnsupportedOperationException("Not supported yet.");
/*      */                           }
/*      */                         });
/* 5555 */                     find = true;
/*      */                     break;
/*      */                   } 
/*      */                 } 
/* 5559 */                 if (!find) {
/* 5560 */                   JOptionPane.showMessageDialog(null, "No Product Found");
/*      */                 }
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public void onCancelled(DatabaseError de) {}
/*      */             });
/*      */       } else {
/* 5569 */         JOptionPane.showMessageDialog(this, "Please fill mandatory items");
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jklOPhsklopKeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void jButton12ActionPerformed(ActionEvent evt) {
/* 5580 */     OrderData o = this.g3.get(1 + 10 * this.currentPage);
/* 5581 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton13ActionPerformed(ActionEvent evt) {
/* 5586 */     OrderData o = this.g3.get(2 + 10 * this.currentPage);
/* 5587 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton20ActionPerformed(ActionEvent evt) {
/* 5592 */     OrderData o = this.g3.get(6 + 10 * this.currentPage);
/* 5593 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void search_order_icon1KeyPressed(KeyEvent evt) {
/* 5598 */     switch (evt.getKeyCode()) {
/*      */       case 10:
/* 5600 */         (new sdfkh32()).setVisible(true);
/*      */         break;
/*      */       case 37:
/*      */       case 40:
/* 5604 */         ty568fdfgh();
/* 5605 */         this.search_order_icon1.requestFocus();
/*      */         break;
/*      */       case 38:
/*      */       case 39:
/* 5609 */         gh65yu67();
/* 5610 */         this.search_order_icon1.requestFocus();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void search_order_iconKeyPressed(KeyEvent evt) {
/* 5619 */     switch (evt.getKeyCode()) {
/*      */       case 10:
/* 5621 */         (new Iuy34asjkh(this.g3, this)).setVisible(true);
/*      */         break;
/*      */       case 37:
/*      */       case 40:
/* 5625 */         jk765rty76();
/* 5626 */         this.search_order_icon.requestFocus();
/*      */         break;
/*      */       case 38:
/*      */       case 39:
/* 5630 */         jk765rty77();
/* 5631 */         this.search_order_icon.requestFocus();
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void kloupKeyPressed(KeyEvent evt) {
/* 5639 */     this.search_order_icon.requestFocus();
/*      */   }
/*      */ 
/*      */   
/*      */   private void kloupMouseClicked(MouseEvent evt) {
/* 5644 */     this.search_order_icon.requestFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void sd9KeyPressed(KeyEvent evt) {}
/*      */ 
/*      */   
/*      */   private void sd9MouseClicked(MouseEvent evt) {
/* 5653 */     this.sd9.setText("");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void sd9KeyReleased(KeyEvent evt) {
/* 5659 */     filter(this.sd9.getText().toLowerCase());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void fdshQoActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void dsfklopActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */   
/*      */   private void dsfklopMouseClicked(MouseEvent evt) {
/* 5672 */     JFileChooser f = new JFileChooser();
/* 5673 */     int v = f.showDialog(this, "Select");
/* 5674 */     if (v == f.getApproveButtonMnemonic()) {
/* 5675 */       this.sub_nto8 = f.getSelectedFile().getName();
/*      */       try {
/* 5677 */         File url = new File(f.getSelectedFile().getAbsolutePath());
/* 5678 */         BufferedImage image = ImageIO.read(url);
/* 5679 */         Image dimg = image.getScaledInstance(156, 177, 4);
/*      */         
/* 5681 */         this.sdfjho90.setIcon(new ImageIcon(dimg));
/* 5682 */         this.sdfjho90.updateUI();
/* 5683 */       } catch (IOException ex) {
/* 5684 */         Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void xdfj12MouseClicked(MouseEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void djskfLopActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void dfhskj123456MouseClicked(MouseEvent evt) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void dsfljslKIOPActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */   
/*      */   private void dsfljslKIOPMouseClicked(MouseEvent evt) {
/* 5707 */     JFileChooser f = new JFileChooser();
/* 5708 */     int v = f.showDialog(this, "Select");
/* 5709 */     if (v == f.getApproveButtonMnemonic()) {
/*      */       try {
/* 5711 */         this.nto8 = f.getSelectedFile().getName();
/* 5712 */         File url = new File(f.getSelectedFile().getAbsolutePath());
/* 5713 */         BufferedImage image = ImageIO.read(url);
/* 5714 */         Image dimg = image.getScaledInstance(156, 177, 4);
/*      */         
/* 5716 */         this.sdfhk89076.setIcon(new ImageIcon(dimg));
/* 5717 */         this.sdfhk89076.updateUI();
/* 5718 */       } catch (IOException ex) {
/* 5719 */         Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void djskfLopKeyPressed(KeyEvent evt) {
/* 5726 */     if (evt.getKeyCode() == 10)
/*      */     {
/* 5728 */       if (!this.catsaveInProgress) {
/* 5729 */         this.catsaveInProgress = true;
/* 5730 */         yt65();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void dsfljslKIOPKeyPressed(KeyEvent evt) {
/* 5737 */     if (evt.getKeyCode() == 10) {
/* 5738 */       JFileChooser f = new JFileChooser();
/* 5739 */       int v = f.showDialog(this, "Select");
/* 5740 */       if (v == f.getApproveButtonMnemonic()) {
/*      */         try {
/* 5742 */           this.nto8 = f.getSelectedFile().getName();
/* 5743 */           this.nto8_path = f.getSelectedFile().getAbsolutePath();
/* 5744 */           File url = new File(f.getSelectedFile().getAbsolutePath());
/* 5745 */           BufferedImage image = ImageIO.read(url);
/* 5746 */           Image dimg = image.getScaledInstance(156, 177, 4);
/*      */           
/* 5748 */           this.sdfhk89076.setIcon(new ImageIcon(dimg));
/* 5749 */           this.sdfhk89076.updateUI();
/* 5750 */         } catch (IOException ex) {
/* 5751 */           JOptionPane.showMessageDialog(null, "Error while loading image try again");
/* 5752 */           this.nto8 = "";
/* 5753 */           this.nto8_path = "";
/* 5754 */           this.sdfhk89076.setIcon((Icon)null);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void fdshQoKeyPressed(KeyEvent evt) {
/* 5762 */     if (evt.getKeyCode() == 10 && 
/* 5763 */       !this.subcatsaveInProgress) {
/* 5764 */       this.subcatsaveInProgress = false;
/* 5765 */       yt65Cat();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void fdshQoMouseClicked(MouseEvent evt) {
/* 5772 */     if (!this.subcatsaveInProgress) {
/* 5773 */       this.subcatsaveInProgress = false;
/* 5774 */       yt65Cat();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void dsfklopKeyPressed(KeyEvent evt) {
/* 5780 */     if (evt.getKeyCode() == 10) {
/* 5781 */       JFileChooser f = new JFileChooser();
/* 5782 */       int v = f.showDialog(this, "Select");
/* 5783 */       if (v == f.getApproveButtonMnemonic()) {
/* 5784 */         this.sub_nto8 = f.getSelectedFile().getName();
/* 5785 */         this.sub_nto8_path = f.getSelectedFile().getAbsolutePath();
/*      */         try {
/* 5787 */           File url = new File(f.getSelectedFile().getAbsolutePath());
/* 5788 */           BufferedImage image = ImageIO.read(url);
/* 5789 */           Image dimg = image.getScaledInstance(156, 177, 4);
/*      */           
/* 5791 */           this.sdfjho90.setIcon(new ImageIcon(dimg));
/* 5792 */           this.sdfjho90.updateUI();
/* 5793 */         } catch (IOException ex) {
/* 5794 */           JOptionPane.showMessageDialog(this.hjyt, "Error while loading image.\nTry again later.");
/* 5795 */           this.sub_nto8 = "";
/* 5796 */           this.sub_nto8_path = "";
/* 5797 */           this.sdfjho90.setIcon((Icon)null);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void dfhskj123456FocusGained(FocusEvent evt) {
/* 5805 */     this.dfhskj123456.setText("");
/*      */   }
/*      */ 
/*      */   
/*      */   private void xdfj12FocusGained(FocusEvent evt) {
/* 5810 */     this.xdfj12.setText("");
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton2MouseClicked(MouseEvent evt) {
/* 5815 */     OrderData o = this.g3.get(0 + 10 * this.currentPage);
/* 5816 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton17ActionPerformed(ActionEvent evt) {
/* 5821 */     OrderData o = this.g3.get(3 + 10 * this.currentPage);
/* 5822 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton18ActionPerformed(ActionEvent evt) {
/* 5827 */     OrderData o = this.g3.get(4 + 10 * this.currentPage);
/* 5828 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton19ActionPerformed(ActionEvent evt) {
/* 5833 */     OrderData o = this.g3.get(5 + 10 * this.currentPage);
/* 5834 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void sawdwaQEWMouseClicked(MouseEvent evt) {
/* 5839 */     if (this.mode == 0) {
/* 5840 */       (new afqr0(this.hjkouyth.getText())).setVisible(true);
/*      */     } else {
/* 5842 */       g90();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void pdrty654r(ProductData pd, int num) {
/* 5847 */     switch (num) {
/*      */       case 1:
/* 5849 */         hjk65899P(this.o1_id13, this.o1_on13, this.o1_oq13, this.o1_p13, pd, this.o_u14, this.inv_pp1);
/*      */         break;
/*      */       case 2:
/* 5852 */         hjk65899P(this.o1_id12, this.o1_on12, this.o1_oq12, this.o1_p12, pd, this.o_u13, this.inv_pp2);
/*      */         break;
/*      */       case 3:
/* 5855 */         hjk65899P(this.o1_id11, this.o1_on11, this.o1_oq11, this.o1_p11, pd, this.o_u12, this.inv_pp3);
/*      */         break;
/*      */       case 4:
/* 5858 */         hjk65899P(this.o1_id10, this.o1_on10, this.o1_oq10, this.o1_p10, pd, this.o_u11, this.inv_pp4);
/*      */         break;
/*      */       case 5:
/* 5861 */         hjk65899P(this.o1_id9, this.o1_on9, this.o1_oq9, this.o1_p9, pd, this.o_u10, this.inv_pp5);
/*      */         break;
/*      */       case 6:
/* 5864 */         hjk65899P(this.o1_id8, this.o1_on8, this.o1_oq8, this.o1_p8, pd, this.o_u9, this.inv_pp6);
/*      */         break;
/*      */       case 7:
/* 5867 */         hjk65899P(this.o1_id7, this.o1_on7, this.o1_oq7, this.o1_p7, pd, this.o_u8, this.inv_pp7);
/*      */         break;
/*      */       case 8:
/* 5870 */         hjk65899P(this.o1_id15, this.o1_on15, this.o1_oq15, this.o1_p15, pd, this.o_u16, this.inv_pp9);
/*      */         break;
/*      */       case 9:
/* 5873 */         hjk65899P(this.o1_id14, this.o1_on14, this.o1_oq14, this.o1_p14, pd, this.o_u15, this.inv_pp8);
/*      */         break;
/*      */       case 10:
/* 5876 */         hjk65899P(this.o1_id16, this.o1_on16, this.o1_oq16, this.o1_p16, pd, this.o_u17, this.inv_pp10);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void hjk65899P(JLabel orderId, JLabel pName, JLabel pquantity, JLabel price, ProductData pd, JPanel panel, JLabel pprice) {
/* 5883 */     orderId.setText(pd.getName());
/* 5884 */     pName.setText(pd.getBarcode());
/* 5885 */     pquantity.setText("" + pd.getQuantity());
/* 5886 */     pprice.setText(pd.getPrice());
/* 5887 */     price.setText(pd.getSalesprice());
/* 5888 */     if (pd.getQuantity() <= 8) {
/* 5889 */       panel.setBackground(new Color(151, 255, 255));
/*      */     } else {
/* 5891 */       panel.setBackground(new Color(240, 240, 240));
/*      */     } 
/* 5893 */     panel.setVisible(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void gh65fh() {
/* 5901 */     if (this.gio90.size() > 1) {
/* 5902 */       LinkedList<ProductData> s = new LinkedList<>();
/* 5903 */       LinkedList<String> index = new LinkedList<>();
/* 5904 */       s.add(this.gio90.get(0));
/* 5905 */       index.add(this.gio90index.get(0));
/* 5906 */       for (int i = 1; i < this.gio90.size(); i++) {
/* 5907 */         ProductData val = this.gio90.get(i);
/* 5908 */         String id = this.gio90index.get(i);
/* 5909 */         for (int j = 0; j < s.size(); j++) {
/* 5910 */           if (val.getQuantity() <= ((ProductData)s.get(j)).getQuantity()) {
/* 5911 */             s.add(j, val);
/* 5912 */             index.add(j, id); break;
/*      */           } 
/* 5914 */           if (j + 1 == s.size()) {
/* 5915 */             s.add(val);
/* 5916 */             index.add(id);
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/* 5921 */       this.gio90 = s;
/* 5922 */       this.gio90index = index;
/* 5923 */       this.hjt5676 = 0;
/*      */ 
/*      */ 
/*      */       
/* 5927 */       QWhg34asdA();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void gh65yu67() {
/* 5932 */     int val = this.gio90.size() - (1 + this.hjt5676) * 10;
/* 5933 */     if (val > 0) {
/* 5934 */       this.hjt5676++;
/* 5935 */       for (int i = 0; i < 10; i++) {
/* 5936 */         pdrty654r(this.gio90.get(i + 10 * this.hjt5676), i + 1);
/* 5937 */         if (val - i + 1 <= 0) {
/* 5938 */           for (int j = i + 1; j < 10; j++) {
/* 5939 */             QWh(j + 1);
/*      */           }
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } else {
/* 5945 */       JOptionPane.showMessageDialog(this, "Already on Last Page");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void ty568fdfgh() {
/* 5950 */     if (this.hjt5676 > 0) {
/* 5951 */       this.hjt5676--;
/* 5952 */       for (int i = 0; i < 10; i++) {
/* 5953 */         pdrty654r(this.gio90.get(i + 10 * this.hjt5676), i + 1);
/*      */       }
/*      */     } else {
/* 5956 */       JOptionPane.showMessageDialog(this, "Already on First Page");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void QWhg34asdA() {
/* 5961 */     for (int i = 1; i <= 10; i++) {
/* 5962 */       if (i <= this.gio90.size()) {
/* 5963 */         pdrty654r(this.gio90.get(i - 1), i);
/*      */       } else {
/* 5965 */         QWh(i);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void QWh(int j) {
/* 5971 */     switch (j) {
/*      */       case 1:
/* 5973 */         this.o_u14.setVisible(false);
/*      */         break;
/*      */       case 2:
/* 5976 */         this.o_u13.setVisible(false);
/*      */         break;
/*      */       case 3:
/* 5979 */         this.o_u12.setVisible(false);
/*      */         break;
/*      */       case 4:
/* 5982 */         this.o_u11.setVisible(false);
/*      */         break;
/*      */       case 5:
/* 5985 */         this.o_u10.setVisible(false);
/*      */         break;
/*      */       case 6:
/* 5988 */         this.o_u9.setVisible(false);
/*      */         break;
/*      */       case 7:
/* 5991 */         this.o_u8.setVisible(false);
/*      */         break;
/*      */       case 8:
/* 5994 */         this.o_u16.setVisible(false);
/*      */         break;
/*      */       case 9:
/* 5997 */         this.o_u15.setVisible(false);
/*      */         break;
/*      */       case 10:
/* 6000 */         this.o_u17.setVisible(false);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void AdrtfghKeyPressed(KeyEvent evt) {
/* 6007 */     if (evt.getKeyCode() == 10) {
/* 6008 */       this.dfsh34hsd.requestFocus();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void klopdfger67MouseClicked(MouseEvent evt) {
/* 6014 */     this.Aa.requestFocus();
/*      */   }
/*      */ 
/*      */   
/*      */   private void dfsh34hsdKeyPressed(KeyEvent evt) {
/* 6019 */     if (evt.getKeyCode() == 10) {
/* 6020 */       JFileChooser f = new JFileChooser();
/* 6021 */       int v = f.showDialog(this, "Select");
/* 6022 */       if (v == f.getApproveButtonMnemonic()) {
/*      */         try {
/* 6024 */           this.nto898u78file = f.getSelectedFile().getName();
/* 6025 */           this.nto898u78file_path = f.getSelectedFile().getAbsolutePath();
/* 6026 */           File url = new File(f.getSelectedFile().getAbsolutePath());
/* 6027 */           BufferedImage image = ImageIO.read(url);
/* 6028 */           Image dimg = image.getScaledInstance(156, 177, 4);
/*      */           
/* 6030 */           this.sfdjkh12940.setIcon(new ImageIcon(dimg));
/* 6031 */           this.sfdjkh12940.updateUI();
/* 6032 */         } catch (IOException ex) {
/* 6033 */           kl.ek("Error while readomg prod image ");
/* 6034 */           kl.ek("Error Details " + ex.toString());
/* 6035 */           JOptionPane.showMessageDialog(null, "Error while reading image try again.");
/* 6036 */           this.nto898u78file = "";
/* 6037 */           this.nto898u78file_path = "";
/* 6038 */           this.sfdjkh12940.setIcon((Icon)null);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jButton21ActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */   
/*      */   private void jButton22ActionPerformed(ActionEvent evt) {
/* 6050 */     OrderData o = this.g3.get(7 + 10 * this.currentPage);
/* 6051 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jButton23ActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */   
/*      */   private void jButton24ActionPerformed(ActionEvent evt) {
/* 6060 */     OrderData o = this.g3.get(8 + 10 * this.currentPage);
/* 6061 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void jButton25ActionPerformed(ActionEvent evt) {}
/*      */ 
/*      */   
/*      */   private void jButton27ActionPerformed(ActionEvent evt) {
/* 6070 */     OrderData o = this.g3.get(9 + 10 * this.currentPage);
/* 6071 */     (new jkhadfkj(o, this)).setVisible(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private void JKlopwrKeyPressed(KeyEvent evt) {
/* 6076 */     if (evt.getKeyCode() == 10) {
/* 6077 */       this.XAa.requestFocus();
/*      */     }
/*      */   }
/*      */   
/*      */   private void jButton3ActionPerformed(ActionEvent evt) {
/* 6082 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
/* 6083 */     ref.child("Shop").orderByChild("id").equalTo(this.AK90.getText()).addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/* 6086 */             if (ds.getChildrenCount() > 0L) {
/* 6087 */               File fold = new File("bin/Creds/shopId.txt");
/* 6088 */               fold.delete();
/* 6089 */               File fnew = new File("bin/Creds/shopId.txt");
/* 6090 */               String source = hjklout678.this.AK90.getText();
/* 6091 */               hjklout678.this.hjkouyth.setText(hjklout678.this.AK90.getText());
/*      */               try {
/* 6093 */                 FileWriter f2 = new FileWriter(fnew, false);
/* 6094 */                 f2.write(source);
/* 6095 */                 f2.close();
/* 6096 */               } catch (IOException ex) {
/* 6097 */                 hjklout678.this.kk; kl.ek("ERROR While saving shop id");
/* 6098 */                 hjklout678.this.kk; kl.ek("ERROR Cause " + ex.getCause());
/* 6099 */                 hjklout678.this.kk; kl.ek("Error Details " + ex.toString());
/*      */               } 
/* 6101 */               JOptionPane.showMessageDialog(null, "Updated SuccessFuly");
/*      */             } else {
/* 6103 */               JOptionPane.showMessageDialog(null, "Please Enter a valid id.\nShop Doesnot exist.");
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 6109 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void hjuKeyPressed(KeyEvent evt) {
/* 6116 */     if (evt.getKeyCode() == 10) {
/* 6117 */       updateCount(this.hju, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void zKeyPressed(KeyEvent evt) {
/* 6123 */     if (evt.getKeyCode() == 10) {
/* 6124 */       updateCount(this.z, 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void kKeyPressed(KeyEvent evt) {
/* 6130 */     if (evt.getKeyCode() == 10) {
/* 6131 */       updateCount(this.k, 2);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void ghyrtioyKeyPressed(KeyEvent evt) {
/* 6137 */     if (evt.getKeyCode() == 10) {
/* 6138 */       updateCount(this.ghyrtioy, 3);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void ggsd579KeyPressed(KeyEvent evt) {
/* 6144 */     if (evt.getKeyCode() == 10) {
/* 6145 */       updateCount(this.ggsd579, 4);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_c7KeyPressed(KeyEvent evt) {
/* 6151 */     if (evt.getKeyCode() == 10) {
/* 6152 */       updateCount(this.cart_c7, 6);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void cart_c6KeyPressed(KeyEvent evt) {
/* 6158 */     if (evt.getKeyCode() == 10) {
/* 6159 */       updateCount(this.cart_c6, 5);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void ghjuyto90KeyPressed(KeyEvent evt) {
/* 6165 */     if (evt.getKeyCode() == 10) {
/* 6166 */       updateCount(this.ghjuyto90, 7);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton4ActionPerformed(ActionEvent evt) {
/*      */     try {
/* 6173 */       PreparedStatement ps = con.prepareStatement("delete from cartInfo");
/* 6174 */       ps.execute();
/* 6175 */       ps.close();
/* 6176 */       ps = con.prepareStatement("delete from ImageTable");
/* 6177 */       ps.execute();
/* 6178 */       ps.close();
/* 6179 */     } catch (SQLException ex) {
/* 6180 */       kl.ek("LOCAL DB CLEAN FAILED");
/* 6181 */       kl.ek("ERROR Cause " + ex.getCause());
/* 6182 */       kl.ek("ERROR Cause " + ex.getErrorCode());
/* 6183 */       kl.ek("Error Details " + ex.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void djskfLopMouseClicked(MouseEvent evt) {
/* 6189 */     if (!this.catsaveInProgress) {
/* 6190 */       this.catsaveInProgress = true;
/* 6191 */       yt65();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton28MouseClicked(MouseEvent evt) {
/* 6197 */     DefaultTableModel model = (DefaultTableModel)this.Al09.getModel();
/*      */     
/* 6199 */     final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 6200 */     ref.orderByChild("shop_id").equalTo(this.hjkouyth.getText()).addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/* 6203 */             for (DataSnapshot dataSnapshot : ds.getChildren()) {
/* 6204 */               ref.child(dataSnapshot.getKey()).child("soldItems").setValueAsync("0");
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 6210 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void jButton29ActionPerformed(ActionEvent evt) {
/* 6217 */     final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 6218 */     ref.orderByChild("shop_id").equalTo(this.hjkouyth.getText()).addListenerForSingleValueEvent(new ValueEventListener()
/*      */         {
/*      */           public void onDataChange(DataSnapshot ds) {
/* 6221 */             for (DataSnapshot d : ds.getChildren()) {
/* 6222 */               ref.child(d.getKey()).removeValueAsync();
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           public void onCancelled(DatabaseError de) {
/* 6228 */             throw new UnsupportedOperationException("Not supported yet.");
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void jButton30ActionPerformed(ActionEvent evt) {
/* 6234 */     String name = this.skldf821.getText();
/* 6235 */     if (!name.trim().isEmpty()) {
/*      */       try {
/* 6237 */         FileWriter f = new FileWriter("bin/creds/shopName.txt");
/* 6238 */         f.write(name);
/* 6239 */         f.close();
/* 6240 */         JOptionPane.showMessageDialog(null, "Saved.");
/* 6241 */         this.skldf821.setText("");
/* 6242 */       } catch (IOException ex) {
/* 6243 */         kl.ek("Error while updating shop Name");
/* 6244 */         JOptionPane.showMessageDialog(null, "Error while updating shop Name");
/*      */       } 
/*      */     } else {
/* 6247 */       JOptionPane.showMessageDialog(null, "Enter shop Name.");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void updateCount(JTextField cartc, int index) {
/* 6252 */     cartData item = this.ca65.getAllProds().get(index);
/*      */     try {
/* 6254 */       int val = Integer.parseInt(cartc.getText());
/* 6255 */       if (val > 0) {
/* 6256 */         String barcode = item.getBarcode();
/* 6257 */         PreparedStatement ps = con.prepareStatement("Select quantity from cartInfo where barcode = '" + barcode + "'");
/* 6258 */         ResultSet rs = ps.executeQuery();
/* 6259 */         if (rs.next()) {
/* 6260 */           int tval = rs.getInt(1);
/* 6261 */           if (val <= tval) {
/* 6262 */             this.ca65.updateCount(val, index);
/*      */           } else {
/* 6264 */             cartc.setText("" + item.getCount());
/* 6265 */             JOptionPane.showMessageDialog(null, "Total Count Exceded limit.\n Max items are " + tval);
/*      */           } 
/*      */         } else {
/* 6268 */           cartc.setText("" + item.getCount());
/*      */         } 
/*      */       } else {
/* 6271 */         cartc.setText("" + item.getCount());
/*      */       } 
/* 6273 */     } catch (SQLException ex) {
/* 6274 */       kl.ek("MANUAL UPDATE CART COUNT FAILED");
/* 6275 */       kl.ek("ERROR Cause " + ex.getCause());
/* 6276 */       kl.ek("ERROR CODE " + ex.getErrorCode());
/* 6277 */       kl.ek("Error Details " + ex.toString());
/* 6278 */       cartc.setText("" + item.getCount());
/* 6279 */     } catch (Exception ex) {
/* 6280 */       cartc.setText("" + item.getCount());
/*      */     } 
/*      */     
/* 6283 */     this.Aa.requestFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/*      */     try {
/* 6296 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 6297 */         if ("Windows".equals(info.getName())) {
/* 6298 */           UIManager.setLookAndFeel(info.getClassName());
/*      */           break;
/*      */         } 
/*      */       } 
/* 6302 */     } catch (ClassNotFoundException ex) {
/* 6303 */       Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 6304 */     } catch (InstantiationException ex) {
/* 6305 */       Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 6306 */     } catch (IllegalAccessException ex) {
/* 6307 */       Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 6308 */     } catch (UnsupportedLookAndFeelException ex) {
/* 6309 */       Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */     } 
/*      */     
/* 6312 */     Common.initFirebase();
/*      */     
/* 6314 */     EventQueue.invokeLater(new Runnable() {
/*      */           public void run() {
/* 6316 */             (new hjklout678(0, "")).setVisible(true);
/*      */           }
/*      */         });
/*      */   }
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\hjklout678.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */