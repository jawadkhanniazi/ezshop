/*    */ package EasyShop.front_end;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ek
/*    */ {
/*    */   public static void kl(String s) {
/* 16 */     System.out.println(s);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\ek.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */