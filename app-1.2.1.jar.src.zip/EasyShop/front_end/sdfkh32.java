/*     */ package EasyShop.front_end;
/*     */ 
/*     */ import com.google.firebase.database.DataSnapshot;
/*     */ import com.google.firebase.database.DatabaseReference;
/*     */ import com.google.firebase.database.ValueEventListener;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.util.LinkedList;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ public class sdfkh32 extends JFrame {
/*     */   private class pdata { String name;
/*     */     
/*     */     public pdata(String name, String barcode, String quant, String sp, String pp, String shopid) {
/*  32 */       this.name = name;
/*  33 */       this.barcode = barcode;
/*  34 */       this.quant = quant;
/*  35 */       this.sp = sp;
/*  36 */       this.pp = pp;
/*  37 */       this.shopid = shopid;
/*     */     }
/*     */     String barcode; String quant; String sp;
/*     */     String pp;
/*     */     String shopid; }
/*  42 */   private LinkedList<pdata> list = new LinkedList<>();
/*  43 */   private int index = 1;
/*  44 */   private int xMouse = 0;
/*  45 */   private int yMouse = 0; private JPanel dfkjsh12; private JTextField djskfh123; private JTable hsad123rte; private JLabel jLabel1; private JLabel jLabel2; private JLabel jLabel3; private JPanel jPanel2;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JComboBox<String> sdfjh234nm;
/*     */   
/*     */   public sdfkh32() {
/*  50 */     setUndecorated(true);
/*  51 */     initComponents();
/*  52 */     setLocationRelativeTo(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  64 */     this.dfkjsh12 = new JPanel();
/*  65 */     this.jPanel2 = new JPanel();
/*  66 */     this.jLabel2 = new JLabel();
/*  67 */     this.sdfjh234nm = new JComboBox<>();
/*  68 */     this.djskfh123 = new JTextField();
/*  69 */     this.jScrollPane1 = new JScrollPane();
/*  70 */     this.hsad123rte = new JTable();
/*  71 */     this.jLabel1 = new JLabel();
/*  72 */     this.jLabel3 = new JLabel();
/*     */     
/*  74 */     setDefaultCloseOperation(2);
/*     */     
/*  76 */     this.dfkjsh12.setBackground(new Color(255, 255, 255));
/*  77 */     this.dfkjsh12.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */     
/*  79 */     this.jPanel2.setBackground(new Color(0, 0, 0));
/*  80 */     this.jPanel2.addMouseMotionListener(new MouseMotionAdapter() {
/*     */           public void mouseDragged(MouseEvent evt) {
/*  82 */             sdfkh32.this.jPanel2MouseDragged(evt);
/*     */           }
/*     */         });
/*  85 */     this.jPanel2.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  87 */             sdfkh32.this.jPanel2MouseClicked(evt);
/*     */           }
/*     */           public void mousePressed(MouseEvent evt) {
/*  90 */             sdfkh32.this.jPanel2MousePressed(evt);
/*     */           }
/*     */         });
/*     */     
/*  94 */     this.jLabel2.setBackground(new Color(255, 255, 255));
/*  95 */     this.jLabel2.setFont(new Font("Tahoma", 0, 14));
/*  96 */     this.jLabel2.setForeground(new Color(255, 255, 255));
/*  97 */     this.jLabel2.setText("X");
/*  98 */     this.jLabel2.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 100 */             sdfkh32.this.jLabel2MouseClicked(evt);
/*     */           }
/*     */           public void mouseEntered(MouseEvent evt) {
/* 103 */             sdfkh32.this.jLabel2MouseEntered(evt);
/*     */           }
/*     */           public void mouseExited(MouseEvent evt) {
/* 106 */             sdfkh32.this.jLabel2MouseExited(evt);
/*     */           }
/*     */         });
/*     */     
/* 110 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 111 */     this.jPanel2.setLayout(jPanel2Layout);
/* 112 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout
/* 113 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 114 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
/* 115 */           .addContainerGap(-1, 32767)
/* 116 */           .addComponent(this.jLabel2)
/* 117 */           .addContainerGap()));
/*     */     
/* 119 */     jPanel2Layout.setVerticalGroup(jPanel2Layout
/* 120 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 121 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
/* 122 */           .addContainerGap(-1, 32767)
/* 123 */           .addComponent(this.jLabel2)
/* 124 */           .addContainerGap()));
/*     */ 
/*     */     
/* 127 */     this.sdfjh234nm.setModel(new DefaultComboBoxModel<>(new String[] { "name", "barcode" }));
/* 128 */     this.sdfjh234nm.setBorder((Border)null);
/* 129 */     this.sdfjh234nm.setRequestFocusEnabled(false);
/*     */     
/* 131 */     this.djskfh123.setFont(new Font("Tahoma", 0, 14));
/* 132 */     this.djskfh123.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/* 133 */     this.djskfh123.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 135 */             sdfkh32.this.djskfh123MouseClicked(evt);
/*     */           }
/*     */         });
/* 138 */     this.djskfh123.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 140 */             sdfkh32.this.djskfh123ActionPerformed(evt);
/*     */           }
/*     */         });
/* 143 */     this.djskfh123.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 145 */             sdfkh32.this.djskfh123KeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 149 */     this.hsad123rte.setFont(new Font("Tahoma", 0, 14));
/* 150 */     this.hsad123rte.setModel(new DefaultTableModel(new Object[][] { { null, null }, , { null, null }, , { null, null }, , { null, null }, , { null, null }, , { null, null },  }, (Object[])new String[] { "", "" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     this.hsad123rte.setRowHeight(20);
/* 164 */     this.jScrollPane1.setViewportView(this.hsad123rte);
/*     */     
/* 166 */     this.jLabel1.setFont(new Font("Tahoma", 0, 24));
/* 167 */     this.jLabel1.setText("Product Search");
/*     */     
/* 169 */     this.jLabel3.setFont(new Font("Tahoma", 0, 14));
/* 170 */     this.jLabel3.setText("Product Details");
/*     */     
/* 172 */     GroupLayout dfkjsh12Layout = new GroupLayout(this.dfkjsh12);
/* 173 */     this.dfkjsh12.setLayout(dfkjsh12Layout);
/* 174 */     dfkjsh12Layout.setHorizontalGroup(dfkjsh12Layout
/* 175 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 176 */         .addComponent(this.jPanel2, -1, -1, 32767)
/* 177 */         .addGroup(dfkjsh12Layout.createSequentialGroup()
/* 178 */           .addContainerGap()
/* 179 */           .addComponent(this.jLabel1)
/* 180 */           .addContainerGap(378, 32767))
/* 181 */         .addGroup(GroupLayout.Alignment.TRAILING, dfkjsh12Layout.createSequentialGroup()
/* 182 */           .addContainerGap(-1, 32767)
/* 183 */           .addGroup(dfkjsh12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 184 */             .addComponent(this.jScrollPane1, -2, -1, -2)
/* 185 */             .addGroup(dfkjsh12Layout.createSequentialGroup()
/* 186 */               .addComponent(this.sdfjh234nm, -2, 115, -2)
/* 187 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 188 */               .addComponent(this.djskfh123, -2, 266, -2))
/* 189 */             .addComponent(this.jLabel3))
/* 190 */           .addGap(41, 41, 41)));
/*     */     
/* 192 */     dfkjsh12Layout.setVerticalGroup(dfkjsh12Layout
/* 193 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 194 */         .addGroup(dfkjsh12Layout.createSequentialGroup()
/* 195 */           .addComponent(this.jPanel2, -2, -1, -2)
/* 196 */           .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 197 */           .addComponent(this.jLabel1)
/* 198 */           .addGap(39, 39, 39)
/* 199 */           .addGroup(dfkjsh12Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 200 */             .addComponent(this.sdfjh234nm, -2, 30, -2)
/* 201 */             .addComponent(this.djskfh123, -2, 30, -2))
/* 202 */           .addGap(18, 18, 18)
/* 203 */           .addComponent(this.jLabel3)
/* 204 */           .addGap(18, 18, 18)
/* 205 */           .addComponent(this.jScrollPane1, -2, 134, -2)
/* 206 */           .addContainerGap(41, 32767)));
/*     */ 
/*     */     
/* 209 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 210 */     getContentPane().setLayout(layout);
/* 211 */     layout.setHorizontalGroup(layout
/* 212 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 213 */         .addComponent(this.dfkjsh12, -1, -1, 32767));
/*     */     
/* 215 */     layout.setVerticalGroup(layout
/* 216 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 217 */         .addGroup(layout.createSequentialGroup()
/* 218 */           .addComponent(this.dfkjsh12, -2, -1, -2)
/* 219 */           .addGap(0, 0, 32767)));
/*     */ 
/*     */     
/* 222 */     pack();
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateview(pdata d) {
/* 227 */     DefaultTableModel model = (DefaultTableModel)this.hsad123rte.getModel();
/* 228 */     model.setRowCount(0);
/* 229 */     Object[] row0 = { "name", d.name };
/* 230 */     model.addRow(row0);
/* 231 */     Object[] row1 = { "barcode", d.barcode };
/* 232 */     model.addRow(row1);
/* 233 */     Object[] row2 = { "Purchase Price", d.pp };
/* 234 */     model.addRow(row2);
/* 235 */     Object[] row3 = { "Sales Price", d.sp };
/* 236 */     model.addRow(row3);
/* 237 */     Object[] row4 = { "quantity", d.quant };
/* 238 */     model.addRow(row4);
/* 239 */     Object[] row5 = { "Shop ID", d.shopid };
/* 240 */     model.addRow(row5);
/*     */   }
/*     */ 
/*     */   
/*     */   private void djskfh123KeyPressed(KeyEvent evt) {
/* 245 */     if (evt.getKeyCode() == 10) {
/* 246 */       DatabaseReference ref = FirebaseDatabase.getInstance().getReference("ProductsItems");
/* 247 */       ref.orderByChild(this.sdfjh234nm.getSelectedItem().toString()).equalTo(this.djskfh123.getText()).addListenerForSingleValueEvent(new ValueEventListener()
/*     */           {
/*     */             public void onDataChange(DataSnapshot ds) {
/* 250 */               sdfkh32.this.list.clear();
/* 251 */               if (ds.getChildrenCount() > 0L) {
/* 252 */                 for (DataSnapshot d : ds.getChildren()) {
/* 253 */                   String name = d.child("name").getValue().toString();
/* 254 */                   String barcode = d.child("barcode").getValue().toString();
/* 255 */                   String q = d.child("quantity").getValue().toString();
/* 256 */                   String sp = d.child("salesprice").getValue().toString();
/* 257 */                   String pp = d.child("price").getValue().toString();
/* 258 */                   String sh = d.child("shop_id").getValue().toString();
/* 259 */                   sdfkh32.this.list.add(new sdfkh32.pdata(name, barcode, q, sp, pp, sh));
/*     */                 } 
/*     */                 
/* 262 */                 sdfkh32.this.updateview(sdfkh32.this.list.get(0));
/*     */               } else {
/* 264 */                 JOptionPane.showMessageDialog(null, "No Product Found");
/*     */               } 
/*     */             }
/*     */ 
/*     */             
/*     */             public void onCancelled(DatabaseError de) {
/* 270 */               throw new UnsupportedOperationException("Not supported yet.");
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void jLabel2MouseClicked(MouseEvent evt) {
/* 278 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void jLabel2MouseEntered(MouseEvent evt) {
/* 283 */     this.jLabel2.setForeground(Color.red);
/*     */   }
/*     */ 
/*     */   
/*     */   private void jLabel2MouseExited(MouseEvent evt) {
/* 288 */     this.jLabel2.setForeground(Color.white);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void djskfh123ActionPerformed(ActionEvent evt) {}
/*     */ 
/*     */   
/*     */   private void djskfh123MouseClicked(MouseEvent evt) {
/* 297 */     this.djskfh123.setText("");
/* 298 */     DefaultTableModel model = (DefaultTableModel)this.hsad123rte.getModel();
/* 299 */     model.setRowCount(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void jPanel2MouseClicked(MouseEvent evt) {}
/*     */ 
/*     */   
/*     */   private void jPanel2MouseDragged(MouseEvent evt) {
/* 308 */     int x = evt.getXOnScreen();
/* 309 */     int y = evt.getYOnScreen();
/* 310 */     setLocation(x - this.xMouse, y - this.yMouse);
/*     */   }
/*     */ 
/*     */   
/*     */   private void jPanel2MousePressed(MouseEvent evt) {
/* 315 */     this.xMouse = evt.getX();
/* 316 */     this.yMouse = evt.getY();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\sdfkh32.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */