/*     */ package EasyShop.front_end;
/*     */ import com.google.firebase.database.DataSnapshot;
/*     */ import com.google.firebase.database.ValueEventListener;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ public class login extends JFrame {
/*  27 */   int xMouse = 0;
/*  28 */   int yMouse = 0; private JLabel exit; private JButton jButton1; private JButton jButton2; private JPanel jPanel1; private JPanel jPanel3; private JPasswordField pass; private JLabel pass_icon;
/*     */   private JTextField uname;
/*     */   private JLabel uname_icon;
/*     */   private JLabel valid;
/*     */   
/*     */   public login() {
/*  34 */     setUndecorated(true);
/*  35 */     initComponents();
/*  36 */     setLocationRelativeTo(this);
/*  37 */     this.valid.setVisible(false);
/*  38 */     this.uname_icon.setIcon(new ImageIcon("bin/Icons/icons8-name-50.back.png"));
/*  39 */     this.pass_icon.setIcon(new ImageIcon("bin/Icons/icons8-password-50.png"));
/*  40 */     Common.initFirebase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  53 */     this.jPanel1 = new JPanel();
/*  54 */     this.uname = new JTextField();
/*  55 */     this.pass = new JPasswordField();
/*  56 */     this.jButton2 = new JButton();
/*  57 */     this.jPanel3 = new JPanel();
/*  58 */     this.exit = new JLabel();
/*  59 */     this.jButton1 = new JButton();
/*  60 */     this.valid = new JLabel();
/*  61 */     this.uname_icon = new JLabel();
/*  62 */     this.pass_icon = new JLabel();
/*     */     
/*  64 */     setDefaultCloseOperation(3);
/*     */     
/*  66 */     this.jPanel1.setBackground(new Color(255, 255, 255));
/*  67 */     this.jPanel1.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*  68 */     this.jPanel1.setFont(new Font("Tahoma", 0, 18));
/*     */     
/*  70 */     this.uname.setForeground(new Color(153, 153, 153));
/*  71 */     this.uname.setText("Enter User Name");
/*  72 */     this.uname.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*  73 */     this.uname.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  75 */             login.this.unameMouseClicked(evt);
/*     */           }
/*     */         });
/*  78 */     this.uname.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  80 */             login.this.unameActionPerformed(evt);
/*     */           }
/*     */         });
/*  83 */     this.uname.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  85 */             login.this.unameKeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/*  89 */     this.pass.setForeground(new Color(153, 153, 153));
/*  90 */     this.pass.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(153, 153, 153)));
/*  91 */     this.pass.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  93 */             login.this.passMouseClicked(evt);
/*     */           }
/*     */         });
/*  96 */     this.pass.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  98 */             login.this.passKeyPressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 102 */     this.jButton2.setText("Login");
/* 103 */     this.jButton2.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 105 */             login.this.jButton2MouseClicked(evt);
/*     */           }
/*     */         });
/* 108 */     this.jButton2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 110 */             login.this.jButton2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 114 */     this.jPanel3.setBackground(new Color(102, 102, 102));
/* 115 */     this.jPanel3.addMouseMotionListener(new MouseMotionAdapter() {
/*     */           public void mouseDragged(MouseEvent evt) {
/* 117 */             login.this.jPanel3MouseDragged(evt);
/*     */           }
/*     */         });
/* 120 */     this.jPanel3.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 122 */             login.this.jPanel3MouseClicked(evt);
/*     */           }
/*     */           public void mousePressed(MouseEvent evt) {
/* 125 */             login.this.jPanel3MousePressed(evt);
/*     */           }
/*     */         });
/*     */     
/* 129 */     this.exit.setFont(new Font("Tahoma", 0, 18));
/* 130 */     this.exit.setForeground(new Color(255, 255, 255));
/* 131 */     this.exit.setHorizontalAlignment(0);
/* 132 */     this.exit.setText("X");
/* 133 */     this.exit.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 135 */             login.this.exitMouseClicked(evt);
/*     */           }
/*     */           public void mouseEntered(MouseEvent evt) {
/* 138 */             login.this.exitMouseEntered(evt);
/*     */           }
/*     */           public void mouseExited(MouseEvent evt) {
/* 141 */             login.this.exitMouseExited(evt);
/*     */           }
/*     */         });
/*     */     
/* 145 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 146 */     this.jPanel3.setLayout(jPanel3Layout);
/* 147 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout
/* 148 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 149 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
/* 150 */           .addGap(0, 594, 32767)
/* 151 */           .addComponent(this.exit, -2, 45, -2)));
/*     */     
/* 153 */     jPanel3Layout.setVerticalGroup(jPanel3Layout
/* 154 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 155 */         .addGroup(jPanel3Layout.createSequentialGroup()
/* 156 */           .addComponent(this.exit, -2, 35, -2)
/* 157 */           .addGap(0, 26, 32767)));
/*     */ 
/*     */     
/* 160 */     this.jButton1.setText("Work offline");
/* 161 */     this.jButton1.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 163 */             login.this.jButton1MouseClicked(evt);
/*     */           }
/*     */         });
/*     */     
/* 167 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 168 */     this.jPanel1.setLayout(jPanel1Layout);
/* 169 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout
/* 170 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 171 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 172 */           .addComponent(this.jPanel3, -2, -1, -2)
/* 173 */           .addGap(0, 0, 32767))
/* 174 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 175 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 176 */             .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 177 */               .addGroup(jPanel1Layout.createSequentialGroup()
/* 178 */                 .addGap(86, 86, 86)
/* 179 */                 .addComponent(this.valid, -2, 66, -2))
/* 180 */               .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
/* 181 */                 .addGap(89, 89, 89)
/* 182 */                 .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 183 */                   .addComponent(this.uname_icon)
/* 184 */                   .addComponent(this.pass_icon))
/* 185 */                 .addGap(18, 18, 18)
/* 186 */                 .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 187 */                   .addComponent(this.pass, GroupLayout.Alignment.TRAILING)
/* 188 */                   .addComponent(this.uname, GroupLayout.Alignment.TRAILING, -1, 309, 32767))))
/* 189 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 190 */               .addGap(137, 137, 137)
/* 191 */               .addComponent(this.jButton2, -2, 144, -2)
/* 192 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 41, 32767)
/* 193 */               .addComponent(this.jButton1, -2, 144, -2)))
/* 194 */           .addContainerGap(-1, 32767)));
/*     */     
/* 196 */     jPanel1Layout.setVerticalGroup(jPanel1Layout
/* 197 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 198 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 199 */           .addComponent(this.jPanel3, -2, -1, -2)
/* 200 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 74, 32767)
/* 201 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 202 */             .addComponent(this.uname_icon, -2, 50, -2)
/* 203 */             .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
/* 204 */               .addComponent(this.uname, -2, 32, -2)
/* 205 */               .addGap(8, 8, 8)))
/* 206 */           .addGap(45, 45, 45)
/* 207 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 208 */             .addComponent(this.pass_icon, GroupLayout.Alignment.TRAILING)
/* 209 */             .addComponent(this.pass, GroupLayout.Alignment.TRAILING, -2, 32, -2))
/* 210 */           .addGap(56, 56, 56)
/* 211 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 212 */             .addComponent(this.jButton2, -2, 32, -2)
/* 213 */             .addComponent(this.jButton1, -2, 32, -2))
/* 214 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 215 */           .addComponent(this.valid, -2, 17, -2)
/* 216 */           .addGap(83, 83, 83)));
/*     */ 
/*     */     
/* 219 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 220 */     getContentPane().setLayout(layout);
/* 221 */     layout.setHorizontalGroup(layout
/* 222 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 223 */         .addComponent(this.jPanel1, -2, -1, -2));
/*     */     
/* 225 */     layout.setVerticalGroup(layout
/* 226 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 227 */         .addComponent(this.jPanel1, -1, -1, 32767));
/*     */ 
/*     */     
/* 230 */     pack();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void unameActionPerformed(ActionEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {}
/*     */ 
/*     */   
/*     */   private void jButton2MouseClicked(MouseEvent evt) {
/* 243 */     verify();
/*     */   }
/*     */   private void verify() {
/* 246 */     DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
/* 247 */     ref.child("ShopOwner").orderByChild("username").equalTo(this.uname.getText()).addListenerForSingleValueEvent(new ValueEventListener()
/*     */         {
/*     */           public void onDataChange(DataSnapshot ds) {
/* 250 */             login.this.valid.setText("wait");
/* 251 */             if (ds.getChildrenCount() > 0L) {
/* 252 */               for (DataSnapshot d : ds.getChildren()) {
/* 253 */                 if (d.child("password").getValue().toString().equalsIgnoreCase(login.this.pass.getText().toString())) {
/* 254 */                   login.this.valid.setText("");
/*     */                   try {
/* 256 */                     FileWriter file = new FileWriter("bin/creds/shopID.txt");
/* 257 */                     file.write(d.child("shopid").getValue().toString());
/* 258 */                     file.close();
/* 259 */                   } catch (IOException ex) {
/* 260 */                     JOptionPane.showMessageDialog(null, "error");
/*     */                   } 
/*     */                   
/* 263 */                   if (d.hasChild("shopid")) {
/* 264 */                     login.this.success(d.child("shopid").getValue().toString()); break;
/*     */                   } 
/* 266 */                   JOptionPane.showMessageDialog(null, "No Shop Id found!");
/* 267 */                   System.exit(0);
/*     */                   
/*     */                   break;
/*     */                 } 
/*     */               } 
/*     */             }
/* 273 */             if (login.this.valid.getText().equalsIgnoreCase("wait")) {
/* 274 */               JOptionPane.showMessageDialog(login.this.rootPane, "Enter valid username or password");
/*     */             }
/*     */           }
/*     */ 
/*     */           
/*     */           public void onCancelled(DatabaseError de) {
/* 280 */             System.out.println("Connection cancled");
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void success(String id) {
/*     */     try {
/* 287 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 288 */         if ("Windows".equals(info.getName())) {
/* 289 */           UIManager.setLookAndFeel(info.getClassName());
/*     */           break;
/*     */         } 
/*     */       } 
/* 293 */     } catch (ClassNotFoundException|InstantiationException|IllegalAccessException|javax.swing.UnsupportedLookAndFeelException ex) {
/* 294 */       Logger.getLogger(hjklout678.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/* 296 */     (new hjklout678(0, id)).setVisible(true);
/* 297 */     dispose();
/*     */   }
/*     */   
/*     */   private void passKeyPressed(KeyEvent evt) {
/* 301 */     if (evt.getKeyCode() == 10) {
/* 302 */       verify();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void exitMouseClicked(MouseEvent evt) {
/* 308 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void exitMouseEntered(MouseEvent evt) {
/* 313 */     this.exit.setForeground(Color.red);
/*     */   }
/*     */ 
/*     */   
/*     */   private void exitMouseExited(MouseEvent evt) {
/* 318 */     this.exit.setForeground(Color.white);
/*     */   }
/*     */ 
/*     */   
/*     */   private void jButton1MouseClicked(MouseEvent evt) {
/* 323 */     (new hjklout678(1, "")).setVisible(true);
/* 324 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   private void unameMouseClicked(MouseEvent evt) {
/* 329 */     this.uname.setText("");
/* 330 */     this.pass.setText("");
/*     */   }
/*     */ 
/*     */   
/*     */   private void passMouseClicked(MouseEvent evt) {
/* 335 */     this.pass.setText("");
/*     */   }
/*     */ 
/*     */   
/*     */   private void unameKeyPressed(KeyEvent evt) {
/* 340 */     if (evt.getKeyCode() == 10) {
/* 341 */       this.pass.setText("");
/* 342 */       this.pass.requestFocus();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void jPanel3MouseClicked(MouseEvent evt) {}
/*     */ 
/*     */   
/*     */   private void jPanel3MouseDragged(MouseEvent evt) {
/* 352 */     int x = evt.getXOnScreen();
/* 353 */     int y = evt.getYOnScreen();
/* 354 */     setLocation(x - this.xMouse, y - this.yMouse);
/*     */   }
/*     */ 
/*     */   
/*     */   private void jPanel3MousePressed(MouseEvent evt) {
/* 359 */     this.xMouse = evt.getX();
/* 360 */     this.yMouse = evt.getY();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\front_end\login.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */