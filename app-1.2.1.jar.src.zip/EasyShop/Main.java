/*    */ package EasyShop;
/*    */ 
/*    */ import EasyShop.front_end.login;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.PrintStream;
/*    */ import java.time.LocalDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */ {
/*    */   private static PrintStream out;
/*    */   
/*    */   public static void main(String[] args) {
/* 23 */     DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd- HH-mm-ss");
/* 24 */     LocalDateTime now = LocalDateTime.now();
/*    */     try {
/* 26 */       out = new PrintStream("bin/logs/log" + dtf.format(now).toString() + ".txt");
/* 27 */       System.setOut(out);
/* 28 */       System.out.println("******************************************************************************************************");
/* 29 */       System.out.println("New Log  Dated " + dtf.format(now));
/* 30 */       System.out.println("******************************************************************************************************");
/* 31 */       System.out.println("Internet Connection ");
/* 32 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 33 */         if ("Windows".equals(info.getName())) {
/* 34 */           UIManager.setLookAndFeel(info.getClassName());
/*    */           break;
/*    */         } 
/*    */       } 
/* 38 */     } catch (FileNotFoundException|ClassNotFoundException|InstantiationException|IllegalAccessException|javax.swing.UnsupportedLookAndFeelException ex) {
/* 39 */       System.out.println("Error during init process Error Details are as following ");
/* 40 */       System.out.println("Error occured in " + ex.getClass());
/* 41 */       System.out.println("Error Cause " + ex.getCause());
/* 42 */       System.out.println("Error Details " + ex.toString());
/*    */     } 
/*    */     try {
/* 45 */       (new login()).setVisible(true);
/* 46 */     } catch (Exception e) {
/* 47 */       System.out.println("Un handled Exception -->");
/* 48 */       System.out.println("Error Cause " + e.getCause());
/* 49 */       System.out.println("Error Details " + e.toString());
/* 50 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\EasyShop\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */