/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.JsonStringEncoder;
/*     */ import java.lang.ref.SoftReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferRecyclers
/*     */ {
/*     */   public static final String SYSTEM_PROPERTY_TRACK_REUSABLE_BUFFERS = "com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers";
/*  39 */   private static final ThreadLocalBufferManager _bufferRecyclerTracker = "true".equals(System.getProperty("com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers")) ? 
/*  40 */     ThreadLocalBufferManager.instance() : null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   protected static final ThreadLocal<SoftReference<BufferRecycler>> _recyclerRef = new ThreadLocal<SoftReference<BufferRecycler>>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferRecycler getBufferRecycler() {
/*  63 */     SoftReference<BufferRecycler> ref = _recyclerRef.get();
/*  64 */     BufferRecycler br = (ref == null) ? null : ref.get();
/*     */     
/*  66 */     if (br == null) {
/*  67 */       br = new BufferRecycler();
/*  68 */       if (_bufferRecyclerTracker != null) {
/*  69 */         ref = _bufferRecyclerTracker.wrapAndTrack(br);
/*     */       } else {
/*  71 */         ref = new SoftReference<BufferRecycler>(br);
/*     */       } 
/*  73 */       _recyclerRef.set(ref);
/*     */     } 
/*  75 */     return br;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int releaseBuffers() {
/*  92 */     if (_bufferRecyclerTracker != null) {
/*  93 */       return _bufferRecyclerTracker.releaseBuffers();
/*     */     }
/*  95 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   protected static final ThreadLocal<SoftReference<JsonStringEncoder>> _encoderRef = new ThreadLocal<SoftReference<JsonStringEncoder>>();
/*     */ 
/*     */   
/*     */   public static JsonStringEncoder getJsonStringEncoder() {
/* 113 */     SoftReference<JsonStringEncoder> ref = _encoderRef.get();
/* 114 */     JsonStringEncoder enc = (ref == null) ? null : ref.get();
/*     */     
/* 116 */     if (enc == null) {
/* 117 */       enc = new JsonStringEncoder();
/* 118 */       _encoderRef.set(new SoftReference<JsonStringEncoder>(enc));
/*     */     } 
/* 120 */     return enc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeAsUTF8(String text) {
/* 129 */     return getJsonStringEncoder().encodeAsUTF8(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] quoteAsJsonText(String rawText) {
/* 136 */     return getJsonStringEncoder().quoteAsString(rawText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void quoteAsJsonText(CharSequence input, StringBuilder output) {
/* 143 */     getJsonStringEncoder().quoteAsString(input, output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] quoteAsJsonUTF8(String rawText) {
/* 150 */     return getJsonStringEncoder().quoteAsUTF8(rawText);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\cor\\util\BufferRecyclers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */