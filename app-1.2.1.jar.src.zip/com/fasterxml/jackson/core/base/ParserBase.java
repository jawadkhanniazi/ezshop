/*      */ package com.fasterxml.jackson.core.base;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.core.json.DupDetector;
/*      */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ParserBase
/*      */   extends ParserMinimalBase
/*      */ {
/*      */   protected final IOContext _ioContext;
/*      */   protected boolean _closed;
/*      */   protected int _inputPtr;
/*      */   protected int _inputEnd;
/*      */   protected long _currInputProcessed;
/*   77 */   protected int _currInputRow = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _currInputRowStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _tokenInputTotal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   protected int _tokenInputRow = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _tokenInputCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonReadContext _parsingContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _nextToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TextBuffer _textBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _nameCopyBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _nameCopied;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ByteArrayBuilder _byteArrayBuilder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _binaryValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  181 */   protected int _numTypesValid = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _numberInt;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _numberLong;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double _numberDouble;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigInteger _numberBigInt;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal _numberBigDecimal;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _numberNegative;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _intLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _fractLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _expLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ParserBase(IOContext ctxt, int features) {
/*  232 */     super(features);
/*  233 */     this._ioContext = ctxt;
/*  234 */     this._textBuffer = ctxt.constructTextBuffer();
/*      */     
/*  236 */     DupDetector dups = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(features) ? DupDetector.rootDetector(this) : null;
/*  237 */     this._parsingContext = JsonReadContext.createRootContext(dups);
/*      */   }
/*      */   public Version version() {
/*  240 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */   public Object getCurrentValue() {
/*  244 */     return this._parsingContext.getCurrentValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCurrentValue(Object v) {
/*  249 */     this._parsingContext.setCurrentValue(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser enable(JsonParser.Feature f) {
/*  260 */     this._features |= f.getMask();
/*  261 */     if (f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION && 
/*  262 */       this._parsingContext.getDupDetector() == null) {
/*  263 */       this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */     }
/*      */     
/*  266 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser disable(JsonParser.Feature f) {
/*  271 */     this._features &= f.getMask() ^ 0xFFFFFFFF;
/*  272 */     if (f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION) {
/*  273 */       this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */     }
/*  275 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser setFeatureMask(int newMask) {
/*  281 */     int changes = this._features ^ newMask;
/*  282 */     if (changes != 0) {
/*  283 */       this._features = newMask;
/*  284 */       _checkStdFeatureChanges(newMask, changes);
/*      */     } 
/*  286 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser overrideStdFeatures(int values, int mask) {
/*  291 */     int oldState = this._features;
/*  292 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  293 */     int changed = oldState ^ newState;
/*  294 */     if (changed != 0) {
/*  295 */       this._features = newState;
/*  296 */       _checkStdFeatureChanges(newState, changed);
/*      */     } 
/*  298 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkStdFeatureChanges(int newFeatureFlags, int changedFeatures) {
/*  312 */     int f = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.getMask();
/*      */     
/*  314 */     if ((changedFeatures & f) != 0 && (
/*  315 */       newFeatureFlags & f) != 0) {
/*  316 */       if (this._parsingContext.getDupDetector() == null) {
/*  317 */         this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */       } else {
/*  319 */         this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCurrentName() throws IOException {
/*  337 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  338 */       JsonReadContext parent = this._parsingContext.getParent();
/*  339 */       if (parent != null) {
/*  340 */         return parent.getCurrentName();
/*      */       }
/*      */     } 
/*  343 */     return this._parsingContext.getCurrentName();
/*      */   }
/*      */ 
/*      */   
/*      */   public void overrideCurrentName(String name) {
/*  348 */     JsonReadContext ctxt = this._parsingContext;
/*  349 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  350 */       ctxt = ctxt.getParent();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  356 */       ctxt.setCurrentName(name);
/*  357 */     } catch (IOException e) {
/*  358 */       throw new IllegalStateException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void close() throws IOException {
/*  363 */     if (!this._closed) {
/*      */       
/*  365 */       this._inputPtr = Math.max(this._inputPtr, this._inputEnd);
/*  366 */       this._closed = true;
/*      */       try {
/*  368 */         _closeInput();
/*      */       }
/*      */       finally {
/*      */         
/*  372 */         _releaseBuffers();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*  377 */   public boolean isClosed() { return this._closed; } public JsonReadContext getParsingContext() {
/*  378 */     return this._parsingContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/*  387 */     return new JsonLocation(_getSourceReference(), -1L, 
/*  388 */         getTokenCharacterOffset(), 
/*  389 */         getTokenLineNr(), 
/*  390 */         getTokenColumnNr());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/*  399 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*  400 */     return new JsonLocation(_getSourceReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasTextCharacters() {
/*  413 */     if (this._currToken == JsonToken.VALUE_STRING) return true; 
/*  414 */     if (this._currToken == JsonToken.FIELD_NAME) return this._nameCopied; 
/*  415 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant variant) throws IOException {
/*  422 */     if (this._binaryValue == null) {
/*  423 */       if (this._currToken != JsonToken.VALUE_STRING) {
/*  424 */         _reportError("Current token (" + this._currToken + ") not VALUE_STRING, can not access as binary");
/*      */       }
/*  426 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  427 */       _decodeBase64(getText(), builder, variant);
/*  428 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*  430 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTokenCharacterOffset() {
/*  439 */     return this._tokenInputTotal; } public int getTokenLineNr() {
/*  440 */     return this._tokenInputRow;
/*      */   }
/*      */   public int getTokenColumnNr() {
/*  443 */     int col = this._tokenInputCol;
/*  444 */     return (col < 0) ? col : (col + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  468 */     this._textBuffer.releaseBuffers();
/*  469 */     char[] buf = this._nameCopyBuffer;
/*  470 */     if (buf != null) {
/*  471 */       this._nameCopyBuffer = null;
/*  472 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleEOF() throws JsonParseException {
/*  483 */     if (!this._parsingContext.inRoot()) {
/*  484 */       String marker = this._parsingContext.inArray() ? "Array" : "Object";
/*  485 */       _reportInvalidEOF(String.format(": expected close marker for %s (start marker at %s)", new Object[] { marker, this._parsingContext
/*      */ 
/*      */               
/*  488 */               .getStartLocation(_getSourceReference()) }), (JsonToken)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _eofAsNextChar() throws JsonParseException {
/*  497 */     _handleEOF();
/*  498 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayBuilder _getByteArrayBuilder() {
/*  509 */     if (this._byteArrayBuilder == null) {
/*  510 */       this._byteArrayBuilder = new ByteArrayBuilder();
/*      */     } else {
/*  512 */       this._byteArrayBuilder.reset();
/*      */     } 
/*  514 */     return this._byteArrayBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken reset(boolean negative, int intLen, int fractLen, int expLen) {
/*  527 */     if (fractLen < 1 && expLen < 1) {
/*  528 */       return resetInt(negative, intLen);
/*      */     }
/*  530 */     return resetFloat(negative, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken resetInt(boolean negative, int intLen) {
/*  535 */     this._numberNegative = negative;
/*  536 */     this._intLength = intLen;
/*  537 */     this._fractLength = 0;
/*  538 */     this._expLength = 0;
/*  539 */     this._numTypesValid = 0;
/*  540 */     return JsonToken.VALUE_NUMBER_INT;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken resetFloat(boolean negative, int intLen, int fractLen, int expLen) {
/*  545 */     this._numberNegative = negative;
/*  546 */     this._intLength = intLen;
/*  547 */     this._fractLength = fractLen;
/*  548 */     this._expLength = expLen;
/*  549 */     this._numTypesValid = 0;
/*  550 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken resetAsNaN(String valueStr, double value) {
/*  555 */     this._textBuffer.resetWithString(valueStr);
/*  556 */     this._numberDouble = value;
/*  557 */     this._numTypesValid = 8;
/*  558 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNaN() {
/*  563 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT && (
/*  564 */       this._numTypesValid & 0x8) != 0) {
/*      */       
/*  566 */       double d = this._numberDouble;
/*  567 */       return (Double.isNaN(d) || Double.isInfinite(d));
/*      */     } 
/*      */     
/*  570 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number getNumberValue() throws IOException {
/*  582 */     if (this._numTypesValid == 0) {
/*  583 */       _parseNumericValue(0);
/*      */     }
/*      */     
/*  586 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  587 */       if ((this._numTypesValid & 0x1) != 0) {
/*  588 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  590 */       if ((this._numTypesValid & 0x2) != 0) {
/*  591 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  593 */       if ((this._numTypesValid & 0x4) != 0) {
/*  594 */         return this._numberBigInt;
/*      */       }
/*      */       
/*  597 */       return this._numberBigDecimal;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  603 */     if ((this._numTypesValid & 0x10) != 0) {
/*  604 */       return this._numberBigDecimal;
/*      */     }
/*  606 */     if ((this._numTypesValid & 0x8) == 0) {
/*  607 */       _throwInternal();
/*      */     }
/*  609 */     return Double.valueOf(this._numberDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser.NumberType getNumberType() throws IOException {
/*  615 */     if (this._numTypesValid == 0) {
/*  616 */       _parseNumericValue(0);
/*      */     }
/*  618 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  619 */       if ((this._numTypesValid & 0x1) != 0) {
/*  620 */         return JsonParser.NumberType.INT;
/*      */       }
/*  622 */       if ((this._numTypesValid & 0x2) != 0) {
/*  623 */         return JsonParser.NumberType.LONG;
/*      */       }
/*  625 */       return JsonParser.NumberType.BIG_INTEGER;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  634 */     if ((this._numTypesValid & 0x10) != 0) {
/*  635 */       return JsonParser.NumberType.BIG_DECIMAL;
/*      */     }
/*  637 */     return JsonParser.NumberType.DOUBLE;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntValue() throws IOException {
/*  643 */     if ((this._numTypesValid & 0x1) == 0) {
/*  644 */       if (this._numTypesValid == 0) {
/*  645 */         return _parseIntValue();
/*      */       }
/*  647 */       if ((this._numTypesValid & 0x1) == 0) {
/*  648 */         convertNumberToInt();
/*      */       }
/*      */     } 
/*  651 */     return this._numberInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongValue() throws IOException {
/*  657 */     if ((this._numTypesValid & 0x2) == 0) {
/*  658 */       if (this._numTypesValid == 0) {
/*  659 */         _parseNumericValue(2);
/*      */       }
/*  661 */       if ((this._numTypesValid & 0x2) == 0) {
/*  662 */         convertNumberToLong();
/*      */       }
/*      */     } 
/*  665 */     return this._numberLong;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getBigIntegerValue() throws IOException {
/*  671 */     if ((this._numTypesValid & 0x4) == 0) {
/*  672 */       if (this._numTypesValid == 0) {
/*  673 */         _parseNumericValue(4);
/*      */       }
/*  675 */       if ((this._numTypesValid & 0x4) == 0) {
/*  676 */         convertNumberToBigInteger();
/*      */       }
/*      */     } 
/*  679 */     return this._numberBigInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloatValue() throws IOException {
/*  685 */     double value = getDoubleValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  694 */     return (float)value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDoubleValue() throws IOException {
/*  700 */     if ((this._numTypesValid & 0x8) == 0) {
/*  701 */       if (this._numTypesValid == 0) {
/*  702 */         _parseNumericValue(8);
/*      */       }
/*  704 */       if ((this._numTypesValid & 0x8) == 0) {
/*  705 */         convertNumberToDouble();
/*      */       }
/*      */     } 
/*  708 */     return this._numberDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getDecimalValue() throws IOException {
/*  714 */     if ((this._numTypesValid & 0x10) == 0) {
/*  715 */       if (this._numTypesValid == 0) {
/*  716 */         _parseNumericValue(16);
/*      */       }
/*  718 */       if ((this._numTypesValid & 0x10) == 0) {
/*  719 */         convertNumberToBigDecimal();
/*      */       }
/*      */     } 
/*  722 */     return this._numberBigDecimal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _parseNumericValue(int expType) throws IOException {
/*  743 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  744 */       int len = this._intLength;
/*      */       
/*  746 */       if (len <= 9) {
/*  747 */         int i = this._textBuffer.contentsAsInt(this._numberNegative);
/*  748 */         this._numberInt = i;
/*  749 */         this._numTypesValid = 1;
/*      */         return;
/*      */       } 
/*  752 */       if (len <= 18) {
/*  753 */         long l = this._textBuffer.contentsAsLong(this._numberNegative);
/*      */         
/*  755 */         if (len == 10) {
/*  756 */           if (this._numberNegative) {
/*  757 */             if (l >= -2147483648L) {
/*  758 */               this._numberInt = (int)l;
/*  759 */               this._numTypesValid = 1;
/*      */               
/*      */               return;
/*      */             } 
/*  763 */           } else if (l <= 2147483647L) {
/*  764 */             this._numberInt = (int)l;
/*  765 */             this._numTypesValid = 1;
/*      */             
/*      */             return;
/*      */           } 
/*      */         }
/*  770 */         this._numberLong = l;
/*  771 */         this._numTypesValid = 2;
/*      */         return;
/*      */       } 
/*  774 */       _parseSlowInt(expType);
/*      */       return;
/*      */     } 
/*  777 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/*  778 */       _parseSlowFloat(expType);
/*      */       return;
/*      */     } 
/*  781 */     _reportError("Current token (%s) not numeric, can not use numeric value accessors", this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _parseIntValue() throws IOException {
/*  790 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT && 
/*  791 */       this._intLength <= 9) {
/*  792 */       int i = this._textBuffer.contentsAsInt(this._numberNegative);
/*  793 */       this._numberInt = i;
/*  794 */       this._numTypesValid = 1;
/*  795 */       return i;
/*      */     } 
/*      */ 
/*      */     
/*  799 */     _parseNumericValue(1);
/*  800 */     if ((this._numTypesValid & 0x1) == 0) {
/*  801 */       convertNumberToInt();
/*      */     }
/*  803 */     return this._numberInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _parseSlowFloat(int expType) throws IOException {
/*      */     try {
/*  816 */       if (expType == 16) {
/*  817 */         this._numberBigDecimal = this._textBuffer.contentsAsDecimal();
/*  818 */         this._numTypesValid = 16;
/*      */       } else {
/*      */         
/*  821 */         this._numberDouble = this._textBuffer.contentsAsDouble();
/*  822 */         this._numTypesValid = 8;
/*      */       } 
/*  824 */     } catch (NumberFormatException nex) {
/*      */       
/*  826 */       _wrapError("Malformed numeric value (" + _longNumberDesc(this._textBuffer.contentsAsString()) + ")", nex);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _parseSlowInt(int expType) throws IOException {
/*  832 */     String numStr = this._textBuffer.contentsAsString();
/*      */     try {
/*  834 */       int len = this._intLength;
/*  835 */       char[] buf = this._textBuffer.getTextBuffer();
/*  836 */       int offset = this._textBuffer.getTextOffset();
/*  837 */       if (this._numberNegative) {
/*  838 */         offset++;
/*      */       }
/*      */       
/*  841 */       if (NumberInput.inLongRange(buf, offset, len, this._numberNegative)) {
/*      */         
/*  843 */         this._numberLong = Long.parseLong(numStr);
/*  844 */         this._numTypesValid = 2;
/*      */       } else {
/*      */         
/*  847 */         if (expType == 1 || expType == 2) {
/*  848 */           _reportTooLongInt(expType, numStr);
/*      */         }
/*  850 */         if (expType == 8 || expType == 32) {
/*  851 */           this._numberDouble = NumberInput.parseDouble(numStr);
/*  852 */           this._numTypesValid = 8;
/*      */         } else {
/*      */           
/*  855 */           this._numberBigInt = new BigInteger(numStr);
/*  856 */           this._numTypesValid = 4;
/*      */         } 
/*      */       } 
/*  859 */     } catch (NumberFormatException nex) {
/*      */       
/*  861 */       _wrapError("Malformed numeric value (" + _longNumberDesc(numStr) + ")", nex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportTooLongInt(int expType, String rawNum) throws IOException {
/*  868 */     String numDesc = _longIntegerDesc(rawNum);
/*  869 */     _reportError("Numeric value (%s) out of range of %s", numDesc, (expType == 2) ? "long" : "int");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToInt() throws IOException {
/*  882 */     if ((this._numTypesValid & 0x2) != 0) {
/*      */       
/*  884 */       int result = (int)this._numberLong;
/*  885 */       if (result != this._numberLong) {
/*  886 */         _reportError("Numeric value (" + getText() + ") out of range of int");
/*      */       }
/*  888 */       this._numberInt = result;
/*  889 */     } else if ((this._numTypesValid & 0x4) != 0) {
/*  890 */       if (BI_MIN_INT.compareTo(this._numberBigInt) > 0 || BI_MAX_INT
/*  891 */         .compareTo(this._numberBigInt) < 0) {
/*  892 */         reportOverflowInt();
/*      */       }
/*  894 */       this._numberInt = this._numberBigInt.intValue();
/*  895 */     } else if ((this._numTypesValid & 0x8) != 0) {
/*      */       
/*  897 */       if (this._numberDouble < -2.147483648E9D || this._numberDouble > 2.147483647E9D) {
/*  898 */         reportOverflowInt();
/*      */       }
/*  900 */       this._numberInt = (int)this._numberDouble;
/*  901 */     } else if ((this._numTypesValid & 0x10) != 0) {
/*  902 */       if (BD_MIN_INT.compareTo(this._numberBigDecimal) > 0 || BD_MAX_INT
/*  903 */         .compareTo(this._numberBigDecimal) < 0) {
/*  904 */         reportOverflowInt();
/*      */       }
/*  906 */       this._numberInt = this._numberBigDecimal.intValue();
/*      */     } else {
/*  908 */       _throwInternal();
/*      */     } 
/*  910 */     this._numTypesValid |= 0x1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertNumberToLong() throws IOException {
/*  915 */     if ((this._numTypesValid & 0x1) != 0) {
/*  916 */       this._numberLong = this._numberInt;
/*  917 */     } else if ((this._numTypesValid & 0x4) != 0) {
/*  918 */       if (BI_MIN_LONG.compareTo(this._numberBigInt) > 0 || BI_MAX_LONG
/*  919 */         .compareTo(this._numberBigInt) < 0) {
/*  920 */         reportOverflowLong();
/*      */       }
/*  922 */       this._numberLong = this._numberBigInt.longValue();
/*  923 */     } else if ((this._numTypesValid & 0x8) != 0) {
/*      */       
/*  925 */       if (this._numberDouble < -9.223372036854776E18D || this._numberDouble > 9.223372036854776E18D) {
/*  926 */         reportOverflowLong();
/*      */       }
/*  928 */       this._numberLong = (long)this._numberDouble;
/*  929 */     } else if ((this._numTypesValid & 0x10) != 0) {
/*  930 */       if (BD_MIN_LONG.compareTo(this._numberBigDecimal) > 0 || BD_MAX_LONG
/*  931 */         .compareTo(this._numberBigDecimal) < 0) {
/*  932 */         reportOverflowLong();
/*      */       }
/*  934 */       this._numberLong = this._numberBigDecimal.longValue();
/*      */     } else {
/*  936 */       _throwInternal();
/*      */     } 
/*  938 */     this._numTypesValid |= 0x2;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertNumberToBigInteger() throws IOException {
/*  943 */     if ((this._numTypesValid & 0x10) != 0) {
/*      */       
/*  945 */       this._numberBigInt = this._numberBigDecimal.toBigInteger();
/*  946 */     } else if ((this._numTypesValid & 0x2) != 0) {
/*  947 */       this._numberBigInt = BigInteger.valueOf(this._numberLong);
/*  948 */     } else if ((this._numTypesValid & 0x1) != 0) {
/*  949 */       this._numberBigInt = BigInteger.valueOf(this._numberInt);
/*  950 */     } else if ((this._numTypesValid & 0x8) != 0) {
/*  951 */       this._numberBigInt = BigDecimal.valueOf(this._numberDouble).toBigInteger();
/*      */     } else {
/*  953 */       _throwInternal();
/*      */     } 
/*  955 */     this._numTypesValid |= 0x4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToDouble() throws IOException {
/*  966 */     if ((this._numTypesValid & 0x10) != 0) {
/*  967 */       this._numberDouble = this._numberBigDecimal.doubleValue();
/*  968 */     } else if ((this._numTypesValid & 0x4) != 0) {
/*  969 */       this._numberDouble = this._numberBigInt.doubleValue();
/*  970 */     } else if ((this._numTypesValid & 0x2) != 0) {
/*  971 */       this._numberDouble = this._numberLong;
/*  972 */     } else if ((this._numTypesValid & 0x1) != 0) {
/*  973 */       this._numberDouble = this._numberInt;
/*      */     } else {
/*  975 */       _throwInternal();
/*      */     } 
/*  977 */     this._numTypesValid |= 0x8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToBigDecimal() throws IOException {
/*  988 */     if ((this._numTypesValid & 0x8) != 0) {
/*      */ 
/*      */ 
/*      */       
/*  992 */       this._numberBigDecimal = NumberInput.parseBigDecimal(getText());
/*  993 */     } else if ((this._numTypesValid & 0x4) != 0) {
/*  994 */       this._numberBigDecimal = new BigDecimal(this._numberBigInt);
/*  995 */     } else if ((this._numTypesValid & 0x2) != 0) {
/*  996 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberLong);
/*  997 */     } else if ((this._numTypesValid & 0x1) != 0) {
/*  998 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberInt);
/*      */     } else {
/* 1000 */       _throwInternal();
/*      */     } 
/* 1002 */     this._numTypesValid |= 0x10;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportMismatchedEndMarker(int actCh, char expCh) throws JsonParseException {
/* 1012 */     JsonReadContext ctxt = getParsingContext();
/* 1013 */     _reportError(String.format("Unexpected close marker '%s': expected '%c' (for %s starting at %s)", new Object[] {
/*      */             
/* 1015 */             Character.valueOf((char)actCh), Character.valueOf(expCh), ctxt.typeDesc(), ctxt.getStartLocation(_getSourceReference())
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 1030 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, int ch, int index) throws IOException {
/* 1036 */     if (ch != 92) {
/* 1037 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1039 */     int unescaped = _decodeEscaped();
/*      */     
/* 1041 */     if (unescaped <= 32 && 
/* 1042 */       index == 0) {
/* 1043 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 1047 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1048 */     if (bits < 0 && 
/* 1049 */       bits != -2) {
/* 1050 */       throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */     }
/*      */     
/* 1053 */     return bits;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, char ch, int index) throws IOException {
/* 1058 */     if (ch != '\\') {
/* 1059 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1061 */     char unescaped = _decodeEscaped();
/*      */     
/* 1063 */     if (unescaped <= ' ' && 
/* 1064 */       index == 0) {
/* 1065 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 1069 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1070 */     if (bits < 0)
/*      */     {
/* 1072 */       if (bits != -2 || index < 2) {
/* 1073 */         throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */       }
/*      */     }
/* 1076 */     return bits;
/*      */   }
/*      */   
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex) throws IllegalArgumentException {
/* 1080 */     return reportInvalidBase64Char(b64variant, ch, bindex, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex, String msg) throws IllegalArgumentException {
/*      */     String base;
/* 1089 */     if (ch <= 32) {
/* 1090 */       base = String.format("Illegal white space character (code 0x%s) as character #%d of 4-char base64 unit: can only used between units", new Object[] {
/* 1091 */             Integer.toHexString(ch), Integer.valueOf(bindex + 1) });
/* 1092 */     } else if (b64variant.usesPaddingChar(ch)) {
/* 1093 */       base = "Unexpected padding character ('" + b64variant.getPaddingChar() + "') as character #" + (bindex + 1) + " of 4-char base64 unit: padding only legal as 3rd or 4th character";
/* 1094 */     } else if (!Character.isDefined(ch) || Character.isISOControl(ch)) {
/*      */       
/* 1096 */       base = "Illegal character (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */     } else {
/* 1098 */       base = "Illegal character '" + (char)ch + "' (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */     } 
/* 1100 */     if (msg != null) {
/* 1101 */       base = base + ": " + msg;
/*      */     }
/* 1103 */     return new IllegalArgumentException(base);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleBase64MissingPadding(Base64Variant b64variant) throws IOException {
/* 1109 */     _reportError(b64variant.missingPaddingMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _getSourceReference() {
/* 1125 */     if (JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION.enabledIn(this._features)) {
/* 1126 */       return this._ioContext.getSourceReference();
/*      */     }
/* 1128 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected static int[] growArrayBy(int[] arr, int more) {
/* 1133 */     if (arr == null) {
/* 1134 */       return new int[more];
/*      */     }
/* 1136 */     return Arrays.copyOf(arr, arr.length + more);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void loadMoreGuaranteed() throws IOException {
/* 1148 */     if (!loadMore()) _reportInvalidEOF(); 
/*      */   }
/*      */   @Deprecated
/*      */   protected boolean loadMore() throws IOException {
/* 1152 */     return false;
/*      */   }
/*      */   
/*      */   protected void _finishString() throws IOException {}
/*      */   
/*      */   protected abstract void _closeInput() throws IOException;
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\core\base\ParserBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */