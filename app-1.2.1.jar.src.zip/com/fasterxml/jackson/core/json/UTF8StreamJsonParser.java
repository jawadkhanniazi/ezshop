/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ 
/*      */ public class UTF8StreamJsonParser
/*      */   extends ParserBase
/*      */ {
/*      */   static final byte BYTE_LF = 10;
/*   24 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   28 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */   
/*   30 */   protected static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   59 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartRow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream _inputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, boolean bufferRecyclable) {
/*  134 */     super(ctxt, features);
/*  135 */     this._inputStream = in;
/*  136 */     this._objectCodec = codec;
/*  137 */     this._symbols = sym;
/*  138 */     this._inputBuffer = inputBuffer;
/*  139 */     this._inputPtr = start;
/*  140 */     this._inputEnd = end;
/*  141 */     this._currInputRowStart = start;
/*      */     
/*  143 */     this._currInputProcessed = -start;
/*  144 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  149 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodec(ObjectCodec c) {
/*  154 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  166 */     int count = this._inputEnd - this._inputPtr;
/*  167 */     if (count < 1) {
/*  168 */       return 0;
/*      */     }
/*      */     
/*  171 */     int origPtr = this._inputPtr;
/*  172 */     out.write(this._inputBuffer, origPtr, count);
/*  173 */     return count;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  178 */     return this._inputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _loadMore() throws IOException {
/*  189 */     int bufSize = this._inputEnd;
/*      */     
/*  191 */     this._currInputProcessed += this._inputEnd;
/*  192 */     this._currInputRowStart -= this._inputEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  197 */     this._nameStartOffset -= bufSize;
/*      */     
/*  199 */     if (this._inputStream != null) {
/*  200 */       int space = this._inputBuffer.length;
/*  201 */       if (space == 0) {
/*  202 */         return false;
/*      */       }
/*      */       
/*  205 */       int count = this._inputStream.read(this._inputBuffer, 0, space);
/*  206 */       if (count > 0) {
/*  207 */         this._inputPtr = 0;
/*  208 */         this._inputEnd = count;
/*  209 */         return true;
/*      */       } 
/*      */       
/*  212 */       _closeInput();
/*      */       
/*  214 */       if (count == 0) {
/*  215 */         throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
/*      */       }
/*      */     } 
/*  218 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {
/*  226 */     if (this._inputStream != null) {
/*  227 */       if (this._ioContext.isResourceManaged() || isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
/*  228 */         this._inputStream.close();
/*      */       }
/*  230 */       this._inputStream = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  243 */     super._releaseBuffers();
/*      */     
/*  245 */     this._symbols.release();
/*  246 */     if (this._bufferRecyclable) {
/*  247 */       byte[] buf = this._inputBuffer;
/*  248 */       if (buf != null) {
/*      */ 
/*      */         
/*  251 */         this._inputBuffer = NO_BYTES;
/*  252 */         this._ioContext.releaseReadIOBuffer(buf);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  266 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  267 */       if (this._tokenIncomplete) {
/*  268 */         this._tokenIncomplete = false;
/*  269 */         return _finishAndReturnString();
/*      */       } 
/*  271 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  273 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  279 */     JsonToken t = this._currToken;
/*  280 */     if (t == JsonToken.VALUE_STRING) {
/*  281 */       if (this._tokenIncomplete) {
/*  282 */         this._tokenIncomplete = false;
/*  283 */         _finishString();
/*      */       } 
/*  285 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  287 */     if (t == JsonToken.FIELD_NAME) {
/*  288 */       String n = this._parsingContext.getCurrentName();
/*  289 */       writer.write(n);
/*  290 */       return n.length();
/*      */     } 
/*  292 */     if (t != null) {
/*  293 */       if (t.isNumeric()) {
/*  294 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  296 */       char[] ch = t.asCharArray();
/*  297 */       writer.write(ch);
/*  298 */       return ch.length;
/*      */     } 
/*  300 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  309 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  310 */       if (this._tokenIncomplete) {
/*  311 */         this._tokenIncomplete = false;
/*  312 */         return _finishAndReturnString();
/*      */       } 
/*  314 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  316 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  317 */       return getCurrentName();
/*      */     }
/*  319 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  326 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  327 */       if (this._tokenIncomplete) {
/*  328 */         this._tokenIncomplete = false;
/*  329 */         return _finishAndReturnString();
/*      */       } 
/*  331 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  333 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  334 */       return getCurrentName();
/*      */     }
/*  336 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  343 */     JsonToken t = this._currToken;
/*  344 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  346 */       if ((this._numTypesValid & 0x1) == 0) {
/*  347 */         if (this._numTypesValid == 0) {
/*  348 */           return _parseIntValue();
/*      */         }
/*  350 */         if ((this._numTypesValid & 0x1) == 0) {
/*  351 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  354 */       return this._numberInt;
/*      */     } 
/*  356 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  363 */     JsonToken t = this._currToken;
/*  364 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  366 */       if ((this._numTypesValid & 0x1) == 0) {
/*  367 */         if (this._numTypesValid == 0) {
/*  368 */           return _parseIntValue();
/*      */         }
/*  370 */         if ((this._numTypesValid & 0x1) == 0) {
/*  371 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  374 */       return this._numberInt;
/*      */     } 
/*  376 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  381 */     if (t == null) {
/*  382 */       return null;
/*      */     }
/*  384 */     switch (t.id()) {
/*      */       case 5:
/*  386 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  392 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  394 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  401 */     if (this._currToken != null) {
/*  402 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  405 */           if (!this._nameCopied) {
/*  406 */             String name = this._parsingContext.getCurrentName();
/*  407 */             int nameLen = name.length();
/*  408 */             if (this._nameCopyBuffer == null) {
/*  409 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  410 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  411 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  413 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  414 */             this._nameCopied = true;
/*      */           } 
/*  416 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  419 */           if (this._tokenIncomplete) {
/*  420 */             this._tokenIncomplete = false;
/*  421 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  426 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  429 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  432 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  438 */     if (this._currToken != null) {
/*  439 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  442 */           return this._parsingContext.getCurrentName().length();
/*      */         case 6:
/*  444 */           if (this._tokenIncomplete) {
/*  445 */             this._tokenIncomplete = false;
/*  446 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  451 */           return this._textBuffer.size();
/*      */       } 
/*      */       
/*  454 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*      */     
/*  457 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  464 */     if (this._currToken != null) {
/*  465 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  467 */           return 0;
/*      */         case 6:
/*  469 */           if (this._tokenIncomplete) {
/*  470 */             this._tokenIncomplete = false;
/*  471 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  476 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  480 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  486 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  488 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  491 */     if (this._tokenIncomplete) {
/*      */       try {
/*  493 */         this._binaryValue = _decodeBase64(b64variant);
/*  494 */       } catch (IllegalArgumentException iae) {
/*  495 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */       
/*  498 */       this._tokenIncomplete = false;
/*      */     }
/*  500 */     else if (this._binaryValue == null) {
/*      */       
/*  502 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  503 */       _decodeBase64(getText(), builder, b64variant);
/*  504 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  507 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  514 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  515 */       byte[] b = getBinaryValue(b64variant);
/*  516 */       out.write(b);
/*  517 */       return b.length;
/*      */     } 
/*      */     
/*  520 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  522 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  524 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  531 */     int outputPtr = 0;
/*  532 */     int outputEnd = buffer.length - 3;
/*  533 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  539 */       if (this._inputPtr >= this._inputEnd) {
/*  540 */         _loadMoreGuaranteed();
/*      */       }
/*  542 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  543 */       if (ch > 32) {
/*  544 */         int bits = b64variant.decodeBase64Char(ch);
/*  545 */         if (bits < 0) {
/*  546 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  549 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  550 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  556 */         if (outputPtr > outputEnd) {
/*  557 */           outputCount += outputPtr;
/*  558 */           out.write(buffer, 0, outputPtr);
/*  559 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  562 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/*  566 */         if (this._inputPtr >= this._inputEnd) {
/*  567 */           _loadMoreGuaranteed();
/*      */         }
/*  569 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  570 */         bits = b64variant.decodeBase64Char(ch);
/*  571 */         if (bits < 0) {
/*  572 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  574 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  577 */         if (this._inputPtr >= this._inputEnd) {
/*  578 */           _loadMoreGuaranteed();
/*      */         }
/*  580 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  581 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  584 */         if (bits < 0) {
/*  585 */           if (bits != -2) {
/*      */             
/*  587 */             if (ch == 34) {
/*  588 */               decodedData >>= 4;
/*  589 */               buffer[outputPtr++] = (byte)decodedData;
/*  590 */               if (b64variant.usesPadding()) {
/*  591 */                 this._inputPtr--;
/*  592 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  596 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  598 */           if (bits == -2) {
/*      */             
/*  600 */             if (this._inputPtr >= this._inputEnd) {
/*  601 */               _loadMoreGuaranteed();
/*      */             }
/*  603 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  604 */             if (!b64variant.usesPaddingChar(ch) && 
/*  605 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/*  606 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  610 */             decodedData >>= 4;
/*  611 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  616 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  618 */         if (this._inputPtr >= this._inputEnd) {
/*  619 */           _loadMoreGuaranteed();
/*      */         }
/*  621 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  622 */         bits = b64variant.decodeBase64Char(ch);
/*  623 */         if (bits < 0) {
/*  624 */           if (bits != -2) {
/*      */             
/*  626 */             if (ch == 34) {
/*  627 */               decodedData >>= 2;
/*  628 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  629 */               buffer[outputPtr++] = (byte)decodedData;
/*  630 */               if (b64variant.usesPadding()) {
/*  631 */                 this._inputPtr--;
/*  632 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  636 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  638 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  645 */             decodedData >>= 2;
/*  646 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  647 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  652 */         decodedData = decodedData << 6 | bits;
/*  653 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  654 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  655 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  657 */     }  this._tokenIncomplete = false;
/*  658 */     if (outputPtr > 0) {
/*  659 */       outputCount += outputPtr;
/*  660 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  662 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  682 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  683 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  687 */     this._numTypesValid = 0;
/*  688 */     if (this._tokenIncomplete) {
/*  689 */       _skipString();
/*      */     }
/*  691 */     int i = _skipWSOrEnd();
/*  692 */     if (i < 0) {
/*      */       
/*  694 */       close();
/*  695 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  698 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  701 */     if (i == 93) {
/*  702 */       _closeArrayScope();
/*  703 */       return this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/*  705 */     if (i == 125) {
/*  706 */       _closeObjectScope();
/*  707 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */ 
/*      */     
/*  711 */     if (this._parsingContext.expectComma()) {
/*  712 */       if (i != 44) {
/*  713 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  715 */       i = _skipWS();
/*      */       
/*  717 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  718 */         i == 93 || i == 125)) {
/*  719 */         return _closeScope(i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  727 */     if (!this._parsingContext.inObject()) {
/*  728 */       _updateLocation();
/*  729 */       return _nextTokenNotInObject(i);
/*      */     } 
/*      */     
/*  732 */     _updateNameLocation();
/*  733 */     String n = _parseName(i);
/*  734 */     this._parsingContext.setCurrentName(n);
/*  735 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  737 */     i = _skipColon();
/*  738 */     _updateLocation();
/*      */ 
/*      */     
/*  741 */     if (i == 34) {
/*  742 */       this._tokenIncomplete = true;
/*  743 */       this._nextToken = JsonToken.VALUE_STRING;
/*  744 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  748 */     switch (i)
/*      */     { case 45:
/*  750 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  789 */         this._nextToken = t;
/*  790 */         return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return this._currToken;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  795 */     if (i == 34) {
/*  796 */       this._tokenIncomplete = true;
/*  797 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/*  799 */     switch (i) {
/*      */       case 91:
/*  801 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  802 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/*  804 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  805 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/*  807 */         _matchTrue();
/*  808 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/*  810 */         _matchFalse();
/*  811 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/*  813 */         _matchNull();
/*  814 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/*  816 */         return this._currToken = _parseNegNumber();
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  830 */         return this._currToken = _parsePosNumber(i);
/*      */     } 
/*  832 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  837 */     this._nameCopied = false;
/*  838 */     JsonToken t = this._nextToken;
/*  839 */     this._nextToken = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  844 */     if (t == JsonToken.START_ARRAY) {
/*  845 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  846 */     } else if (t == JsonToken.START_OBJECT) {
/*  847 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  849 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  854 */     if (this._tokenIncomplete) {
/*  855 */       this._tokenIncomplete = false;
/*  856 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextFieldName(SerializableString str) throws IOException {
/*  870 */     this._numTypesValid = 0;
/*  871 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  872 */       _nextAfterName();
/*  873 */       return false;
/*      */     } 
/*  875 */     if (this._tokenIncomplete) {
/*  876 */       _skipString();
/*      */     }
/*  878 */     int i = _skipWSOrEnd();
/*  879 */     if (i < 0) {
/*  880 */       close();
/*  881 */       this._currToken = null;
/*  882 */       return false;
/*      */     } 
/*  884 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  887 */     if (i == 93) {
/*  888 */       _closeArrayScope();
/*  889 */       this._currToken = JsonToken.END_ARRAY;
/*  890 */       return false;
/*      */     } 
/*  892 */     if (i == 125) {
/*  893 */       _closeObjectScope();
/*  894 */       this._currToken = JsonToken.END_OBJECT;
/*  895 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  899 */     if (this._parsingContext.expectComma()) {
/*  900 */       if (i != 44) {
/*  901 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  903 */       i = _skipWS();
/*      */ 
/*      */       
/*  906 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  907 */         i == 93 || i == 125)) {
/*  908 */         _closeScope(i);
/*  909 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/*  913 */     if (!this._parsingContext.inObject()) {
/*  914 */       _updateLocation();
/*  915 */       _nextTokenNotInObject(i);
/*  916 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  920 */     _updateNameLocation();
/*  921 */     if (i == 34) {
/*      */       
/*  923 */       byte[] nameBytes = str.asQuotedUTF8();
/*  924 */       int len = nameBytes.length;
/*      */ 
/*      */       
/*  927 */       if (this._inputPtr + len + 4 < this._inputEnd) {
/*      */         
/*  929 */         int end = this._inputPtr + len;
/*  930 */         if (this._inputBuffer[end] == 34) {
/*  931 */           int offset = 0;
/*  932 */           int ptr = this._inputPtr;
/*      */           while (true) {
/*  934 */             if (ptr == end) {
/*  935 */               this._parsingContext.setCurrentName(str.getValue());
/*  936 */               i = _skipColonFast(ptr + 1);
/*  937 */               _isNextTokenNameYes(i);
/*  938 */               return true;
/*      */             } 
/*  940 */             if (nameBytes[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  943 */             offset++;
/*  944 */             ptr++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  949 */     return _isNextTokenNameMaybe(i, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  956 */     this._numTypesValid = 0;
/*  957 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  958 */       _nextAfterName();
/*  959 */       return null;
/*      */     } 
/*  961 */     if (this._tokenIncomplete) {
/*  962 */       _skipString();
/*      */     }
/*  964 */     int i = _skipWSOrEnd();
/*  965 */     if (i < 0) {
/*  966 */       close();
/*  967 */       this._currToken = null;
/*  968 */       return null;
/*      */     } 
/*  970 */     this._binaryValue = null;
/*      */     
/*  972 */     if (i == 93) {
/*  973 */       _closeArrayScope();
/*  974 */       this._currToken = JsonToken.END_ARRAY;
/*  975 */       return null;
/*      */     } 
/*  977 */     if (i == 125) {
/*  978 */       _closeObjectScope();
/*  979 */       this._currToken = JsonToken.END_OBJECT;
/*  980 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  984 */     if (this._parsingContext.expectComma()) {
/*  985 */       if (i != 44) {
/*  986 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  988 */       i = _skipWS();
/*      */       
/*  990 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  991 */         i == 93 || i == 125)) {
/*  992 */         _closeScope(i);
/*  993 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  998 */     if (!this._parsingContext.inObject()) {
/*  999 */       _updateLocation();
/* 1000 */       _nextTokenNotInObject(i);
/* 1001 */       return null;
/*      */     } 
/*      */     
/* 1004 */     _updateNameLocation();
/* 1005 */     String nameStr = _parseName(i);
/* 1006 */     this._parsingContext.setCurrentName(nameStr);
/* 1007 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/* 1009 */     i = _skipColon();
/* 1010 */     _updateLocation();
/* 1011 */     if (i == 34) {
/* 1012 */       this._tokenIncomplete = true;
/* 1013 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1014 */       return nameStr;
/*      */     } 
/*      */     
/* 1017 */     switch (i)
/*      */     { case 45:
/* 1019 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1055 */         this._nextToken = t;
/* 1056 */         return nameStr;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return nameStr;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipColonFast(int ptr) throws IOException {
/* 1062 */     int i = this._inputBuffer[ptr++];
/* 1063 */     if (i == 58) {
/* 1064 */       i = this._inputBuffer[ptr++];
/* 1065 */       if (i > 32) {
/* 1066 */         if (i != 47 && i != 35) {
/* 1067 */           this._inputPtr = ptr;
/* 1068 */           return i;
/*      */         } 
/* 1070 */       } else if (i == 32 || i == 9) {
/* 1071 */         i = this._inputBuffer[ptr++];
/* 1072 */         if (i > 32 && 
/* 1073 */           i != 47 && i != 35) {
/* 1074 */           this._inputPtr = ptr;
/* 1075 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1079 */       this._inputPtr = ptr - 1;
/* 1080 */       return _skipColon2(true);
/*      */     } 
/* 1082 */     if (i == 32 || i == 9) {
/* 1083 */       i = this._inputBuffer[ptr++];
/*      */     }
/* 1085 */     if (i == 58) {
/* 1086 */       i = this._inputBuffer[ptr++];
/* 1087 */       if (i > 32) {
/* 1088 */         if (i != 47 && i != 35) {
/* 1089 */           this._inputPtr = ptr;
/* 1090 */           return i;
/*      */         } 
/* 1092 */       } else if (i == 32 || i == 9) {
/* 1093 */         i = this._inputBuffer[ptr++];
/* 1094 */         if (i > 32 && 
/* 1095 */           i != 47 && i != 35) {
/* 1096 */           this._inputPtr = ptr;
/* 1097 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1101 */       this._inputPtr = ptr - 1;
/* 1102 */       return _skipColon2(true);
/*      */     } 
/* 1104 */     this._inputPtr = ptr - 1;
/* 1105 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException {
/* 1110 */     this._currToken = JsonToken.FIELD_NAME;
/* 1111 */     _updateLocation();
/*      */     
/* 1113 */     switch (i) {
/*      */       case 34:
/* 1115 */         this._tokenIncomplete = true;
/* 1116 */         this._nextToken = JsonToken.VALUE_STRING;
/*      */         return;
/*      */       case 91:
/* 1119 */         this._nextToken = JsonToken.START_ARRAY;
/*      */         return;
/*      */       case 123:
/* 1122 */         this._nextToken = JsonToken.START_OBJECT;
/*      */         return;
/*      */       case 116:
/* 1125 */         _matchTrue();
/* 1126 */         this._nextToken = JsonToken.VALUE_TRUE;
/*      */         return;
/*      */       case 102:
/* 1129 */         _matchFalse();
/* 1130 */         this._nextToken = JsonToken.VALUE_FALSE;
/*      */         return;
/*      */       case 110:
/* 1133 */         _matchNull();
/* 1134 */         this._nextToken = JsonToken.VALUE_NULL;
/*      */         return;
/*      */       case 45:
/* 1137 */         this._nextToken = _parseNegNumber();
/*      */         return;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1149 */         this._nextToken = _parsePosNumber(i);
/*      */         return;
/*      */     } 
/* 1152 */     this._nextToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _isNextTokenNameMaybe(int i, SerializableString str) throws IOException {
/* 1159 */     String n = _parseName(i);
/* 1160 */     this._parsingContext.setCurrentName(n);
/* 1161 */     boolean match = n.equals(str.getValue());
/* 1162 */     this._currToken = JsonToken.FIELD_NAME;
/* 1163 */     i = _skipColon();
/* 1164 */     _updateLocation();
/*      */ 
/*      */     
/* 1167 */     if (i == 34) {
/* 1168 */       this._tokenIncomplete = true;
/* 1169 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1170 */       return match;
/*      */     } 
/*      */ 
/*      */     
/* 1174 */     switch (i)
/*      */     { case 91:
/* 1176 */         t = JsonToken.START_ARRAY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1211 */         this._nextToken = t;
/* 1212 */         return match;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return match;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return match;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return match;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return match;case 45: t = _parseNegNumber(); this._nextToken = t; return match;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return match; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return match;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/* 1219 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1220 */       this._nameCopied = false;
/* 1221 */       JsonToken t = this._nextToken;
/* 1222 */       this._nextToken = null;
/* 1223 */       this._currToken = t;
/* 1224 */       if (t == JsonToken.VALUE_STRING) {
/* 1225 */         if (this._tokenIncomplete) {
/* 1226 */           this._tokenIncomplete = false;
/* 1227 */           return _finishAndReturnString();
/*      */         } 
/* 1229 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1231 */       if (t == JsonToken.START_ARRAY) {
/* 1232 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1233 */       } else if (t == JsonToken.START_OBJECT) {
/* 1234 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1236 */       return null;
/*      */     } 
/*      */     
/* 1239 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/* 1246 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1247 */       this._nameCopied = false;
/* 1248 */       JsonToken t = this._nextToken;
/* 1249 */       this._nextToken = null;
/* 1250 */       this._currToken = t;
/* 1251 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1252 */         return getIntValue();
/*      */       }
/* 1254 */       if (t == JsonToken.START_ARRAY) {
/* 1255 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1256 */       } else if (t == JsonToken.START_OBJECT) {
/* 1257 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1259 */       return defaultValue;
/*      */     } 
/*      */     
/* 1262 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/* 1269 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1270 */       this._nameCopied = false;
/* 1271 */       JsonToken t = this._nextToken;
/* 1272 */       this._nextToken = null;
/* 1273 */       this._currToken = t;
/* 1274 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1275 */         return getLongValue();
/*      */       }
/* 1277 */       if (t == JsonToken.START_ARRAY) {
/* 1278 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1279 */       } else if (t == JsonToken.START_OBJECT) {
/* 1280 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1282 */       return defaultValue;
/*      */     } 
/*      */     
/* 1285 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/* 1292 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1293 */       this._nameCopied = false;
/* 1294 */       JsonToken jsonToken = this._nextToken;
/* 1295 */       this._nextToken = null;
/* 1296 */       this._currToken = jsonToken;
/* 1297 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/* 1298 */         return Boolean.TRUE;
/*      */       }
/* 1300 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/* 1301 */         return Boolean.FALSE;
/*      */       }
/* 1303 */       if (jsonToken == JsonToken.START_ARRAY) {
/* 1304 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1305 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/* 1306 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1308 */       return null;
/*      */     } 
/*      */     
/* 1311 */     JsonToken t = nextToken();
/* 1312 */     if (t == JsonToken.VALUE_TRUE) {
/* 1313 */       return Boolean.TRUE;
/*      */     }
/* 1315 */     if (t == JsonToken.VALUE_FALSE) {
/* 1316 */       return Boolean.FALSE;
/*      */     }
/* 1318 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parsePosNumber(int c) throws IOException {
/* 1344 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/* 1346 */     if (c == 48) {
/* 1347 */       c = _verifyNoLeadingZeroes();
/*      */     }
/*      */     
/* 1350 */     outBuf[0] = (char)c;
/* 1351 */     int intLen = 1;
/* 1352 */     int outPtr = 1;
/*      */ 
/*      */     
/* 1355 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - 1);
/*      */     
/*      */     while (true) {
/* 1358 */       if (this._inputPtr >= end) {
/* 1359 */         return _parseNumber2(outBuf, outPtr, false, intLen);
/*      */       }
/* 1361 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1362 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1365 */       intLen++;
/* 1366 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1368 */     if (c == 46 || c == 101 || c == 69) {
/* 1369 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1371 */     this._inputPtr--;
/* 1372 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1374 */     if (this._parsingContext.inRoot()) {
/* 1375 */       _verifyRootSpace(c);
/*      */     }
/*      */     
/* 1378 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _parseNegNumber() throws IOException {
/* 1383 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1384 */     int outPtr = 0;
/*      */ 
/*      */     
/* 1387 */     outBuf[outPtr++] = '-';
/*      */     
/* 1389 */     if (this._inputPtr >= this._inputEnd) {
/* 1390 */       _loadMoreGuaranteed();
/*      */     }
/* 1392 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     
/* 1394 */     if (c <= 48) {
/*      */       
/* 1396 */       if (c != 48) {
/* 1397 */         return _handleInvalidNumberStart(c, true);
/*      */       }
/* 1399 */       c = _verifyNoLeadingZeroes();
/* 1400 */     } else if (c > 57) {
/* 1401 */       return _handleInvalidNumberStart(c, true);
/*      */     } 
/*      */ 
/*      */     
/* 1405 */     outBuf[outPtr++] = (char)c;
/* 1406 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/* 1410 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - outPtr);
/*      */     
/*      */     while (true) {
/* 1413 */       if (this._inputPtr >= end)
/*      */       {
/* 1415 */         return _parseNumber2(outBuf, outPtr, true, intLen);
/*      */       }
/* 1417 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1418 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1421 */       intLen++;
/* 1422 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1424 */     if (c == 46 || c == 101 || c == 69) {
/* 1425 */       return _parseFloat(outBuf, outPtr, c, true, intLen);
/*      */     }
/*      */     
/* 1428 */     this._inputPtr--;
/* 1429 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1431 */     if (this._parsingContext.inRoot()) {
/* 1432 */       _verifyRootSpace(c);
/*      */     }
/*      */ 
/*      */     
/* 1436 */     return resetInt(true, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseNumber2(char[] outBuf, int outPtr, boolean negative, int intPartLength) throws IOException {
/*      */     while (true) {
/* 1448 */       if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1449 */         this._textBuffer.setCurrentLength(outPtr);
/* 1450 */         return resetInt(negative, intPartLength);
/*      */       } 
/* 1452 */       int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1453 */       if (c > 57 || c < 48) {
/* 1454 */         if (c == 46 || c == 101 || c == 69) {
/* 1455 */           return _parseFloat(outBuf, outPtr, c, negative, intPartLength);
/*      */         }
/*      */         break;
/*      */       } 
/* 1459 */       if (outPtr >= outBuf.length) {
/* 1460 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1461 */         outPtr = 0;
/*      */       } 
/* 1463 */       outBuf[outPtr++] = (char)c;
/* 1464 */       intPartLength++;
/*      */     } 
/* 1466 */     this._inputPtr--;
/* 1467 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1469 */     if (this._parsingContext.inRoot()) {
/* 1470 */       _verifyRootSpace(this._inputBuffer[this._inputPtr] & 0xFF);
/*      */     }
/*      */ 
/*      */     
/* 1474 */     return resetInt(negative, intPartLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _verifyNoLeadingZeroes() throws IOException {
/* 1485 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1486 */       return 48;
/*      */     }
/* 1488 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     
/* 1490 */     if (ch < 48 || ch > 57) {
/* 1491 */       return 48;
/*      */     }
/*      */     
/* 1494 */     if (!isEnabled(JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS)) {
/* 1495 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1498 */     this._inputPtr++;
/* 1499 */     if (ch == 48) {
/* 1500 */       while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 1501 */         ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1502 */         if (ch < 48 || ch > 57) {
/* 1503 */           return 48;
/*      */         }
/* 1505 */         this._inputPtr++;
/* 1506 */         if (ch != 48) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1511 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1517 */     int fractLen = 0;
/* 1518 */     boolean eof = false;
/*      */ 
/*      */     
/* 1521 */     if (c == 46) {
/* 1522 */       if (outPtr >= outBuf.length) {
/* 1523 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1524 */         outPtr = 0;
/*      */       } 
/* 1526 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1530 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1531 */           eof = true;
/*      */           break;
/*      */         } 
/* 1534 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1535 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1538 */         fractLen++;
/* 1539 */         if (outPtr >= outBuf.length) {
/* 1540 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1541 */           outPtr = 0;
/*      */         } 
/* 1543 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1546 */       if (fractLen == 0) {
/* 1547 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1551 */     int expLen = 0;
/* 1552 */     if (c == 101 || c == 69) {
/* 1553 */       if (outPtr >= outBuf.length) {
/* 1554 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1555 */         outPtr = 0;
/*      */       } 
/* 1557 */       outBuf[outPtr++] = (char)c;
/*      */       
/* 1559 */       if (this._inputPtr >= this._inputEnd) {
/* 1560 */         _loadMoreGuaranteed();
/*      */       }
/* 1562 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 1564 */       if (c == 45 || c == 43) {
/* 1565 */         if (outPtr >= outBuf.length) {
/* 1566 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1567 */           outPtr = 0;
/*      */         } 
/* 1569 */         outBuf[outPtr++] = (char)c;
/*      */         
/* 1571 */         if (this._inputPtr >= this._inputEnd) {
/* 1572 */           _loadMoreGuaranteed();
/*      */         }
/* 1574 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */ 
/*      */       
/* 1578 */       while (c >= 48 && c <= 57) {
/* 1579 */         expLen++;
/* 1580 */         if (outPtr >= outBuf.length) {
/* 1581 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1582 */           outPtr = 0;
/*      */         } 
/* 1584 */         outBuf[outPtr++] = (char)c;
/* 1585 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1586 */           eof = true;
/*      */           break;
/*      */         } 
/* 1589 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */       
/* 1592 */       if (expLen == 0) {
/* 1593 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1598 */     if (!eof) {
/* 1599 */       this._inputPtr--;
/*      */       
/* 1601 */       if (this._parsingContext.inRoot()) {
/* 1602 */         _verifyRootSpace(c);
/*      */       }
/*      */     } 
/* 1605 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1608 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace(int ch) throws IOException {
/* 1621 */     this._inputPtr++;
/*      */     
/* 1623 */     switch (ch) {
/*      */       case 9:
/*      */       case 32:
/*      */         return;
/*      */       case 13:
/* 1628 */         _skipCR();
/*      */         return;
/*      */       case 10:
/* 1631 */         this._currInputRow++;
/* 1632 */         this._currInputRowStart = this._inputPtr;
/*      */         return;
/*      */     } 
/* 1635 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1646 */     if (i != 34) {
/* 1647 */       return _handleOddName(i);
/*      */     }
/*      */     
/* 1650 */     if (this._inputPtr + 13 > this._inputEnd) {
/* 1651 */       return slowParseName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1660 */     byte[] input = this._inputBuffer;
/* 1661 */     int[] codes = _icLatin1;
/*      */     
/* 1663 */     int q = input[this._inputPtr++] & 0xFF;
/*      */     
/* 1665 */     if (codes[q] == 0) {
/* 1666 */       i = input[this._inputPtr++] & 0xFF;
/* 1667 */       if (codes[i] == 0) {
/* 1668 */         q = q << 8 | i;
/* 1669 */         i = input[this._inputPtr++] & 0xFF;
/* 1670 */         if (codes[i] == 0) {
/* 1671 */           q = q << 8 | i;
/* 1672 */           i = input[this._inputPtr++] & 0xFF;
/* 1673 */           if (codes[i] == 0) {
/* 1674 */             q = q << 8 | i;
/* 1675 */             i = input[this._inputPtr++] & 0xFF;
/* 1676 */             if (codes[i] == 0) {
/* 1677 */               this._quad1 = q;
/* 1678 */               return parseMediumName(i);
/*      */             } 
/* 1680 */             if (i == 34) {
/* 1681 */               return findName(q, 4);
/*      */             }
/* 1683 */             return parseName(q, i, 4);
/*      */           } 
/* 1685 */           if (i == 34) {
/* 1686 */             return findName(q, 3);
/*      */           }
/* 1688 */           return parseName(q, i, 3);
/*      */         } 
/* 1690 */         if (i == 34) {
/* 1691 */           return findName(q, 2);
/*      */         }
/* 1693 */         return parseName(q, i, 2);
/*      */       } 
/* 1695 */       if (i == 34) {
/* 1696 */         return findName(q, 1);
/*      */       }
/* 1698 */       return parseName(q, i, 1);
/*      */     } 
/* 1700 */     if (q == 34) {
/* 1701 */       return "";
/*      */     }
/* 1703 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseMediumName(int q2) throws IOException {
/* 1708 */     byte[] input = this._inputBuffer;
/* 1709 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1712 */     int i = input[this._inputPtr++] & 0xFF;
/* 1713 */     if (codes[i] != 0) {
/* 1714 */       if (i == 34) {
/* 1715 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1717 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1719 */     q2 = q2 << 8 | i;
/* 1720 */     i = input[this._inputPtr++] & 0xFF;
/* 1721 */     if (codes[i] != 0) {
/* 1722 */       if (i == 34) {
/* 1723 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1725 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1727 */     q2 = q2 << 8 | i;
/* 1728 */     i = input[this._inputPtr++] & 0xFF;
/* 1729 */     if (codes[i] != 0) {
/* 1730 */       if (i == 34) {
/* 1731 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1733 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1735 */     q2 = q2 << 8 | i;
/* 1736 */     i = input[this._inputPtr++] & 0xFF;
/* 1737 */     if (codes[i] != 0) {
/* 1738 */       if (i == 34) {
/* 1739 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1741 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1743 */     return parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseMediumName2(int q3, int q2) throws IOException {
/* 1751 */     byte[] input = this._inputBuffer;
/* 1752 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1755 */     int i = input[this._inputPtr++] & 0xFF;
/* 1756 */     if (codes[i] != 0) {
/* 1757 */       if (i == 34) {
/* 1758 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1760 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1762 */     q3 = q3 << 8 | i;
/* 1763 */     i = input[this._inputPtr++] & 0xFF;
/* 1764 */     if (codes[i] != 0) {
/* 1765 */       if (i == 34) {
/* 1766 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1768 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1770 */     q3 = q3 << 8 | i;
/* 1771 */     i = input[this._inputPtr++] & 0xFF;
/* 1772 */     if (codes[i] != 0) {
/* 1773 */       if (i == 34) {
/* 1774 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1776 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1778 */     q3 = q3 << 8 | i;
/* 1779 */     i = input[this._inputPtr++] & 0xFF;
/* 1780 */     if (codes[i] != 0) {
/* 1781 */       if (i == 34) {
/* 1782 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1784 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1786 */     return parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseLongName(int q, int q2, int q3) throws IOException {
/* 1791 */     this._quadBuffer[0] = this._quad1;
/* 1792 */     this._quadBuffer[1] = q2;
/* 1793 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1796 */     byte[] input = this._inputBuffer;
/* 1797 */     int[] codes = _icLatin1;
/* 1798 */     int qlen = 3;
/*      */     
/* 1800 */     while (this._inputPtr + 4 <= this._inputEnd) {
/* 1801 */       int i = input[this._inputPtr++] & 0xFF;
/* 1802 */       if (codes[i] != 0) {
/* 1803 */         if (i == 34) {
/* 1804 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1806 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1809 */       q = q << 8 | i;
/* 1810 */       i = input[this._inputPtr++] & 0xFF;
/* 1811 */       if (codes[i] != 0) {
/* 1812 */         if (i == 34) {
/* 1813 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1815 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1818 */       q = q << 8 | i;
/* 1819 */       i = input[this._inputPtr++] & 0xFF;
/* 1820 */       if (codes[i] != 0) {
/* 1821 */         if (i == 34) {
/* 1822 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1824 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1827 */       q = q << 8 | i;
/* 1828 */       i = input[this._inputPtr++] & 0xFF;
/* 1829 */       if (codes[i] != 0) {
/* 1830 */         if (i == 34) {
/* 1831 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1833 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1837 */       if (qlen >= this._quadBuffer.length) {
/* 1838 */         this._quadBuffer = growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1840 */       this._quadBuffer[qlen++] = q;
/* 1841 */       q = i;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1848 */     return parseEscapedName(this._quadBuffer, qlen, 0, q, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String slowParseName() throws IOException {
/* 1858 */     if (this._inputPtr >= this._inputEnd && 
/* 1859 */       !_loadMore()) {
/* 1860 */       _reportInvalidEOF(": was expecting closing '\"' for name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 1863 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1864 */     if (i == 34) {
/* 1865 */       return "";
/*      */     }
/* 1867 */     return parseEscapedName(this._quadBuffer, 0, 0, i, 0);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1871 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1875 */     this._quadBuffer[0] = q1;
/* 1876 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1880 */     this._quadBuffer[0] = q1;
/* 1881 */     this._quadBuffer[1] = q2;
/* 1882 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 1897 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 1900 */       if (codes[ch] != 0) {
/* 1901 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1905 */         if (ch != 92) {
/*      */           
/* 1907 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1910 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1915 */         if (ch > 127) {
/*      */           
/* 1917 */           if (currQuadBytes >= 4) {
/* 1918 */             if (qlen >= quads.length) {
/* 1919 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 1921 */             quads[qlen++] = currQuad;
/* 1922 */             currQuad = 0;
/* 1923 */             currQuadBytes = 0;
/*      */           } 
/* 1925 */           if (ch < 2048) {
/* 1926 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1927 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1930 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1931 */             currQuadBytes++;
/*      */             
/* 1933 */             if (currQuadBytes >= 4) {
/* 1934 */               if (qlen >= quads.length) {
/* 1935 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 1937 */               quads[qlen++] = currQuad;
/* 1938 */               currQuad = 0;
/* 1939 */               currQuadBytes = 0;
/*      */             } 
/* 1941 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1942 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1945 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1949 */       if (currQuadBytes < 4) {
/* 1950 */         currQuadBytes++;
/* 1951 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1953 */         if (qlen >= quads.length) {
/* 1954 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 1956 */         quads[qlen++] = currQuad;
/* 1957 */         currQuad = ch;
/* 1958 */         currQuadBytes = 1;
/*      */       } 
/* 1960 */       if (this._inputPtr >= this._inputEnd && 
/* 1961 */         !_loadMore()) {
/* 1962 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 1965 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 1968 */     if (currQuadBytes > 0) {
/* 1969 */       if (qlen >= quads.length) {
/* 1970 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 1972 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 1974 */     String name = this._symbols.findName(quads, qlen);
/* 1975 */     if (name == null) {
/* 1976 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1978 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 1990 */     if (ch == 39 && isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 1991 */       return _parseAposName();
/*      */     }
/*      */     
/* 1994 */     if (!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES)) {
/* 1995 */       char c = (char)_decodeCharForError(ch);
/* 1996 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2002 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2004 */     if (codes[ch] != 0) {
/* 2005 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2011 */     int[] quads = this._quadBuffer;
/* 2012 */     int qlen = 0;
/* 2013 */     int currQuad = 0;
/* 2014 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/* 2018 */       if (currQuadBytes < 4) {
/* 2019 */         currQuadBytes++;
/* 2020 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2022 */         if (qlen >= quads.length) {
/* 2023 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2025 */         quads[qlen++] = currQuad;
/* 2026 */         currQuad = ch;
/* 2027 */         currQuadBytes = 1;
/*      */       } 
/* 2029 */       if (this._inputPtr >= this._inputEnd && 
/* 2030 */         !_loadMore()) {
/* 2031 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2034 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2035 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2038 */       this._inputPtr++;
/*      */     } 
/*      */     
/* 2041 */     if (currQuadBytes > 0) {
/* 2042 */       if (qlen >= quads.length) {
/* 2043 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2045 */       quads[qlen++] = currQuad;
/*      */     } 
/* 2047 */     String name = this._symbols.findName(quads, qlen);
/* 2048 */     if (name == null) {
/* 2049 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2051 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 2061 */     if (this._inputPtr >= this._inputEnd && 
/* 2062 */       !_loadMore()) {
/* 2063 */       _reportInvalidEOF(": was expecting closing ''' for field name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 2066 */     int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2067 */     if (ch == 39) {
/* 2068 */       return "";
/*      */     }
/* 2070 */     int[] quads = this._quadBuffer;
/* 2071 */     int qlen = 0;
/* 2072 */     int currQuad = 0;
/* 2073 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 2077 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 2080 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 2084 */       if (codes[ch] != 0 && ch != 34) {
/* 2085 */         if (ch != 92) {
/*      */ 
/*      */           
/* 2088 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2091 */           ch = _decodeEscaped();
/*      */         } 
/*      */         
/* 2094 */         if (ch > 127) {
/*      */           
/* 2096 */           if (currQuadBytes >= 4) {
/* 2097 */             if (qlen >= quads.length) {
/* 2098 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 2100 */             quads[qlen++] = currQuad;
/* 2101 */             currQuad = 0;
/* 2102 */             currQuadBytes = 0;
/*      */           } 
/* 2104 */           if (ch < 2048) {
/* 2105 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2106 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2109 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2110 */             currQuadBytes++;
/*      */             
/* 2112 */             if (currQuadBytes >= 4) {
/* 2113 */               if (qlen >= quads.length) {
/* 2114 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 2116 */               quads[qlen++] = currQuad;
/* 2117 */               currQuad = 0;
/* 2118 */               currQuadBytes = 0;
/*      */             } 
/* 2120 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2121 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2124 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2128 */       if (currQuadBytes < 4) {
/* 2129 */         currQuadBytes++;
/* 2130 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2132 */         if (qlen >= quads.length) {
/* 2133 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 2135 */         quads[qlen++] = currQuad;
/* 2136 */         currQuad = ch;
/* 2137 */         currQuadBytes = 1;
/*      */       } 
/* 2139 */       if (this._inputPtr >= this._inputEnd && 
/* 2140 */         !_loadMore()) {
/* 2141 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2144 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 2147 */     if (currQuadBytes > 0) {
/* 2148 */       if (qlen >= quads.length) {
/* 2149 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2151 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 2153 */     String name = this._symbols.findName(quads, qlen);
/* 2154 */     if (name == null) {
/* 2155 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2157 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException {
/* 2168 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*      */     
/* 2170 */     String name = this._symbols.findName(q1);
/* 2171 */     if (name != null) {
/* 2172 */       return name;
/*      */     }
/*      */     
/* 2175 */     this._quadBuffer[0] = q1;
/* 2176 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException {
/* 2181 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*      */     
/* 2183 */     String name = this._symbols.findName(q1, q2);
/* 2184 */     if (name != null) {
/* 2185 */       return name;
/*      */     }
/*      */     
/* 2188 */     this._quadBuffer[0] = q1;
/* 2189 */     this._quadBuffer[1] = q2;
/* 2190 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException {
/* 2195 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 2196 */     String name = this._symbols.findName(q1, q2, q3);
/* 2197 */     if (name != null) {
/* 2198 */       return name;
/*      */     }
/* 2200 */     int[] quads = this._quadBuffer;
/* 2201 */     quads[0] = q1;
/* 2202 */     quads[1] = q2;
/* 2203 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 2204 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException {
/* 2209 */     if (qlen >= quads.length) {
/* 2210 */       this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */     }
/* 2212 */     quads[qlen++] = _padLastQuad(lastQuad, lastQuadBytes);
/* 2213 */     String name = this._symbols.findName(quads, qlen);
/* 2214 */     if (name == null) {
/* 2215 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 2217 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException {
/* 2233 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2242 */     if (lastQuadBytes < 4) {
/* 2243 */       lastQuad = quads[qlen - 1];
/*      */       
/* 2245 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 2247 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 2251 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2252 */     int cix = 0;
/*      */     
/* 2254 */     for (int ix = 0; ix < byteLen; ) {
/* 2255 */       int ch = quads[ix >> 2];
/* 2256 */       int byteIx = ix & 0x3;
/* 2257 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 2258 */       ix++;
/*      */       
/* 2260 */       if (ch > 127) {
/*      */         int needed;
/* 2262 */         if ((ch & 0xE0) == 192) {
/* 2263 */           ch &= 0x1F;
/* 2264 */           needed = 1;
/* 2265 */         } else if ((ch & 0xF0) == 224) {
/* 2266 */           ch &= 0xF;
/* 2267 */           needed = 2;
/* 2268 */         } else if ((ch & 0xF8) == 240) {
/* 2269 */           ch &= 0x7;
/* 2270 */           needed = 3;
/*      */         } else {
/* 2272 */           _reportInvalidInitial(ch);
/* 2273 */           needed = ch = 1;
/*      */         } 
/* 2275 */         if (ix + needed > byteLen) {
/* 2276 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 2280 */         int ch2 = quads[ix >> 2];
/* 2281 */         byteIx = ix & 0x3;
/* 2282 */         ch2 >>= 3 - byteIx << 3;
/* 2283 */         ix++;
/*      */         
/* 2285 */         if ((ch2 & 0xC0) != 128) {
/* 2286 */           _reportInvalidOther(ch2);
/*      */         }
/* 2288 */         ch = ch << 6 | ch2 & 0x3F;
/* 2289 */         if (needed > 1) {
/* 2290 */           ch2 = quads[ix >> 2];
/* 2291 */           byteIx = ix & 0x3;
/* 2292 */           ch2 >>= 3 - byteIx << 3;
/* 2293 */           ix++;
/*      */           
/* 2295 */           if ((ch2 & 0xC0) != 128) {
/* 2296 */             _reportInvalidOther(ch2);
/*      */           }
/* 2298 */           ch = ch << 6 | ch2 & 0x3F;
/* 2299 */           if (needed > 2) {
/* 2300 */             ch2 = quads[ix >> 2];
/* 2301 */             byteIx = ix & 0x3;
/* 2302 */             ch2 >>= 3 - byteIx << 3;
/* 2303 */             ix++;
/* 2304 */             if ((ch2 & 0xC0) != 128) {
/* 2305 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 2307 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 2310 */         if (needed > 2) {
/* 2311 */           ch -= 65536;
/* 2312 */           if (cix >= cbuf.length) {
/* 2313 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 2315 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 2316 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 2319 */       if (cix >= cbuf.length) {
/* 2320 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 2322 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 2326 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 2328 */     if (lastQuadBytes < 4) {
/* 2329 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 2331 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _padLastQuad(int q, int bytes) {
/* 2338 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _loadMoreGuaranteed() throws IOException {
/* 2348 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 2355 */     int ptr = this._inputPtr;
/* 2356 */     if (ptr >= this._inputEnd) {
/* 2357 */       _loadMoreGuaranteed();
/* 2358 */       ptr = this._inputPtr;
/*      */     } 
/* 2360 */     int outPtr = 0;
/* 2361 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2362 */     int[] codes = _icUTF8;
/*      */     
/* 2364 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2365 */     byte[] inputBuffer = this._inputBuffer;
/* 2366 */     while (ptr < max) {
/* 2367 */       int c = inputBuffer[ptr] & 0xFF;
/* 2368 */       if (codes[c] != 0) {
/* 2369 */         if (c == 34) {
/* 2370 */           this._inputPtr = ptr + 1;
/* 2371 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       } 
/* 2376 */       ptr++;
/* 2377 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2379 */     this._inputPtr = ptr;
/* 2380 */     _finishString2(outBuf, outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _finishAndReturnString() throws IOException {
/* 2389 */     int ptr = this._inputPtr;
/* 2390 */     if (ptr >= this._inputEnd) {
/* 2391 */       _loadMoreGuaranteed();
/* 2392 */       ptr = this._inputPtr;
/*      */     } 
/* 2394 */     int outPtr = 0;
/* 2395 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2396 */     int[] codes = _icUTF8;
/*      */     
/* 2398 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2399 */     byte[] inputBuffer = this._inputBuffer;
/* 2400 */     while (ptr < max) {
/* 2401 */       int c = inputBuffer[ptr] & 0xFF;
/* 2402 */       if (codes[c] != 0) {
/* 2403 */         if (c == 34) {
/* 2404 */           this._inputPtr = ptr + 1;
/* 2405 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         } 
/*      */         break;
/*      */       } 
/* 2409 */       ptr++;
/* 2410 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2412 */     this._inputPtr = ptr;
/* 2413 */     _finishString2(outBuf, outPtr);
/* 2414 */     return this._textBuffer.contentsAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr) throws IOException {
/* 2423 */     int[] codes = _icUTF8;
/* 2424 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2431 */       int ptr = this._inputPtr;
/* 2432 */       if (ptr >= this._inputEnd) {
/* 2433 */         _loadMoreGuaranteed();
/* 2434 */         ptr = this._inputPtr;
/*      */       } 
/* 2436 */       if (outPtr >= outBuf.length) {
/* 2437 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2438 */         outPtr = 0;
/*      */       } 
/* 2440 */       int max = Math.min(this._inputEnd, ptr + outBuf.length - outPtr);
/* 2441 */       while (ptr < max) {
/* 2442 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2443 */         if (codes[c] != 0) {
/* 2444 */           this._inputPtr = ptr;
/*      */         } else {
/*      */           
/* 2447 */           outBuf[outPtr++] = (char)c;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/* 2452 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2456 */         switch (codes[c]) {
/*      */           case 1:
/* 2458 */             c = _decodeEscaped();
/*      */             break;
/*      */           case 2:
/* 2461 */             c = _decodeUtf8_2(c);
/*      */             break;
/*      */           case 3:
/* 2464 */             if (this._inputEnd - this._inputPtr >= 2) {
/* 2465 */               c = _decodeUtf8_3fast(c); break;
/*      */             } 
/* 2467 */             c = _decodeUtf8_3(c);
/*      */             break;
/*      */           
/*      */           case 4:
/* 2471 */             c = _decodeUtf8_4(c);
/*      */             
/* 2473 */             outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2474 */             if (outPtr >= outBuf.length) {
/* 2475 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2476 */               outPtr = 0;
/*      */             } 
/* 2478 */             c = 0xDC00 | c & 0x3FF;
/*      */             break;
/*      */           
/*      */           default:
/* 2482 */             if (c < 32) {
/*      */               
/* 2484 */               _throwUnquotedSpace(c, "string value");
/*      */               break;
/*      */             } 
/* 2487 */             _reportInvalidChar(c);
/*      */             break;
/*      */         } 
/*      */         
/* 2491 */         if (outPtr >= outBuf.length) {
/* 2492 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2493 */           outPtr = 0;
/*      */         } 
/*      */         
/* 2496 */         outBuf[outPtr++] = (char)c;
/*      */       }  this._inputPtr = ptr;
/* 2498 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 2508 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 2511 */     int[] codes = _icUTF8;
/* 2512 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2520 */       int ptr = this._inputPtr;
/* 2521 */       int max = this._inputEnd;
/* 2522 */       if (ptr >= max) {
/* 2523 */         _loadMoreGuaranteed();
/* 2524 */         ptr = this._inputPtr;
/* 2525 */         max = this._inputEnd;
/*      */       } 
/* 2527 */       while (ptr < max) {
/* 2528 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2529 */         if (codes[c] != 0) {
/* 2530 */           this._inputPtr = ptr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2537 */           if (c != 34) {
/*      */ 
/*      */ 
/*      */             
/* 2541 */             switch (codes[c]) {
/*      */               case 1:
/* 2543 */                 _decodeEscaped();
/*      */                 continue;
/*      */               case 2:
/* 2546 */                 _skipUtf8_2();
/*      */                 continue;
/*      */               case 3:
/* 2549 */                 _skipUtf8_3();
/*      */                 continue;
/*      */               case 4:
/* 2552 */                 _skipUtf8_4(c);
/*      */                 continue;
/*      */             } 
/* 2555 */             if (c < 32) {
/* 2556 */               _throwUnquotedSpace(c, "string value");
/*      */               continue;
/*      */             } 
/* 2559 */             _reportInvalidChar(c);
/*      */             continue;
/*      */           } 
/*      */           return;
/*      */         } 
/*      */       } 
/*      */       this._inputPtr = ptr;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2572 */     switch (c) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 2581 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2589 */         if (isEnabled(JsonParser.Feature.ALLOW_MISSING_VALUES)) {
/* 2590 */           this._inputPtr--;
/* 2591 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2597 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2599 */         if (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 2600 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2604 */         _matchToken("NaN", 1);
/* 2605 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2606 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2608 */         _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 73:
/* 2611 */         _matchToken("Infinity", 1);
/* 2612 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2613 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2615 */         _reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 43:
/* 2618 */         if (this._inputPtr >= this._inputEnd && 
/* 2619 */           !_loadMore()) {
/* 2620 */           _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */         }
/*      */         
/* 2623 */         return _handleInvalidNumberStart(this._inputBuffer[this._inputPtr++] & 0xFF, false);
/*      */     } 
/*      */     
/* 2626 */     if (Character.isJavaIdentifierStart(c)) {
/* 2627 */       _reportInvalidToken("" + (char)c, "('true', 'false' or 'null')");
/*      */     }
/*      */     
/* 2630 */     _reportUnexpectedChar(c, "expected a valid value (number, String, array, object, 'true', 'false' or 'null')");
/* 2631 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2636 */     int c = 0;
/*      */     
/* 2638 */     int outPtr = 0;
/* 2639 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2642 */     int[] codes = _icUTF8;
/* 2643 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true)
/* 2650 */     { if (this._inputPtr >= this._inputEnd) {
/* 2651 */         _loadMoreGuaranteed();
/*      */       }
/* 2653 */       if (outPtr >= outBuf.length) {
/* 2654 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2655 */         outPtr = 0;
/*      */       } 
/* 2657 */       int max = this._inputEnd;
/*      */       
/* 2659 */       int max2 = this._inputPtr + outBuf.length - outPtr;
/* 2660 */       if (max2 < max) {
/* 2661 */         max = max2;
/*      */       }
/*      */       
/* 2664 */       while (this._inputPtr < max)
/* 2665 */       { c = inputBuffer[this._inputPtr++] & 0xFF;
/* 2666 */         if (c == 39 || codes[c] != 0)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2674 */           if (c != 39) {
/*      */ 
/*      */ 
/*      */             
/* 2678 */             switch (codes[c]) {
/*      */               case 1:
/* 2680 */                 c = _decodeEscaped();
/*      */                 break;
/*      */               case 2:
/* 2683 */                 c = _decodeUtf8_2(c);
/*      */                 break;
/*      */               case 3:
/* 2686 */                 if (this._inputEnd - this._inputPtr >= 2) {
/* 2687 */                   c = _decodeUtf8_3fast(c); break;
/*      */                 } 
/* 2689 */                 c = _decodeUtf8_3(c);
/*      */                 break;
/*      */               
/*      */               case 4:
/* 2693 */                 c = _decodeUtf8_4(c);
/*      */                 
/* 2695 */                 outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2696 */                 if (outPtr >= outBuf.length) {
/* 2697 */                   outBuf = this._textBuffer.finishCurrentSegment();
/* 2698 */                   outPtr = 0;
/*      */                 } 
/* 2700 */                 c = 0xDC00 | c & 0x3FF;
/*      */                 break;
/*      */               
/*      */               default:
/* 2704 */                 if (c < 32) {
/* 2705 */                   _throwUnquotedSpace(c, "string value");
/*      */                 }
/*      */                 
/* 2708 */                 _reportInvalidChar(c);
/*      */                 break;
/*      */             } 
/* 2711 */             if (outPtr >= outBuf.length) {
/* 2712 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2713 */               outPtr = 0;
/*      */             } 
/*      */             
/* 2716 */             outBuf[outPtr++] = (char)c; continue;
/*      */           } 
/* 2718 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           
/* 2720 */           return JsonToken.VALUE_STRING; }  outBuf[outPtr++] = (char)c; }  }  this._textBuffer.setCurrentLength(outPtr); return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2735 */     while (ch == 73) {
/* 2736 */       String match; if (this._inputPtr >= this._inputEnd && 
/* 2737 */         !_loadMore()) {
/* 2738 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       }
/*      */       
/* 2741 */       ch = this._inputBuffer[this._inputPtr++];
/*      */       
/* 2743 */       if (ch == 78) {
/* 2744 */         match = neg ? "-INF" : "+INF";
/* 2745 */       } else if (ch == 110) {
/* 2746 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2750 */       _matchToken(match, 3);
/* 2751 */       if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2752 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2754 */       _reportError("Non-standard token '%s': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow", match);
/*      */     } 
/*      */     
/* 2757 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 2758 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _matchTrue() throws IOException {
/* 2764 */     int ptr = this._inputPtr;
/* 2765 */     if (ptr + 3 < this._inputEnd) {
/* 2766 */       byte[] buf = this._inputBuffer;
/* 2767 */       if (buf[ptr++] == 114 && buf[ptr++] == 117 && buf[ptr++] == 101) {
/*      */ 
/*      */         
/* 2770 */         int ch = buf[ptr] & 0xFF;
/* 2771 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2772 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2777 */     _matchToken2("true", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchFalse() throws IOException {
/* 2782 */     int ptr = this._inputPtr;
/* 2783 */     if (ptr + 4 < this._inputEnd) {
/* 2784 */       byte[] buf = this._inputBuffer;
/* 2785 */       if (buf[ptr++] == 97 && buf[ptr++] == 108 && buf[ptr++] == 115 && buf[ptr++] == 101) {
/*      */ 
/*      */ 
/*      */         
/* 2789 */         int ch = buf[ptr] & 0xFF;
/* 2790 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2791 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2796 */     _matchToken2("false", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchNull() throws IOException {
/* 2801 */     int ptr = this._inputPtr;
/* 2802 */     if (ptr + 3 < this._inputEnd) {
/* 2803 */       byte[] buf = this._inputBuffer;
/* 2804 */       if (buf[ptr++] == 117 && buf[ptr++] == 108 && buf[ptr++] == 108) {
/*      */ 
/*      */         
/* 2807 */         int ch = buf[ptr] & 0xFF;
/* 2808 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 2809 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2814 */     _matchToken2("null", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2819 */     int len = matchStr.length();
/* 2820 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2821 */       _matchToken2(matchStr, i);
/*      */       return;
/*      */     } 
/*      */     do {
/* 2825 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2826 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2828 */       this._inputPtr++;
/* 2829 */     } while (++i < len);
/*      */     
/* 2831 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2832 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2833 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2839 */     int len = matchStr.length();
/*      */     do {
/* 2841 */       if ((this._inputPtr >= this._inputEnd && !_loadMore()) || this._inputBuffer[this._inputPtr] != matchStr
/* 2842 */         .charAt(i)) {
/* 2843 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2845 */       this._inputPtr++;
/* 2846 */     } while (++i < len);
/*      */ 
/*      */     
/* 2849 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */       return;
/*      */     }
/* 2852 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2853 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2854 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 2860 */     char c = (char)_decodeCharForError(ch);
/* 2861 */     if (Character.isJavaIdentifierPart(c)) {
/* 2862 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 2874 */     while (this._inputPtr < this._inputEnd) {
/* 2875 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2876 */       if (i > 32) {
/* 2877 */         if (i == 47 || i == 35) {
/* 2878 */           this._inputPtr--;
/* 2879 */           return _skipWS2();
/*      */         } 
/* 2881 */         return i;
/*      */       } 
/* 2883 */       if (i != 32) {
/* 2884 */         if (i == 10) {
/* 2885 */           this._currInputRow++;
/* 2886 */           this._currInputRowStart = this._inputPtr; continue;
/* 2887 */         }  if (i == 13) {
/* 2888 */           _skipCR(); continue;
/* 2889 */         }  if (i != 9) {
/* 2890 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2894 */     return _skipWS2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWS2() throws IOException {
/* 2899 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2900 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2901 */       if (i > 32) {
/* 2902 */         if (i == 47) {
/* 2903 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2906 */         if (i == 35 && 
/* 2907 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2911 */         return i;
/*      */       } 
/* 2913 */       if (i != 32) {
/* 2914 */         if (i == 10) {
/* 2915 */           this._currInputRow++;
/* 2916 */           this._currInputRowStart = this._inputPtr; continue;
/* 2917 */         }  if (i == 13) {
/* 2918 */           _skipCR(); continue;
/* 2919 */         }  if (i != 9) {
/* 2920 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2924 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2931 */     if (this._inputPtr >= this._inputEnd && 
/* 2932 */       !_loadMore()) {
/* 2933 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 2936 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2937 */     if (i > 32) {
/* 2938 */       if (i == 47 || i == 35) {
/* 2939 */         this._inputPtr--;
/* 2940 */         return _skipWSOrEnd2();
/*      */       } 
/* 2942 */       return i;
/*      */     } 
/* 2944 */     if (i != 32) {
/* 2945 */       if (i == 10) {
/* 2946 */         this._currInputRow++;
/* 2947 */         this._currInputRowStart = this._inputPtr;
/* 2948 */       } else if (i == 13) {
/* 2949 */         _skipCR();
/* 2950 */       } else if (i != 9) {
/* 2951 */         _throwInvalidSpace(i);
/*      */       } 
/*      */     }
/*      */     
/* 2955 */     while (this._inputPtr < this._inputEnd) {
/* 2956 */       i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2957 */       if (i > 32) {
/* 2958 */         if (i == 47 || i == 35) {
/* 2959 */           this._inputPtr--;
/* 2960 */           return _skipWSOrEnd2();
/*      */         } 
/* 2962 */         return i;
/*      */       } 
/* 2964 */       if (i != 32) {
/* 2965 */         if (i == 10) {
/* 2966 */           this._currInputRow++;
/* 2967 */           this._currInputRowStart = this._inputPtr; continue;
/* 2968 */         }  if (i == 13) {
/* 2969 */           _skipCR(); continue;
/* 2970 */         }  if (i != 9) {
/* 2971 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2975 */     return _skipWSOrEnd2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd2() throws IOException {
/* 2980 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2981 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2982 */       if (i > 32) {
/* 2983 */         if (i == 47) {
/* 2984 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2987 */         if (i == 35 && 
/* 2988 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2992 */         return i;
/* 2993 */       }  if (i != 32) {
/* 2994 */         if (i == 10) {
/* 2995 */           this._currInputRow++;
/* 2996 */           this._currInputRowStart = this._inputPtr; continue;
/* 2997 */         }  if (i == 13) {
/* 2998 */           _skipCR(); continue;
/* 2999 */         }  if (i != 9) {
/* 3000 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3005 */     return _eofAsNextChar();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 3010 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 3011 */       return _skipColon2(false);
/*      */     }
/*      */     
/* 3014 */     int i = this._inputBuffer[this._inputPtr];
/* 3015 */     if (i == 58) {
/* 3016 */       i = this._inputBuffer[++this._inputPtr];
/* 3017 */       if (i > 32) {
/* 3018 */         if (i == 47 || i == 35) {
/* 3019 */           return _skipColon2(true);
/*      */         }
/* 3021 */         this._inputPtr++;
/* 3022 */         return i;
/*      */       } 
/* 3024 */       if (i == 32 || i == 9) {
/* 3025 */         i = this._inputBuffer[++this._inputPtr];
/* 3026 */         if (i > 32) {
/* 3027 */           if (i == 47 || i == 35) {
/* 3028 */             return _skipColon2(true);
/*      */           }
/* 3030 */           this._inputPtr++;
/* 3031 */           return i;
/*      */         } 
/*      */       } 
/* 3034 */       return _skipColon2(true);
/*      */     } 
/* 3036 */     if (i == 32 || i == 9) {
/* 3037 */       i = this._inputBuffer[++this._inputPtr];
/*      */     }
/* 3039 */     if (i == 58) {
/* 3040 */       i = this._inputBuffer[++this._inputPtr];
/* 3041 */       if (i > 32) {
/* 3042 */         if (i == 47 || i == 35) {
/* 3043 */           return _skipColon2(true);
/*      */         }
/* 3045 */         this._inputPtr++;
/* 3046 */         return i;
/*      */       } 
/* 3048 */       if (i == 32 || i == 9) {
/* 3049 */         i = this._inputBuffer[++this._inputPtr];
/* 3050 */         if (i > 32) {
/* 3051 */           if (i == 47 || i == 35) {
/* 3052 */             return _skipColon2(true);
/*      */           }
/* 3054 */           this._inputPtr++;
/* 3055 */           return i;
/*      */         } 
/*      */       } 
/* 3058 */       return _skipColon2(true);
/*      */     } 
/* 3060 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException {
/* 3065 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3066 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 3068 */       if (i > 32) {
/* 3069 */         if (i == 47) {
/* 3070 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3073 */         if (i == 35 && 
/* 3074 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3078 */         if (gotColon) {
/* 3079 */           return i;
/*      */         }
/* 3081 */         if (i != 58) {
/* 3082 */           _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */         }
/* 3084 */         gotColon = true; continue;
/* 3085 */       }  if (i != 32) {
/* 3086 */         if (i == 10) {
/* 3087 */           this._currInputRow++;
/* 3088 */           this._currInputRowStart = this._inputPtr; continue;
/* 3089 */         }  if (i == 13) {
/* 3090 */           _skipCR(); continue;
/* 3091 */         }  if (i != 9) {
/* 3092 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3096 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 3098 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 3103 */     if (!isEnabled(JsonParser.Feature.ALLOW_COMMENTS)) {
/* 3104 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 3107 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 3108 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 3110 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3111 */     if (c == 47) {
/* 3112 */       _skipLine();
/* 3113 */     } else if (c == 42) {
/* 3114 */       _skipCComment();
/*      */     } else {
/* 3116 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 3123 */     int[] codes = CharTypes.getInputCodeComment();
/*      */ 
/*      */ 
/*      */     
/* 3127 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3128 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3129 */       int code = codes[i];
/* 3130 */       if (code != 0) {
/* 3131 */         switch (code) {
/*      */           case 42:
/* 3133 */             if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */               break;
/*      */             }
/* 3136 */             if (this._inputBuffer[this._inputPtr] == 47) {
/* 3137 */               this._inputPtr++;
/*      */               return;
/*      */             } 
/*      */             continue;
/*      */           case 10:
/* 3142 */             this._currInputRow++;
/* 3143 */             this._currInputRowStart = this._inputPtr;
/*      */             continue;
/*      */           case 13:
/* 3146 */             _skipCR();
/*      */             continue;
/*      */           case 2:
/* 3149 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3152 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3155 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/*      */         
/* 3159 */         _reportInvalidChar(i);
/*      */       } 
/*      */     } 
/*      */     
/* 3163 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 3168 */     if (!isEnabled(JsonParser.Feature.ALLOW_YAML_COMMENTS)) {
/* 3169 */       return false;
/*      */     }
/* 3171 */     _skipLine();
/* 3172 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 3182 */     int[] codes = CharTypes.getInputCodeComment();
/* 3183 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3184 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3185 */       int code = codes[i];
/* 3186 */       if (code != 0) {
/* 3187 */         switch (code) {
/*      */           case 10:
/* 3189 */             this._currInputRow++;
/* 3190 */             this._currInputRowStart = this._inputPtr;
/*      */             return;
/*      */           case 13:
/* 3193 */             _skipCR();
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 3198 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3201 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3204 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/* 3207 */         if (code < 0)
/*      */         {
/* 3209 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 3219 */     if (this._inputPtr >= this._inputEnd && 
/* 3220 */       !_loadMore()) {
/* 3221 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 3224 */     int c = this._inputBuffer[this._inputPtr++];
/*      */     
/* 3226 */     switch (c) {
/*      */       
/*      */       case 98:
/* 3229 */         return '\b';
/*      */       case 116:
/* 3231 */         return '\t';
/*      */       case 110:
/* 3233 */         return '\n';
/*      */       case 102:
/* 3235 */         return '\f';
/*      */       case 114:
/* 3237 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 3243 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 3249 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 3253 */     int value = 0;
/* 3254 */     for (int i = 0; i < 4; i++) {
/* 3255 */       if (this._inputPtr >= this._inputEnd && 
/* 3256 */         !_loadMore()) {
/* 3257 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 3260 */       int ch = this._inputBuffer[this._inputPtr++];
/* 3261 */       int digit = CharTypes.charToHex(ch);
/* 3262 */       if (digit < 0) {
/* 3263 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 3265 */       value = value << 4 | digit;
/*      */     } 
/* 3267 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 3272 */     int c = firstByte & 0xFF;
/* 3273 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 3277 */       if ((c & 0xE0) == 192) {
/* 3278 */         c &= 0x1F;
/* 3279 */         needed = 1;
/* 3280 */       } else if ((c & 0xF0) == 224) {
/* 3281 */         c &= 0xF;
/* 3282 */         needed = 2;
/* 3283 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 3285 */         c &= 0x7;
/* 3286 */         needed = 3;
/*      */       } else {
/* 3288 */         _reportInvalidInitial(c & 0xFF);
/* 3289 */         needed = 1;
/*      */       } 
/*      */       
/* 3292 */       int d = nextByte();
/* 3293 */       if ((d & 0xC0) != 128) {
/* 3294 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 3296 */       c = c << 6 | d & 0x3F;
/*      */       
/* 3298 */       if (needed > 1) {
/* 3299 */         d = nextByte();
/* 3300 */         if ((d & 0xC0) != 128) {
/* 3301 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 3303 */         c = c << 6 | d & 0x3F;
/* 3304 */         if (needed > 2) {
/* 3305 */           d = nextByte();
/* 3306 */           if ((d & 0xC0) != 128) {
/* 3307 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 3309 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 3313 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 3324 */     if (this._inputPtr >= this._inputEnd) {
/* 3325 */       _loadMoreGuaranteed();
/*      */     }
/* 3327 */     int d = this._inputBuffer[this._inputPtr++];
/* 3328 */     if ((d & 0xC0) != 128) {
/* 3329 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3331 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 3336 */     if (this._inputPtr >= this._inputEnd) {
/* 3337 */       _loadMoreGuaranteed();
/*      */     }
/* 3339 */     c1 &= 0xF;
/* 3340 */     int d = this._inputBuffer[this._inputPtr++];
/* 3341 */     if ((d & 0xC0) != 128) {
/* 3342 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3344 */     int c = c1 << 6 | d & 0x3F;
/* 3345 */     if (this._inputPtr >= this._inputEnd) {
/* 3346 */       _loadMoreGuaranteed();
/*      */     }
/* 3348 */     d = this._inputBuffer[this._inputPtr++];
/* 3349 */     if ((d & 0xC0) != 128) {
/* 3350 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3352 */     c = c << 6 | d & 0x3F;
/* 3353 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3fast(int c1) throws IOException {
/* 3358 */     c1 &= 0xF;
/* 3359 */     int d = this._inputBuffer[this._inputPtr++];
/* 3360 */     if ((d & 0xC0) != 128) {
/* 3361 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3363 */     int c = c1 << 6 | d & 0x3F;
/* 3364 */     d = this._inputBuffer[this._inputPtr++];
/* 3365 */     if ((d & 0xC0) != 128) {
/* 3366 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3368 */     c = c << 6 | d & 0x3F;
/* 3369 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 3378 */     if (this._inputPtr >= this._inputEnd) {
/* 3379 */       _loadMoreGuaranteed();
/*      */     }
/* 3381 */     int d = this._inputBuffer[this._inputPtr++];
/* 3382 */     if ((d & 0xC0) != 128) {
/* 3383 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3385 */     c = (c & 0x7) << 6 | d & 0x3F;
/*      */     
/* 3387 */     if (this._inputPtr >= this._inputEnd) {
/* 3388 */       _loadMoreGuaranteed();
/*      */     }
/* 3390 */     d = this._inputBuffer[this._inputPtr++];
/* 3391 */     if ((d & 0xC0) != 128) {
/* 3392 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3394 */     c = c << 6 | d & 0x3F;
/* 3395 */     if (this._inputPtr >= this._inputEnd) {
/* 3396 */       _loadMoreGuaranteed();
/*      */     }
/* 3398 */     d = this._inputBuffer[this._inputPtr++];
/* 3399 */     if ((d & 0xC0) != 128) {
/* 3400 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3406 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 3411 */     if (this._inputPtr >= this._inputEnd) {
/* 3412 */       _loadMoreGuaranteed();
/*      */     }
/* 3414 */     int c = this._inputBuffer[this._inputPtr++];
/* 3415 */     if ((c & 0xC0) != 128) {
/* 3416 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 3425 */     if (this._inputPtr >= this._inputEnd) {
/* 3426 */       _loadMoreGuaranteed();
/*      */     }
/*      */     
/* 3429 */     int c = this._inputBuffer[this._inputPtr++];
/* 3430 */     if ((c & 0xC0) != 128) {
/* 3431 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/* 3433 */     if (this._inputPtr >= this._inputEnd) {
/* 3434 */       _loadMoreGuaranteed();
/*      */     }
/* 3436 */     c = this._inputBuffer[this._inputPtr++];
/* 3437 */     if ((c & 0xC0) != 128) {
/* 3438 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4(int c) throws IOException {
/* 3444 */     if (this._inputPtr >= this._inputEnd) {
/* 3445 */       _loadMoreGuaranteed();
/*      */     }
/* 3447 */     int d = this._inputBuffer[this._inputPtr++];
/* 3448 */     if ((d & 0xC0) != 128) {
/* 3449 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3451 */     if (this._inputPtr >= this._inputEnd) {
/* 3452 */       _loadMoreGuaranteed();
/*      */     }
/* 3454 */     d = this._inputBuffer[this._inputPtr++];
/* 3455 */     if ((d & 0xC0) != 128) {
/* 3456 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3458 */     if (this._inputPtr >= this._inputEnd) {
/* 3459 */       _loadMoreGuaranteed();
/*      */     }
/* 3461 */     d = this._inputBuffer[this._inputPtr++];
/* 3462 */     if ((d & 0xC0) != 128) {
/* 3463 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipCR() throws IOException {
/* 3479 */     if ((this._inputPtr < this._inputEnd || _loadMore()) && 
/* 3480 */       this._inputBuffer[this._inputPtr] == 10) {
/* 3481 */       this._inputPtr++;
/*      */     }
/*      */     
/* 3484 */     this._currInputRow++;
/* 3485 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private int nextByte() throws IOException {
/* 3490 */     if (this._inputPtr >= this._inputEnd) {
/* 3491 */       _loadMoreGuaranteed();
/*      */     }
/* 3493 */     return this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, int ptr) throws IOException {
/* 3503 */     this._inputPtr = ptr;
/* 3504 */     _reportInvalidToken(matchedPart, "'null', 'true', 'false' or NaN");
/*      */   }
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 3508 */     _reportInvalidToken(matchedPart, "'null', 'true', 'false' or NaN");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, String msg) throws IOException {
/* 3517 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 3518 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3519 */       int i = this._inputBuffer[this._inputPtr++];
/* 3520 */       char c = (char)_decodeCharForError(i);
/* 3521 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/* 3526 */       sb.append(c);
/* 3527 */       if (sb.length() >= 256) {
/* 3528 */         sb.append("...");
/*      */         break;
/*      */       } 
/*      */     } 
/* 3532 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 3538 */     if (c < 32) {
/* 3539 */       _throwInvalidSpace(c);
/*      */     }
/* 3541 */     _reportInvalidInitial(c);
/*      */   }
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 3545 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */   
/*      */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 3549 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidOther(int mask, int ptr) throws JsonParseException {
/* 3555 */     this._inputPtr = ptr;
/* 3556 */     _reportInvalidOther(mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 3572 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 3578 */       if (this._inputPtr >= this._inputEnd) {
/* 3579 */         _loadMoreGuaranteed();
/*      */       }
/* 3581 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3582 */       if (ch > 32) {
/* 3583 */         int bits = b64variant.decodeBase64Char(ch);
/* 3584 */         if (bits < 0) {
/* 3585 */           if (ch == 34) {
/* 3586 */             return builder.toByteArray();
/*      */           }
/* 3588 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 3589 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 3593 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/* 3597 */         if (this._inputPtr >= this._inputEnd) {
/* 3598 */           _loadMoreGuaranteed();
/*      */         }
/* 3600 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3601 */         bits = b64variant.decodeBase64Char(ch);
/* 3602 */         if (bits < 0) {
/* 3603 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 3605 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/* 3608 */         if (this._inputPtr >= this._inputEnd) {
/* 3609 */           _loadMoreGuaranteed();
/*      */         }
/* 3611 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3612 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 3615 */         if (bits < 0) {
/* 3616 */           if (bits != -2) {
/*      */             
/* 3618 */             if (ch == 34) {
/* 3619 */               decodedData >>= 4;
/* 3620 */               builder.append(decodedData);
/* 3621 */               if (b64variant.usesPadding()) {
/* 3622 */                 this._inputPtr--;
/* 3623 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3625 */               return builder.toByteArray();
/*      */             } 
/* 3627 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 3629 */           if (bits == -2) {
/*      */             
/* 3631 */             if (this._inputPtr >= this._inputEnd) {
/* 3632 */               _loadMoreGuaranteed();
/*      */             }
/* 3634 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3635 */             if (!b64variant.usesPaddingChar(ch) && 
/* 3636 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/* 3637 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 3641 */             decodedData >>= 4;
/* 3642 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3647 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 3649 */         if (this._inputPtr >= this._inputEnd) {
/* 3650 */           _loadMoreGuaranteed();
/*      */         }
/* 3652 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3653 */         bits = b64variant.decodeBase64Char(ch);
/* 3654 */         if (bits < 0) {
/* 3655 */           if (bits != -2) {
/*      */             
/* 3657 */             if (ch == 34) {
/* 3658 */               decodedData >>= 2;
/* 3659 */               builder.appendTwoBytes(decodedData);
/* 3660 */               if (b64variant.usesPadding()) {
/* 3661 */                 this._inputPtr--;
/* 3662 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3664 */               return builder.toByteArray();
/*      */             } 
/* 3666 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 3668 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */             
/* 3672 */             decodedData >>= 2;
/* 3673 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3678 */         decodedData = decodedData << 6 | bits;
/* 3679 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 3693 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 3694 */       long total = this._currInputProcessed + (this._nameStartOffset - 1);
/* 3695 */       return new JsonLocation(_getSourceReference(), total, -1L, this._nameStartRow, this._nameStartCol);
/*      */     } 
/*      */     
/* 3698 */     return new JsonLocation(_getSourceReference(), this._tokenInputTotal - 1L, -1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 3706 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 3707 */     return new JsonLocation(_getSourceReference(), this._currInputProcessed + this._inputPtr, -1L, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateLocation() {
/* 3715 */     this._tokenInputRow = this._currInputRow;
/* 3716 */     int ptr = this._inputPtr;
/* 3717 */     this._tokenInputTotal = this._currInputProcessed + ptr;
/* 3718 */     this._tokenInputCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateNameLocation() {
/* 3724 */     this._nameStartRow = this._currInputRow;
/* 3725 */     int ptr = this._inputPtr;
/* 3726 */     this._nameStartOffset = ptr;
/* 3727 */     this._nameStartCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _closeScope(int i) throws JsonParseException {
/* 3737 */     if (i == 125) {
/* 3738 */       _closeObjectScope();
/* 3739 */       return this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/* 3741 */     _closeArrayScope();
/* 3742 */     return this._currToken = JsonToken.END_ARRAY;
/*      */   }
/*      */   
/*      */   private final void _closeArrayScope() throws JsonParseException {
/* 3746 */     _updateLocation();
/* 3747 */     if (!this._parsingContext.inArray()) {
/* 3748 */       _reportMismatchedEndMarker(93, '}');
/*      */     }
/* 3750 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */   private final void _closeObjectScope() throws JsonParseException {
/* 3754 */     _updateLocation();
/* 3755 */     if (!this._parsingContext.inObject()) {
/* 3756 */       _reportMismatchedEndMarker(125, ']');
/*      */     }
/* 3758 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\core\json\UTF8StreamJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */