/*      */ package com.fasterxml.jackson.core.json.async;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.async.ByteArrayFeeder;
/*      */ import com.fasterxml.jackson.core.async.NonBlockingInputFeeder;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.VersionUtil;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ 
/*      */ 
/*      */ public class NonBlockingJsonParser
/*      */   extends NonBlockingJsonParserBase
/*      */   implements ByteArrayFeeder
/*      */ {
/*   19 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   23 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   34 */   protected byte[] _inputBuffer = NO_BYTES;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _origBufferLen;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NonBlockingJsonParser(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym) {
/*   57 */     super(ctxt, parserFeatures, sym);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayFeeder getNonBlockingInputFeeder() {
/*   68 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean needMoreInput() {
/*   73 */     return (this._inputPtr >= this._inputEnd && !this._endOfInput);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void feedInput(byte[] buf, int start, int end) throws IOException {
/*   80 */     if (this._inputPtr < this._inputEnd) {
/*   81 */       _reportError("Still have %d undecoded bytes, should not call 'feedInput'", Integer.valueOf(this._inputEnd - this._inputPtr));
/*      */     }
/*   83 */     if (end < start) {
/*   84 */       _reportError("Input end (%d) may not be before start (%d)", Integer.valueOf(end), Integer.valueOf(start));
/*      */     }
/*      */     
/*   87 */     if (this._endOfInput) {
/*   88 */       _reportError("Already closed, can not feed more input");
/*      */     }
/*      */     
/*   91 */     this._currInputProcessed += this._origBufferLen;
/*      */ 
/*      */     
/*   94 */     this._currInputRowStart = start - this._inputEnd - this._currInputRowStart;
/*      */ 
/*      */     
/*   97 */     this._currBufferStart = start;
/*   98 */     this._inputBuffer = buf;
/*   99 */     this._inputPtr = start;
/*  100 */     this._inputEnd = end;
/*  101 */     this._origBufferLen = end - start;
/*      */   }
/*      */ 
/*      */   
/*      */   public void endOfInput() {
/*  106 */     this._endOfInput = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  128 */     int avail = this._inputEnd - this._inputPtr;
/*  129 */     if (avail > 0) {
/*  130 */       out.write(this._inputBuffer, this._inputPtr, avail);
/*      */     }
/*  132 */     return avail;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/*  139 */     VersionUtil.throwInternal();
/*  140 */     return ' ';
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  154 */     if (this._inputPtr >= this._inputEnd) {
/*  155 */       if (this._closed) {
/*  156 */         return null;
/*      */       }
/*      */       
/*  159 */       if (this._endOfInput) {
/*      */ 
/*      */         
/*  162 */         if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  163 */           return _finishTokenWithEOF();
/*      */         }
/*  165 */         return _eofAsNextToken();
/*      */       } 
/*  167 */       return JsonToken.NOT_AVAILABLE;
/*      */     } 
/*      */     
/*  170 */     if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  171 */       return _finishToken();
/*      */     }
/*      */ 
/*      */     
/*  175 */     this._numTypesValid = 0;
/*  176 */     this._tokenInputTotal = this._currInputProcessed + this._inputPtr;
/*      */     
/*  178 */     this._binaryValue = null;
/*  179 */     int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     
/*  181 */     switch (this._majorState) {
/*      */       case 0:
/*  183 */         return _startDocument(ch);
/*      */       
/*      */       case 1:
/*  186 */         return _startValue(ch);
/*      */       
/*      */       case 2:
/*  189 */         return _startFieldName(ch);
/*      */       case 3:
/*  191 */         return _startFieldNameAfterComma(ch);
/*      */       
/*      */       case 4:
/*  194 */         return _startValueExpectColon(ch);
/*      */       
/*      */       case 5:
/*  197 */         return _startValue(ch);
/*      */       
/*      */       case 6:
/*  200 */         return _startValueExpectComma(ch);
/*      */     } 
/*      */ 
/*      */     
/*  204 */     VersionUtil.throwInternal();
/*  205 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishToken() throws IOException {
/*      */     int c;
/*  216 */     switch (this._minorState) {
/*      */       case 1:
/*  218 */         return _finishBOM(this._pending32);
/*      */       case 4:
/*  220 */         return _startFieldName(this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       case 5:
/*  222 */         return _startFieldNameAfterComma(this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */ 
/*      */       
/*      */       case 7:
/*  226 */         return _parseEscapedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */       case 8:
/*  228 */         return _finishFieldWithEscape();
/*      */       case 9:
/*  230 */         return _finishAposName(this._quadLength, this._pending32, this._pendingBytes);
/*      */       case 10:
/*  232 */         return _finishUnquotedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  237 */         return _startValue(this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       case 15:
/*  239 */         return _startValueAfterComma(this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       case 13:
/*  241 */         return _startValueExpectComma(this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       case 14:
/*  243 */         return _startValueExpectColon(this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       
/*      */       case 16:
/*  246 */         return _finishKeywordToken("null", this._pending32, JsonToken.VALUE_NULL);
/*      */       case 17:
/*  248 */         return _finishKeywordToken("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */       case 18:
/*  250 */         return _finishKeywordToken("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */       case 19:
/*  252 */         return _finishNonStdToken(this._nonStdTokenType, this._pending32);
/*      */       
/*      */       case 23:
/*  255 */         return _finishNumberMinus(this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       case 24:
/*  257 */         return _finishNumberLeadingZeroes();
/*      */       case 25:
/*  259 */         return _finishNumberLeadingNegZeroes();
/*      */       case 26:
/*  261 */         return _finishNumberIntegralPart(this._textBuffer.getBufferWithoutReset(), this._textBuffer
/*  262 */             .getCurrentSegmentSize());
/*      */       case 30:
/*  264 */         return _finishFloatFraction();
/*      */       case 31:
/*  266 */         return _finishFloatExponent(true, this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       case 32:
/*  268 */         return _finishFloatExponent(false, this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */       
/*      */       case 40:
/*  271 */         return _finishRegularString();
/*      */       case 42:
/*  273 */         this._textBuffer.append((char)_decodeUTF8_2(this._pending32, this._inputBuffer[this._inputPtr++]));
/*  274 */         if (this._minorStateAfterSplit == 45) {
/*  275 */           return _finishAposString();
/*      */         }
/*  277 */         return _finishRegularString();
/*      */       case 43:
/*  279 */         if (!_decodeSplitUTF8_3(this._pending32, this._pendingBytes, this._inputBuffer[this._inputPtr++])) {
/*  280 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  282 */         if (this._minorStateAfterSplit == 45) {
/*  283 */           return _finishAposString();
/*      */         }
/*  285 */         return _finishRegularString();
/*      */       case 44:
/*  287 */         if (!_decodeSplitUTF8_4(this._pending32, this._pendingBytes, this._inputBuffer[this._inputPtr++])) {
/*  288 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  290 */         if (this._minorStateAfterSplit == 45) {
/*  291 */           return _finishAposString();
/*      */         }
/*  293 */         return _finishRegularString();
/*      */ 
/*      */       
/*      */       case 41:
/*  297 */         c = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/*  298 */         if (c < 0) {
/*  299 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  301 */         this._textBuffer.append((char)c);
/*      */         
/*  303 */         if (this._minorStateAfterSplit == 45) {
/*  304 */           return _finishAposString();
/*      */         }
/*  306 */         return _finishRegularString();
/*      */       
/*      */       case 45:
/*  309 */         return _finishAposString();
/*      */       
/*      */       case 50:
/*  312 */         return _finishErrorToken();
/*      */ 
/*      */ 
/*      */       
/*      */       case 51:
/*  317 */         return _startSlashComment(this._pending32);
/*      */       case 52:
/*  319 */         return _finishCComment(this._pending32, true);
/*      */       case 53:
/*  321 */         return _finishCComment(this._pending32, false);
/*      */       case 54:
/*  323 */         return _finishCppComment(this._pending32);
/*      */       case 55:
/*  325 */         return _finishHashComment(this._pending32);
/*      */     } 
/*  327 */     VersionUtil.throwInternal();
/*  328 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishTokenWithEOF() throws IOException {
/*      */     int len;
/*  340 */     JsonToken t = this._currToken;
/*  341 */     switch (this._minorState) {
/*      */       case 3:
/*  343 */         return _eofAsNextToken();
/*      */       case 12:
/*  345 */         return _eofAsNextToken();
/*      */ 
/*      */       
/*      */       case 16:
/*  349 */         return _finishKeywordTokenWithEOF("null", this._pending32, JsonToken.VALUE_NULL);
/*      */       case 17:
/*  351 */         return _finishKeywordTokenWithEOF("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */       case 18:
/*  353 */         return _finishKeywordTokenWithEOF("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */       case 19:
/*  355 */         return _finishNonStdTokenWithEOF(this._nonStdTokenType, this._pending32);
/*      */       case 50:
/*  357 */         return _finishErrorTokenWithEOF();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*      */       case 25:
/*  364 */         return _valueCompleteInt(0, "0");
/*      */ 
/*      */       
/*      */       case 26:
/*  368 */         len = this._textBuffer.getCurrentSegmentSize();
/*  369 */         if (this._numberNegative) {
/*  370 */           len--;
/*      */         }
/*  372 */         this._intLength = len;
/*      */         
/*  374 */         return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */       
/*      */       case 30:
/*  377 */         this._expLength = 0;
/*      */       
/*      */       case 32:
/*  380 */         return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       
/*      */       case 31:
/*  383 */         _reportInvalidEOF(": was expecting fraction after exponent marker", JsonToken.VALUE_NUMBER_FLOAT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 52:
/*      */       case 53:
/*  391 */         _reportInvalidEOF(": was expecting closing '*/' for comment", JsonToken.NOT_AVAILABLE);
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*  396 */         return _eofAsNextToken();
/*      */     } 
/*      */ 
/*      */     
/*  400 */     _reportInvalidEOF(": was expecting rest of token (internal state: " + this._minorState + ")", this._currToken);
/*  401 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startDocument(int ch) throws IOException {
/*  412 */     ch &= 0xFF;
/*      */ 
/*      */     
/*  415 */     if (ch == 239 && this._minorState != 1) {
/*  416 */       return _finishBOM(1);
/*      */     }
/*      */ 
/*      */     
/*  420 */     while (ch <= 32) {
/*  421 */       if (ch != 32) {
/*  422 */         if (ch == 10) {
/*  423 */           this._currInputRow++;
/*  424 */           this._currInputRowStart = this._inputPtr;
/*  425 */         } else if (ch == 13) {
/*  426 */           this._currInputRowAlt++;
/*  427 */           this._currInputRowStart = this._inputPtr;
/*  428 */         } else if (ch != 9) {
/*  429 */           _throwInvalidSpace(ch);
/*      */         } 
/*      */       }
/*  432 */       if (this._inputPtr >= this._inputEnd) {
/*  433 */         this._minorState = 3;
/*  434 */         if (this._closed) {
/*  435 */           return null;
/*      */         }
/*      */         
/*  438 */         if (this._endOfInput) {
/*  439 */           return _eofAsNextToken();
/*      */         }
/*  441 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/*  443 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*  445 */     return _startValue(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishBOM(int bytesHandled) throws IOException {
/*  454 */     while (this._inputPtr < this._inputEnd) {
/*  455 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  456 */       switch (bytesHandled) {
/*      */ 
/*      */         
/*      */         case 3:
/*  460 */           this._currInputProcessed -= 3L;
/*  461 */           return _startDocument(ch);
/*      */         case 2:
/*  463 */           if (ch != 191) {
/*  464 */             _reportError("Unexpected byte 0x%02x following 0xEF 0xBB; should get 0xBF as third byte of UTF-8 BOM", Integer.valueOf(ch));
/*      */           }
/*      */           break;
/*      */         case 1:
/*  468 */           if (ch != 187) {
/*  469 */             _reportError("Unexpected byte 0x%02x following 0xEF; should get 0xBB as second byte UTF-8 BOM", Integer.valueOf(ch));
/*      */           }
/*      */           break;
/*      */       } 
/*  473 */       bytesHandled++;
/*      */     } 
/*  475 */     this._pending32 = bytesHandled;
/*  476 */     this._minorState = 1;
/*  477 */     return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startFieldName(int ch) throws IOException {
/*  493 */     if (ch <= 32) {
/*  494 */       ch = _skipWS(ch);
/*  495 */       if (ch <= 0) {
/*  496 */         this._minorState = 4;
/*  497 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  500 */     _updateTokenLocation();
/*  501 */     if (ch != 34) {
/*  502 */       if (ch == 125) {
/*  503 */         return _closeObjectScope();
/*      */       }
/*  505 */       return _handleOddName(ch);
/*      */     } 
/*      */     
/*  508 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  509 */       String n = _fastParseName();
/*  510 */       if (n != null) {
/*  511 */         return _fieldComplete(n);
/*      */       }
/*      */     } 
/*  514 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startFieldNameAfterComma(int ch) throws IOException {
/*  520 */     if (ch <= 32) {
/*  521 */       ch = _skipWS(ch);
/*  522 */       if (ch <= 0) {
/*  523 */         this._minorState = 5;
/*  524 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  527 */     if (ch != 44) {
/*  528 */       if (ch == 125) {
/*  529 */         return _closeObjectScope();
/*      */       }
/*  531 */       if (ch == 35) {
/*  532 */         return _finishHashComment(5);
/*      */       }
/*  534 */       if (ch == 47) {
/*  535 */         return _startSlashComment(5);
/*      */       }
/*  537 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     } 
/*  539 */     int ptr = this._inputPtr;
/*  540 */     if (ptr >= this._inputEnd) {
/*  541 */       this._minorState = 4;
/*  542 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  544 */     ch = this._inputBuffer[ptr];
/*  545 */     this._inputPtr = ptr + 1;
/*  546 */     if (ch <= 32) {
/*  547 */       ch = _skipWS(ch);
/*  548 */       if (ch <= 0) {
/*  549 */         this._minorState = 4;
/*  550 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  553 */     _updateTokenLocation();
/*  554 */     if (ch != 34) {
/*  555 */       if (ch == 125 && 
/*  556 */         JsonParser.Feature.ALLOW_TRAILING_COMMA.enabledIn(this._features)) {
/*  557 */         return _closeObjectScope();
/*      */       }
/*      */       
/*  560 */       return _handleOddName(ch);
/*      */     } 
/*      */     
/*  563 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  564 */       String n = _fastParseName();
/*  565 */       if (n != null) {
/*  566 */         return _fieldComplete(n);
/*      */       }
/*      */     } 
/*  569 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValue(int ch) throws IOException {
/*  586 */     if (ch <= 32) {
/*  587 */       ch = _skipWS(ch);
/*  588 */       if (ch <= 0) {
/*  589 */         this._minorState = 12;
/*  590 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  593 */     _updateTokenLocation();
/*  594 */     if (ch == 34) {
/*  595 */       return _startString();
/*      */     }
/*  597 */     switch (ch) {
/*      */       case 35:
/*  599 */         return _finishHashComment(12);
/*      */       case 45:
/*  601 */         return _startNegativeNumber();
/*      */       case 47:
/*  603 */         return _startSlashComment(12);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  609 */         return _startNumberLeadingZero();
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  619 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  621 */         return _startFalseToken();
/*      */       case 110:
/*  623 */         return _startNullToken();
/*      */       case 116:
/*  625 */         return _startTrueToken();
/*      */       case 91:
/*  627 */         return _startArrayScope();
/*      */       case 93:
/*  629 */         return _closeArrayScope();
/*      */       case 123:
/*  631 */         return _startObjectScope();
/*      */       case 125:
/*  633 */         return _closeObjectScope();
/*      */     } 
/*      */     
/*  636 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueExpectComma(int ch) throws IOException {
/*  646 */     if (ch <= 32) {
/*  647 */       ch = _skipWS(ch);
/*  648 */       if (ch <= 0) {
/*  649 */         this._minorState = 13;
/*  650 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  653 */     if (ch != 44) {
/*  654 */       if (ch == 93) {
/*  655 */         return _closeArrayScope();
/*      */       }
/*  657 */       if (ch == 125) {
/*  658 */         return _closeObjectScope();
/*      */       }
/*  660 */       if (ch == 47) {
/*  661 */         return _startSlashComment(13);
/*      */       }
/*  663 */       if (ch == 35) {
/*  664 */         return _finishHashComment(13);
/*      */       }
/*  666 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     } 
/*  668 */     int ptr = this._inputPtr;
/*  669 */     if (ptr >= this._inputEnd) {
/*  670 */       this._minorState = 15;
/*  671 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  673 */     ch = this._inputBuffer[ptr];
/*  674 */     this._inputPtr = ptr + 1;
/*  675 */     if (ch <= 32) {
/*  676 */       ch = _skipWS(ch);
/*  677 */       if (ch <= 0) {
/*  678 */         this._minorState = 15;
/*  679 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  682 */     _updateTokenLocation();
/*  683 */     if (ch == 34) {
/*  684 */       return _startString();
/*      */     }
/*  686 */     switch (ch) {
/*      */       case 35:
/*  688 */         return _finishHashComment(15);
/*      */       case 45:
/*  690 */         return _startNegativeNumber();
/*      */       case 47:
/*  692 */         return _startSlashComment(15);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  698 */         return _startNumberLeadingZero();
/*      */       case 49: case 50: case 51: case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  705 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  707 */         return _startFalseToken();
/*      */       case 110:
/*  709 */         return _startNullToken();
/*      */       case 116:
/*  711 */         return _startTrueToken();
/*      */       case 91:
/*  713 */         return _startArrayScope();
/*      */       
/*      */       case 93:
/*  716 */         if (isEnabled(JsonParser.Feature.ALLOW_TRAILING_COMMA)) {
/*  717 */           return _closeArrayScope();
/*      */         }
/*      */         break;
/*      */       case 123:
/*  721 */         return _startObjectScope();
/*      */       
/*      */       case 125:
/*  724 */         if (isEnabled(JsonParser.Feature.ALLOW_TRAILING_COMMA)) {
/*  725 */           return _closeObjectScope();
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  730 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueExpectColon(int ch) throws IOException {
/*  741 */     if (ch <= 32) {
/*  742 */       ch = _skipWS(ch);
/*  743 */       if (ch <= 0) {
/*  744 */         this._minorState = 14;
/*  745 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  748 */     if (ch != 58) {
/*  749 */       if (ch == 47) {
/*  750 */         return _startSlashComment(14);
/*      */       }
/*  752 */       if (ch == 35) {
/*  753 */         return _finishHashComment(14);
/*      */       }
/*      */       
/*  756 */       _reportUnexpectedChar(ch, "was expecting a colon to separate field name and value");
/*      */     } 
/*  758 */     int ptr = this._inputPtr;
/*  759 */     if (ptr >= this._inputEnd) {
/*  760 */       this._minorState = 12;
/*  761 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  763 */     ch = this._inputBuffer[ptr];
/*  764 */     this._inputPtr = ptr + 1;
/*  765 */     if (ch <= 32) {
/*  766 */       ch = _skipWS(ch);
/*  767 */       if (ch <= 0) {
/*  768 */         this._minorState = 12;
/*  769 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  772 */     _updateTokenLocation();
/*  773 */     if (ch == 34) {
/*  774 */       return _startString();
/*      */     }
/*  776 */     switch (ch) {
/*      */       case 35:
/*  778 */         return _finishHashComment(12);
/*      */       case 45:
/*  780 */         return _startNegativeNumber();
/*      */       case 47:
/*  782 */         return _startSlashComment(12);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  788 */         return _startNumberLeadingZero();
/*      */       case 49: case 50: case 51: case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  795 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  797 */         return _startFalseToken();
/*      */       case 110:
/*  799 */         return _startNullToken();
/*      */       case 116:
/*  801 */         return _startTrueToken();
/*      */       case 91:
/*  803 */         return _startArrayScope();
/*      */       case 123:
/*  805 */         return _startObjectScope();
/*      */     } 
/*      */     
/*  808 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueAfterComma(int ch) throws IOException {
/*  816 */     if (ch <= 32) {
/*  817 */       ch = _skipWS(ch);
/*  818 */       if (ch <= 0) {
/*  819 */         this._minorState = 15;
/*  820 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  823 */     _updateTokenLocation();
/*  824 */     if (ch == 34) {
/*  825 */       return _startString();
/*      */     }
/*  827 */     switch (ch) {
/*      */       case 35:
/*  829 */         return _finishHashComment(15);
/*      */       case 45:
/*  831 */         return _startNegativeNumber();
/*      */       case 47:
/*  833 */         return _startSlashComment(15);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  839 */         return _startNumberLeadingZero();
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  849 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  851 */         return _startFalseToken();
/*      */       case 110:
/*  853 */         return _startNullToken();
/*      */       case 116:
/*  855 */         return _startTrueToken();
/*      */       case 91:
/*  857 */         return _startArrayScope();
/*      */       
/*      */       case 93:
/*  860 */         if (isEnabled(JsonParser.Feature.ALLOW_TRAILING_COMMA)) {
/*  861 */           return _closeArrayScope();
/*      */         }
/*      */         break;
/*      */       case 123:
/*  865 */         return _startObjectScope();
/*      */       
/*      */       case 125:
/*  868 */         if (isEnabled(JsonParser.Feature.ALLOW_TRAILING_COMMA)) {
/*  869 */           return _closeObjectScope();
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  874 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startUnexpectedValue(boolean leadingComma, int ch) throws IOException {
/*  879 */     switch (ch) {
/*      */       case 93:
/*  881 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/*  889 */         if (isEnabled(JsonParser.Feature.ALLOW_MISSING_VALUES)) {
/*  890 */           this._inputPtr--;
/*  891 */           return _valueComplete(JsonToken.VALUE_NULL);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/*  899 */         if (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/*  900 */           return _startAposString();
/*      */         }
/*      */         break;
/*      */       case 43:
/*  904 */         return _finishNonStdToken(2, 1);
/*      */       case 78:
/*  906 */         return _finishNonStdToken(0, 1);
/*      */       case 73:
/*  908 */         return _finishNonStdToken(1, 1);
/*      */     } 
/*      */     
/*  911 */     _reportUnexpectedChar(ch, "expected a valid value (number, String, array, object, 'true', 'false' or 'null')");
/*  912 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS(int ch) throws IOException {
/*      */     while (true) {
/*  924 */       if (ch != 32) {
/*  925 */         if (ch == 10) {
/*  926 */           this._currInputRow++;
/*  927 */           this._currInputRowStart = this._inputPtr;
/*  928 */         } else if (ch == 13) {
/*  929 */           this._currInputRowAlt++;
/*  930 */           this._currInputRowStart = this._inputPtr;
/*  931 */         } else if (ch != 9) {
/*  932 */           _throwInvalidSpace(ch);
/*      */         } 
/*      */       }
/*  935 */       if (this._inputPtr >= this._inputEnd) {
/*  936 */         this._currToken = JsonToken.NOT_AVAILABLE;
/*  937 */         return 0;
/*      */       } 
/*  939 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  940 */       if (ch > 32)
/*  941 */         return ch; 
/*      */     } 
/*      */   }
/*      */   
/*      */   private final JsonToken _startSlashComment(int fromMinorState) throws IOException {
/*  946 */     if (!JsonParser.Feature.ALLOW_COMMENTS.enabledIn(this._features)) {
/*  947 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */ 
/*      */     
/*  951 */     if (this._inputPtr >= this._inputEnd) {
/*  952 */       this._pending32 = fromMinorState;
/*  953 */       this._minorState = 51;
/*  954 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*  956 */     int ch = this._inputBuffer[this._inputPtr++];
/*  957 */     if (ch == 42) {
/*  958 */       return _finishCComment(fromMinorState, false);
/*      */     }
/*  960 */     if (ch == 47) {
/*  961 */       return _finishCppComment(fromMinorState);
/*      */     }
/*  963 */     _reportUnexpectedChar(ch & 0xFF, "was expecting either '*' or '/' for a comment");
/*  964 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishHashComment(int fromMinorState) throws IOException {
/*  970 */     if (!JsonParser.Feature.ALLOW_YAML_COMMENTS.enabledIn(this._features)) {
/*  971 */       _reportUnexpectedChar(35, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_YAML_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     while (true) {
/*  974 */       if (this._inputPtr >= this._inputEnd) {
/*  975 */         this._minorState = 55;
/*  976 */         this._pending32 = fromMinorState;
/*  977 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/*  979 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  980 */       if (ch < 32) {
/*  981 */         if (ch == 10) {
/*  982 */           this._currInputRow++;
/*  983 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/*  985 */         if (ch == 13) {
/*  986 */           this._currInputRowAlt++;
/*  987 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/*  989 */         if (ch != 9) {
/*  990 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       } 
/*      */     } 
/*  994 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _finishCppComment(int fromMinorState) throws IOException {
/*      */     while (true) {
/* 1000 */       if (this._inputPtr >= this._inputEnd) {
/* 1001 */         this._minorState = 54;
/* 1002 */         this._pending32 = fromMinorState;
/* 1003 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1005 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1006 */       if (ch < 32) {
/* 1007 */         if (ch == 10) {
/* 1008 */           this._currInputRow++;
/* 1009 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1011 */         if (ch == 13) {
/* 1012 */           this._currInputRowAlt++;
/* 1013 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1015 */         if (ch != 9) {
/* 1016 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       } 
/*      */     } 
/* 1020 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _finishCComment(int fromMinorState, boolean gotStar) throws IOException {
/*      */     while (true) {
/* 1026 */       if (this._inputPtr >= this._inputEnd) {
/* 1027 */         this._minorState = gotStar ? 52 : 53;
/* 1028 */         this._pending32 = fromMinorState;
/* 1029 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1031 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1032 */       if (ch < 32)
/* 1033 */       { if (ch == 10) {
/* 1034 */           this._currInputRow++;
/* 1035 */           this._currInputRowStart = this._inputPtr;
/* 1036 */         } else if (ch == 13) {
/* 1037 */           this._currInputRowAlt++;
/* 1038 */           this._currInputRowStart = this._inputPtr;
/* 1039 */         } else if (ch != 9) {
/* 1040 */           _throwInvalidSpace(ch);
/*      */         }  }
/* 1042 */       else { if (ch == 42) {
/* 1043 */           gotStar = true; continue;
/*      */         } 
/* 1045 */         if (ch == 47 && 
/* 1046 */           gotStar) {
/*      */           break;
/*      */         } }
/*      */       
/* 1050 */       gotStar = false;
/*      */     } 
/* 1052 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startAfterComment(int fromMinorState) throws IOException {
/* 1058 */     if (this._inputPtr >= this._inputEnd) {
/* 1059 */       this._minorState = fromMinorState;
/* 1060 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1062 */     int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1063 */     switch (fromMinorState) {
/*      */       case 4:
/* 1065 */         return _startFieldName(ch);
/*      */       case 5:
/* 1067 */         return _startFieldNameAfterComma(ch);
/*      */       case 12:
/* 1069 */         return _startValue(ch);
/*      */       case 13:
/* 1071 */         return _startValueExpectComma(ch);
/*      */       case 14:
/* 1073 */         return _startValueExpectColon(ch);
/*      */       case 15:
/* 1075 */         return _startValueAfterComma(ch);
/*      */     } 
/*      */     
/* 1078 */     VersionUtil.throwInternal();
/* 1079 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startFalseToken() throws IOException {
/* 1090 */     int ptr = this._inputPtr;
/* 1091 */     if (ptr + 4 < this._inputEnd) {
/* 1092 */       byte[] buf = this._inputBuffer;
/* 1093 */       if (buf[ptr++] == 97 && buf[ptr++] == 108 && buf[ptr++] == 115 && buf[ptr++] == 101) {
/*      */ 
/*      */ 
/*      */         
/* 1097 */         int ch = buf[ptr] & 0xFF;
/* 1098 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 1099 */           this._inputPtr = ptr;
/* 1100 */           return _valueComplete(JsonToken.VALUE_FALSE);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1104 */     this._minorState = 18;
/* 1105 */     return _finishKeywordToken("false", 1, JsonToken.VALUE_FALSE);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startTrueToken() throws IOException {
/* 1110 */     int ptr = this._inputPtr;
/* 1111 */     if (ptr + 3 < this._inputEnd) {
/* 1112 */       byte[] buf = this._inputBuffer;
/* 1113 */       if (buf[ptr++] == 114 && buf[ptr++] == 117 && buf[ptr++] == 101) {
/*      */ 
/*      */         
/* 1116 */         int ch = buf[ptr] & 0xFF;
/* 1117 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 1118 */           this._inputPtr = ptr;
/* 1119 */           return _valueComplete(JsonToken.VALUE_TRUE);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1123 */     this._minorState = 17;
/* 1124 */     return _finishKeywordToken("true", 1, JsonToken.VALUE_TRUE);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNullToken() throws IOException {
/* 1129 */     int ptr = this._inputPtr;
/* 1130 */     if (ptr + 3 < this._inputEnd) {
/* 1131 */       byte[] buf = this._inputBuffer;
/* 1132 */       if (buf[ptr++] == 117 && buf[ptr++] == 108 && buf[ptr++] == 108) {
/*      */ 
/*      */         
/* 1135 */         int ch = buf[ptr] & 0xFF;
/* 1136 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 1137 */           this._inputPtr = ptr;
/* 1138 */           return _valueComplete(JsonToken.VALUE_NULL);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1142 */     this._minorState = 16;
/* 1143 */     return _finishKeywordToken("null", 1, JsonToken.VALUE_NULL);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishKeywordToken(String expToken, int matched, JsonToken result) throws IOException {
/* 1149 */     int end = expToken.length();
/*      */     
/*      */     while (true) {
/* 1152 */       if (this._inputPtr >= this._inputEnd) {
/* 1153 */         this._pending32 = matched;
/* 1154 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1156 */       int ch = this._inputBuffer[this._inputPtr];
/* 1157 */       if (matched == end) {
/* 1158 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 1159 */           return _valueComplete(result);
/*      */         }
/*      */         break;
/*      */       } 
/* 1163 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1166 */       matched++;
/* 1167 */       this._inputPtr++;
/*      */     } 
/* 1169 */     this._minorState = 50;
/* 1170 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1171 */     return _finishErrorToken();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishKeywordTokenWithEOF(String expToken, int matched, JsonToken result) throws IOException {
/* 1177 */     if (matched == expToken.length()) {
/* 1178 */       return this._currToken = result;
/*      */     }
/* 1180 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1181 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNonStdToken(int type, int matched) throws IOException {
/* 1186 */     String expToken = _nonStdToken(type);
/* 1187 */     int end = expToken.length();
/*      */     
/*      */     while (true) {
/* 1190 */       if (this._inputPtr >= this._inputEnd) {
/* 1191 */         this._nonStdTokenType = type;
/* 1192 */         this._pending32 = matched;
/* 1193 */         this._minorState = 19;
/* 1194 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1196 */       int ch = this._inputBuffer[this._inputPtr];
/* 1197 */       if (matched == end) {
/* 1198 */         if (ch < 48 || ch == 93 || ch == 125) {
/* 1199 */           return _valueNonStdNumberComplete(type);
/*      */         }
/*      */         break;
/*      */       } 
/* 1203 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1206 */       matched++;
/* 1207 */       this._inputPtr++;
/*      */     } 
/* 1209 */     this._minorState = 50;
/* 1210 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1211 */     return _finishErrorToken();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNonStdTokenWithEOF(int type, int matched) throws IOException {
/* 1216 */     String expToken = _nonStdToken(type);
/* 1217 */     if (matched == expToken.length()) {
/* 1218 */       return _valueNonStdNumberComplete(type);
/*      */     }
/* 1220 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1221 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishErrorToken() throws IOException {
/* 1226 */     while (this._inputPtr < this._inputEnd) {
/* 1227 */       int i = this._inputBuffer[this._inputPtr++];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1232 */       char ch = (char)i;
/* 1233 */       if (Character.isJavaIdentifierPart(ch)) {
/*      */ 
/*      */         
/* 1236 */         this._textBuffer.append(ch);
/* 1237 */         if (this._textBuffer.size() < 256) {
/*      */           continue;
/*      */         }
/*      */       } 
/* 1241 */       return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */     } 
/* 1243 */     return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishErrorTokenWithEOF() throws IOException {
/* 1248 */     return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _reportErrorToken(String actualToken) throws IOException {
/* 1254 */     _reportError("Unrecognized token '%s': was expecting %s", this._textBuffer.contentsAsString(), "'null', 'true' or 'false'");
/*      */     
/* 1256 */     return JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startPositiveNumber(int ch) throws IOException {
/* 1267 */     this._numberNegative = false;
/* 1268 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1269 */     outBuf[0] = (char)ch;
/*      */     
/* 1271 */     if (this._inputPtr >= this._inputEnd) {
/* 1272 */       this._minorState = 26;
/* 1273 */       this._textBuffer.setCurrentLength(1);
/* 1274 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*      */     
/* 1277 */     int outPtr = 1;
/*      */     
/* 1279 */     ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     while (true) {
/* 1281 */       if (ch < 48) {
/* 1282 */         if (ch == 46) {
/* 1283 */           this._intLength = outPtr;
/* 1284 */           this._inputPtr++;
/* 1285 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1289 */       if (ch > 57) {
/* 1290 */         if (ch == 101 || ch == 69) {
/* 1291 */           this._intLength = outPtr;
/* 1292 */           this._inputPtr++;
/* 1293 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1297 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */         
/* 1300 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1302 */       outBuf[outPtr++] = (char)ch;
/* 1303 */       if (++this._inputPtr >= this._inputEnd) {
/* 1304 */         this._minorState = 26;
/* 1305 */         this._textBuffer.setCurrentLength(outPtr);
/* 1306 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1308 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     } 
/* 1310 */     this._intLength = outPtr;
/* 1311 */     this._textBuffer.setCurrentLength(outPtr);
/* 1312 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNegativeNumber() throws IOException {
/* 1317 */     this._numberNegative = true;
/* 1318 */     if (this._inputPtr >= this._inputEnd) {
/* 1319 */       this._minorState = 23;
/* 1320 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1322 */     int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1323 */     if (ch <= 48) {
/* 1324 */       if (ch == 48) {
/* 1325 */         return _finishNumberLeadingNegZeroes();
/*      */       }
/*      */       
/* 1328 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1329 */     } else if (ch > 57) {
/* 1330 */       if (ch == 73) {
/* 1331 */         return _finishNonStdToken(3, 2);
/*      */       }
/* 1333 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/*      */     } 
/* 1335 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1336 */     outBuf[0] = '-';
/* 1337 */     outBuf[1] = (char)ch;
/* 1338 */     if (this._inputPtr >= this._inputEnd) {
/* 1339 */       this._minorState = 26;
/* 1340 */       this._textBuffer.setCurrentLength(2);
/* 1341 */       this._intLength = 1;
/* 1342 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 1344 */     ch = this._inputBuffer[this._inputPtr];
/* 1345 */     int outPtr = 2;
/*      */     
/*      */     while (true) {
/* 1348 */       if (ch < 48) {
/* 1349 */         if (ch == 46) {
/* 1350 */           this._intLength = outPtr - 1;
/* 1351 */           this._inputPtr++;
/* 1352 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1356 */       if (ch > 57) {
/* 1357 */         if (ch == 101 || ch == 69) {
/* 1358 */           this._intLength = outPtr - 1;
/* 1359 */           this._inputPtr++;
/* 1360 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1364 */       if (outPtr >= outBuf.length)
/*      */       {
/* 1366 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1368 */       outBuf[outPtr++] = (char)ch;
/* 1369 */       if (++this._inputPtr >= this._inputEnd) {
/* 1370 */         this._minorState = 26;
/* 1371 */         this._textBuffer.setCurrentLength(outPtr);
/* 1372 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1374 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     } 
/* 1376 */     this._intLength = outPtr - 1;
/* 1377 */     this._textBuffer.setCurrentLength(outPtr);
/* 1378 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNumberLeadingZero() throws IOException {
/* 1383 */     int ptr = this._inputPtr;
/* 1384 */     if (ptr >= this._inputEnd) {
/* 1385 */       this._minorState = 24;
/* 1386 */       return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1393 */     int ch = this._inputBuffer[ptr++] & 0xFF;
/*      */     
/* 1395 */     if (ch < 48) {
/* 1396 */       if (ch == 46) {
/* 1397 */         this._inputPtr = ptr;
/* 1398 */         this._intLength = 1;
/* 1399 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1400 */         outBuf[0] = '0';
/* 1401 */         return _startFloat(outBuf, 1, ch);
/*      */       } 
/* 1403 */     } else if (ch > 57) {
/* 1404 */       if (ch == 101 || ch == 69) {
/* 1405 */         this._inputPtr = ptr;
/* 1406 */         this._intLength = 1;
/* 1407 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1408 */         outBuf[0] = '0';
/* 1409 */         return _startFloat(outBuf, 1, ch);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1414 */       if (ch != 93 && ch != 125) {
/* 1415 */         reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1420 */       return _finishNumberLeadingZeroes();
/*      */     } 
/*      */     
/* 1423 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberMinus(int ch) throws IOException {
/* 1428 */     if (ch <= 48) {
/* 1429 */       if (ch == 48) {
/* 1430 */         return _finishNumberLeadingNegZeroes();
/*      */       }
/* 1432 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1433 */     } else if (ch > 57) {
/* 1434 */       if (ch == 73) {
/* 1435 */         return _finishNonStdToken(3, 2);
/*      */       }
/* 1437 */       reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/*      */     } 
/* 1439 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1440 */     outBuf[0] = '-';
/* 1441 */     outBuf[1] = (char)ch;
/* 1442 */     this._intLength = 1;
/* 1443 */     return _finishNumberIntegralPart(outBuf, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingZeroes() throws IOException {
/*      */     while (true) {
/* 1451 */       if (this._inputPtr >= this._inputEnd) {
/* 1452 */         this._minorState = 24;
/* 1453 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1455 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1456 */       if (ch < 48) {
/* 1457 */         if (ch == 46) {
/* 1458 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1459 */           arrayOfChar[0] = '0';
/* 1460 */           this._intLength = 1;
/* 1461 */           return _startFloat(arrayOfChar, 1, ch);
/*      */         }  break;
/* 1463 */       }  if (ch > 57) {
/* 1464 */         if (ch == 101 || ch == 69) {
/* 1465 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1466 */           arrayOfChar[0] = '0';
/* 1467 */           this._intLength = 1;
/* 1468 */           return _startFloat(arrayOfChar, 1, ch);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1473 */         if (ch != 93 && ch != 125) {
/* 1474 */           reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1480 */       if (!isEnabled(JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS)) {
/* 1481 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1483 */       if (ch == 48) {
/*      */         continue;
/*      */       }
/* 1486 */       char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */       
/* 1488 */       outBuf[0] = (char)ch;
/* 1489 */       this._intLength = 1;
/* 1490 */       return _finishNumberIntegralPart(outBuf, 1);
/*      */     } 
/* 1492 */     this._inputPtr--;
/* 1493 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingNegZeroes() throws IOException {
/*      */     while (true) {
/* 1502 */       if (this._inputPtr >= this._inputEnd) {
/* 1503 */         this._minorState = 25;
/* 1504 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1506 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1507 */       if (ch < 48) {
/* 1508 */         if (ch == 46) {
/* 1509 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1510 */           arrayOfChar[0] = '-';
/* 1511 */           arrayOfChar[1] = '0';
/* 1512 */           this._intLength = 1;
/* 1513 */           return _startFloat(arrayOfChar, 2, ch);
/*      */         }  break;
/* 1515 */       }  if (ch > 57) {
/* 1516 */         if (ch == 101 || ch == 69) {
/* 1517 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1518 */           arrayOfChar[0] = '-';
/* 1519 */           arrayOfChar[1] = '0';
/* 1520 */           this._intLength = 1;
/* 1521 */           return _startFloat(arrayOfChar, 2, ch);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1526 */         if (ch != 93 && ch != 125) {
/* 1527 */           reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1533 */       if (!isEnabled(JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS)) {
/* 1534 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1536 */       if (ch == 48) {
/*      */         continue;
/*      */       }
/* 1539 */       char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */       
/* 1541 */       outBuf[0] = '-';
/* 1542 */       outBuf[1] = (char)ch;
/* 1543 */       this._intLength = 1;
/* 1544 */       return _finishNumberIntegralPart(outBuf, 2);
/*      */     } 
/* 1546 */     this._inputPtr--;
/* 1547 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberIntegralPart(char[] outBuf, int outPtr) throws IOException {
/* 1553 */     int negMod = this._numberNegative ? -1 : 0;
/*      */     
/*      */     while (true) {
/* 1556 */       if (this._inputPtr >= this._inputEnd) {
/* 1557 */         this._minorState = 26;
/* 1558 */         this._textBuffer.setCurrentLength(outPtr);
/* 1559 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1561 */       int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1562 */       if (ch < 48) {
/* 1563 */         if (ch == 46) {
/* 1564 */           this._intLength = outPtr + negMod;
/* 1565 */           this._inputPtr++;
/* 1566 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1570 */       if (ch > 57) {
/* 1571 */         if (ch == 101 || ch == 69) {
/* 1572 */           this._intLength = outPtr + negMod;
/* 1573 */           this._inputPtr++;
/* 1574 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1578 */       this._inputPtr++;
/* 1579 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */         
/* 1582 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1584 */       outBuf[outPtr++] = (char)ch;
/*      */     } 
/* 1586 */     this._intLength = outPtr + negMod;
/* 1587 */     this._textBuffer.setCurrentLength(outPtr);
/* 1588 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startFloat(char[] outBuf, int outPtr, int ch) throws IOException {
/* 1593 */     int fractLen = 0;
/* 1594 */     if (ch == 46) {
/* 1595 */       if (outPtr >= outBuf.length) {
/* 1596 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1598 */       outBuf[outPtr++] = '.';
/*      */       while (true) {
/* 1600 */         if (this._inputPtr >= this._inputEnd) {
/* 1601 */           this._textBuffer.setCurrentLength(outPtr);
/* 1602 */           this._minorState = 30;
/* 1603 */           this._fractLength = fractLen;
/* 1604 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1606 */         ch = this._inputBuffer[this._inputPtr++];
/* 1607 */         if (ch < 48 || ch > 57) {
/* 1608 */           ch &= 0xFF;
/*      */           
/* 1610 */           if (fractLen == 0) {
/* 1611 */             reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */           }
/*      */           break;
/*      */         } 
/* 1615 */         if (outPtr >= outBuf.length) {
/* 1616 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1618 */         outBuf[outPtr++] = (char)ch;
/* 1619 */         fractLen++;
/*      */       } 
/*      */     } 
/* 1622 */     this._fractLength = fractLen;
/* 1623 */     int expLen = 0;
/* 1624 */     if (ch == 101 || ch == 69) {
/* 1625 */       if (outPtr >= outBuf.length) {
/* 1626 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1628 */       outBuf[outPtr++] = (char)ch;
/* 1629 */       if (this._inputPtr >= this._inputEnd) {
/* 1630 */         this._textBuffer.setCurrentLength(outPtr);
/* 1631 */         this._minorState = 31;
/* 1632 */         this._expLength = 0;
/* 1633 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1635 */       ch = this._inputBuffer[this._inputPtr++];
/* 1636 */       if (ch == 45 || ch == 43) {
/* 1637 */         if (outPtr >= outBuf.length) {
/* 1638 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1640 */         outBuf[outPtr++] = (char)ch;
/* 1641 */         if (this._inputPtr >= this._inputEnd) {
/* 1642 */           this._textBuffer.setCurrentLength(outPtr);
/* 1643 */           this._minorState = 32;
/* 1644 */           this._expLength = 0;
/* 1645 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1647 */         ch = this._inputBuffer[this._inputPtr++];
/*      */       } 
/* 1649 */       while (ch >= 48 && ch <= 57) {
/* 1650 */         expLen++;
/* 1651 */         if (outPtr >= outBuf.length) {
/* 1652 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1654 */         outBuf[outPtr++] = (char)ch;
/* 1655 */         if (this._inputPtr >= this._inputEnd) {
/* 1656 */           this._textBuffer.setCurrentLength(outPtr);
/* 1657 */           this._minorState = 32;
/* 1658 */           this._expLength = expLen;
/* 1659 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1661 */         ch = this._inputBuffer[this._inputPtr++];
/*      */       } 
/*      */       
/* 1664 */       ch &= 0xFF;
/* 1665 */       if (expLen == 0) {
/* 1666 */         reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1670 */     this._inputPtr--;
/* 1671 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1673 */     this._expLength = expLen;
/* 1674 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishFloatFraction() throws IOException {
/* 1679 */     int fractLen = this._fractLength;
/* 1680 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1681 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     int ch;
/*      */     
/* 1685 */     while ((ch = this._inputBuffer[this._inputPtr++]) >= 48 && ch <= 57) {
/* 1686 */       fractLen++;
/* 1687 */       if (outPtr >= outBuf.length) {
/* 1688 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1690 */       outBuf[outPtr++] = (char)ch;
/* 1691 */       if (this._inputPtr >= this._inputEnd) {
/* 1692 */         this._textBuffer.setCurrentLength(outPtr);
/* 1693 */         this._fractLength = fractLen;
/* 1694 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1700 */     if (fractLen == 0) {
/* 1701 */       reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */     }
/* 1703 */     this._fractLength = fractLen;
/* 1704 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1707 */     if (ch == 101 || ch == 69) {
/* 1708 */       this._textBuffer.append((char)ch);
/* 1709 */       this._expLength = 0;
/* 1710 */       if (this._inputPtr >= this._inputEnd) {
/* 1711 */         this._minorState = 31;
/* 1712 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1714 */       this._minorState = 32;
/* 1715 */       return _finishFloatExponent(true, this._inputBuffer[this._inputPtr++] & 0xFF);
/*      */     } 
/*      */ 
/*      */     
/* 1719 */     this._inputPtr--;
/* 1720 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1722 */     this._expLength = 0;
/* 1723 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishFloatExponent(boolean checkSign, int ch) throws IOException {
/* 1728 */     if (checkSign) {
/* 1729 */       this._minorState = 32;
/* 1730 */       if (ch == 45 || ch == 43) {
/* 1731 */         this._textBuffer.append((char)ch);
/* 1732 */         if (this._inputPtr >= this._inputEnd) {
/* 1733 */           this._minorState = 32;
/* 1734 */           this._expLength = 0;
/* 1735 */           return JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1737 */         ch = this._inputBuffer[this._inputPtr++];
/*      */       } 
/*      */     } 
/*      */     
/* 1741 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1742 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 1743 */     int expLen = this._expLength;
/*      */     
/* 1745 */     while (ch >= 48 && ch <= 57) {
/* 1746 */       expLen++;
/* 1747 */       if (outPtr >= outBuf.length) {
/* 1748 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1750 */       outBuf[outPtr++] = (char)ch;
/* 1751 */       if (this._inputPtr >= this._inputEnd) {
/* 1752 */         this._textBuffer.setCurrentLength(outPtr);
/* 1753 */         this._expLength = expLen;
/* 1754 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1756 */       ch = this._inputBuffer[this._inputPtr++];
/*      */     } 
/*      */     
/* 1759 */     ch &= 0xFF;
/* 1760 */     if (expLen == 0) {
/* 1761 */       reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */     }
/*      */     
/* 1764 */     this._inputPtr--;
/* 1765 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1767 */     this._expLength = expLen;
/* 1768 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String _fastParseName() throws IOException {
/* 1784 */     byte[] input = this._inputBuffer;
/* 1785 */     int[] codes = _icLatin1;
/* 1786 */     int ptr = this._inputPtr;
/*      */     
/* 1788 */     int q0 = input[ptr++] & 0xFF;
/* 1789 */     if (codes[q0] == 0) {
/* 1790 */       int i = input[ptr++] & 0xFF;
/* 1791 */       if (codes[i] == 0) {
/* 1792 */         int q = q0 << 8 | i;
/* 1793 */         i = input[ptr++] & 0xFF;
/* 1794 */         if (codes[i] == 0) {
/* 1795 */           q = q << 8 | i;
/* 1796 */           i = input[ptr++] & 0xFF;
/* 1797 */           if (codes[i] == 0) {
/* 1798 */             q = q << 8 | i;
/* 1799 */             i = input[ptr++] & 0xFF;
/* 1800 */             if (codes[i] == 0) {
/* 1801 */               this._quad1 = q;
/* 1802 */               return _parseMediumName(ptr, i);
/*      */             } 
/* 1804 */             if (i == 34) {
/* 1805 */               this._inputPtr = ptr;
/* 1806 */               return _findName(q, 4);
/*      */             } 
/* 1808 */             return null;
/*      */           } 
/* 1810 */           if (i == 34) {
/* 1811 */             this._inputPtr = ptr;
/* 1812 */             return _findName(q, 3);
/*      */           } 
/* 1814 */           return null;
/*      */         } 
/* 1816 */         if (i == 34) {
/* 1817 */           this._inputPtr = ptr;
/* 1818 */           return _findName(q, 2);
/*      */         } 
/* 1820 */         return null;
/*      */       } 
/* 1822 */       if (i == 34) {
/* 1823 */         this._inputPtr = ptr;
/* 1824 */         return _findName(q0, 1);
/*      */       } 
/* 1826 */       return null;
/*      */     } 
/* 1828 */     if (q0 == 34) {
/* 1829 */       this._inputPtr = ptr;
/* 1830 */       return "";
/*      */     } 
/* 1832 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName(int ptr, int q2) throws IOException {
/* 1837 */     byte[] input = this._inputBuffer;
/* 1838 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1841 */     int i = input[ptr++] & 0xFF;
/* 1842 */     if (codes[i] == 0) {
/* 1843 */       q2 = q2 << 8 | i;
/* 1844 */       i = input[ptr++] & 0xFF;
/* 1845 */       if (codes[i] == 0) {
/* 1846 */         q2 = q2 << 8 | i;
/* 1847 */         i = input[ptr++] & 0xFF;
/* 1848 */         if (codes[i] == 0) {
/* 1849 */           q2 = q2 << 8 | i;
/* 1850 */           i = input[ptr++] & 0xFF;
/* 1851 */           if (codes[i] == 0) {
/* 1852 */             return _parseMediumName2(ptr, i, q2);
/*      */           }
/* 1854 */           if (i == 34) {
/* 1855 */             this._inputPtr = ptr;
/* 1856 */             return _findName(this._quad1, q2, 4);
/*      */           } 
/* 1858 */           return null;
/*      */         } 
/* 1860 */         if (i == 34) {
/* 1861 */           this._inputPtr = ptr;
/* 1862 */           return _findName(this._quad1, q2, 3);
/*      */         } 
/* 1864 */         return null;
/*      */       } 
/* 1866 */       if (i == 34) {
/* 1867 */         this._inputPtr = ptr;
/* 1868 */         return _findName(this._quad1, q2, 2);
/*      */       } 
/* 1870 */       return null;
/*      */     } 
/* 1872 */     if (i == 34) {
/* 1873 */       this._inputPtr = ptr;
/* 1874 */       return _findName(this._quad1, q2, 1);
/*      */     } 
/* 1876 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName2(int ptr, int q3, int q2) throws IOException {
/* 1881 */     byte[] input = this._inputBuffer;
/* 1882 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1885 */     int i = input[ptr++] & 0xFF;
/* 1886 */     if (codes[i] != 0) {
/* 1887 */       if (i == 34) {
/* 1888 */         this._inputPtr = ptr;
/* 1889 */         return _findName(this._quad1, q2, q3, 1);
/*      */       } 
/* 1891 */       return null;
/*      */     } 
/* 1893 */     q3 = q3 << 8 | i;
/* 1894 */     i = input[ptr++] & 0xFF;
/* 1895 */     if (codes[i] != 0) {
/* 1896 */       if (i == 34) {
/* 1897 */         this._inputPtr = ptr;
/* 1898 */         return _findName(this._quad1, q2, q3, 2);
/*      */       } 
/* 1900 */       return null;
/*      */     } 
/* 1902 */     q3 = q3 << 8 | i;
/* 1903 */     i = input[ptr++] & 0xFF;
/* 1904 */     if (codes[i] != 0) {
/* 1905 */       if (i == 34) {
/* 1906 */         this._inputPtr = ptr;
/* 1907 */         return _findName(this._quad1, q2, q3, 3);
/*      */       } 
/* 1909 */       return null;
/*      */     } 
/* 1911 */     q3 = q3 << 8 | i;
/* 1912 */     i = input[ptr++] & 0xFF;
/* 1913 */     if (i == 34) {
/* 1914 */       this._inputPtr = ptr;
/* 1915 */       return _findName(this._quad1, q2, q3, 4);
/*      */     } 
/*      */     
/* 1918 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseEscapedName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 1934 */     int[] quads = this._quadBuffer;
/* 1935 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 1938 */       if (this._inputPtr >= this._inputEnd) {
/* 1939 */         this._quadLength = qlen;
/* 1940 */         this._pending32 = currQuad;
/* 1941 */         this._pendingBytes = currQuadBytes;
/* 1942 */         this._minorState = 7;
/* 1943 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1945 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1946 */       if (codes[ch] == 0) {
/* 1947 */         if (currQuadBytes < 4) {
/* 1948 */           currQuadBytes++;
/* 1949 */           currQuad = currQuad << 8 | ch;
/*      */           continue;
/*      */         } 
/* 1952 */         if (qlen >= quads.length) {
/* 1953 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 1955 */         quads[qlen++] = currQuad;
/* 1956 */         currQuad = ch;
/* 1957 */         currQuadBytes = 1;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1962 */       if (ch == 34) {
/*      */         break;
/*      */       }
/*      */       
/* 1966 */       if (ch != 92) {
/*      */         
/* 1968 */         _throwUnquotedSpace(ch, "name");
/*      */       } else {
/*      */         
/* 1971 */         ch = _decodeCharEscape();
/* 1972 */         if (ch < 0) {
/* 1973 */           this._minorState = 8;
/* 1974 */           this._minorStateAfterSplit = 7;
/* 1975 */           this._quadLength = qlen;
/* 1976 */           this._pending32 = currQuad;
/* 1977 */           this._pendingBytes = currQuadBytes;
/* 1978 */           return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1985 */       if (qlen >= quads.length) {
/* 1986 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 1988 */       if (ch > 127) {
/*      */         
/* 1990 */         if (currQuadBytes >= 4) {
/* 1991 */           quads[qlen++] = currQuad;
/* 1992 */           currQuad = 0;
/* 1993 */           currQuadBytes = 0;
/*      */         } 
/* 1995 */         if (ch < 2048) {
/* 1996 */           currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1997 */           currQuadBytes++;
/*      */         } else {
/*      */           
/* 2000 */           currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2001 */           currQuadBytes++;
/*      */           
/* 2003 */           if (currQuadBytes >= 4) {
/* 2004 */             quads[qlen++] = currQuad;
/* 2005 */             currQuad = 0;
/* 2006 */             currQuadBytes = 0;
/*      */           } 
/* 2008 */           currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2009 */           currQuadBytes++;
/*      */         } 
/*      */         
/* 2012 */         ch = 0x80 | ch & 0x3F;
/*      */       } 
/* 2014 */       if (currQuadBytes < 4) {
/* 2015 */         currQuadBytes++;
/* 2016 */         currQuad = currQuad << 8 | ch;
/*      */         continue;
/*      */       } 
/* 2019 */       quads[qlen++] = currQuad;
/* 2020 */       currQuad = ch;
/* 2021 */       currQuadBytes = 1;
/*      */     } 
/*      */     
/* 2024 */     if (currQuadBytes > 0) {
/* 2025 */       if (qlen >= quads.length) {
/* 2026 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2028 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/* 2029 */     } else if (qlen == 0) {
/* 2030 */       return _fieldComplete("");
/*      */     } 
/* 2032 */     String name = this._symbols.findName(quads, qlen);
/* 2033 */     if (name == null) {
/* 2034 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2036 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _handleOddName(int ch) throws IOException {
/* 2048 */     switch (ch) {
/*      */ 
/*      */       
/*      */       case 35:
/* 2052 */         if (JsonParser.Feature.ALLOW_YAML_COMMENTS.enabledIn(this._features)) {
/* 2053 */           return _finishHashComment(4);
/*      */         }
/*      */         break;
/*      */       case 47:
/* 2057 */         return _startSlashComment(4);
/*      */       case 39:
/* 2059 */         if (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 2060 */           return _finishAposName(0, 0, 0);
/*      */         }
/*      */         break;
/*      */       case 93:
/* 2064 */         return _closeArrayScope();
/*      */     } 
/*      */     
/* 2067 */     if (!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES)) {
/*      */ 
/*      */       
/* 2070 */       char c = (char)ch;
/* 2071 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */     
/* 2075 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2077 */     if (codes[ch] != 0) {
/* 2078 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */     
/* 2081 */     return _finishUnquotedName(0, ch, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _finishUnquotedName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2092 */     int[] quads = this._quadBuffer;
/* 2093 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2098 */       if (this._inputPtr >= this._inputEnd) {
/* 2099 */         this._quadLength = qlen;
/* 2100 */         this._pending32 = currQuad;
/* 2101 */         this._pendingBytes = currQuadBytes;
/* 2102 */         this._minorState = 10;
/* 2103 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2105 */       int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2106 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2109 */       this._inputPtr++;
/*      */       
/* 2111 */       if (currQuadBytes < 4) {
/* 2112 */         currQuadBytes++;
/* 2113 */         currQuad = currQuad << 8 | ch; continue;
/*      */       } 
/* 2115 */       if (qlen >= quads.length) {
/* 2116 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2118 */       quads[qlen++] = currQuad;
/* 2119 */       currQuad = ch;
/* 2120 */       currQuadBytes = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2124 */     if (currQuadBytes > 0) {
/* 2125 */       if (qlen >= quads.length) {
/* 2126 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2128 */       quads[qlen++] = currQuad;
/*      */     } 
/* 2130 */     String name = this._symbols.findName(quads, qlen);
/* 2131 */     if (name == null) {
/* 2132 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2134 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _finishAposName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2140 */     int[] quads = this._quadBuffer;
/* 2141 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 2144 */       if (this._inputPtr >= this._inputEnd) {
/* 2145 */         this._quadLength = qlen;
/* 2146 */         this._pending32 = currQuad;
/* 2147 */         this._pendingBytes = currQuadBytes;
/* 2148 */         this._minorState = 9;
/* 2149 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2151 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2152 */       if (ch == 39) {
/*      */         break;
/*      */       }
/*      */       
/* 2156 */       if (ch != 34 && codes[ch] != 0) {
/* 2157 */         if (ch != 92) {
/*      */           
/* 2159 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2162 */           ch = _decodeCharEscape();
/* 2163 */           if (ch < 0) {
/* 2164 */             this._minorState = 8;
/* 2165 */             this._minorStateAfterSplit = 9;
/* 2166 */             this._quadLength = qlen;
/* 2167 */             this._pending32 = currQuad;
/* 2168 */             this._pendingBytes = currQuadBytes;
/* 2169 */             return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */           } 
/*      */         } 
/* 2172 */         if (ch > 127) {
/*      */           
/* 2174 */           if (currQuadBytes >= 4) {
/* 2175 */             if (qlen >= quads.length) {
/* 2176 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 2178 */             quads[qlen++] = currQuad;
/* 2179 */             currQuad = 0;
/* 2180 */             currQuadBytes = 0;
/*      */           } 
/* 2182 */           if (ch < 2048) {
/* 2183 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2184 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2187 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2188 */             currQuadBytes++;
/*      */             
/* 2190 */             if (currQuadBytes >= 4) {
/* 2191 */               if (qlen >= quads.length) {
/* 2192 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 2194 */               quads[qlen++] = currQuad;
/* 2195 */               currQuad = 0;
/* 2196 */               currQuadBytes = 0;
/*      */             } 
/* 2198 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2199 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2202 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2206 */       if (currQuadBytes < 4) {
/* 2207 */         currQuadBytes++;
/* 2208 */         currQuad = currQuad << 8 | ch; continue;
/*      */       } 
/* 2210 */       if (qlen >= quads.length) {
/* 2211 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2213 */       quads[qlen++] = currQuad;
/* 2214 */       currQuad = ch;
/* 2215 */       currQuadBytes = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2219 */     if (currQuadBytes > 0) {
/* 2220 */       if (qlen >= quads.length) {
/* 2221 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 2223 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/* 2224 */     } else if (qlen == 0) {
/* 2225 */       return _fieldComplete("");
/*      */     } 
/* 2227 */     String name = this._symbols.findName(quads, qlen);
/* 2228 */     if (name == null) {
/* 2229 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2231 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishFieldWithEscape() throws IOException {
/* 2237 */     int ch = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/* 2238 */     if (ch < 0) {
/* 2239 */       this._minorState = 8;
/* 2240 */       return JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 2242 */     if (this._quadLength >= this._quadBuffer.length) {
/* 2243 */       this._quadBuffer = growArrayBy(this._quadBuffer, 32);
/*      */     }
/* 2245 */     int currQuad = this._pending32;
/* 2246 */     int currQuadBytes = this._pendingBytes;
/* 2247 */     if (ch > 127) {
/*      */       
/* 2249 */       if (currQuadBytes >= 4) {
/* 2250 */         this._quadBuffer[this._quadLength++] = currQuad;
/* 2251 */         currQuad = 0;
/* 2252 */         currQuadBytes = 0;
/*      */       } 
/* 2254 */       if (ch < 2048) {
/* 2255 */         currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2256 */         currQuadBytes++;
/*      */       } else {
/*      */         
/* 2259 */         currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/*      */         
/* 2261 */         if (++currQuadBytes >= 4) {
/* 2262 */           this._quadBuffer[this._quadLength++] = currQuad;
/* 2263 */           currQuad = 0;
/* 2264 */           currQuadBytes = 0;
/*      */         } 
/* 2266 */         currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2267 */         currQuadBytes++;
/*      */       } 
/*      */       
/* 2270 */       ch = 0x80 | ch & 0x3F;
/*      */     } 
/* 2272 */     if (currQuadBytes < 4) {
/* 2273 */       currQuadBytes++;
/* 2274 */       currQuad = currQuad << 8 | ch;
/*      */     } else {
/* 2276 */       this._quadBuffer[this._quadLength++] = currQuad;
/* 2277 */       currQuad = ch;
/* 2278 */       currQuadBytes = 1;
/*      */     } 
/* 2280 */     if (this._minorStateAfterSplit == 9) {
/* 2281 */       return _finishAposName(this._quadLength, currQuad, currQuadBytes);
/*      */     }
/* 2283 */     return _parseEscapedName(this._quadLength, currQuad, currQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private int _decodeSplitEscaped(int value, int bytesRead) throws IOException {
/* 2288 */     if (this._inputPtr >= this._inputEnd) {
/* 2289 */       this._quoted32 = value;
/* 2290 */       this._quotedDigits = bytesRead;
/* 2291 */       return -1;
/*      */     } 
/* 2293 */     int c = this._inputBuffer[this._inputPtr++];
/* 2294 */     if (bytesRead == -1) {
/* 2295 */       char ch; switch (c) {
/*      */         
/*      */         case 98:
/* 2298 */           return 8;
/*      */         case 116:
/* 2300 */           return 9;
/*      */         case 110:
/* 2302 */           return 10;
/*      */         case 102:
/* 2304 */           return 12;
/*      */         case 114:
/* 2306 */           return 13;
/*      */ 
/*      */         
/*      */         case 34:
/*      */         case 47:
/*      */         case 92:
/* 2312 */           return c;
/*      */ 
/*      */ 
/*      */         
/*      */         case 117:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2321 */           ch = (char)c;
/* 2322 */           return _handleUnrecognizedCharacterEscape(ch);
/*      */       } 
/*      */       
/* 2325 */       if (this._inputPtr >= this._inputEnd) {
/* 2326 */         this._quotedDigits = 0;
/* 2327 */         this._quoted32 = 0;
/* 2328 */         return -1;
/*      */       } 
/* 2330 */       c = this._inputBuffer[this._inputPtr++];
/* 2331 */       bytesRead = 0;
/*      */     } 
/* 2333 */     c &= 0xFF;
/*      */     while (true) {
/* 2335 */       int digit = CharTypes.charToHex(c);
/* 2336 */       if (digit < 0) {
/* 2337 */         _reportUnexpectedChar(c, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2339 */       value = value << 4 | digit;
/* 2340 */       if (++bytesRead == 4) {
/* 2341 */         return value;
/*      */       }
/* 2343 */       if (this._inputPtr >= this._inputEnd) {
/* 2344 */         this._quotedDigits = bytesRead;
/* 2345 */         this._quoted32 = value;
/* 2346 */         return -1;
/*      */       } 
/* 2348 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startString() throws IOException {
/* 2360 */     int ptr = this._inputPtr;
/* 2361 */     int outPtr = 0;
/* 2362 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2363 */     int[] codes = _icUTF8;
/*      */     
/* 2365 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2366 */     byte[] inputBuffer = this._inputBuffer;
/* 2367 */     while (ptr < max) {
/* 2368 */       int c = inputBuffer[ptr] & 0xFF;
/* 2369 */       if (codes[c] != 0) {
/* 2370 */         if (c == 34) {
/* 2371 */           this._inputPtr = ptr + 1;
/* 2372 */           this._textBuffer.setCurrentLength(outPtr);
/* 2373 */           return _valueComplete(JsonToken.VALUE_STRING);
/*      */         } 
/*      */         break;
/*      */       } 
/* 2377 */       ptr++;
/* 2378 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2380 */     this._textBuffer.setCurrentLength(outPtr);
/* 2381 */     this._inputPtr = ptr;
/* 2382 */     return _finishRegularString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishRegularString() throws IOException {
/* 2390 */     int[] codes = _icUTF8;
/* 2391 */     byte[] inputBuffer = this._inputBuffer;
/*      */     
/* 2393 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2394 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2395 */     int ptr = this._inputPtr;
/* 2396 */     int safeEnd = this._inputEnd - 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2403 */       if (ptr >= this._inputEnd) {
/* 2404 */         this._inputPtr = ptr;
/* 2405 */         this._minorState = 40;
/* 2406 */         this._textBuffer.setCurrentLength(outPtr);
/* 2407 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2409 */       if (outPtr >= outBuf.length) {
/* 2410 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2411 */         outPtr = 0;
/*      */       } 
/* 2413 */       int max = Math.min(this._inputEnd, ptr + outBuf.length - outPtr);
/* 2414 */       while (ptr < max) {
/* 2415 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2416 */         if (codes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2423 */           if (c == 34) {
/* 2424 */             this._inputPtr = ptr;
/* 2425 */             this._textBuffer.setCurrentLength(outPtr);
/* 2426 */             return _valueComplete(JsonToken.VALUE_STRING);
/*      */           } 
/*      */           
/* 2429 */           if (ptr >= safeEnd) {
/* 2430 */             this._inputPtr = ptr;
/* 2431 */             this._textBuffer.setCurrentLength(outPtr);
/* 2432 */             if (!_decodeSplitMultiByte(c, codes[c], (ptr < this._inputEnd))) {
/* 2433 */               this._minorStateAfterSplit = 40;
/* 2434 */               return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */             } 
/* 2436 */             outBuf = this._textBuffer.getBufferWithoutReset();
/* 2437 */             outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2438 */             ptr = this._inputPtr;
/*      */             
/*      */             continue;
/*      */           } 
/* 2442 */           switch (codes[c]) {
/*      */             case 1:
/* 2444 */               this._inputPtr = ptr;
/* 2445 */               c = _decodeFastCharEscape();
/* 2446 */               ptr = this._inputPtr;
/*      */               break;
/*      */             case 2:
/* 2449 */               c = _decodeUTF8_2(c, this._inputBuffer[ptr++]);
/*      */               break;
/*      */             case 3:
/* 2452 */               c = _decodeUTF8_3(c, this._inputBuffer[ptr++], this._inputBuffer[ptr++]);
/*      */               break;
/*      */             case 4:
/* 2455 */               c = _decodeUTF8_4(c, this._inputBuffer[ptr++], this._inputBuffer[ptr++], this._inputBuffer[ptr++]);
/*      */ 
/*      */               
/* 2458 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2459 */               if (outPtr >= outBuf.length) {
/* 2460 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2461 */                 outPtr = 0;
/*      */               } 
/* 2463 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2467 */               if (c < 32) {
/*      */                 
/* 2469 */                 _throwUnquotedSpace(c, "string value");
/*      */                 break;
/*      */               } 
/* 2472 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/*      */           
/* 2476 */           if (outPtr >= outBuf.length) {
/* 2477 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2478 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2481 */           outBuf[outPtr++] = (char)c;
/*      */           continue;
/*      */         } 
/*      */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */     }  } protected JsonToken _startAposString() throws IOException {
/* 2487 */     int ptr = this._inputPtr;
/* 2488 */     int outPtr = 0;
/* 2489 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2490 */     int[] codes = _icUTF8;
/*      */     
/* 2492 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2493 */     byte[] inputBuffer = this._inputBuffer;
/* 2494 */     while (ptr < max) {
/* 2495 */       int c = inputBuffer[ptr] & 0xFF;
/* 2496 */       if (c == 39) {
/* 2497 */         this._inputPtr = ptr + 1;
/* 2498 */         this._textBuffer.setCurrentLength(outPtr);
/* 2499 */         return _valueComplete(JsonToken.VALUE_STRING);
/*      */       } 
/*      */       
/* 2502 */       if (codes[c] != 0) {
/*      */         break;
/*      */       }
/* 2505 */       ptr++;
/* 2506 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2508 */     this._textBuffer.setCurrentLength(outPtr);
/* 2509 */     this._inputPtr = ptr;
/* 2510 */     return _finishAposString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishAposString() throws IOException {
/* 2516 */     int[] codes = _icUTF8;
/* 2517 */     byte[] inputBuffer = this._inputBuffer;
/*      */     
/* 2519 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2520 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2521 */     int ptr = this._inputPtr;
/* 2522 */     int safeEnd = this._inputEnd - 5;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2528 */       if (ptr >= this._inputEnd) {
/* 2529 */         this._inputPtr = ptr;
/* 2530 */         this._minorState = 45;
/* 2531 */         this._textBuffer.setCurrentLength(outPtr);
/* 2532 */         return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 2534 */       if (outPtr >= outBuf.length) {
/* 2535 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2536 */         outPtr = 0;
/*      */       } 
/* 2538 */       int max = Math.min(this._inputEnd, ptr + outBuf.length - outPtr);
/* 2539 */       while (ptr < max) {
/* 2540 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2541 */         if (codes[c] != 0 && c != 34) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2554 */           if (ptr >= safeEnd) {
/* 2555 */             this._inputPtr = ptr;
/* 2556 */             this._textBuffer.setCurrentLength(outPtr);
/* 2557 */             if (!_decodeSplitMultiByte(c, codes[c], (ptr < this._inputEnd))) {
/* 2558 */               this._minorStateAfterSplit = 45;
/* 2559 */               return this._currToken = JsonToken.NOT_AVAILABLE;
/*      */             } 
/* 2561 */             outBuf = this._textBuffer.getBufferWithoutReset();
/* 2562 */             outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2563 */             ptr = this._inputPtr;
/*      */             
/*      */             continue;
/*      */           } 
/* 2567 */           switch (codes[c]) {
/*      */             case 1:
/* 2569 */               this._inputPtr = ptr;
/* 2570 */               c = _decodeFastCharEscape();
/* 2571 */               ptr = this._inputPtr;
/*      */               break;
/*      */             case 2:
/* 2574 */               c = _decodeUTF8_2(c, this._inputBuffer[ptr++]);
/*      */               break;
/*      */             case 3:
/* 2577 */               c = _decodeUTF8_3(c, this._inputBuffer[ptr++], this._inputBuffer[ptr++]);
/*      */               break;
/*      */             case 4:
/* 2580 */               c = _decodeUTF8_4(c, this._inputBuffer[ptr++], this._inputBuffer[ptr++], this._inputBuffer[ptr++]);
/*      */ 
/*      */               
/* 2583 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2584 */               if (outPtr >= outBuf.length) {
/* 2585 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2586 */                 outPtr = 0;
/*      */               } 
/* 2588 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2592 */               if (c < 32) {
/*      */                 
/* 2594 */                 _throwUnquotedSpace(c, "string value");
/*      */                 break;
/*      */               } 
/* 2597 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/*      */           
/* 2601 */           if (outPtr >= outBuf.length) {
/* 2602 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2603 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2606 */           outBuf[outPtr++] = (char)c; continue;
/*      */         }  if (c == 39) {
/*      */           this._inputPtr = ptr; this._textBuffer.setCurrentLength(outPtr);
/*      */           return _valueComplete(JsonToken.VALUE_STRING);
/*      */         } 
/*      */         outBuf[outPtr++] = (char)c;
/*      */       } 
/* 2613 */     }  } private final boolean _decodeSplitMultiByte(int c, int type, boolean gotNext) throws IOException { switch (type) {
/*      */       case 1:
/* 2615 */         c = _decodeSplitEscaped(0, -1);
/* 2616 */         if (c < 0) {
/* 2617 */           this._minorState = 41;
/* 2618 */           return false;
/*      */         } 
/* 2620 */         this._textBuffer.append((char)c);
/* 2621 */         return true;
/*      */       case 2:
/* 2623 */         if (gotNext) {
/*      */           
/* 2625 */           c = _decodeUTF8_2(c, this._inputBuffer[this._inputPtr++]);
/* 2626 */           this._textBuffer.append((char)c);
/* 2627 */           return true;
/*      */         } 
/* 2629 */         this._minorState = 42;
/* 2630 */         this._pending32 = c;
/* 2631 */         return false;
/*      */       case 3:
/* 2633 */         c &= 0xF;
/* 2634 */         if (gotNext) {
/* 2635 */           return _decodeSplitUTF8_3(c, 1, this._inputBuffer[this._inputPtr++]);
/*      */         }
/* 2637 */         this._minorState = 43;
/* 2638 */         this._pending32 = c;
/* 2639 */         this._pendingBytes = 1;
/* 2640 */         return false;
/*      */       case 4:
/* 2642 */         c &= 0x7;
/* 2643 */         if (gotNext) {
/* 2644 */           return _decodeSplitUTF8_4(c, 1, this._inputBuffer[this._inputPtr++]);
/*      */         }
/* 2646 */         this._pending32 = c;
/* 2647 */         this._pendingBytes = 1;
/* 2648 */         this._minorState = 44;
/* 2649 */         return false;
/*      */     } 
/* 2651 */     if (c < 32) {
/*      */       
/* 2653 */       _throwUnquotedSpace(c, "string value");
/*      */     } else {
/*      */       
/* 2656 */       _reportInvalidChar(c);
/*      */     } 
/* 2658 */     this._textBuffer.append((char)c);
/* 2659 */     return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _decodeSplitUTF8_3(int prev, int prevCount, int next) throws IOException {
/* 2666 */     if (prevCount == 1) {
/* 2667 */       if ((next & 0xC0) != 128) {
/* 2668 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2670 */       prev = prev << 6 | next & 0x3F;
/* 2671 */       if (this._inputPtr >= this._inputEnd) {
/* 2672 */         this._minorState = 43;
/* 2673 */         this._pending32 = prev;
/* 2674 */         this._pendingBytes = 2;
/* 2675 */         return false;
/*      */       } 
/* 2677 */       next = this._inputBuffer[this._inputPtr++];
/*      */     } 
/* 2679 */     if ((next & 0xC0) != 128) {
/* 2680 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2682 */     this._textBuffer.append((char)(prev << 6 | next & 0x3F));
/* 2683 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _decodeSplitUTF8_4(int prev, int prevCount, int next) throws IOException {
/* 2691 */     if (prevCount == 1) {
/* 2692 */       if ((next & 0xC0) != 128) {
/* 2693 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2695 */       prev = prev << 6 | next & 0x3F;
/* 2696 */       if (this._inputPtr >= this._inputEnd) {
/* 2697 */         this._minorState = 44;
/* 2698 */         this._pending32 = prev;
/* 2699 */         this._pendingBytes = 2;
/* 2700 */         return false;
/*      */       } 
/* 2702 */       prevCount = 2;
/* 2703 */       next = this._inputBuffer[this._inputPtr++];
/*      */     } 
/* 2705 */     if (prevCount == 2) {
/* 2706 */       if ((next & 0xC0) != 128) {
/* 2707 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2709 */       prev = prev << 6 | next & 0x3F;
/* 2710 */       if (this._inputPtr >= this._inputEnd) {
/* 2711 */         this._minorState = 44;
/* 2712 */         this._pending32 = prev;
/* 2713 */         this._pendingBytes = 3;
/* 2714 */         return false;
/*      */       } 
/* 2716 */       next = this._inputBuffer[this._inputPtr++];
/*      */     } 
/* 2718 */     if ((next & 0xC0) != 128) {
/* 2719 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2721 */     int c = (prev << 6 | next & 0x3F) - 65536;
/*      */     
/* 2723 */     this._textBuffer.append((char)(0xD800 | c >> 10));
/* 2724 */     c = 0xDC00 | c & 0x3FF;
/*      */     
/* 2726 */     this._textBuffer.append((char)c);
/* 2727 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeCharEscape() throws IOException {
/* 2738 */     int left = this._inputEnd - this._inputPtr;
/* 2739 */     if (left < 5) {
/* 2740 */       return _decodeSplitEscaped(0, -1);
/*      */     }
/* 2742 */     return _decodeFastCharEscape();
/*      */   }
/*      */   
/*      */   private final int _decodeFastCharEscape() throws IOException {
/*      */     char c1;
/* 2747 */     int c = this._inputBuffer[this._inputPtr++];
/* 2748 */     switch (c) {
/*      */       
/*      */       case 98:
/* 2751 */         return 8;
/*      */       case 116:
/* 2753 */         return 9;
/*      */       case 110:
/* 2755 */         return 10;
/*      */       case 102:
/* 2757 */         return 12;
/*      */       case 114:
/* 2759 */         return 13;
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 2765 */         return (char)c;
/*      */ 
/*      */ 
/*      */       
/*      */       case 117:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2774 */         c1 = (char)c;
/* 2775 */         return _handleUnrecognizedCharacterEscape(c1);
/*      */     } 
/*      */ 
/*      */     
/* 2779 */     int ch = this._inputBuffer[this._inputPtr++];
/* 2780 */     int digit = CharTypes.charToHex(ch);
/* 2781 */     int result = digit;
/*      */     
/* 2783 */     if (digit >= 0) {
/* 2784 */       ch = this._inputBuffer[this._inputPtr++];
/* 2785 */       digit = CharTypes.charToHex(ch);
/* 2786 */       if (digit >= 0) {
/* 2787 */         result = result << 4 | digit;
/* 2788 */         ch = this._inputBuffer[this._inputPtr++];
/* 2789 */         digit = CharTypes.charToHex(ch);
/* 2790 */         if (digit >= 0) {
/* 2791 */           result = result << 4 | digit;
/* 2792 */           ch = this._inputBuffer[this._inputPtr++];
/* 2793 */           digit = CharTypes.charToHex(ch);
/* 2794 */           if (digit >= 0) {
/* 2795 */             return result << 4 | digit;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2800 */     _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/* 2801 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_2(int c, int d) throws IOException {
/* 2812 */     if ((d & 0xC0) != 128) {
/* 2813 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2815 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_3(int c, int d, int e) throws IOException {
/* 2820 */     c &= 0xF;
/* 2821 */     if ((d & 0xC0) != 128) {
/* 2822 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2824 */     c = c << 6 | d & 0x3F;
/* 2825 */     if ((e & 0xC0) != 128) {
/* 2826 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2828 */     return c << 6 | e & 0x3F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_4(int c, int d, int e, int f) throws IOException {
/* 2835 */     if ((d & 0xC0) != 128) {
/* 2836 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2838 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2839 */     if ((e & 0xC0) != 128) {
/* 2840 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2842 */     c = c << 6 | e & 0x3F;
/* 2843 */     if ((f & 0xC0) != 128) {
/* 2844 */       _reportInvalidOther(f & 0xFF, this._inputPtr);
/*      */     }
/* 2846 */     return (c << 6 | f & 0x3F) - 65536;
/*      */   }
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\core\json\async\NonBlockingJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */