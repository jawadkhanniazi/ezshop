/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.base.ParserBase;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import java.io.DataInput;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UTF8DataInputJsonParser
/*      */   extends ParserBase
/*      */ {
/*      */   static final byte BYTE_LF = 10;
/*   41 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   45 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   74 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DataInput _inputData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  100 */   protected int _nextByte = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8DataInputJsonParser(IOContext ctxt, int features, DataInput inputData, ObjectCodec codec, ByteQuadsCanonicalizer sym, int firstByte) {
/*  112 */     super(ctxt, features);
/*  113 */     this._objectCodec = codec;
/*  114 */     this._symbols = sym;
/*  115 */     this._inputData = inputData;
/*  116 */     this._nextByte = firstByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  121 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCodec(ObjectCodec c) {
/*  126 */     this._objectCodec = c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  137 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  142 */     return this._inputData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  163 */     super._releaseBuffers();
/*      */     
/*  165 */     this._symbols.release();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  177 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  178 */       if (this._tokenIncomplete) {
/*  179 */         this._tokenIncomplete = false;
/*  180 */         return _finishAndReturnString();
/*      */       } 
/*  182 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  184 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  190 */     JsonToken t = this._currToken;
/*  191 */     if (t == JsonToken.VALUE_STRING) {
/*  192 */       if (this._tokenIncomplete) {
/*  193 */         this._tokenIncomplete = false;
/*  194 */         _finishString();
/*      */       } 
/*  196 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  198 */     if (t == JsonToken.FIELD_NAME) {
/*  199 */       String n = this._parsingContext.getCurrentName();
/*  200 */       writer.write(n);
/*  201 */       return n.length();
/*      */     } 
/*  203 */     if (t != null) {
/*  204 */       if (t.isNumeric()) {
/*  205 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  207 */       char[] ch = t.asCharArray();
/*  208 */       writer.write(ch);
/*  209 */       return ch.length;
/*      */     } 
/*  211 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  218 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  219 */       if (this._tokenIncomplete) {
/*  220 */         this._tokenIncomplete = false;
/*  221 */         return _finishAndReturnString();
/*      */       } 
/*  223 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  225 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  226 */       return getCurrentName();
/*      */     }
/*  228 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  234 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  235 */       if (this._tokenIncomplete) {
/*  236 */         this._tokenIncomplete = false;
/*  237 */         return _finishAndReturnString();
/*      */       } 
/*  239 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  241 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  242 */       return getCurrentName();
/*      */     }
/*  244 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  250 */     JsonToken t = this._currToken;
/*  251 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  253 */       if ((this._numTypesValid & 0x1) == 0) {
/*  254 */         if (this._numTypesValid == 0) {
/*  255 */           return _parseIntValue();
/*      */         }
/*  257 */         if ((this._numTypesValid & 0x1) == 0) {
/*  258 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  261 */       return this._numberInt;
/*      */     } 
/*  263 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  269 */     JsonToken t = this._currToken;
/*  270 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  272 */       if ((this._numTypesValid & 0x1) == 0) {
/*  273 */         if (this._numTypesValid == 0) {
/*  274 */           return _parseIntValue();
/*      */         }
/*  276 */         if ((this._numTypesValid & 0x1) == 0) {
/*  277 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  280 */       return this._numberInt;
/*      */     } 
/*  282 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) {
/*  287 */     if (t == null) {
/*  288 */       return null;
/*      */     }
/*  290 */     switch (t.id()) {
/*      */       case 5:
/*  292 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  298 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  300 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  307 */     if (this._currToken != null) {
/*  308 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  311 */           if (!this._nameCopied) {
/*  312 */             String name = this._parsingContext.getCurrentName();
/*  313 */             int nameLen = name.length();
/*  314 */             if (this._nameCopyBuffer == null) {
/*  315 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  316 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  317 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  319 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  320 */             this._nameCopied = true;
/*      */           } 
/*  322 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  325 */           if (this._tokenIncomplete) {
/*  326 */             this._tokenIncomplete = false;
/*  327 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  332 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  335 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  338 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  344 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  345 */       if (this._tokenIncomplete) {
/*  346 */         this._tokenIncomplete = false;
/*  347 */         _finishString();
/*      */       } 
/*  349 */       return this._textBuffer.size();
/*      */     } 
/*  351 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  352 */       return this._parsingContext.getCurrentName().length();
/*      */     }
/*  354 */     if (this._currToken != null) {
/*  355 */       if (this._currToken.isNumeric()) {
/*  356 */         return this._textBuffer.size();
/*      */       }
/*  358 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*  360 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  367 */     if (this._currToken != null) {
/*  368 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  370 */           return 0;
/*      */         case 6:
/*  372 */           if (this._tokenIncomplete) {
/*  373 */             this._tokenIncomplete = false;
/*  374 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  379 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  383 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  389 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  391 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  396 */     if (this._tokenIncomplete) {
/*      */       try {
/*  398 */         this._binaryValue = _decodeBase64(b64variant);
/*  399 */       } catch (IllegalArgumentException iae) {
/*  400 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  405 */       this._tokenIncomplete = false;
/*      */     }
/*  407 */     else if (this._binaryValue == null) {
/*      */       
/*  409 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  410 */       _decodeBase64(getText(), builder, b64variant);
/*  411 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  414 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  421 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  422 */       byte[] b = getBinaryValue(b64variant);
/*  423 */       out.write(b);
/*  424 */       return b.length;
/*      */     } 
/*      */     
/*  427 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  429 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  431 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  438 */     int outputPtr = 0;
/*  439 */     int outputEnd = buffer.length - 3;
/*  440 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  446 */       int ch = this._inputData.readUnsignedByte();
/*  447 */       if (ch > 32) {
/*  448 */         int bits = b64variant.decodeBase64Char(ch);
/*  449 */         if (bits < 0) {
/*  450 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  453 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  454 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  460 */         if (outputPtr > outputEnd) {
/*  461 */           outputCount += outputPtr;
/*  462 */           out.write(buffer, 0, outputPtr);
/*  463 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  466 */         int decodedData = bits;
/*      */ 
/*      */         
/*  469 */         ch = this._inputData.readUnsignedByte();
/*  470 */         bits = b64variant.decodeBase64Char(ch);
/*  471 */         if (bits < 0) {
/*  472 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  474 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  477 */         ch = this._inputData.readUnsignedByte();
/*  478 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  481 */         if (bits < 0) {
/*  482 */           if (bits != -2) {
/*      */             
/*  484 */             if (ch == 34) {
/*  485 */               decodedData >>= 4;
/*  486 */               buffer[outputPtr++] = (byte)decodedData;
/*  487 */               if (b64variant.usesPadding()) {
/*  488 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  492 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  494 */           if (bits == -2) {
/*      */             
/*  496 */             ch = this._inputData.readUnsignedByte();
/*  497 */             if (!b64variant.usesPaddingChar(ch) && (
/*  498 */               ch != 92 || 
/*  499 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/*  500 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  504 */             decodedData >>= 4;
/*  505 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  510 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  512 */         ch = this._inputData.readUnsignedByte();
/*  513 */         bits = b64variant.decodeBase64Char(ch);
/*  514 */         if (bits < 0) {
/*  515 */           if (bits != -2) {
/*      */             
/*  517 */             if (ch == 34) {
/*  518 */               decodedData >>= 2;
/*  519 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  520 */               buffer[outputPtr++] = (byte)decodedData;
/*  521 */               if (b64variant.usesPadding()) {
/*  522 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  526 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  528 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  535 */             decodedData >>= 2;
/*  536 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  537 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  542 */         decodedData = decodedData << 6 | bits;
/*  543 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  544 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  545 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  547 */     }  this._tokenIncomplete = false;
/*  548 */     if (outputPtr > 0) {
/*  549 */       outputCount += outputPtr;
/*  550 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  552 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  568 */     if (this._closed) {
/*  569 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  575 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  576 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  580 */     this._numTypesValid = 0;
/*  581 */     if (this._tokenIncomplete) {
/*  582 */       _skipString();
/*      */     }
/*  584 */     int i = _skipWSOrEnd();
/*  585 */     if (i < 0) {
/*      */       
/*  587 */       close();
/*  588 */       return this._currToken = null;
/*      */     } 
/*      */     
/*  591 */     this._binaryValue = null;
/*  592 */     this._tokenInputRow = this._currInputRow;
/*      */ 
/*      */     
/*  595 */     if (i == 93 || i == 125) {
/*  596 */       _closeScope(i);
/*  597 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  601 */     if (this._parsingContext.expectComma()) {
/*  602 */       if (i != 44) {
/*  603 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  605 */       i = _skipWS();
/*      */ 
/*      */       
/*  608 */       if (JsonParser.Feature.ALLOW_TRAILING_COMMA.enabledIn(this._features) && (
/*  609 */         i == 93 || i == 125)) {
/*  610 */         _closeScope(i);
/*  611 */         return this._currToken;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  620 */     if (!this._parsingContext.inObject()) {
/*  621 */       return _nextTokenNotInObject(i);
/*      */     }
/*      */     
/*  624 */     String n = _parseName(i);
/*  625 */     this._parsingContext.setCurrentName(n);
/*  626 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  628 */     i = _skipColon();
/*      */ 
/*      */     
/*  631 */     if (i == 34) {
/*  632 */       this._tokenIncomplete = true;
/*  633 */       this._nextToken = JsonToken.VALUE_STRING;
/*  634 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  638 */     switch (i)
/*      */     { case 45:
/*  640 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  681 */         this._nextToken = t;
/*  682 */         return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return this._currToken;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  687 */     if (i == 34) {
/*  688 */       this._tokenIncomplete = true;
/*  689 */       return this._currToken = JsonToken.VALUE_STRING;
/*      */     } 
/*  691 */     switch (i) {
/*      */       case 91:
/*  693 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  694 */         return this._currToken = JsonToken.START_ARRAY;
/*      */       case 123:
/*  696 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  697 */         return this._currToken = JsonToken.START_OBJECT;
/*      */       case 116:
/*  699 */         _matchToken("true", 1);
/*  700 */         return this._currToken = JsonToken.VALUE_TRUE;
/*      */       case 102:
/*  702 */         _matchToken("false", 1);
/*  703 */         return this._currToken = JsonToken.VALUE_FALSE;
/*      */       case 110:
/*  705 */         _matchToken("null", 1);
/*  706 */         return this._currToken = JsonToken.VALUE_NULL;
/*      */       case 45:
/*  708 */         return this._currToken = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  723 */         return this._currToken = _parsePosNumber(i);
/*      */     } 
/*  725 */     return this._currToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() {
/*  730 */     this._nameCopied = false;
/*  731 */     JsonToken t = this._nextToken;
/*  732 */     this._nextToken = null;
/*      */ 
/*      */     
/*  735 */     if (t == JsonToken.START_ARRAY) {
/*  736 */       this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  737 */     } else if (t == JsonToken.START_OBJECT) {
/*  738 */       this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  740 */     return this._currToken = t;
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  745 */     if (this._tokenIncomplete) {
/*  746 */       this._tokenIncomplete = false;
/*  747 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  765 */     this._numTypesValid = 0;
/*  766 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  767 */       _nextAfterName();
/*  768 */       return null;
/*      */     } 
/*  770 */     if (this._tokenIncomplete) {
/*  771 */       _skipString();
/*      */     }
/*  773 */     int i = _skipWS();
/*  774 */     this._binaryValue = null;
/*  775 */     this._tokenInputRow = this._currInputRow;
/*      */     
/*  777 */     if (i == 93 || i == 125) {
/*  778 */       _closeScope(i);
/*  779 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  783 */     if (this._parsingContext.expectComma()) {
/*  784 */       if (i != 44) {
/*  785 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  787 */       i = _skipWS();
/*      */ 
/*      */       
/*  790 */       if (JsonParser.Feature.ALLOW_TRAILING_COMMA.enabledIn(this._features) && (
/*  791 */         i == 93 || i == 125)) {
/*  792 */         _closeScope(i);
/*  793 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  798 */     if (!this._parsingContext.inObject()) {
/*  799 */       _nextTokenNotInObject(i);
/*  800 */       return null;
/*      */     } 
/*      */     
/*  803 */     String nameStr = _parseName(i);
/*  804 */     this._parsingContext.setCurrentName(nameStr);
/*  805 */     this._currToken = JsonToken.FIELD_NAME;
/*      */     
/*  807 */     i = _skipColon();
/*  808 */     if (i == 34) {
/*  809 */       this._tokenIncomplete = true;
/*  810 */       this._nextToken = JsonToken.VALUE_STRING;
/*  811 */       return nameStr;
/*      */     } 
/*      */     
/*  814 */     switch (i)
/*      */     { case 45:
/*  816 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  852 */         this._nextToken = t;
/*  853 */         return nameStr;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parsePosNumber(i); this._nextToken = t; return nameStr;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/*  860 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  861 */       this._nameCopied = false;
/*  862 */       JsonToken t = this._nextToken;
/*  863 */       this._nextToken = null;
/*  864 */       this._currToken = t;
/*  865 */       if (t == JsonToken.VALUE_STRING) {
/*  866 */         if (this._tokenIncomplete) {
/*  867 */           this._tokenIncomplete = false;
/*  868 */           return _finishAndReturnString();
/*      */         } 
/*  870 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*  872 */       if (t == JsonToken.START_ARRAY) {
/*  873 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  874 */       } else if (t == JsonToken.START_OBJECT) {
/*  875 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  877 */       return null;
/*      */     } 
/*  879 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/*  886 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  887 */       this._nameCopied = false;
/*  888 */       JsonToken t = this._nextToken;
/*  889 */       this._nextToken = null;
/*  890 */       this._currToken = t;
/*  891 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  892 */         return getIntValue();
/*      */       }
/*  894 */       if (t == JsonToken.START_ARRAY) {
/*  895 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  896 */       } else if (t == JsonToken.START_OBJECT) {
/*  897 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  899 */       return defaultValue;
/*      */     } 
/*  901 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/*  908 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  909 */       this._nameCopied = false;
/*  910 */       JsonToken t = this._nextToken;
/*  911 */       this._nextToken = null;
/*  912 */       this._currToken = t;
/*  913 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  914 */         return getLongValue();
/*      */       }
/*  916 */       if (t == JsonToken.START_ARRAY) {
/*  917 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  918 */       } else if (t == JsonToken.START_OBJECT) {
/*  919 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  921 */       return defaultValue;
/*      */     } 
/*  923 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/*  930 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  931 */       this._nameCopied = false;
/*  932 */       JsonToken jsonToken = this._nextToken;
/*  933 */       this._nextToken = null;
/*  934 */       this._currToken = jsonToken;
/*  935 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/*  936 */         return Boolean.TRUE;
/*      */       }
/*  938 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/*  939 */         return Boolean.FALSE;
/*      */       }
/*  941 */       if (jsonToken == JsonToken.START_ARRAY) {
/*  942 */         this._parsingContext = this._parsingContext.createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  943 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/*  944 */         this._parsingContext = this._parsingContext.createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  946 */       return null;
/*      */     } 
/*      */     
/*  949 */     JsonToken t = nextToken();
/*  950 */     if (t == JsonToken.VALUE_TRUE) {
/*  951 */       return Boolean.TRUE;
/*      */     }
/*  953 */     if (t == JsonToken.VALUE_FALSE) {
/*  954 */       return Boolean.FALSE;
/*      */     }
/*  956 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parsePosNumber(int c) throws IOException {
/*      */     int outPtr;
/*  982 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  987 */     if (c == 48) {
/*  988 */       c = _handleLeadingZeroes();
/*  989 */       if (c <= 57 && c >= 48) {
/*  990 */         outPtr = 0;
/*      */       } else {
/*  992 */         outBuf[0] = '0';
/*  993 */         outPtr = 1;
/*      */       } 
/*      */     } else {
/*  996 */       outBuf[0] = (char)c;
/*  997 */       c = this._inputData.readUnsignedByte();
/*  998 */       outPtr = 1;
/*      */     } 
/* 1000 */     int intLen = outPtr;
/*      */ 
/*      */     
/* 1003 */     while (c <= 57 && c >= 48) {
/* 1004 */       intLen++;
/* 1005 */       outBuf[outPtr++] = (char)c;
/* 1006 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1008 */     if (c == 46 || c == 101 || c == 69) {
/* 1009 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1011 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1013 */     if (this._parsingContext.inRoot()) {
/* 1014 */       _verifyRootSpace();
/*      */     } else {
/* 1016 */       this._nextByte = c;
/*      */     } 
/*      */     
/* 1019 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _parseNegNumber() throws IOException {
/* 1024 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1025 */     int outPtr = 0;
/*      */ 
/*      */     
/* 1028 */     outBuf[outPtr++] = '-';
/* 1029 */     int c = this._inputData.readUnsignedByte();
/* 1030 */     outBuf[outPtr++] = (char)c;
/*      */     
/* 1032 */     if (c <= 48) {
/*      */       
/* 1034 */       if (c == 48) {
/* 1035 */         c = _handleLeadingZeroes();
/*      */       } else {
/* 1037 */         return _handleInvalidNumberStart(c, true);
/*      */       } 
/*      */     } else {
/* 1040 */       if (c > 57) {
/* 1041 */         return _handleInvalidNumberStart(c, true);
/*      */       }
/* 1043 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1046 */     int intLen = 1;
/*      */ 
/*      */     
/* 1049 */     while (c <= 57 && c >= 48) {
/* 1050 */       intLen++;
/* 1051 */       outBuf[outPtr++] = (char)c;
/* 1052 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1054 */     if (c == 46 || c == 101 || c == 69) {
/* 1055 */       return _parseFloat(outBuf, outPtr, c, true, intLen);
/*      */     }
/* 1057 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1059 */     this._nextByte = c;
/* 1060 */     if (this._parsingContext.inRoot()) {
/* 1061 */       _verifyRootSpace();
/*      */     }
/*      */     
/* 1064 */     return resetInt(true, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _handleLeadingZeroes() throws IOException {
/* 1076 */     int ch = this._inputData.readUnsignedByte();
/*      */     
/* 1078 */     if (ch < 48 || ch > 57) {
/* 1079 */       return ch;
/*      */     }
/*      */     
/* 1082 */     if (!isEnabled(JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS)) {
/* 1083 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1086 */     while (ch == 48) {
/* 1087 */       ch = this._inputData.readUnsignedByte();
/*      */     }
/* 1089 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1095 */     int fractLen = 0;
/*      */ 
/*      */     
/* 1098 */     if (c == 46) {
/* 1099 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1103 */         c = this._inputData.readUnsignedByte();
/* 1104 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1107 */         fractLen++;
/* 1108 */         if (outPtr >= outBuf.length) {
/* 1109 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1110 */           outPtr = 0;
/*      */         } 
/* 1112 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1115 */       if (fractLen == 0) {
/* 1116 */         reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1120 */     int expLen = 0;
/* 1121 */     if (c == 101 || c == 69) {
/* 1122 */       if (outPtr >= outBuf.length) {
/* 1123 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1124 */         outPtr = 0;
/*      */       } 
/* 1126 */       outBuf[outPtr++] = (char)c;
/* 1127 */       c = this._inputData.readUnsignedByte();
/*      */       
/* 1129 */       if (c == 45 || c == 43) {
/* 1130 */         if (outPtr >= outBuf.length) {
/* 1131 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1132 */           outPtr = 0;
/*      */         } 
/* 1134 */         outBuf[outPtr++] = (char)c;
/* 1135 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/* 1137 */       while (c <= 57 && c >= 48) {
/* 1138 */         expLen++;
/* 1139 */         if (outPtr >= outBuf.length) {
/* 1140 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1141 */           outPtr = 0;
/*      */         } 
/* 1143 */         outBuf[outPtr++] = (char)c;
/* 1144 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 1147 */       if (expLen == 0) {
/* 1148 */         reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1154 */     this._nextByte = c;
/* 1155 */     if (this._parsingContext.inRoot()) {
/* 1156 */       _verifyRootSpace();
/*      */     }
/* 1158 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1161 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace() throws IOException {
/* 1174 */     int ch = this._nextByte;
/* 1175 */     if (ch <= 32) {
/* 1176 */       this._nextByte = -1;
/* 1177 */       if (ch == 13 || ch == 10) {
/* 1178 */         this._currInputRow++;
/*      */       }
/*      */       return;
/*      */     } 
/* 1182 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1193 */     if (i != 34) {
/* 1194 */       return _handleOddName(i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1202 */     int[] codes = _icLatin1;
/*      */     
/* 1204 */     int q = this._inputData.readUnsignedByte();
/*      */     
/* 1206 */     if (codes[q] == 0) {
/* 1207 */       i = this._inputData.readUnsignedByte();
/* 1208 */       if (codes[i] == 0) {
/* 1209 */         q = q << 8 | i;
/* 1210 */         i = this._inputData.readUnsignedByte();
/* 1211 */         if (codes[i] == 0) {
/* 1212 */           q = q << 8 | i;
/* 1213 */           i = this._inputData.readUnsignedByte();
/* 1214 */           if (codes[i] == 0) {
/* 1215 */             q = q << 8 | i;
/* 1216 */             i = this._inputData.readUnsignedByte();
/* 1217 */             if (codes[i] == 0) {
/* 1218 */               this._quad1 = q;
/* 1219 */               return _parseMediumName(i);
/*      */             } 
/* 1221 */             if (i == 34) {
/* 1222 */               return findName(q, 4);
/*      */             }
/* 1224 */             return parseName(q, i, 4);
/*      */           } 
/* 1226 */           if (i == 34) {
/* 1227 */             return findName(q, 3);
/*      */           }
/* 1229 */           return parseName(q, i, 3);
/*      */         } 
/* 1231 */         if (i == 34) {
/* 1232 */           return findName(q, 2);
/*      */         }
/* 1234 */         return parseName(q, i, 2);
/*      */       } 
/* 1236 */       if (i == 34) {
/* 1237 */         return findName(q, 1);
/*      */       }
/* 1239 */       return parseName(q, i, 1);
/*      */     } 
/* 1241 */     if (q == 34) {
/* 1242 */       return "";
/*      */     }
/* 1244 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName(int q2) throws IOException {
/* 1249 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1252 */     int i = this._inputData.readUnsignedByte();
/* 1253 */     if (codes[i] != 0) {
/* 1254 */       if (i == 34) {
/* 1255 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1257 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1259 */     q2 = q2 << 8 | i;
/* 1260 */     i = this._inputData.readUnsignedByte();
/* 1261 */     if (codes[i] != 0) {
/* 1262 */       if (i == 34) {
/* 1263 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1265 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1267 */     q2 = q2 << 8 | i;
/* 1268 */     i = this._inputData.readUnsignedByte();
/* 1269 */     if (codes[i] != 0) {
/* 1270 */       if (i == 34) {
/* 1271 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1273 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1275 */     q2 = q2 << 8 | i;
/* 1276 */     i = this._inputData.readUnsignedByte();
/* 1277 */     if (codes[i] != 0) {
/* 1278 */       if (i == 34) {
/* 1279 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1281 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1283 */     return _parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName2(int q3, int q2) throws IOException {
/* 1288 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1291 */     int i = this._inputData.readUnsignedByte();
/* 1292 */     if (codes[i] != 0) {
/* 1293 */       if (i == 34) {
/* 1294 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1296 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1298 */     q3 = q3 << 8 | i;
/* 1299 */     i = this._inputData.readUnsignedByte();
/* 1300 */     if (codes[i] != 0) {
/* 1301 */       if (i == 34) {
/* 1302 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1304 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1306 */     q3 = q3 << 8 | i;
/* 1307 */     i = this._inputData.readUnsignedByte();
/* 1308 */     if (codes[i] != 0) {
/* 1309 */       if (i == 34) {
/* 1310 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1312 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1314 */     q3 = q3 << 8 | i;
/* 1315 */     i = this._inputData.readUnsignedByte();
/* 1316 */     if (codes[i] != 0) {
/* 1317 */       if (i == 34) {
/* 1318 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1320 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1322 */     return _parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseLongName(int q, int q2, int q3) throws IOException {
/* 1327 */     this._quadBuffer[0] = this._quad1;
/* 1328 */     this._quadBuffer[1] = q2;
/* 1329 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1332 */     int[] codes = _icLatin1;
/* 1333 */     int qlen = 3;
/*      */     
/*      */     while (true) {
/* 1336 */       int i = this._inputData.readUnsignedByte();
/* 1337 */       if (codes[i] != 0) {
/* 1338 */         if (i == 34) {
/* 1339 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1341 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1344 */       q = q << 8 | i;
/* 1345 */       i = this._inputData.readUnsignedByte();
/* 1346 */       if (codes[i] != 0) {
/* 1347 */         if (i == 34) {
/* 1348 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1350 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1353 */       q = q << 8 | i;
/* 1354 */       i = this._inputData.readUnsignedByte();
/* 1355 */       if (codes[i] != 0) {
/* 1356 */         if (i == 34) {
/* 1357 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1359 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1362 */       q = q << 8 | i;
/* 1363 */       i = this._inputData.readUnsignedByte();
/* 1364 */       if (codes[i] != 0) {
/* 1365 */         if (i == 34) {
/* 1366 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1368 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1372 */       if (qlen >= this._quadBuffer.length) {
/* 1373 */         this._quadBuffer = _growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1375 */       this._quadBuffer[qlen++] = q;
/* 1376 */       q = i;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1381 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1385 */     this._quadBuffer[0] = q1;
/* 1386 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1390 */     this._quadBuffer[0] = q1;
/* 1391 */     this._quadBuffer[1] = q2;
/* 1392 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 1409 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 1412 */       if (codes[ch] != 0) {
/* 1413 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1417 */         if (ch != 92) {
/*      */           
/* 1419 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1422 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1429 */         if (ch > 127) {
/*      */           
/* 1431 */           if (currQuadBytes >= 4) {
/* 1432 */             if (qlen >= quads.length) {
/* 1433 */               this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */             }
/* 1435 */             quads[qlen++] = currQuad;
/* 1436 */             currQuad = 0;
/* 1437 */             currQuadBytes = 0;
/*      */           } 
/* 1439 */           if (ch < 2048) {
/* 1440 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1441 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1444 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1445 */             currQuadBytes++;
/*      */             
/* 1447 */             if (currQuadBytes >= 4) {
/* 1448 */               if (qlen >= quads.length) {
/* 1449 */                 this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */               }
/* 1451 */               quads[qlen++] = currQuad;
/* 1452 */               currQuad = 0;
/* 1453 */               currQuadBytes = 0;
/*      */             } 
/* 1455 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1456 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1459 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1463 */       if (currQuadBytes < 4) {
/* 1464 */         currQuadBytes++;
/* 1465 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1467 */         if (qlen >= quads.length) {
/* 1468 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1470 */         quads[qlen++] = currQuad;
/* 1471 */         currQuad = ch;
/* 1472 */         currQuadBytes = 1;
/*      */       } 
/* 1474 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1477 */     if (currQuadBytes > 0) {
/* 1478 */       if (qlen >= quads.length) {
/* 1479 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1481 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1483 */     String name = this._symbols.findName(quads, qlen);
/* 1484 */     if (name == null) {
/* 1485 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1487 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 1498 */     if (ch == 39 && isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 1499 */       return _parseAposName();
/*      */     }
/* 1501 */     if (!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES)) {
/* 1502 */       char c = (char)_decodeCharForError(ch);
/* 1503 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1509 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 1511 */     if (codes[ch] != 0) {
/* 1512 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1519 */     int[] quads = this._quadBuffer;
/* 1520 */     int qlen = 0;
/* 1521 */     int currQuad = 0;
/* 1522 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     do {
/* 1526 */       if (currQuadBytes < 4) {
/* 1527 */         currQuadBytes++;
/* 1528 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1530 */         if (qlen >= quads.length) {
/* 1531 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1533 */         quads[qlen++] = currQuad;
/* 1534 */         currQuad = ch;
/* 1535 */         currQuadBytes = 1;
/*      */       } 
/* 1537 */       ch = this._inputData.readUnsignedByte();
/* 1538 */     } while (codes[ch] == 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1543 */     this._nextByte = ch;
/* 1544 */     if (currQuadBytes > 0) {
/* 1545 */       if (qlen >= quads.length) {
/* 1546 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1548 */       quads[qlen++] = currQuad;
/*      */     } 
/* 1550 */     String name = this._symbols.findName(quads, qlen);
/* 1551 */     if (name == null) {
/* 1552 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1554 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 1565 */     int ch = this._inputData.readUnsignedByte();
/* 1566 */     if (ch == 39) {
/* 1567 */       return "";
/*      */     }
/* 1569 */     int[] quads = this._quadBuffer;
/* 1570 */     int qlen = 0;
/* 1571 */     int currQuad = 0;
/* 1572 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 1576 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1579 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 1583 */       if (ch != 34 && codes[ch] != 0) {
/* 1584 */         if (ch != 92) {
/*      */ 
/*      */           
/* 1587 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1590 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1596 */         if (ch > 127) {
/*      */           
/* 1598 */           if (currQuadBytes >= 4) {
/* 1599 */             if (qlen >= quads.length) {
/* 1600 */               this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */             }
/* 1602 */             quads[qlen++] = currQuad;
/* 1603 */             currQuad = 0;
/* 1604 */             currQuadBytes = 0;
/*      */           } 
/* 1606 */           if (ch < 2048) {
/* 1607 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1608 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1611 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1612 */             currQuadBytes++;
/*      */             
/* 1614 */             if (currQuadBytes >= 4) {
/* 1615 */               if (qlen >= quads.length) {
/* 1616 */                 this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */               }
/* 1618 */               quads[qlen++] = currQuad;
/* 1619 */               currQuad = 0;
/* 1620 */               currQuadBytes = 0;
/*      */             } 
/* 1622 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1623 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1626 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1630 */       if (currQuadBytes < 4) {
/* 1631 */         currQuadBytes++;
/* 1632 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1634 */         if (qlen >= quads.length) {
/* 1635 */           this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */         }
/* 1637 */         quads[qlen++] = currQuad;
/* 1638 */         currQuad = ch;
/* 1639 */         currQuadBytes = 1;
/*      */       } 
/* 1641 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1644 */     if (currQuadBytes > 0) {
/* 1645 */       if (qlen >= quads.length) {
/* 1646 */         this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */       }
/* 1648 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1650 */     String name = this._symbols.findName(quads, qlen);
/* 1651 */     if (name == null) {
/* 1652 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1654 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException {
/* 1665 */     q1 = pad(q1, lastQuadBytes);
/*      */     
/* 1667 */     String name = this._symbols.findName(q1);
/* 1668 */     if (name != null) {
/* 1669 */       return name;
/*      */     }
/*      */     
/* 1672 */     this._quadBuffer[0] = q1;
/* 1673 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException {
/* 1678 */     q2 = pad(q2, lastQuadBytes);
/*      */     
/* 1680 */     String name = this._symbols.findName(q1, q2);
/* 1681 */     if (name != null) {
/* 1682 */       return name;
/*      */     }
/*      */     
/* 1685 */     this._quadBuffer[0] = q1;
/* 1686 */     this._quadBuffer[1] = q2;
/* 1687 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException {
/* 1692 */     q3 = pad(q3, lastQuadBytes);
/* 1693 */     String name = this._symbols.findName(q1, q2, q3);
/* 1694 */     if (name != null) {
/* 1695 */       return name;
/*      */     }
/* 1697 */     int[] quads = this._quadBuffer;
/* 1698 */     quads[0] = q1;
/* 1699 */     quads[1] = q2;
/* 1700 */     quads[2] = pad(q3, lastQuadBytes);
/* 1701 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException {
/* 1706 */     if (qlen >= quads.length) {
/* 1707 */       this._quadBuffer = quads = _growArrayBy(quads, quads.length);
/*      */     }
/* 1709 */     quads[qlen++] = pad(lastQuad, lastQuadBytes);
/* 1710 */     String name = this._symbols.findName(quads, qlen);
/* 1711 */     if (name == null) {
/* 1712 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 1714 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException {
/* 1730 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1739 */     if (lastQuadBytes < 4) {
/* 1740 */       lastQuad = quads[qlen - 1];
/*      */       
/* 1742 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 1744 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1748 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1749 */     int cix = 0;
/*      */     
/* 1751 */     for (int ix = 0; ix < byteLen; ) {
/* 1752 */       int ch = quads[ix >> 2];
/* 1753 */       int byteIx = ix & 0x3;
/* 1754 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 1755 */       ix++;
/*      */       
/* 1757 */       if (ch > 127) {
/*      */         int needed;
/* 1759 */         if ((ch & 0xE0) == 192) {
/* 1760 */           ch &= 0x1F;
/* 1761 */           needed = 1;
/* 1762 */         } else if ((ch & 0xF0) == 224) {
/* 1763 */           ch &= 0xF;
/* 1764 */           needed = 2;
/* 1765 */         } else if ((ch & 0xF8) == 240) {
/* 1766 */           ch &= 0x7;
/* 1767 */           needed = 3;
/*      */         } else {
/* 1769 */           _reportInvalidInitial(ch);
/* 1770 */           needed = ch = 1;
/*      */         } 
/* 1772 */         if (ix + needed > byteLen) {
/* 1773 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 1777 */         int ch2 = quads[ix >> 2];
/* 1778 */         byteIx = ix & 0x3;
/* 1779 */         ch2 >>= 3 - byteIx << 3;
/* 1780 */         ix++;
/*      */         
/* 1782 */         if ((ch2 & 0xC0) != 128) {
/* 1783 */           _reportInvalidOther(ch2);
/*      */         }
/* 1785 */         ch = ch << 6 | ch2 & 0x3F;
/* 1786 */         if (needed > 1) {
/* 1787 */           ch2 = quads[ix >> 2];
/* 1788 */           byteIx = ix & 0x3;
/* 1789 */           ch2 >>= 3 - byteIx << 3;
/* 1790 */           ix++;
/*      */           
/* 1792 */           if ((ch2 & 0xC0) != 128) {
/* 1793 */             _reportInvalidOther(ch2);
/*      */           }
/* 1795 */           ch = ch << 6 | ch2 & 0x3F;
/* 1796 */           if (needed > 2) {
/* 1797 */             ch2 = quads[ix >> 2];
/* 1798 */             byteIx = ix & 0x3;
/* 1799 */             ch2 >>= 3 - byteIx << 3;
/* 1800 */             ix++;
/* 1801 */             if ((ch2 & 0xC0) != 128) {
/* 1802 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 1804 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 1807 */         if (needed > 2) {
/* 1808 */           ch -= 65536;
/* 1809 */           if (cix >= cbuf.length) {
/* 1810 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 1812 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 1813 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 1816 */       if (cix >= cbuf.length) {
/* 1817 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1819 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 1823 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 1825 */     if (lastQuadBytes < 4) {
/* 1826 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 1828 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 1840 */     int outPtr = 0;
/* 1841 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1842 */     int[] codes = _icUTF8;
/* 1843 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1846 */       int c = this._inputData.readUnsignedByte();
/* 1847 */       if (codes[c] != 0) {
/* 1848 */         if (c == 34) {
/* 1849 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/* 1852 */         _finishString2(outBuf, outPtr, c);
/*      */         return;
/*      */       } 
/* 1855 */       outBuf[outPtr++] = (char)c;
/* 1856 */       if (outPtr >= outEnd) {
/* 1857 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   } private String _finishAndReturnString() throws IOException {
/* 1862 */     int outPtr = 0;
/* 1863 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1864 */     int[] codes = _icUTF8;
/* 1865 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1868 */       int c = this._inputData.readUnsignedByte();
/* 1869 */       if (codes[c] != 0) {
/* 1870 */         if (c == 34) {
/* 1871 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         }
/* 1873 */         _finishString2(outBuf, outPtr, c);
/* 1874 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1876 */       outBuf[outPtr++] = (char)c;
/* 1877 */       if (outPtr >= outEnd) {
/* 1878 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/* 1879 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr, int c) throws IOException {
/* 1886 */     int[] codes = _icUTF8;
/* 1887 */     int outEnd = outBuf.length;
/*      */ 
/*      */     
/* 1890 */     for (;; c = this._inputData.readUnsignedByte()) {
/*      */       
/* 1892 */       while (codes[c] == 0) {
/* 1893 */         if (outPtr >= outEnd) {
/* 1894 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1895 */           outPtr = 0;
/* 1896 */           outEnd = outBuf.length;
/*      */         } 
/* 1898 */         outBuf[outPtr++] = (char)c;
/* 1899 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 1902 */       if (c == 34) {
/*      */         break;
/*      */       }
/* 1905 */       switch (codes[c]) {
/*      */         case 1:
/* 1907 */           c = _decodeEscaped();
/*      */           break;
/*      */         case 2:
/* 1910 */           c = _decodeUtf8_2(c);
/*      */           break;
/*      */         case 3:
/* 1913 */           c = _decodeUtf8_3(c);
/*      */           break;
/*      */         case 4:
/* 1916 */           c = _decodeUtf8_4(c);
/*      */           
/* 1918 */           outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 1919 */           if (outPtr >= outBuf.length) {
/* 1920 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 1921 */             outPtr = 0;
/* 1922 */             outEnd = outBuf.length;
/*      */           } 
/* 1924 */           c = 0xDC00 | c & 0x3FF;
/*      */           break;
/*      */         
/*      */         default:
/* 1928 */           if (c < 32) {
/* 1929 */             _throwUnquotedSpace(c, "string value");
/*      */             break;
/*      */           } 
/* 1932 */           _reportInvalidChar(c);
/*      */           break;
/*      */       } 
/*      */       
/* 1936 */       if (outPtr >= outBuf.length) {
/* 1937 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1938 */         outPtr = 0;
/* 1939 */         outEnd = outBuf.length;
/*      */       } 
/*      */       
/* 1942 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1944 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 1954 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 1957 */     int[] codes = _icUTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1965 */       int c = this._inputData.readUnsignedByte();
/* 1966 */       if (codes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1971 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1975 */         switch (codes[c]) {
/*      */           case 1:
/* 1977 */             _decodeEscaped();
/*      */             continue;
/*      */           case 2:
/* 1980 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 1983 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 1986 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 1989 */         if (c < 32) {
/* 1990 */           _throwUnquotedSpace(c, "string value");
/*      */           continue;
/*      */         } 
/* 1993 */         _reportInvalidChar(c);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2007 */     switch (c) {
/*      */       case 93:
/* 2009 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2017 */         if (isEnabled(JsonParser.Feature.ALLOW_MISSING_VALUES)) {
/*      */           
/* 2019 */           this._nextByte = c;
/* 2020 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2026 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2028 */         if (isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 2029 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2033 */         _matchToken("NaN", 1);
/* 2034 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2035 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2037 */         _reportError("Non-standard token 'NaN': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 73:
/* 2040 */         _matchToken("Infinity", 1);
/* 2041 */         if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2042 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2044 */         _reportError("Non-standard token 'Infinity': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */         break;
/*      */       case 43:
/* 2047 */         return _handleInvalidNumberStart(this._inputData.readUnsignedByte(), false);
/*      */     } 
/*      */     
/* 2050 */     if (Character.isJavaIdentifierStart(c)) {
/* 2051 */       _reportInvalidToken(c, "" + (char)c, "('true', 'false' or 'null')");
/*      */     }
/*      */     
/* 2054 */     _reportUnexpectedChar(c, "expected a valid value (number, String, array, object, 'true', 'false' or 'null')");
/* 2055 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2060 */     int c = 0;
/*      */     
/* 2062 */     int outPtr = 0;
/* 2063 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2066 */     int[] codes = _icUTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label35: while (true) {
/* 2073 */       int outEnd = outBuf.length;
/* 2074 */       if (outPtr >= outBuf.length) {
/* 2075 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2076 */         outPtr = 0;
/* 2077 */         outEnd = outBuf.length;
/*      */       } 
/*      */       while (true)
/* 2080 */       { c = this._inputData.readUnsignedByte();
/* 2081 */         if (c == 39) {
/*      */           break;
/*      */         }
/* 2084 */         if (codes[c] != 0)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */           
/* 2090 */           switch (codes[c]) {
/*      */             case 1:
/* 2092 */               c = _decodeEscaped();
/*      */               break;
/*      */             case 2:
/* 2095 */               c = _decodeUtf8_2(c);
/*      */               break;
/*      */             case 3:
/* 2098 */               c = _decodeUtf8_3(c);
/*      */               break;
/*      */             case 4:
/* 2101 */               c = _decodeUtf8_4(c);
/*      */               
/* 2103 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2104 */               if (outPtr >= outBuf.length) {
/* 2105 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2106 */                 outPtr = 0;
/*      */               } 
/* 2108 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2112 */               if (c < 32) {
/* 2113 */                 _throwUnquotedSpace(c, "string value");
/*      */               }
/*      */               
/* 2116 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/* 2119 */           if (outPtr >= outBuf.length) {
/* 2120 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2121 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2124 */           outBuf[outPtr++] = (char)c; continue; }  outBuf[outPtr++] = (char)c; if (outPtr >= outEnd)
/*      */           continue label35;  }  break;
/* 2126 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2128 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2138 */     while (ch == 73) {
/* 2139 */       String match; ch = this._inputData.readUnsignedByte();
/*      */       
/* 2141 */       if (ch == 78) {
/* 2142 */         match = neg ? "-INF" : "+INF";
/* 2143 */       } else if (ch == 110) {
/* 2144 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2148 */       _matchToken(match, 3);
/* 2149 */       if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 2150 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2152 */       _reportError("Non-standard token '" + match + "': enable JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS to allow");
/*      */     } 
/* 2154 */     reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 2155 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2160 */     int len = matchStr.length();
/*      */     do {
/* 2162 */       int j = this._inputData.readUnsignedByte();
/* 2163 */       if (j == matchStr.charAt(i))
/* 2164 */         continue;  _reportInvalidToken(j, matchStr.substring(0, i));
/*      */     }
/* 2166 */     while (++i < len);
/*      */     
/* 2168 */     int ch = this._inputData.readUnsignedByte();
/* 2169 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2170 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/* 2172 */     this._nextByte = ch;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 2177 */     char c = (char)_decodeCharForError(ch);
/* 2178 */     if (Character.isJavaIdentifierPart(c)) {
/* 2179 */       _reportInvalidToken(c, matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 2191 */     int i = this._nextByte;
/* 2192 */     if (i < 0) {
/* 2193 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2195 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2198 */       if (i > 32) {
/* 2199 */         if (i == 47 || i == 35) {
/* 2200 */           return _skipWSComment(i);
/*      */         }
/* 2202 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2206 */       if (i == 13 || i == 10) {
/* 2207 */         this._currInputRow++;
/*      */       }
/*      */       
/* 2210 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2222 */     int i = this._nextByte;
/* 2223 */     if (i < 0) {
/*      */       try {
/* 2225 */         i = this._inputData.readUnsignedByte();
/* 2226 */       } catch (EOFException e) {
/* 2227 */         return _eofAsNextChar();
/*      */       } 
/*      */     } else {
/* 2230 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2233 */       if (i > 32) {
/* 2234 */         if (i == 47 || i == 35) {
/* 2235 */           return _skipWSComment(i);
/*      */         }
/* 2237 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2241 */       if (i == 13 || i == 10) {
/* 2242 */         this._currInputRow++;
/*      */       }
/*      */       
/*      */       try {
/* 2246 */         i = this._inputData.readUnsignedByte();
/* 2247 */       } catch (EOFException e) {
/* 2248 */         return _eofAsNextChar();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSComment(int i) throws IOException {
/*      */     while (true) {
/* 2256 */       if (i > 32) {
/* 2257 */         if (i == 47) {
/* 2258 */           _skipComment();
/* 2259 */         } else if (i == 35) {
/* 2260 */           if (!_skipYAMLComment()) {
/* 2261 */             return i;
/*      */           }
/*      */         } else {
/* 2264 */           return i;
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 2269 */       else if (i == 13 || i == 10) {
/* 2270 */         this._currInputRow++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2278 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 2284 */     int i = this._nextByte;
/* 2285 */     if (i < 0) {
/* 2286 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2288 */       this._nextByte = -1;
/*      */     } 
/*      */     
/* 2291 */     if (i == 58) {
/* 2292 */       i = this._inputData.readUnsignedByte();
/* 2293 */       if (i > 32) {
/* 2294 */         if (i == 47 || i == 35) {
/* 2295 */           return _skipColon2(i, true);
/*      */         }
/* 2297 */         return i;
/*      */       } 
/* 2299 */       if (i == 32 || i == 9) {
/* 2300 */         i = this._inputData.readUnsignedByte();
/* 2301 */         if (i > 32) {
/* 2302 */           if (i == 47 || i == 35) {
/* 2303 */             return _skipColon2(i, true);
/*      */           }
/* 2305 */           return i;
/*      */         } 
/*      */       } 
/* 2308 */       return _skipColon2(i, true);
/*      */     } 
/* 2310 */     if (i == 32 || i == 9) {
/* 2311 */       i = this._inputData.readUnsignedByte();
/*      */     }
/* 2313 */     if (i == 58) {
/* 2314 */       i = this._inputData.readUnsignedByte();
/* 2315 */       if (i > 32) {
/* 2316 */         if (i == 47 || i == 35) {
/* 2317 */           return _skipColon2(i, true);
/*      */         }
/* 2319 */         return i;
/*      */       } 
/* 2321 */       if (i == 32 || i == 9) {
/* 2322 */         i = this._inputData.readUnsignedByte();
/* 2323 */         if (i > 32) {
/* 2324 */           if (i == 47 || i == 35) {
/* 2325 */             return _skipColon2(i, true);
/*      */           }
/* 2327 */           return i;
/*      */         } 
/*      */       } 
/* 2330 */       return _skipColon2(i, true);
/*      */     } 
/* 2332 */     return _skipColon2(i, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(int i, boolean gotColon) throws IOException {
/* 2337 */     for (;; i = this._inputData.readUnsignedByte()) {
/* 2338 */       if (i > 32) {
/* 2339 */         if (i == 47) {
/* 2340 */           _skipComment();
/*      */         
/*      */         }
/* 2343 */         else if (i != 35 || 
/* 2344 */           !_skipYAMLComment()) {
/*      */ 
/*      */ 
/*      */           
/* 2348 */           if (gotColon) {
/* 2349 */             return i;
/*      */           }
/* 2351 */           if (i != 58) {
/* 2352 */             _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */           }
/* 2354 */           gotColon = true;
/*      */         }
/*      */       
/*      */       }
/* 2358 */       else if (i == 13 || i == 10) {
/* 2359 */         this._currInputRow++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 2367 */     if (!isEnabled(JsonParser.Feature.ALLOW_COMMENTS)) {
/* 2368 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/* 2370 */     int c = this._inputData.readUnsignedByte();
/* 2371 */     if (c == 47) {
/* 2372 */       _skipLine();
/* 2373 */     } else if (c == 42) {
/* 2374 */       _skipCComment();
/*      */     } else {
/* 2376 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 2383 */     int[] codes = CharTypes.getInputCodeComment();
/* 2384 */     int i = this._inputData.readUnsignedByte();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2389 */       int code = codes[i];
/* 2390 */       if (code != 0)
/* 2391 */         switch (code) {
/*      */           case 42:
/* 2393 */             i = this._inputData.readUnsignedByte();
/* 2394 */             if (i == 47) {
/*      */               return;
/*      */             }
/*      */             continue;
/*      */           case 10:
/*      */           case 13:
/* 2400 */             this._currInputRow++;
/*      */             break;
/*      */           case 2:
/* 2403 */             _skipUtf8_2();
/*      */             break;
/*      */           case 3:
/* 2406 */             _skipUtf8_3();
/*      */             break;
/*      */           case 4:
/* 2409 */             _skipUtf8_4();
/*      */             break;
/*      */           
/*      */           default:
/* 2413 */             _reportInvalidChar(i);
/*      */             break;
/*      */         }  
/* 2416 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 2422 */     if (!isEnabled(JsonParser.Feature.ALLOW_YAML_COMMENTS)) {
/* 2423 */       return false;
/*      */     }
/* 2425 */     _skipLine();
/* 2426 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 2436 */     int[] codes = CharTypes.getInputCodeComment();
/*      */     while (true) {
/* 2438 */       int i = this._inputData.readUnsignedByte();
/* 2439 */       int code = codes[i];
/* 2440 */       if (code != 0) {
/* 2441 */         switch (code) {
/*      */           case 10:
/*      */           case 13:
/* 2444 */             this._currInputRow++;
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 2449 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 2452 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 2455 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 2458 */         if (code < 0)
/*      */         {
/* 2460 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 2470 */     int c = this._inputData.readUnsignedByte();
/*      */     
/* 2472 */     switch (c) {
/*      */       
/*      */       case 98:
/* 2475 */         return '\b';
/*      */       case 116:
/* 2477 */         return '\t';
/*      */       case 110:
/* 2479 */         return '\n';
/*      */       case 102:
/* 2481 */         return '\f';
/*      */       case 114:
/* 2483 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 2489 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 2495 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 2499 */     int value = 0;
/* 2500 */     for (int i = 0; i < 4; i++) {
/* 2501 */       int ch = this._inputData.readUnsignedByte();
/* 2502 */       int digit = CharTypes.charToHex(ch);
/* 2503 */       if (digit < 0) {
/* 2504 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2506 */       value = value << 4 | digit;
/*      */     } 
/* 2508 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 2513 */     int c = firstByte & 0xFF;
/* 2514 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 2518 */       if ((c & 0xE0) == 192) {
/* 2519 */         c &= 0x1F;
/* 2520 */         needed = 1;
/* 2521 */       } else if ((c & 0xF0) == 224) {
/* 2522 */         c &= 0xF;
/* 2523 */         needed = 2;
/* 2524 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 2526 */         c &= 0x7;
/* 2527 */         needed = 3;
/*      */       } else {
/* 2529 */         _reportInvalidInitial(c & 0xFF);
/* 2530 */         needed = 1;
/*      */       } 
/*      */       
/* 2533 */       int d = this._inputData.readUnsignedByte();
/* 2534 */       if ((d & 0xC0) != 128) {
/* 2535 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 2537 */       c = c << 6 | d & 0x3F;
/*      */       
/* 2539 */       if (needed > 1) {
/* 2540 */         d = this._inputData.readUnsignedByte();
/* 2541 */         if ((d & 0xC0) != 128) {
/* 2542 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 2544 */         c = c << 6 | d & 0x3F;
/* 2545 */         if (needed > 2) {
/* 2546 */           d = this._inputData.readUnsignedByte();
/* 2547 */           if ((d & 0xC0) != 128) {
/* 2548 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 2550 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2554 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 2565 */     int d = this._inputData.readUnsignedByte();
/* 2566 */     if ((d & 0xC0) != 128) {
/* 2567 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2569 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 2574 */     c1 &= 0xF;
/* 2575 */     int d = this._inputData.readUnsignedByte();
/* 2576 */     if ((d & 0xC0) != 128) {
/* 2577 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2579 */     int c = c1 << 6 | d & 0x3F;
/* 2580 */     d = this._inputData.readUnsignedByte();
/* 2581 */     if ((d & 0xC0) != 128) {
/* 2582 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2584 */     c = c << 6 | d & 0x3F;
/* 2585 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 2594 */     int d = this._inputData.readUnsignedByte();
/* 2595 */     if ((d & 0xC0) != 128) {
/* 2596 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2598 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2599 */     d = this._inputData.readUnsignedByte();
/* 2600 */     if ((d & 0xC0) != 128) {
/* 2601 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2603 */     c = c << 6 | d & 0x3F;
/* 2604 */     d = this._inputData.readUnsignedByte();
/* 2605 */     if ((d & 0xC0) != 128) {
/* 2606 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2612 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 2617 */     int c = this._inputData.readUnsignedByte();
/* 2618 */     if ((c & 0xC0) != 128) {
/* 2619 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 2629 */     int c = this._inputData.readUnsignedByte();
/* 2630 */     if ((c & 0xC0) != 128) {
/* 2631 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/* 2633 */     c = this._inputData.readUnsignedByte();
/* 2634 */     if ((c & 0xC0) != 128) {
/* 2635 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4() throws IOException {
/* 2641 */     int d = this._inputData.readUnsignedByte();
/* 2642 */     if ((d & 0xC0) != 128) {
/* 2643 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2645 */     d = this._inputData.readUnsignedByte();
/* 2646 */     if ((d & 0xC0) != 128) {
/* 2647 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2649 */     d = this._inputData.readUnsignedByte();
/* 2650 */     if ((d & 0xC0) != 128) {
/* 2651 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart) throws IOException {
/* 2663 */     _reportInvalidToken(ch, matchedPart, "'null', 'true', 'false' or NaN");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart, String msg) throws IOException {
/* 2669 */     StringBuilder sb = new StringBuilder(matchedPart);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2676 */       char c = (char)_decodeCharForError(ch);
/* 2677 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2680 */       sb.append(c);
/* 2681 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/* 2683 */     _reportError("Unrecognized token '" + sb.toString() + "': was expecting " + msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 2690 */     if (c < 32) {
/* 2691 */       _throwInvalidSpace(c);
/*      */     }
/* 2693 */     _reportInvalidInitial(c);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 2699 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _reportInvalidOther(int mask) throws JsonParseException {
/* 2705 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */   
/*      */   private static int[] _growArrayBy(int[] arr, int more) {
/* 2710 */     if (arr == null) {
/* 2711 */       return new int[more];
/*      */     }
/* 2713 */     return Arrays.copyOf(arr, arr.length + more);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 2729 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2736 */       int ch = this._inputData.readUnsignedByte();
/* 2737 */       if (ch > 32) {
/* 2738 */         int bits = b64variant.decodeBase64Char(ch);
/* 2739 */         if (bits < 0) {
/* 2740 */           if (ch == 34) {
/* 2741 */             return builder.toByteArray();
/*      */           }
/* 2743 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2744 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 2748 */         int decodedData = bits;
/*      */ 
/*      */         
/* 2751 */         ch = this._inputData.readUnsignedByte();
/* 2752 */         bits = b64variant.decodeBase64Char(ch);
/* 2753 */         if (bits < 0) {
/* 2754 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 2756 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2758 */         ch = this._inputData.readUnsignedByte();
/* 2759 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 2762 */         if (bits < 0) {
/* 2763 */           if (bits != -2) {
/*      */             
/* 2765 */             if (ch == 34) {
/* 2766 */               decodedData >>= 4;
/* 2767 */               builder.append(decodedData);
/* 2768 */               if (b64variant.usesPadding()) {
/* 2769 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2771 */               return builder.toByteArray();
/*      */             } 
/* 2773 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 2775 */           if (bits == -2) {
/* 2776 */             ch = this._inputData.readUnsignedByte();
/* 2777 */             if (!b64variant.usesPaddingChar(ch) && (
/* 2778 */               ch != 92 || 
/* 2779 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/* 2780 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 2784 */             decodedData >>= 4;
/* 2785 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2790 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2792 */         ch = this._inputData.readUnsignedByte();
/* 2793 */         bits = b64variant.decodeBase64Char(ch);
/* 2794 */         if (bits < 0) {
/* 2795 */           if (bits != -2) {
/*      */             
/* 2797 */             if (ch == 34) {
/* 2798 */               decodedData >>= 2;
/* 2799 */               builder.appendTwoBytes(decodedData);
/* 2800 */               if (b64variant.usesPadding()) {
/* 2801 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2803 */               return builder.toByteArray();
/*      */             } 
/* 2805 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 2807 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2814 */             decodedData >>= 2;
/* 2815 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2820 */         decodedData = decodedData << 6 | bits;
/* 2821 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation getTokenLocation() {
/* 2833 */     return new JsonLocation(_getSourceReference(), -1L, -1L, this._tokenInputRow, -1);
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonLocation getCurrentLocation() {
/* 2838 */     return new JsonLocation(_getSourceReference(), -1L, -1L, this._currInputRow, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _closeScope(int i) throws JsonParseException {
/* 2848 */     if (i == 93) {
/* 2849 */       if (!this._parsingContext.inArray()) {
/* 2850 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 2852 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2853 */       this._currToken = JsonToken.END_ARRAY;
/*      */     } 
/* 2855 */     if (i == 125) {
/* 2856 */       if (!this._parsingContext.inObject()) {
/* 2857 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 2859 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2860 */       this._currToken = JsonToken.END_OBJECT;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int pad(int q, int bytes) {
/* 2868 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\core\json\UTF8DataInputJsonParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */