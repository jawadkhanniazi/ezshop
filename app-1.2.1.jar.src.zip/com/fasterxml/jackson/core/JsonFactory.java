/*      */ package com.fasterxml.jackson.core;
/*      */ 
/*      */ import com.fasterxml.jackson.core.format.InputAccessor;
/*      */ import com.fasterxml.jackson.core.format.MatchStrength;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.DataOutputAsStream;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.InputDecorator;
/*      */ import com.fasterxml.jackson.core.io.OutputDecorator;
/*      */ import com.fasterxml.jackson.core.io.SerializedString;
/*      */ import com.fasterxml.jackson.core.io.UTF8Writer;
/*      */ import com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.json.ReaderBasedJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8DataInputJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8JsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.WriterBasedJsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.async.NonBlockingJsonParser;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*      */ import com.fasterxml.jackson.core.util.BufferRecyclers;
/*      */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.io.Writer;
/*      */ import java.net.URL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JsonFactory
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   public static final String FORMAT_NAME_JSON = "JSON";
/*      */   
/*      */   public enum Feature
/*      */   {
/*   78 */     INTERN_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   88 */     CANONICALIZE_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  104 */     FAIL_ON_SYMBOL_HASH_OVERFLOW(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  121 */     USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean _defaultState;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static int collectDefaults() {
/*  135 */       int flags = 0;
/*  136 */       for (Feature f : values()) {
/*  137 */         if (f.enabledByDefault()) flags |= f.getMask(); 
/*      */       } 
/*  139 */       return flags;
/*      */     }
/*      */     Feature(boolean defaultState) {
/*  142 */       this._defaultState = defaultState;
/*      */     }
/*  144 */     public boolean enabledByDefault() { return this._defaultState; }
/*  145 */     public boolean enabledIn(int flags) { return ((flags & getMask()) != 0); } public int getMask() {
/*  146 */       return 1 << ordinal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  164 */   protected static final int DEFAULT_FACTORY_FEATURE_FLAGS = Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   protected static final int DEFAULT_PARSER_FEATURE_FLAGS = JsonParser.Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  176 */   protected static final int DEFAULT_GENERATOR_FEATURE_FLAGS = JsonGenerator.Feature.collectDefaults();
/*      */   
/*  178 */   private static final SerializableString DEFAULT_ROOT_VALUE_SEPARATOR = (SerializableString)DefaultPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  191 */   protected final transient CharsToNameCanonicalizer _rootCharSymbols = CharsToNameCanonicalizer.createRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   protected final transient ByteQuadsCanonicalizer _byteSymbolCanonicalizer = ByteQuadsCanonicalizer.createRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  222 */   protected int _factoryFeatures = DEFAULT_FACTORY_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  227 */   protected int _parserFeatures = DEFAULT_PARSER_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  232 */   protected int _generatorFeatures = DEFAULT_GENERATOR_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CharacterEscapes _characterEscapes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputDecorator _inputDecorator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OutputDecorator _outputDecorator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  260 */   protected SerializableString _rootValueSeparator = DEFAULT_ROOT_VALUE_SEPARATOR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory() {
/*  278 */     this(null);
/*      */   } public JsonFactory(ObjectCodec oc) {
/*  280 */     this._objectCodec = oc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFactory(JsonFactory src, ObjectCodec codec) {
/*  289 */     this._objectCodec = codec;
/*  290 */     this._factoryFeatures = src._factoryFeatures;
/*  291 */     this._parserFeatures = src._parserFeatures;
/*  292 */     this._generatorFeatures = src._generatorFeatures;
/*  293 */     this._characterEscapes = src._characterEscapes;
/*  294 */     this._inputDecorator = src._inputDecorator;
/*  295 */     this._outputDecorator = src._outputDecorator;
/*  296 */     this._rootValueSeparator = src._rootValueSeparator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory copy() {
/*  320 */     _checkInvalidCopy(JsonFactory.class);
/*      */     
/*  322 */     return new JsonFactory(this, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkInvalidCopy(Class<?> exp) {
/*  331 */     if (getClass() != exp) {
/*  332 */       throw new IllegalStateException("Failed copy(): " + getClass().getName() + " (version: " + 
/*  333 */           version() + ") does not override copy(); it has to");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object readResolve() {
/*  349 */     return new JsonFactory(this, this._objectCodec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requiresPropertyOrdering() {
/*  373 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canHandleBinaryNatively() {
/*  387 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseCharArrays() {
/*  401 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canParseAsync() {
/*  414 */     return _isJSONFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatReadFeatureType() {
/*  425 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatWriteFeatureType() {
/*  436 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseSchema(FormatSchema schema) {
/*  455 */     if (schema == null) {
/*  456 */       return false;
/*      */     }
/*  458 */     String ourFormat = getFormatName();
/*  459 */     return (ourFormat != null && ourFormat.equals(schema.getSchemaType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFormatName() {
/*  475 */     if (getClass() == JsonFactory.class) {
/*  476 */       return "JSON";
/*      */     }
/*  478 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MatchStrength hasFormat(InputAccessor acc) throws IOException {
/*  488 */     if (getClass() == JsonFactory.class) {
/*  489 */       return hasJSONFormat(acc);
/*      */     }
/*  491 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requiresCustomCodec() {
/*  508 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MatchStrength hasJSONFormat(InputAccessor acc) throws IOException {
/*  517 */     return ByteSourceJsonBootstrapper.hasJSONFormat(acc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  528 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonFactory configure(Feature f, boolean state) {
/*  542 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory enable(Feature f) {
/*  550 */     this._factoryFeatures |= f.getMask();
/*  551 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory disable(Feature f) {
/*  559 */     this._factoryFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  560 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(Feature f) {
/*  567 */     return ((this._factoryFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonFactory configure(JsonParser.Feature f, boolean state) {
/*  581 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory enable(JsonParser.Feature f) {
/*  589 */     this._parserFeatures |= f.getMask();
/*  590 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory disable(JsonParser.Feature f) {
/*  598 */     this._parserFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  599 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(JsonParser.Feature f) {
/*  606 */     return ((this._parserFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputDecorator getInputDecorator() {
/*  614 */     return this._inputDecorator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setInputDecorator(InputDecorator d) {
/*  621 */     this._inputDecorator = d;
/*  622 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonFactory configure(JsonGenerator.Feature f, boolean state) {
/*  636 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory enable(JsonGenerator.Feature f) {
/*  645 */     this._generatorFeatures |= f.getMask();
/*  646 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory disable(JsonGenerator.Feature f) {
/*  654 */     this._generatorFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  655 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(JsonGenerator.Feature f) {
/*  662 */     return ((this._generatorFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterEscapes getCharacterEscapes() {
/*  669 */     return this._characterEscapes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setCharacterEscapes(CharacterEscapes esc) {
/*  676 */     this._characterEscapes = esc;
/*  677 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputDecorator getOutputDecorator() {
/*  685 */     return this._outputDecorator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setOutputDecorator(OutputDecorator d) {
/*  692 */     this._outputDecorator = d;
/*  693 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setRootValueSeparator(String sep) {
/*  706 */     this._rootValueSeparator = (sep == null) ? null : (SerializableString)new SerializedString(sep);
/*  707 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRootValueSeparator() {
/*  714 */     return (this._rootValueSeparator == null) ? null : this._rootValueSeparator.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setCodec(ObjectCodec oc) {
/*  731 */     this._objectCodec = oc;
/*  732 */     return this;
/*      */   }
/*      */   public ObjectCodec getCodec() {
/*  735 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(File f) throws IOException, JsonParseException {
/*  765 */     IOContext ctxt = _createContext(f, true);
/*  766 */     InputStream in = new FileInputStream(f);
/*  767 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(URL url) throws IOException, JsonParseException {
/*  792 */     IOContext ctxt = _createContext(url, true);
/*  793 */     InputStream in = _optimizedStreamFromURL(url);
/*  794 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(InputStream in) throws IOException, JsonParseException {
/*  819 */     IOContext ctxt = _createContext(in, false);
/*  820 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(Reader r) throws IOException, JsonParseException {
/*  839 */     IOContext ctxt = _createContext(r, false);
/*  840 */     return _createParser(_decorate(r, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] data) throws IOException, JsonParseException {
/*  850 */     IOContext ctxt = _createContext(data, true);
/*  851 */     if (this._inputDecorator != null) {
/*  852 */       InputStream in = this._inputDecorator.decorate(ctxt, data, 0, data.length);
/*  853 */       if (in != null) {
/*  854 */         return _createParser(in, ctxt);
/*      */       }
/*      */     } 
/*  857 */     return _createParser(data, 0, data.length, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] data, int offset, int len) throws IOException, JsonParseException {
/*  871 */     IOContext ctxt = _createContext(data, true);
/*      */     
/*  873 */     if (this._inputDecorator != null) {
/*  874 */       InputStream in = this._inputDecorator.decorate(ctxt, data, offset, len);
/*  875 */       if (in != null) {
/*  876 */         return _createParser(in, ctxt);
/*      */       }
/*      */     } 
/*  879 */     return _createParser(data, offset, len, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(String content) throws IOException, JsonParseException {
/*  889 */     int strLen = content.length();
/*      */     
/*  891 */     if (this._inputDecorator != null || strLen > 32768 || !canUseCharArrays())
/*      */     {
/*      */       
/*  894 */       return createParser(new StringReader(content));
/*      */     }
/*  896 */     IOContext ctxt = _createContext(content, true);
/*  897 */     char[] buf = ctxt.allocTokenBuffer(strLen);
/*  898 */     content.getChars(0, strLen, buf, 0);
/*  899 */     return _createParser(buf, 0, strLen, ctxt, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content) throws IOException {
/*  909 */     return createParser(content, 0, content.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content, int offset, int len) throws IOException {
/*  918 */     if (this._inputDecorator != null) {
/*  919 */       return createParser(new CharArrayReader(content, offset, len));
/*      */     }
/*  921 */     return _createParser(content, offset, len, _createContext(content, true), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(DataInput in) throws IOException {
/*  936 */     IOContext ctxt = _createContext(in, false);
/*  937 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteArrayParser() throws IOException {
/*  962 */     _requireJSONFactory("Non-blocking source not (yet?) support for this format (%s)");
/*  963 */     IOContext ctxt = _createNonBlockingContext(null);
/*  964 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChild(this._factoryFeatures);
/*  965 */     return (JsonParser)new NonBlockingJsonParser(ctxt, this._parserFeatures, can);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(File f) throws IOException, JsonParseException {
/*  995 */     return createParser(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(URL url) throws IOException, JsonParseException {
/* 1020 */     return createParser(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(InputStream in) throws IOException, JsonParseException {
/* 1046 */     return createParser(in);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(Reader r) throws IOException, JsonParseException {
/* 1065 */     return createParser(r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data) throws IOException, JsonParseException {
/* 1075 */     return createParser(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data, int offset, int len) throws IOException, JsonParseException {
/* 1090 */     return createParser(data, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(String content) throws IOException, JsonParseException {
/* 1101 */     return createParser(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1136 */     IOContext ctxt = _createContext(out, false);
/* 1137 */     ctxt.setEncoding(enc);
/* 1138 */     if (enc == JsonEncoding.UTF8) {
/* 1139 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1141 */     Writer w = _createWriter(out, enc, ctxt);
/* 1142 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out) throws IOException {
/* 1154 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(Writer w) throws IOException {
/* 1173 */     IOContext ctxt = _createContext(w, false);
/* 1174 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(File f, JsonEncoding enc) throws IOException {
/* 1195 */     OutputStream out = new FileOutputStream(f);
/*      */     
/* 1197 */     IOContext ctxt = _createContext(out, true);
/* 1198 */     ctxt.setEncoding(enc);
/* 1199 */     if (enc == JsonEncoding.UTF8) {
/* 1200 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1202 */     Writer w = _createWriter(out, enc, ctxt);
/* 1203 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out, JsonEncoding enc) throws IOException {
/* 1213 */     return createGenerator(_createDataOutputWrapper(out), enc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out) throws IOException {
/* 1225 */     return createGenerator(_createDataOutputWrapper(out), JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1258 */     return createGenerator(out, enc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(Writer out) throws IOException {
/* 1278 */     return createGenerator(out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out) throws IOException {
/* 1291 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(InputStream in, IOContext ctxt) throws IOException {
/* 1315 */     return (new ByteSourceJsonBootstrapper(ctxt, in)).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(Reader r, IOContext ctxt) throws IOException {
/* 1332 */     return (JsonParser)new ReaderBasedJsonParser(ctxt, this._parserFeatures, r, this._objectCodec, this._rootCharSymbols
/* 1333 */         .makeChild(this._factoryFeatures));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(char[] data, int offset, int len, IOContext ctxt, boolean recyclable) throws IOException {
/* 1344 */     return (JsonParser)new ReaderBasedJsonParser(ctxt, this._parserFeatures, null, this._objectCodec, this._rootCharSymbols
/* 1345 */         .makeChild(this._factoryFeatures), data, offset, offset + len, recyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(byte[] data, int offset, int len, IOContext ctxt) throws IOException {
/* 1362 */     return (new ByteSourceJsonBootstrapper(ctxt, data, offset, len)).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(DataInput input, IOContext ctxt) throws IOException {
/* 1375 */     _requireJSONFactory("InputData source not (yet?) support for this format (%s)");
/*      */ 
/*      */     
/* 1378 */     int firstByte = ByteSourceJsonBootstrapper.skipUTF8BOM(input);
/* 1379 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChild(this._factoryFeatures);
/* 1380 */     return (JsonParser)new UTF8DataInputJsonParser(ctxt, this._parserFeatures, input, this._objectCodec, can, firstByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonGenerator _createGenerator(Writer out, IOContext ctxt) throws IOException {
/* 1403 */     WriterBasedJsonGenerator gen = new WriterBasedJsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out);
/*      */     
/* 1405 */     if (this._characterEscapes != null) {
/* 1406 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 1408 */     SerializableString rootSep = this._rootValueSeparator;
/* 1409 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 1410 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 1412 */     return (JsonGenerator)gen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonGenerator _createUTF8Generator(OutputStream out, IOContext ctxt) throws IOException {
/* 1426 */     UTF8JsonGenerator gen = new UTF8JsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out);
/*      */     
/* 1428 */     if (this._characterEscapes != null) {
/* 1429 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 1431 */     SerializableString rootSep = this._rootValueSeparator;
/* 1432 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 1433 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 1435 */     return (JsonGenerator)gen;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Writer _createWriter(OutputStream out, JsonEncoding enc, IOContext ctxt) throws IOException {
/* 1441 */     if (enc == JsonEncoding.UTF8) {
/* 1442 */       return (Writer)new UTF8Writer(ctxt, out);
/*      */     }
/*      */     
/* 1445 */     return new OutputStreamWriter(out, enc.getJavaName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final InputStream _decorate(InputStream in, IOContext ctxt) throws IOException {
/* 1458 */     if (this._inputDecorator != null) {
/* 1459 */       InputStream in2 = this._inputDecorator.decorate(ctxt, in);
/* 1460 */       if (in2 != null) {
/* 1461 */         return in2;
/*      */       }
/*      */     } 
/* 1464 */     return in;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Reader _decorate(Reader in, IOContext ctxt) throws IOException {
/* 1471 */     if (this._inputDecorator != null) {
/* 1472 */       Reader in2 = this._inputDecorator.decorate(ctxt, in);
/* 1473 */       if (in2 != null) {
/* 1474 */         return in2;
/*      */       }
/*      */     } 
/* 1477 */     return in;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DataInput _decorate(DataInput in, IOContext ctxt) throws IOException {
/* 1484 */     if (this._inputDecorator != null) {
/* 1485 */       DataInput in2 = this._inputDecorator.decorate(ctxt, in);
/* 1486 */       if (in2 != null) {
/* 1487 */         return in2;
/*      */       }
/*      */     } 
/* 1490 */     return in;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final OutputStream _decorate(OutputStream out, IOContext ctxt) throws IOException {
/* 1497 */     if (this._outputDecorator != null) {
/* 1498 */       OutputStream out2 = this._outputDecorator.decorate(ctxt, out);
/* 1499 */       if (out2 != null) {
/* 1500 */         return out2;
/*      */       }
/*      */     } 
/* 1503 */     return out;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Writer _decorate(Writer out, IOContext ctxt) throws IOException {
/* 1510 */     if (this._outputDecorator != null) {
/* 1511 */       Writer out2 = this._outputDecorator.decorate(ctxt, out);
/* 1512 */       if (out2 != null) {
/* 1513 */         return out2;
/*      */       }
/*      */     } 
/* 1516 */     return out;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferRecycler _getBufferRecycler() {
/* 1537 */     if (Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING.enabledIn(this._factoryFeatures)) {
/* 1538 */       return BufferRecyclers.getBufferRecycler();
/*      */     }
/* 1540 */     return new BufferRecycler();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IOContext _createContext(Object srcRef, boolean resourceManaged) {
/* 1548 */     return new IOContext(_getBufferRecycler(), srcRef, resourceManaged);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IOContext _createNonBlockingContext(Object srcRef) {
/* 1560 */     BufferRecycler recycler = new BufferRecycler();
/* 1561 */     return new IOContext(recycler, srcRef, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OutputStream _createDataOutputWrapper(DataOutput out) {
/* 1568 */     return (OutputStream)new DataOutputAsStream(out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream _optimizedStreamFromURL(URL url) throws IOException {
/* 1577 */     if ("file".equals(url.getProtocol())) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1584 */       String host = url.getHost();
/* 1585 */       if (host == null || host.length() == 0) {
/*      */         
/* 1587 */         String path = url.getPath();
/* 1588 */         if (path.indexOf('%') < 0) {
/* 1589 */           return new FileInputStream(url.getPath());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1595 */     return url.openStream();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _requireJSONFactory(String msg) {
/* 1617 */     if (!_isJSONFactory()) {
/* 1618 */       throw new UnsupportedOperationException(String.format(msg, new Object[] { getFormatName() }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _isJSONFactory() {
/* 1625 */     return (getFormatName() == "JSON");
/*      */   }
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\core\JsonFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */