/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.BufferRecyclers;
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonStringEncoder
/*     */ {
/*  20 */   private static final char[] HC = CharTypes.copyHexChars();
/*     */   
/*  22 */   private static final byte[] HB = CharTypes.copyHexBytes();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SURR1_FIRST = 55296;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SURR1_LAST = 56319;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SURR2_FIRST = 56320;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SURR2_LAST = 57343;
/*     */ 
/*     */ 
/*     */   
/*     */   protected TextBuffer _text;
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteArrayBuilder _bytes;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final char[] _qbuf;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonStringEncoder() {
/*  57 */     this._qbuf = new char[6];
/*  58 */     this._qbuf[0] = '\\';
/*  59 */     this._qbuf[2] = '0';
/*  60 */     this._qbuf[3] = '0';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JsonStringEncoder getInstance() {
/*  71 */     return BufferRecyclers.getJsonStringEncoder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] quoteAsString(String input) {
/*  86 */     TextBuffer textBuffer = this._text;
/*  87 */     if (textBuffer == null)
/*     */     {
/*  89 */       this._text = textBuffer = new TextBuffer(null);
/*     */     }
/*  91 */     char[] outputBuffer = textBuffer.emptyAndGetCurrentSegment();
/*  92 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/*  93 */     int escCodeCount = escCodes.length;
/*  94 */     int inPtr = 0;
/*  95 */     int inputLen = input.length();
/*  96 */     int outPtr = 0;
/*     */ 
/*     */     
/*  99 */     while (inPtr < inputLen) {
/*     */       
/*     */       label30: while (true) {
/* 102 */         char d, c = input.charAt(inPtr);
/* 103 */         if (c < escCodeCount && escCodes[c] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 116 */           d = input.charAt(inPtr++);
/* 117 */           int escCode = escCodes[d];
/*     */ 
/*     */           
/* 120 */           int length = (escCode < 0) ? _appendNumeric(d, this._qbuf) : _appendNamed(escCode, this._qbuf);
/*     */           
/* 122 */           if (outPtr + length > outputBuffer.length) {
/* 123 */             int first = outputBuffer.length - outPtr;
/* 124 */             if (first > 0) {
/* 125 */               System.arraycopy(this._qbuf, 0, outputBuffer, outPtr, first);
/*     */               
/* 127 */               outputBuffer = textBuffer.finishCurrentSegment();
/* 128 */               int second = length - first;
/* 129 */               System.arraycopy(this._qbuf, first, outputBuffer, 0, second);
/* 130 */               outPtr = second; continue;
/*     */             }  break label30;
/* 132 */           }  System.arraycopy(this._qbuf, 0, outputBuffer, outPtr, length);
/* 133 */           outPtr += length; continue; }  if (outPtr >= outputBuffer.length) { outputBuffer = textBuffer.finishCurrentSegment(); outPtr = 0; }  outputBuffer[outPtr++] = d; if (++inPtr >= inputLen)
/*     */           break; 
/*     */       } 
/* 136 */     }  textBuffer.setCurrentLength(outPtr);
/* 137 */     return textBuffer.contentsAsArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quoteAsString(CharSequence input, StringBuilder output) {
/* 149 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/* 150 */     int escCodeCount = escCodes.length;
/* 151 */     int inPtr = 0;
/* 152 */     int inputLen = input.length();
/*     */ 
/*     */     
/* 155 */     while (inPtr < inputLen) {
/*     */       
/*     */       while (true) {
/* 158 */         char d, c = input.charAt(inPtr);
/* 159 */         if (c < escCodeCount && escCodes[c] != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 168 */           d = input.charAt(inPtr++);
/* 169 */           int escCode = escCodes[d];
/* 170 */           if (escCode < 0);
/*     */           
/* 172 */           int length = _appendNamed(escCode, this._qbuf);
/*     */           
/* 174 */           output.append(this._qbuf, 0, length);
/*     */           continue;
/*     */         } 
/*     */         output.append(d);
/*     */         if (++inPtr >= inputLen)
/*     */           break; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] quoteAsUTF8(String text) {
/* 185 */     ByteArrayBuilder bb = this._bytes;
/* 186 */     if (bb == null)
/*     */     {
/* 188 */       this._bytes = bb = new ByteArrayBuilder(null);
/*     */     }
/* 190 */     int inputPtr = 0;
/* 191 */     int inputEnd = text.length();
/* 192 */     int outputPtr = 0;
/* 193 */     byte[] outputBuffer = bb.resetAndGetFirstSegment();
/*     */ 
/*     */     
/* 196 */     while (inputPtr < inputEnd) {
/* 197 */       int[] escCodes = CharTypes.get7BitOutputEscapes();
/*     */ 
/*     */       
/*     */       label52: while (true)
/* 201 */       { int ch = text.charAt(inputPtr);
/* 202 */         if (ch > 127 || escCodes[ch] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 214 */           if (outputPtr >= outputBuffer.length) {
/* 215 */             outputBuffer = bb.finishCurrentSegment();
/* 216 */             outputPtr = 0;
/*     */           } 
/*     */           
/* 219 */           ch = text.charAt(inputPtr++);
/* 220 */           if (ch <= 127) {
/* 221 */             int escape = escCodes[ch];
/*     */             
/* 223 */             outputPtr = _appendByte(ch, escape, bb, outputPtr);
/* 224 */             outputBuffer = bb.getCurrentSegment();
/*     */             continue;
/*     */           } 
/* 227 */           if (ch <= 2047) {
/* 228 */             outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 229 */             ch = 0x80 | ch & 0x3F;
/*     */           
/*     */           }
/* 232 */           else if (ch < 55296 || ch > 57343) {
/* 233 */             outputBuffer[outputPtr++] = (byte)(0xE0 | ch >> 12);
/* 234 */             if (outputPtr >= outputBuffer.length) {
/* 235 */               outputBuffer = bb.finishCurrentSegment();
/* 236 */               outputPtr = 0;
/*     */             } 
/* 238 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 239 */             ch = 0x80 | ch & 0x3F;
/*     */           } else {
/* 241 */             if (ch > 56319) {
/* 242 */               _illegal(ch);
/*     */             }
/*     */             
/* 245 */             if (inputPtr >= inputEnd) {
/* 246 */               _illegal(ch);
/*     */             }
/* 248 */             ch = _convert(ch, text.charAt(inputPtr++));
/* 249 */             if (ch > 1114111) {
/* 250 */               _illegal(ch);
/*     */             }
/* 252 */             outputBuffer[outputPtr++] = (byte)(0xF0 | ch >> 18);
/* 253 */             if (outputPtr >= outputBuffer.length) {
/* 254 */               outputBuffer = bb.finishCurrentSegment();
/* 255 */               outputPtr = 0;
/*     */             } 
/* 257 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 12 & 0x3F);
/* 258 */             if (outputPtr >= outputBuffer.length) {
/* 259 */               outputBuffer = bb.finishCurrentSegment();
/* 260 */               outputPtr = 0;
/*     */             } 
/* 262 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 263 */             ch = 0x80 | ch & 0x3F;
/*     */           } 
/*     */           
/* 266 */           if (outputPtr >= outputBuffer.length)
/* 267 */           { outputBuffer = bb.finishCurrentSegment();
/* 268 */             outputPtr = 0;
/*     */             
/* 270 */             outputBuffer[outputPtr++] = (byte)ch; continue; }  break label52; }  if (outputPtr >= outputBuffer.length) { outputBuffer = bb.finishCurrentSegment(); outputPtr = 0; }  outputBuffer[outputPtr++] = (byte)ch; if (++inputPtr >= inputEnd)
/*     */           break;  } 
/* 272 */     }  return this._bytes.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encodeAsUTF8(String text) {
/* 282 */     ByteArrayBuilder byteBuilder = this._bytes;
/* 283 */     if (byteBuilder == null)
/*     */     {
/* 285 */       this._bytes = byteBuilder = new ByteArrayBuilder(null);
/*     */     }
/* 287 */     int inputPtr = 0;
/* 288 */     int inputEnd = text.length();
/* 289 */     int outputPtr = 0;
/* 290 */     byte[] outputBuffer = byteBuilder.resetAndGetFirstSegment();
/* 291 */     int outputEnd = outputBuffer.length;
/*     */ 
/*     */     
/* 294 */     label48: while (inputPtr < inputEnd) {
/* 295 */       int c = text.charAt(inputPtr++);
/*     */ 
/*     */       
/* 298 */       while (c <= 127) {
/* 299 */         if (outputPtr >= outputEnd) {
/* 300 */           outputBuffer = byteBuilder.finishCurrentSegment();
/* 301 */           outputEnd = outputBuffer.length;
/* 302 */           outputPtr = 0;
/*     */         } 
/* 304 */         outputBuffer[outputPtr++] = (byte)c;
/* 305 */         if (inputPtr >= inputEnd) {
/*     */           break label48;
/*     */         }
/* 308 */         c = text.charAt(inputPtr++);
/*     */       } 
/*     */ 
/*     */       
/* 312 */       if (outputPtr >= outputEnd) {
/* 313 */         outputBuffer = byteBuilder.finishCurrentSegment();
/* 314 */         outputEnd = outputBuffer.length;
/* 315 */         outputPtr = 0;
/*     */       } 
/* 317 */       if (c < 2048) {
/* 318 */         outputBuffer[outputPtr++] = (byte)(0xC0 | c >> 6);
/*     */       
/*     */       }
/* 321 */       else if (c < 55296 || c > 57343) {
/* 322 */         outputBuffer[outputPtr++] = (byte)(0xE0 | c >> 12);
/* 323 */         if (outputPtr >= outputEnd) {
/* 324 */           outputBuffer = byteBuilder.finishCurrentSegment();
/* 325 */           outputEnd = outputBuffer.length;
/* 326 */           outputPtr = 0;
/*     */         } 
/* 328 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } else {
/* 330 */         if (c > 56319) {
/* 331 */           _illegal(c);
/*     */         }
/*     */         
/* 334 */         if (inputPtr >= inputEnd) {
/* 335 */           _illegal(c);
/*     */         }
/* 337 */         c = _convert(c, text.charAt(inputPtr++));
/* 338 */         if (c > 1114111) {
/* 339 */           _illegal(c);
/*     */         }
/* 341 */         outputBuffer[outputPtr++] = (byte)(0xF0 | c >> 18);
/* 342 */         if (outputPtr >= outputEnd) {
/* 343 */           outputBuffer = byteBuilder.finishCurrentSegment();
/* 344 */           outputEnd = outputBuffer.length;
/* 345 */           outputPtr = 0;
/*     */         } 
/* 347 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 348 */         if (outputPtr >= outputEnd) {
/* 349 */           outputBuffer = byteBuilder.finishCurrentSegment();
/* 350 */           outputEnd = outputBuffer.length;
/* 351 */           outputPtr = 0;
/*     */         } 
/* 353 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } 
/*     */       
/* 356 */       if (outputPtr >= outputEnd) {
/* 357 */         outputBuffer = byteBuilder.finishCurrentSegment();
/* 358 */         outputEnd = outputBuffer.length;
/* 359 */         outputPtr = 0;
/*     */       } 
/* 361 */       outputBuffer[outputPtr++] = (byte)(0x80 | c & 0x3F);
/*     */     } 
/* 363 */     return this._bytes.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int _appendNumeric(int value, char[] qbuf) {
/* 373 */     qbuf[1] = 'u';
/*     */     
/* 375 */     qbuf[4] = HC[value >> 4];
/* 376 */     qbuf[5] = HC[value & 0xF];
/* 377 */     return 6;
/*     */   }
/*     */   
/*     */   private int _appendNamed(int esc, char[] qbuf) {
/* 381 */     qbuf[1] = (char)esc;
/* 382 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   private int _appendByte(int ch, int esc, ByteArrayBuilder bb, int ptr) {
/* 387 */     bb.setCurrentSegmentLength(ptr);
/* 388 */     bb.append(92);
/* 389 */     if (esc < 0) {
/* 390 */       bb.append(117);
/* 391 */       if (ch > 255) {
/* 392 */         int hi = ch >> 8;
/* 393 */         bb.append(HB[hi >> 4]);
/* 394 */         bb.append(HB[hi & 0xF]);
/* 395 */         ch &= 0xFF;
/*     */       } else {
/* 397 */         bb.append(48);
/* 398 */         bb.append(48);
/*     */       } 
/* 400 */       bb.append(HB[ch >> 4]);
/* 401 */       bb.append(HB[ch & 0xF]);
/*     */     } else {
/* 403 */       bb.append((byte)esc);
/*     */     } 
/* 405 */     return bb.getCurrentSegmentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _convert(int p1, int p2) {
/* 410 */     if (p2 < 56320 || p2 > 57343) {
/* 411 */       throw new IllegalArgumentException("Broken surrogate pair: first char 0x" + Integer.toHexString(p1) + ", second 0x" + Integer.toHexString(p2) + "; illegal combination");
/*     */     }
/* 413 */     return 65536 + (p1 - 55296 << 10) + p2 - 56320;
/*     */   }
/*     */   
/*     */   private static void _illegal(int c) {
/* 417 */     throw new IllegalArgumentException(UTF8Writer.illegalSurrogateDesc(c));
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\core\io\JsonStringEncoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */