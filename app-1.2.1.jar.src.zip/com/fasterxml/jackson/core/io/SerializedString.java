/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.util.BufferRecyclers;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.nio.ByteBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializedString
/*     */   implements SerializableString, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final String _value;
/*     */   protected byte[] _quotedUTF8Ref;
/*     */   protected byte[] _unquotedUTF8Ref;
/*     */   protected char[] _quotedChars;
/*     */   protected transient String _jdkSerializeValue;
/*     */   
/*     */   public SerializedString(String v) {
/*  51 */     if (v == null) {
/*  52 */       throw new IllegalStateException("Null String illegal for SerializedString");
/*     */     }
/*  54 */     this._value = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException {
/*  72 */     this._jdkSerializeValue = in.readUTF();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/*  76 */     out.writeUTF(this._value);
/*     */   }
/*     */   
/*     */   protected Object readResolve() {
/*  80 */     return new SerializedString(this._jdkSerializeValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getValue() {
/*  90 */     return this._value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int charLength() {
/*  96 */     return this._value.length();
/*     */   }
/*     */   
/*     */   public final char[] asQuotedChars() {
/* 100 */     char[] result = this._quotedChars;
/* 101 */     if (result == null) {
/* 102 */       result = BufferRecyclers.quoteAsJsonText(this._value);
/* 103 */       this._quotedChars = result;
/*     */     } 
/* 105 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] asUnquotedUTF8() {
/* 114 */     byte[] result = this._unquotedUTF8Ref;
/* 115 */     if (result == null) {
/* 116 */       result = BufferRecyclers.encodeAsUTF8(this._value);
/* 117 */       this._unquotedUTF8Ref = result;
/*     */     } 
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] asQuotedUTF8() {
/* 128 */     byte[] result = this._quotedUTF8Ref;
/* 129 */     if (result == null) {
/* 130 */       result = BufferRecyclers.quoteAsJsonUTF8(this._value);
/* 131 */       this._quotedUTF8Ref = result;
/*     */     } 
/* 133 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int appendQuotedUTF8(byte[] buffer, int offset) {
/* 144 */     byte[] result = this._quotedUTF8Ref;
/* 145 */     if (result == null) {
/* 146 */       result = BufferRecyclers.quoteAsJsonUTF8(this._value);
/* 147 */       this._quotedUTF8Ref = result;
/*     */     } 
/* 149 */     int length = result.length;
/* 150 */     if (offset + length > buffer.length) {
/* 151 */       return -1;
/*     */     }
/* 153 */     System.arraycopy(result, 0, buffer, offset, length);
/* 154 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int appendQuoted(char[] buffer, int offset) {
/* 159 */     char[] result = this._quotedChars;
/* 160 */     if (result == null) {
/* 161 */       result = BufferRecyclers.quoteAsJsonText(this._value);
/* 162 */       this._quotedChars = result;
/*     */     } 
/* 164 */     int length = result.length;
/* 165 */     if (offset + length > buffer.length) {
/* 166 */       return -1;
/*     */     }
/* 168 */     System.arraycopy(result, 0, buffer, offset, length);
/* 169 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int appendUnquotedUTF8(byte[] buffer, int offset) {
/* 174 */     byte[] result = this._unquotedUTF8Ref;
/* 175 */     if (result == null) {
/* 176 */       result = BufferRecyclers.encodeAsUTF8(this._value);
/* 177 */       this._unquotedUTF8Ref = result;
/*     */     } 
/* 179 */     int length = result.length;
/* 180 */     if (offset + length > buffer.length) {
/* 181 */       return -1;
/*     */     }
/* 183 */     System.arraycopy(result, 0, buffer, offset, length);
/* 184 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int appendUnquoted(char[] buffer, int offset) {
/* 189 */     String str = this._value;
/* 190 */     int length = str.length();
/* 191 */     if (offset + length > buffer.length) {
/* 192 */       return -1;
/*     */     }
/* 194 */     str.getChars(0, length, buffer, offset);
/* 195 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int writeQuotedUTF8(OutputStream out) throws IOException {
/* 200 */     byte[] result = this._quotedUTF8Ref;
/* 201 */     if (result == null) {
/* 202 */       result = BufferRecyclers.quoteAsJsonUTF8(this._value);
/* 203 */       this._quotedUTF8Ref = result;
/*     */     } 
/* 205 */     int length = result.length;
/* 206 */     out.write(result, 0, length);
/* 207 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int writeUnquotedUTF8(OutputStream out) throws IOException {
/* 212 */     byte[] result = this._unquotedUTF8Ref;
/* 213 */     if (result == null) {
/* 214 */       result = BufferRecyclers.encodeAsUTF8(this._value);
/* 215 */       this._unquotedUTF8Ref = result;
/*     */     } 
/* 217 */     int length = result.length;
/* 218 */     out.write(result, 0, length);
/* 219 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int putQuotedUTF8(ByteBuffer buffer) {
/* 224 */     byte[] result = this._quotedUTF8Ref;
/* 225 */     if (result == null) {
/* 226 */       result = BufferRecyclers.quoteAsJsonUTF8(this._value);
/* 227 */       this._quotedUTF8Ref = result;
/*     */     } 
/* 229 */     int length = result.length;
/* 230 */     if (length > buffer.remaining()) {
/* 231 */       return -1;
/*     */     }
/* 233 */     buffer.put(result, 0, length);
/* 234 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int putUnquotedUTF8(ByteBuffer buffer) {
/* 239 */     byte[] result = this._unquotedUTF8Ref;
/* 240 */     if (result == null) {
/* 241 */       result = BufferRecyclers.encodeAsUTF8(this._value);
/* 242 */       this._unquotedUTF8Ref = result;
/*     */     } 
/* 244 */     int length = result.length;
/* 245 */     if (length > buffer.remaining()) {
/* 246 */       return -1;
/*     */     }
/* 248 */     buffer.put(result, 0, length);
/* 249 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 260 */     return this._value;
/*     */   }
/*     */   public final int hashCode() {
/* 263 */     return this._value.hashCode();
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/* 267 */     if (o == this) return true; 
/* 268 */     if (o == null || o.getClass() != getClass()) return false; 
/* 269 */     SerializedString other = (SerializedString)o;
/* 270 */     return this._value.equals(other._value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\fasterxml\jackson\core\io\SerializedString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */