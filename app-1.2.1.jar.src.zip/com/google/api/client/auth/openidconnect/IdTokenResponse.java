/*     */ package com.google.api.client.auth.openidconnect;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.TokenRequest;
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class IdTokenResponse
/*     */   extends TokenResponse
/*     */ {
/*     */   @Key("id_token")
/*     */   private String idToken;
/*     */   
/*     */   public final String getIdToken() {
/*  57 */     return this.idToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdTokenResponse setIdToken(String idToken) {
/*  69 */     this.idToken = (String)Preconditions.checkNotNull(idToken);
/*  70 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IdTokenResponse setAccessToken(String accessToken) {
/*  75 */     super.setAccessToken(accessToken);
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IdTokenResponse setTokenType(String tokenType) {
/*  81 */     super.setTokenType(tokenType);
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IdTokenResponse setExpiresInSeconds(Long expiresIn) {
/*  87 */     super.setExpiresInSeconds(expiresIn);
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IdTokenResponse setRefreshToken(String refreshToken) {
/*  93 */     super.setRefreshToken(refreshToken);
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IdTokenResponse setScope(String scope) {
/*  99 */     super.setScope(scope);
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IdToken parseIdToken() throws IOException {
/* 109 */     return IdToken.parse(getFactory(), this.idToken);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IdTokenResponse execute(TokenRequest tokenRequest) throws IOException {
/* 120 */     return (IdTokenResponse)tokenRequest.executeUnparsed().parseAs(IdTokenResponse.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public IdTokenResponse set(String fieldName, Object value) {
/* 125 */     return (IdTokenResponse)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public IdTokenResponse clone() {
/* 130 */     return (IdTokenResponse)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\openidconnect\IdTokenResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */