/*     */ package com.google.api.client.auth.openidconnect;
/*     */ 
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.webtoken.JsonWebSignature;
/*     */ import com.google.api.client.json.webtoken.JsonWebToken;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class IdToken
/*     */   extends JsonWebSignature
/*     */ {
/*     */   public IdToken(JsonWebSignature.Header header, Payload payload, byte[] signatureBytes, byte[] signedContentBytes) {
/*  55 */     super(header, payload, signatureBytes, signedContentBytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public Payload getPayload() {
/*  60 */     return (Payload)super.getPayload();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean verifyIssuer(String expectedIssuer) {
/*  72 */     return verifyIssuer(Collections.singleton(expectedIssuer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean verifyIssuer(Collection<String> expectedIssuer) {
/*  85 */     return expectedIssuer.contains(getPayload().getIssuer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean verifyAudience(Collection<String> trustedClientIds) {
/*  97 */     Collection<String> audience = getPayload().getAudienceAsList();
/*  98 */     if (audience.isEmpty()) {
/*  99 */       return false;
/*     */     }
/* 101 */     return trustedClientIds.containsAll(audience);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean verifyTime(long currentTimeMillis, long acceptableTimeSkewSeconds) {
/* 116 */     return (verifyExpirationTime(currentTimeMillis, acceptableTimeSkewSeconds) && 
/* 117 */       verifyIssuedAtTime(currentTimeMillis, acceptableTimeSkewSeconds));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean verifyExpirationTime(long currentTimeMillis, long acceptableTimeSkewSeconds) {
/* 132 */     return 
/* 133 */       (currentTimeMillis <= (getPayload().getExpirationTimeSeconds().longValue() + acceptableTimeSkewSeconds) * 1000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean verifyIssuedAtTime(long currentTimeMillis, long acceptableTimeSkewSeconds) {
/* 147 */     return 
/* 148 */       (currentTimeMillis >= (getPayload().getIssuedAtTimeSeconds().longValue() - acceptableTimeSkewSeconds) * 1000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IdToken parse(JsonFactory jsonFactory, String idTokenString) throws IOException {
/* 160 */     JsonWebSignature jws = JsonWebSignature.parser(jsonFactory).setPayloadClass(Payload.class).parse(idTokenString);
/* 161 */     return new IdToken(jws.getHeader(), (Payload)jws.getPayload(), jws.getSignatureBytes(), jws
/* 162 */         .getSignedContentBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Payload
/*     */     extends JsonWebToken.Payload
/*     */   {
/*     */     @Key("auth_time")
/*     */     private Long authorizationTimeSeconds;
/*     */ 
/*     */     
/*     */     @Key("azp")
/*     */     private String authorizedParty;
/*     */ 
/*     */     
/*     */     @Key
/*     */     private String nonce;
/*     */ 
/*     */     
/*     */     @Key("at_hash")
/*     */     private String accessTokenHash;
/*     */ 
/*     */     
/*     */     @Key("acr")
/*     */     private String classReference;
/*     */ 
/*     */     
/*     */     @Key("amr")
/*     */     private List<String> methodsReferences;
/*     */ 
/*     */ 
/*     */     
/*     */     public final Long getAuthorizationTimeSeconds() {
/* 198 */       return this.authorizationTimeSeconds;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setAuthorizationTimeSeconds(Long authorizationTimeSeconds) {
/* 210 */       this.authorizationTimeSeconds = authorizationTimeSeconds;
/* 211 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getAuthorizedParty() {
/* 223 */       return this.authorizedParty;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setAuthorizedParty(String authorizedParty) {
/* 240 */       this.authorizedParty = authorizedParty;
/* 241 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getNonce() {
/* 251 */       return this.nonce;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setNonce(String nonce) {
/* 265 */       this.nonce = nonce;
/* 266 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getAccessTokenHash() {
/* 275 */       return this.accessTokenHash;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setAccessTokenHash(String accessTokenHash) {
/* 289 */       this.accessTokenHash = accessTokenHash;
/* 290 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getClassReference() {
/* 299 */       return this.classReference;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setClassReference(String classReference) {
/* 313 */       this.classReference = classReference;
/* 314 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final List<String> getMethodsReferences() {
/* 323 */       return this.methodsReferences;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setMethodsReferences(List<String> methodsReferences) {
/* 337 */       this.methodsReferences = methodsReferences;
/* 338 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setExpirationTimeSeconds(Long expirationTimeSeconds) {
/* 343 */       return (Payload)super.setExpirationTimeSeconds(expirationTimeSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setNotBeforeTimeSeconds(Long notBeforeTimeSeconds) {
/* 348 */       return (Payload)super.setNotBeforeTimeSeconds(notBeforeTimeSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setIssuedAtTimeSeconds(Long issuedAtTimeSeconds) {
/* 353 */       return (Payload)super.setIssuedAtTimeSeconds(issuedAtTimeSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setIssuer(String issuer) {
/* 358 */       return (Payload)super.setIssuer(issuer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setAudience(Object audience) {
/* 363 */       return (Payload)super.setAudience(audience);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setJwtId(String jwtId) {
/* 368 */       return (Payload)super.setJwtId(jwtId);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setType(String type) {
/* 373 */       return (Payload)super.setType(type);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setSubject(String subject) {
/* 378 */       return (Payload)super.setSubject(subject);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload set(String fieldName, Object value) {
/* 383 */       return (Payload)super.set(fieldName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload clone() {
/* 388 */       return (Payload)super.clone();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\openidconnect\IdToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */