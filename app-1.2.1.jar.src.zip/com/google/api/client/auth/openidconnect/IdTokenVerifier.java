/*     */ package com.google.api.client.auth.openidconnect;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class IdTokenVerifier
/*     */ {
/*     */   public static final long DEFAULT_TIME_SKEW_SECONDS = 300L;
/*     */   private final Clock clock;
/*     */   private final long acceptableTimeSkewSeconds;
/*     */   private final Collection<String> issuers;
/*     */   private final Collection<String> audience;
/*     */   
/*     */   public IdTokenVerifier() {
/*  78 */     this(new Builder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IdTokenVerifier(Builder builder) {
/*  85 */     this.clock = builder.clock;
/*  86 */     this.acceptableTimeSkewSeconds = builder.acceptableTimeSkewSeconds;
/*  87 */     this.issuers = (builder.issuers == null) ? null : Collections.<String>unmodifiableCollection(builder.issuers);
/*  88 */     this
/*  89 */       .audience = (builder.audience == null) ? null : Collections.<String>unmodifiableCollection(builder.audience);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Clock getClock() {
/*  94 */     return this.clock;
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getAcceptableTimeSkewSeconds() {
/*  99 */     return this.acceptableTimeSkewSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getIssuer() {
/* 106 */     if (this.issuers == null) {
/* 107 */       return null;
/*     */     }
/* 109 */     return this.issuers.iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Collection<String> getIssuers() {
/* 119 */     return this.issuers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Collection<String> getAudience() {
/* 127 */     return this.audience;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verify(IdToken idToken) {
/* 153 */     return ((this.issuers == null || idToken.verifyIssuer(this.issuers)) && (this.audience == null || idToken
/* 154 */       .verifyAudience(this.audience)) && idToken
/* 155 */       .verifyTime(this.clock.currentTimeMillis(), this.acceptableTimeSkewSeconds));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */   {
/* 172 */     Clock clock = Clock.SYSTEM;
/*     */ 
/*     */     
/* 175 */     long acceptableTimeSkewSeconds = 300L;
/*     */ 
/*     */     
/*     */     Collection<String> issuers;
/*     */ 
/*     */     
/*     */     Collection<String> audience;
/*     */ 
/*     */     
/*     */     public IdTokenVerifier build() {
/* 185 */       return new IdTokenVerifier(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public final Clock getClock() {
/* 190 */       return this.clock;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 202 */       this.clock = (Clock)Preconditions.checkNotNull(clock);
/* 203 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getIssuer() {
/* 210 */       if (this.issuers == null) {
/* 211 */         return null;
/*     */       }
/* 213 */       return this.issuers.iterator().next();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setIssuer(String issuer) {
/* 226 */       if (issuer == null) {
/* 227 */         return setIssuers(null);
/*     */       }
/* 229 */       return setIssuers(Collections.singleton(issuer));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Collection<String> getIssuers() {
/* 239 */       return this.issuers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setIssuers(Collection<String> issuers) {
/* 255 */       Preconditions.checkArgument((issuers == null || !issuers.isEmpty()), "Issuers must not be empty");
/*     */       
/* 257 */       this.issuers = issuers;
/* 258 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Collection<String> getAudience() {
/* 266 */       return this.audience;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setAudience(Collection<String> audience) {
/* 278 */       this.audience = audience;
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final long getAcceptableTimeSkewSeconds() {
/* 284 */       return this.acceptableTimeSkewSeconds;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setAcceptableTimeSkewSeconds(long acceptableTimeSkewSeconds) {
/* 301 */       Preconditions.checkArgument((acceptableTimeSkewSeconds >= 0L));
/* 302 */       this.acceptableTimeSkewSeconds = acceptableTimeSkewSeconds;
/* 303 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\openidconnect\IdTokenVerifier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */