/*    */ package com.google.api.client.auth.oauth;
/*    */ 
/*    */ import com.google.api.client.util.Beta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class OAuthGetTemporaryToken
/*    */   extends AbstractOAuthGetToken
/*    */ {
/*    */   public String callback;
/*    */   
/*    */   public OAuthGetTemporaryToken(String authorizationServerUrl) {
/* 45 */     super(authorizationServerUrl);
/*    */   }
/*    */ 
/*    */   
/*    */   public OAuthParameters createParameters() {
/* 50 */     OAuthParameters result = super.createParameters();
/* 51 */     result.callback = this.callback;
/* 52 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth\OAuthGetTemporaryToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */