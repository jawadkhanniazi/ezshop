/*    */ package com.google.api.client.auth.oauth;
/*    */ 
/*    */ import com.google.api.client.http.GenericUrl;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Key;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class OAuthCallbackUrl
/*    */   extends GenericUrl
/*    */ {
/*    */   @Key("oauth_token")
/*    */   public String token;
/*    */   @Key("oauth_verifier")
/*    */   public String verifier;
/*    */   
/*    */   public OAuthCallbackUrl(String encodedUrl) {
/* 44 */     super(encodedUrl);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth\OAuthCallbackUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */