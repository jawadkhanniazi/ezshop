/*    */ package com.google.api.client.auth.oauth;
/*    */ 
/*    */ import com.google.api.client.http.GenericUrl;
/*    */ import com.google.api.client.http.HttpRequest;
/*    */ import com.google.api.client.http.HttpRequestFactory;
/*    */ import com.google.api.client.http.HttpResponse;
/*    */ import com.google.api.client.http.HttpTransport;
/*    */ import com.google.api.client.http.UrlEncodedParser;
/*    */ import com.google.api.client.util.Beta;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public abstract class AbstractOAuthGetToken
/*    */   extends GenericUrl
/*    */ {
/*    */   public HttpTransport transport;
/*    */   public String consumerKey;
/*    */   public OAuthSigner signer;
/*    */   protected boolean usePost;
/*    */   
/*    */   protected AbstractOAuthGetToken(String authorizationServerUrl) {
/* 60 */     super(authorizationServerUrl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final OAuthCredentialsResponse execute() throws IOException {
/* 69 */     HttpRequestFactory requestFactory = this.transport.createRequestFactory();
/*    */     
/* 71 */     HttpRequest request = requestFactory.buildRequest(this.usePost ? "POST" : "GET", this, null);
/* 72 */     createParameters().intercept(request);
/* 73 */     HttpResponse response = request.execute();
/* 74 */     response.setContentLoggingLimit(0);
/* 75 */     OAuthCredentialsResponse oauthResponse = new OAuthCredentialsResponse();
/* 76 */     UrlEncodedParser.parse(response.parseAsString(), oauthResponse);
/* 77 */     return oauthResponse;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public OAuthParameters createParameters() {
/* 85 */     OAuthParameters result = new OAuthParameters();
/* 86 */     result.consumerKey = this.consumerKey;
/* 87 */     result.signer = this.signer;
/* 88 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth\AbstractOAuthGetToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */