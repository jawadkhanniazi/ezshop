/*    */ package com.google.api.client.auth.oauth;
/*    */ 
/*    */ import com.google.api.client.util.Base64;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.SecurityUtils;
/*    */ import com.google.api.client.util.StringUtils;
/*    */ import java.security.GeneralSecurityException;
/*    */ import java.security.PrivateKey;
/*    */ import java.security.Signature;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public final class OAuthRsaSigner
/*    */   implements OAuthSigner
/*    */ {
/*    */   public PrivateKey privateKey;
/*    */   
/*    */   public String getSignatureMethod() {
/* 44 */     return "RSA-SHA1";
/*    */   }
/*    */   
/*    */   public String computeSignature(String signatureBaseString) throws GeneralSecurityException {
/* 48 */     Signature signer = SecurityUtils.getSha1WithRsaSignatureAlgorithm();
/* 49 */     byte[] data = StringUtils.getBytesUtf8(signatureBaseString);
/* 50 */     return Base64.encodeBase64String(SecurityUtils.sign(signer, this.privateKey, data));
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth\OAuthRsaSigner.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */