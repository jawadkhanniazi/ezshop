/*    */ package com.google.api.client.auth.oauth;
/*    */ 
/*    */ import com.google.api.client.util.Base64;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.StringUtils;
/*    */ import java.security.GeneralSecurityException;
/*    */ import javax.crypto.Mac;
/*    */ import javax.crypto.SecretKey;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public final class OAuthHmacSigner
/*    */   implements OAuthSigner
/*    */ {
/*    */   public String clientSharedSecret;
/*    */   public String tokenSharedSecret;
/*    */   
/*    */   public String getSignatureMethod() {
/* 44 */     return "HMAC-SHA1";
/*    */   }
/*    */ 
/*    */   
/*    */   public String computeSignature(String signatureBaseString) throws GeneralSecurityException {
/* 49 */     StringBuilder keyBuf = new StringBuilder();
/* 50 */     String clientSharedSecret = this.clientSharedSecret;
/* 51 */     if (clientSharedSecret != null) {
/* 52 */       keyBuf.append(OAuthParameters.escape(clientSharedSecret));
/*    */     }
/* 54 */     keyBuf.append('&');
/* 55 */     String tokenSharedSecret = this.tokenSharedSecret;
/* 56 */     if (tokenSharedSecret != null) {
/* 57 */       keyBuf.append(OAuthParameters.escape(tokenSharedSecret));
/*    */     }
/* 59 */     String key = keyBuf.toString();
/*    */     
/* 61 */     SecretKey secretKey = new SecretKeySpec(StringUtils.getBytesUtf8(key), "HmacSHA1");
/* 62 */     Mac mac = Mac.getInstance("HmacSHA1");
/* 63 */     mac.init(secretKey);
/* 64 */     return Base64.encodeBase64String(mac.doFinal(StringUtils.getBytesUtf8(signatureBaseString)));
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth\OAuthHmacSigner.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */