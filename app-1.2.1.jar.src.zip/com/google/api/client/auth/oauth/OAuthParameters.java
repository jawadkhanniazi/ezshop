/*     */ package com.google.api.client.auth.oauth;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.escape.PercentEscaper;
/*     */ import com.google.common.collect.Multiset;
/*     */ import com.google.common.collect.TreeMultiset;
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public final class OAuthParameters
/*     */   implements HttpExecuteInterceptor, HttpRequestInitializer
/*     */ {
/*  64 */   private static final SecureRandom RANDOM = new SecureRandom();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OAuthSigner signer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String callback;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumerKey;
/*     */ 
/*     */ 
/*     */   
/*     */   public String nonce;
/*     */ 
/*     */ 
/*     */   
/*     */   public String realm;
/*     */ 
/*     */ 
/*     */   
/*     */   public String signature;
/*     */ 
/*     */ 
/*     */   
/*     */   public String signatureMethod;
/*     */ 
/*     */ 
/*     */   
/*     */   public String timestamp;
/*     */ 
/*     */ 
/*     */   
/*     */   public String token;
/*     */ 
/*     */ 
/*     */   
/*     */   public String verifier;
/*     */ 
/*     */ 
/*     */   
/*     */   public String version;
/*     */ 
/*     */ 
/*     */   
/* 115 */   private static final PercentEscaper ESCAPER = new PercentEscaper("-_.~", false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeNonce() {
/* 122 */     this.nonce = Long.toHexString(Math.abs(RANDOM.nextLong()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeTimestamp() {
/* 130 */     this.timestamp = Long.toString(System.currentTimeMillis() / 1000L);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Parameter
/*     */     implements Comparable<Parameter>
/*     */   {
/*     */     private final String key;
/*     */     
/*     */     private final String value;
/*     */     
/*     */     public Parameter(String key, String value) {
/* 142 */       this.key = key;
/* 143 */       this.value = value;
/*     */     }
/*     */     
/*     */     public String getKey() {
/* 147 */       return this.key;
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 151 */       return this.value;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareTo(Parameter p) {
/* 157 */       int result = this.key.compareTo(p.key);
/* 158 */       return (result == 0) ? this.value.compareTo(p.value) : result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeSignature(String requestMethod, GenericUrl requestUrl) throws GeneralSecurityException {
/* 170 */     OAuthSigner signer = this.signer;
/* 171 */     String signatureMethod = this.signatureMethod = signer.getSignatureMethod();
/*     */     
/* 173 */     TreeMultiset treeMultiset = TreeMultiset.create();
/* 174 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_callback", this.callback);
/* 175 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_consumer_key", this.consumerKey);
/* 176 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_nonce", this.nonce);
/* 177 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_signature_method", signatureMethod);
/* 178 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_timestamp", this.timestamp);
/* 179 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_token", this.token);
/* 180 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_verifier", this.verifier);
/* 181 */     putParameterIfValueNotNull((Multiset<Parameter>)treeMultiset, "oauth_version", this.version);
/*     */     
/* 183 */     for (Map.Entry<String, Object> fieldEntry : (Iterable<Map.Entry<String, Object>>)requestUrl.entrySet()) {
/* 184 */       Object value = fieldEntry.getValue();
/* 185 */       if (value != null) {
/* 186 */         String name = fieldEntry.getKey();
/* 187 */         if (value instanceof java.util.Collection) {
/* 188 */           for (Object repeatedValue : value)
/* 189 */             putParameter((Multiset<Parameter>)treeMultiset, name, repeatedValue); 
/*     */           continue;
/*     */         } 
/* 192 */         putParameter((Multiset<Parameter>)treeMultiset, name, value);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 197 */     StringBuilder parametersBuf = new StringBuilder();
/* 198 */     boolean first = true;
/* 199 */     for (Parameter parameter : treeMultiset.elementSet()) {
/* 200 */       if (first) {
/* 201 */         first = false;
/*     */       } else {
/* 203 */         parametersBuf.append('&');
/*     */       } 
/* 205 */       parametersBuf.append(parameter.getKey());
/* 206 */       String value = parameter.getValue();
/* 207 */       if (value != null) {
/* 208 */         parametersBuf.append('=').append(value);
/*     */       }
/*     */     } 
/* 211 */     String normalizedParameters = parametersBuf.toString();
/*     */     
/* 213 */     GenericUrl normalized = new GenericUrl();
/* 214 */     String scheme = requestUrl.getScheme();
/* 215 */     normalized.setScheme(scheme);
/* 216 */     normalized.setHost(requestUrl.getHost());
/* 217 */     normalized.setPathParts(requestUrl.getPathParts());
/* 218 */     int port = requestUrl.getPort();
/* 219 */     if (("http".equals(scheme) && port == 80) || ("https".equals(scheme) && port == 443)) {
/* 220 */       port = -1;
/*     */     }
/* 222 */     normalized.setPort(port);
/* 223 */     String normalizedPath = normalized.build();
/*     */     
/* 225 */     StringBuilder buf = new StringBuilder();
/* 226 */     buf.append(escape(requestMethod)).append('&');
/* 227 */     buf.append(escape(normalizedPath)).append('&');
/* 228 */     buf.append(escape(normalizedParameters));
/* 229 */     String signatureBaseString = buf.toString();
/* 230 */     this.signature = signer.computeSignature(signatureBaseString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAuthorizationHeader() {
/* 238 */     StringBuilder buf = new StringBuilder("OAuth");
/* 239 */     appendParameter(buf, "realm", this.realm);
/* 240 */     appendParameter(buf, "oauth_callback", this.callback);
/* 241 */     appendParameter(buf, "oauth_consumer_key", this.consumerKey);
/* 242 */     appendParameter(buf, "oauth_nonce", this.nonce);
/* 243 */     appendParameter(buf, "oauth_signature", this.signature);
/* 244 */     appendParameter(buf, "oauth_signature_method", this.signatureMethod);
/* 245 */     appendParameter(buf, "oauth_timestamp", this.timestamp);
/* 246 */     appendParameter(buf, "oauth_token", this.token);
/* 247 */     appendParameter(buf, "oauth_verifier", this.verifier);
/* 248 */     appendParameter(buf, "oauth_version", this.version);
/*     */     
/* 250 */     return buf.substring(0, buf.length() - 1);
/*     */   }
/*     */   
/*     */   private void appendParameter(StringBuilder buf, String name, String value) {
/* 254 */     if (value != null) {
/* 255 */       buf.append(' ').append(escape(name)).append("=\"").append(escape(value)).append("\",");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void putParameterIfValueNotNull(Multiset<Parameter> parameters, String key, String value) {
/* 261 */     if (value != null) {
/* 262 */       putParameter(parameters, key, value);
/*     */     }
/*     */   }
/*     */   
/*     */   private void putParameter(Multiset<Parameter> parameters, String key, Object value) {
/* 267 */     parameters.add(new Parameter(escape(key), (value == null) ? null : escape(value.toString())));
/*     */   }
/*     */ 
/*     */   
/*     */   public static String escape(String value) {
/* 272 */     return ESCAPER.escape(value);
/*     */   }
/*     */   
/*     */   public void initialize(HttpRequest request) throws IOException {
/* 276 */     request.setInterceptor(this);
/*     */   }
/*     */   
/*     */   public void intercept(HttpRequest request) throws IOException {
/* 280 */     computeNonce();
/* 281 */     computeTimestamp();
/*     */     try {
/* 283 */       computeSignature(request.getRequestMethod(), request.getUrl());
/* 284 */     } catch (GeneralSecurityException e) {
/* 285 */       IOException io = new IOException();
/* 286 */       io.initCause(e);
/* 287 */       throw io;
/*     */     } 
/* 289 */     request.getHeaders().setAuthorization(getAuthorizationHeader());
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth\OAuthParameters.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */