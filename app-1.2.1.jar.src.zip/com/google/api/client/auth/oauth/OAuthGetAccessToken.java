/*    */ package com.google.api.client.auth.oauth;
/*    */ 
/*    */ import com.google.api.client.util.Beta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class OAuthGetAccessToken
/*    */   extends AbstractOAuthGetToken
/*    */ {
/*    */   public String temporaryToken;
/*    */   public String verifier;
/*    */   
/*    */   public OAuthGetAccessToken(String authorizationServerUrl) {
/* 50 */     super(authorizationServerUrl);
/*    */   }
/*    */ 
/*    */   
/*    */   public OAuthParameters createParameters() {
/* 55 */     OAuthParameters result = super.createParameters();
/* 56 */     result.token = this.temporaryToken;
/* 57 */     result.verifier = this.verifier;
/* 58 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth\OAuthGetAccessToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */