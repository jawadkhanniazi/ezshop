/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationCodeResponseUrl
/*     */   extends GenericUrl
/*     */ {
/*     */   @Key
/*     */   private String code;
/*     */   @Key
/*     */   private String state;
/*     */   @Key
/*     */   private String error;
/*     */   @Key("error_description")
/*     */   private String errorDescription;
/*     */   @Key("error_uri")
/*     */   private String errorUri;
/*     */   
/*     */   public AuthorizationCodeResponseUrl(String encodedResponseUrl) {
/*  99 */     super(encodedResponseUrl);
/*     */     
/* 101 */     Preconditions.checkArgument((((this.code == null) ? true : false) != ((this.error == null) ? true : false)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCode() {
/* 108 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeResponseUrl setCode(String code) {
/* 120 */     this.code = code;
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getState() {
/* 129 */     return this.state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeResponseUrl setState(String state) {
/* 142 */     this.state = state;
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getError() {
/* 154 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeResponseUrl setError(String error) {
/* 170 */     this.error = error;
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getErrorDescription() {
/* 179 */     return this.errorDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeResponseUrl setErrorDescription(String errorDescription) {
/* 192 */     this.errorDescription = errorDescription;
/* 193 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getErrorUri() {
/* 202 */     return this.errorUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeResponseUrl setErrorUri(String errorUri) {
/* 216 */     this.errorUri = errorUri;
/* 217 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationCodeResponseUrl set(String fieldName, Object value) {
/* 222 */     return (AuthorizationCodeResponseUrl)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationCodeResponseUrl clone() {
/* 227 */     return (AuthorizationCodeResponseUrl)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\AuthorizationCodeResponseUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */