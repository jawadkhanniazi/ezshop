/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Objects;
/*     */ import com.google.api.client.util.store.DataStore;
/*     */ import com.google.api.client.util.store.DataStoreFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public final class StoredCredential
/*     */   implements Serializable
/*     */ {
/*  43 */   public static final String DEFAULT_DATA_STORE_ID = StoredCredential.class.getSimpleName();
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*  48 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */   
/*     */   private String accessToken;
/*     */ 
/*     */   
/*     */   private Long expirationTimeMilliseconds;
/*     */ 
/*     */   
/*     */   private String refreshToken;
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredCredential() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredCredential(Credential credential) {
/*  66 */     setAccessToken(credential.getAccessToken());
/*  67 */     setRefreshToken(credential.getRefreshToken());
/*  68 */     setExpirationTimeMilliseconds(credential.getExpirationTimeMilliseconds());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAccessToken() {
/*  73 */     this.lock.lock();
/*     */     try {
/*  75 */       return this.accessToken;
/*     */     } finally {
/*  77 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StoredCredential setAccessToken(String accessToken) {
/*  83 */     this.lock.lock();
/*     */     try {
/*  85 */       this.accessToken = accessToken;
/*     */     } finally {
/*  87 */       this.lock.unlock();
/*     */     } 
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Long getExpirationTimeMilliseconds() {
/*  94 */     this.lock.lock();
/*     */     try {
/*  96 */       return this.expirationTimeMilliseconds;
/*     */     } finally {
/*  98 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StoredCredential setExpirationTimeMilliseconds(Long expirationTimeMilliseconds) {
/* 104 */     this.lock.lock();
/*     */     try {
/* 106 */       this.expirationTimeMilliseconds = expirationTimeMilliseconds;
/*     */     } finally {
/* 108 */       this.lock.unlock();
/*     */     } 
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRefreshToken() {
/* 115 */     this.lock.lock();
/*     */     try {
/* 117 */       return this.refreshToken;
/*     */     } finally {
/* 119 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public StoredCredential setRefreshToken(String refreshToken) {
/* 125 */     this.lock.lock();
/*     */     try {
/* 127 */       this.refreshToken = refreshToken;
/*     */     } finally {
/* 129 */       this.lock.unlock();
/*     */     } 
/* 131 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return Objects.toStringHelper(StoredCredential.class)
/* 137 */       .add("accessToken", getAccessToken())
/* 138 */       .add("refreshToken", getRefreshToken())
/* 139 */       .add("expirationTimeMilliseconds", getExpirationTimeMilliseconds())
/* 140 */       .toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 145 */     if (this == other) {
/* 146 */       return true;
/*     */     }
/* 148 */     if (!(other instanceof StoredCredential)) {
/* 149 */       return false;
/*     */     }
/* 151 */     StoredCredential o = (StoredCredential)other;
/* 152 */     return (Objects.equal(getAccessToken(), o.getAccessToken()) && 
/* 153 */       Objects.equal(getRefreshToken(), o.getRefreshToken()) && 
/* 154 */       Objects.equal(getExpirationTimeMilliseconds(), o.getExpirationTimeMilliseconds()));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 159 */     return Arrays.hashCode(new Object[] {
/* 160 */           getAccessToken(), getRefreshToken(), getExpirationTimeMilliseconds()
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataStore<StoredCredential> getDefaultDataStore(DataStoreFactory dataStoreFactory) throws IOException {
/* 171 */     return dataStoreFactory.getDataStore(DEFAULT_DATA_STORE_ID);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\StoredCredential.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */