/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.UrlEncodedContent;
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BearerToken
/*     */ {
/*     */   static final String PARAM_NAME = "access_token";
/*  45 */   static final Pattern INVALID_TOKEN_ERROR = Pattern.compile("\\s*error\\s*=\\s*\"?invalid_token\"?");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AuthorizationHeaderAccessMethod
/*     */     implements Credential.AccessMethod
/*     */   {
/*     */     static final String HEADER_PREFIX = "Bearer ";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void intercept(HttpRequest request, String accessToken) throws IOException {
/*  64 */       request.getHeaders().setAuthorization("Bearer " + accessToken);
/*     */     }
/*     */     
/*     */     public String getAccessTokenFromRequest(HttpRequest request) {
/*  68 */       List<String> authorizationAsList = request.getHeaders().getAuthorizationAsList();
/*  69 */       if (authorizationAsList != null) {
/*  70 */         for (String header : authorizationAsList) {
/*  71 */           if (header.startsWith("Bearer ")) {
/*  72 */             return header.substring("Bearer ".length());
/*     */           }
/*     */         } 
/*     */       }
/*  76 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class FormEncodedBodyAccessMethod
/*     */     implements Credential.AccessMethod
/*     */   {
/*     */     public void intercept(HttpRequest request, String accessToken) throws IOException {
/*  90 */       Preconditions.checkArgument(
/*  91 */           !"GET".equals(request.getRequestMethod()), "HTTP GET method is not supported");
/*  92 */       getData(request).put("access_token", accessToken);
/*     */     }
/*     */     
/*     */     public String getAccessTokenFromRequest(HttpRequest request) {
/*  96 */       Object bodyParam = getData(request).get("access_token");
/*  97 */       return (bodyParam == null) ? null : bodyParam.toString();
/*     */     }
/*     */     
/*     */     private static Map<String, Object> getData(HttpRequest request) {
/* 101 */       return Data.mapOf(UrlEncodedContent.getContent(request).getData());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class QueryParameterAccessMethod
/*     */     implements Credential.AccessMethod
/*     */   {
/*     */     public void intercept(HttpRequest request, String accessToken) throws IOException {
/* 115 */       request.getUrl().set("access_token", accessToken);
/*     */     }
/*     */     
/*     */     public String getAccessTokenFromRequest(HttpRequest request) {
/* 119 */       Object param = request.getUrl().get("access_token");
/* 120 */       return (param == null) ? null : param.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Credential.AccessMethod authorizationHeaderAccessMethod() {
/* 134 */     return new AuthorizationHeaderAccessMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Credential.AccessMethod formEncodedBodyAccessMethod() {
/* 143 */     return new FormEncodedBodyAccessMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Credential.AccessMethod queryParameterAccessMethod() {
/* 152 */     return new QueryParameterAccessMethod();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\BearerToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */