/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.Joiner;
/*     */ import com.google.api.client.util.Lists;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Strings;
/*     */ import com.google.api.client.util.store.DataStore;
/*     */ import com.google.api.client.util.store.DataStoreFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationCodeFlow
/*     */ {
/*     */   private final Credential.AccessMethod method;
/*     */   private final HttpTransport transport;
/*     */   private final JsonFactory jsonFactory;
/*     */   private final String tokenServerEncodedUrl;
/*     */   private final HttpExecuteInterceptor clientAuthentication;
/*     */   private final String clientId;
/*     */   private final String authorizationServerEncodedUrl;
/*     */   @Deprecated
/*     */   @Beta
/*     */   private final CredentialStore credentialStore;
/*     */   @Beta
/*     */   private final DataStore<StoredCredential> credentialDataStore;
/*     */   private final HttpRequestInitializer requestInitializer;
/*     */   private final Clock clock;
/*     */   private final Collection<String> scopes;
/*     */   private final CredentialCreatedListener credentialCreatedListener;
/*     */   private final Collection<CredentialRefreshListener> refreshListeners;
/*     */   
/*     */   public AuthorizationCodeFlow(Credential.AccessMethod method, HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl, HttpExecuteInterceptor clientAuthentication, String clientId, String authorizationServerEncodedUrl) {
/* 132 */     this(new Builder(method, transport, jsonFactory, tokenServerUrl, clientAuthentication, clientId, authorizationServerEncodedUrl));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AuthorizationCodeFlow(Builder builder) {
/* 147 */     this.method = (Credential.AccessMethod)Preconditions.checkNotNull(builder.method);
/* 148 */     this.transport = (HttpTransport)Preconditions.checkNotNull(builder.transport);
/* 149 */     this.jsonFactory = (JsonFactory)Preconditions.checkNotNull(builder.jsonFactory);
/* 150 */     this.tokenServerEncodedUrl = ((GenericUrl)Preconditions.checkNotNull(builder.tokenServerUrl)).build();
/* 151 */     this.clientAuthentication = builder.clientAuthentication;
/* 152 */     this.clientId = (String)Preconditions.checkNotNull(builder.clientId);
/* 153 */     this
/* 154 */       .authorizationServerEncodedUrl = (String)Preconditions.checkNotNull(builder.authorizationServerEncodedUrl);
/* 155 */     this.requestInitializer = builder.requestInitializer;
/* 156 */     this.credentialStore = builder.credentialStore;
/* 157 */     this.credentialDataStore = builder.credentialDataStore;
/* 158 */     this.scopes = Collections.unmodifiableCollection(builder.scopes);
/* 159 */     this.clock = (Clock)Preconditions.checkNotNull(builder.clock);
/* 160 */     this.credentialCreatedListener = builder.credentialCreatedListener;
/* 161 */     this.refreshListeners = Collections.unmodifiableCollection(builder.refreshListeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeRequestUrl newAuthorizationUrl() {
/* 185 */     return (new AuthorizationCodeRequestUrl(this.authorizationServerEncodedUrl, this.clientId)).setScopes(this.scopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest newTokenRequest(String authorizationCode) {
/* 209 */     return (new AuthorizationCodeTokenRequest(this.transport, this.jsonFactory, new GenericUrl(this.tokenServerEncodedUrl), authorizationCode))
/* 210 */       .setClientAuthentication(this.clientAuthentication)
/* 211 */       .setRequestInitializer(this.requestInitializer).setScopes(this.scopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential createAndStoreCredential(TokenResponse response, String userId) throws IOException {
/* 225 */     Credential credential = newCredential(userId).setFromTokenResponse(response);
/* 226 */     if (this.credentialStore != null) {
/* 227 */       this.credentialStore.store(userId, credential);
/*     */     }
/* 229 */     if (this.credentialDataStore != null) {
/* 230 */       this.credentialDataStore.set(userId, new StoredCredential(credential));
/*     */     }
/* 232 */     if (this.credentialCreatedListener != null) {
/* 233 */       this.credentialCreatedListener.onCredentialCreated(credential, response);
/*     */     }
/* 235 */     return credential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential loadCredential(String userId) throws IOException {
/* 249 */     if (Strings.isNullOrEmpty(userId)) {
/* 250 */       return null;
/*     */     }
/*     */     
/* 253 */     if (this.credentialDataStore == null && this.credentialStore == null) {
/* 254 */       return null;
/*     */     }
/* 256 */     Credential credential = newCredential(userId);
/* 257 */     if (this.credentialDataStore != null) {
/* 258 */       StoredCredential stored = (StoredCredential)this.credentialDataStore.get(userId);
/* 259 */       if (stored == null) {
/* 260 */         return null;
/*     */       }
/* 262 */       credential.setAccessToken(stored.getAccessToken());
/* 263 */       credential.setRefreshToken(stored.getRefreshToken());
/* 264 */       credential.setExpirationTimeMilliseconds(stored.getExpirationTimeMilliseconds());
/* 265 */     } else if (!this.credentialStore.load(userId, credential)) {
/* 266 */       return null;
/*     */     } 
/* 268 */     return credential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Credential newCredential(String userId) {
/* 283 */     Credential.Builder builder = (new Credential.Builder(this.method)).setTransport(this.transport).setJsonFactory(this.jsonFactory).setTokenServerEncodedUrl(this.tokenServerEncodedUrl).setClientAuthentication(this.clientAuthentication).setRequestInitializer(this.requestInitializer).setClock(this.clock);
/* 284 */     if (this.credentialDataStore != null) {
/* 285 */       builder.addRefreshListener(new DataStoreCredentialRefreshListener(userId, this.credentialDataStore));
/*     */     }
/* 287 */     else if (this.credentialStore != null) {
/* 288 */       builder.addRefreshListener(new CredentialStoreRefreshListener(userId, this.credentialStore));
/*     */     } 
/* 290 */     builder.getRefreshListeners().addAll(this.refreshListeners);
/* 291 */     return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Credential.AccessMethod getMethod() {
/* 299 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpTransport getTransport() {
/* 304 */     return this.transport;
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/* 309 */     return this.jsonFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getTokenServerEncodedUrl() {
/* 314 */     return this.tokenServerEncodedUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final HttpExecuteInterceptor getClientAuthentication() {
/* 322 */     return this.clientAuthentication;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getClientId() {
/* 327 */     return this.clientId;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getAuthorizationServerEncodedUrl() {
/* 332 */     return this.authorizationServerEncodedUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Beta
/*     */   public final CredentialStore getCredentialStore() {
/* 343 */     return this.credentialStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final DataStore<StoredCredential> getCredentialDataStore() {
/* 354 */     return this.credentialDataStore;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpRequestInitializer getRequestInitializer() {
/* 359 */     return this.requestInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getScopesAsString() {
/* 368 */     return Joiner.on(' ').join(this.scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Collection<String> getScopes() {
/* 373 */     return this.scopes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Clock getClock() {
/* 381 */     return this.clock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Collection<CredentialRefreshListener> getRefreshListeners() {
/* 390 */     return this.refreshListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     Credential.AccessMethod method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpTransport transport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JsonFactory jsonFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     GenericUrl tokenServerUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpExecuteInterceptor clientAuthentication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String clientId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String authorizationServerEncodedUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     @Beta
/*     */     CredentialStore credentialStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     DataStore<StoredCredential> credentialDataStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpRequestInitializer requestInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 464 */     Collection<String> scopes = Lists.newArrayList();
/*     */ 
/*     */     
/* 467 */     Clock clock = Clock.SYSTEM;
/*     */ 
/*     */     
/*     */     AuthorizationCodeFlow.CredentialCreatedListener credentialCreatedListener;
/*     */ 
/*     */     
/* 473 */     Collection<CredentialRefreshListener> refreshListeners = Lists.newArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(Credential.AccessMethod method, HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl, HttpExecuteInterceptor clientAuthentication, String clientId, String authorizationServerEncodedUrl) {
/* 493 */       setMethod(method);
/* 494 */       setTransport(transport);
/* 495 */       setJsonFactory(jsonFactory);
/* 496 */       setTokenServerUrl(tokenServerUrl);
/* 497 */       setClientAuthentication(clientAuthentication);
/* 498 */       setClientId(clientId);
/* 499 */       setAuthorizationServerEncodedUrl(authorizationServerEncodedUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     public AuthorizationCodeFlow build() {
/* 504 */       return new AuthorizationCodeFlow(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Credential.AccessMethod getMethod() {
/* 512 */       return this.method;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMethod(Credential.AccessMethod method) {
/* 526 */       this.method = (Credential.AccessMethod)Preconditions.checkNotNull(method);
/* 527 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final HttpTransport getTransport() {
/* 532 */       return this.transport;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setTransport(HttpTransport transport) {
/* 545 */       this.transport = (HttpTransport)Preconditions.checkNotNull(transport);
/* 546 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final JsonFactory getJsonFactory() {
/* 551 */       return this.jsonFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setJsonFactory(JsonFactory jsonFactory) {
/* 564 */       this.jsonFactory = (JsonFactory)Preconditions.checkNotNull(jsonFactory);
/* 565 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final GenericUrl getTokenServerUrl() {
/* 570 */       return this.tokenServerUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 583 */       this.tokenServerUrl = (GenericUrl)Preconditions.checkNotNull(tokenServerUrl);
/* 584 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final HttpExecuteInterceptor getClientAuthentication() {
/* 592 */       return this.clientAuthentication;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 606 */       this.clientAuthentication = clientAuthentication;
/* 607 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final String getClientId() {
/* 612 */       return this.clientId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClientId(String clientId) {
/* 625 */       this.clientId = (String)Preconditions.checkNotNull(clientId);
/* 626 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final String getAuthorizationServerEncodedUrl() {
/* 631 */       return this.authorizationServerEncodedUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setAuthorizationServerEncodedUrl(String authorizationServerEncodedUrl) {
/* 644 */       this
/* 645 */         .authorizationServerEncodedUrl = (String)Preconditions.checkNotNull(authorizationServerEncodedUrl);
/* 646 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     @Beta
/*     */     public final CredentialStore getCredentialStore() {
/* 657 */       return this.credentialStore;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public final DataStore<StoredCredential> getCredentialDataStore() {
/* 668 */       return this.credentialDataStore;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Clock getClock() {
/* 677 */       return this.clock;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 694 */       this.clock = (Clock)Preconditions.checkNotNull(clock);
/* 695 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     @Beta
/*     */     public Builder setCredentialStore(CredentialStore credentialStore) {
/* 720 */       Preconditions.checkArgument((this.credentialDataStore == null));
/* 721 */       this.credentialStore = credentialStore;
/* 722 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public Builder setDataStoreFactory(DataStoreFactory dataStoreFactory) throws IOException {
/* 743 */       return setCredentialDataStore(StoredCredential.getDefaultDataStore(dataStoreFactory));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public Builder setCredentialDataStore(DataStore<StoredCredential> credentialDataStore) {
/* 764 */       Preconditions.checkArgument((this.credentialStore == null));
/* 765 */       this.credentialDataStore = credentialDataStore;
/* 766 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final HttpRequestInitializer getRequestInitializer() {
/* 771 */       return this.requestInitializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 783 */       this.requestInitializer = requestInitializer;
/* 784 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setScopes(Collection<String> scopes) {
/* 799 */       this.scopes = (Collection<String>)Preconditions.checkNotNull(scopes);
/* 800 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final Collection<String> getScopes() {
/* 805 */       return this.scopes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setCredentialCreatedListener(AuthorizationCodeFlow.CredentialCreatedListener credentialCreatedListener) {
/* 820 */       this.credentialCreatedListener = credentialCreatedListener;
/* 821 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addRefreshListener(CredentialRefreshListener refreshListener) {
/* 836 */       this.refreshListeners.add(Preconditions.checkNotNull(refreshListener));
/* 837 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Collection<CredentialRefreshListener> getRefreshListeners() {
/* 846 */       return this.refreshListeners;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRefreshListeners(Collection<CredentialRefreshListener> refreshListeners) {
/* 860 */       this.refreshListeners = (Collection<CredentialRefreshListener>)Preconditions.checkNotNull(refreshListeners);
/* 861 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final AuthorizationCodeFlow.CredentialCreatedListener getCredentialCreatedListener() {
/* 870 */       return this.credentialCreatedListener;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface CredentialCreatedListener {
/*     */     void onCredentialCreated(Credential param1Credential, TokenResponse param1TokenResponse) throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\AuthorizationCodeFlow.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */