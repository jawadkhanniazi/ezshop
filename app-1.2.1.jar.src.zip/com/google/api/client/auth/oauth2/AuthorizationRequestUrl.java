/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Joiner;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationRequestUrl
/*     */   extends GenericUrl
/*     */ {
/*     */   @Key("response_type")
/*     */   private String responseTypes;
/*     */   @Key("redirect_uri")
/*     */   private String redirectUri;
/*     */   @Key("scope")
/*     */   private String scopes;
/*     */   @Key("client_id")
/*     */   private String clientId;
/*     */   @Key
/*     */   private String state;
/*     */   
/*     */   public AuthorizationRequestUrl(String authorizationServerEncodedUrl, String clientId, Collection<String> responseTypes) {
/*  99 */     super(authorizationServerEncodedUrl);
/* 100 */     Preconditions.checkArgument((getFragment() == null));
/* 101 */     setClientId(clientId);
/* 102 */     setResponseTypes(responseTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getResponseTypes() {
/* 111 */     return this.responseTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationRequestUrl setResponseTypes(Collection<String> responseTypes) {
/* 127 */     this.responseTypes = Joiner.on(' ').join(responseTypes);
/* 128 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getRedirectUri() {
/* 138 */     return this.redirectUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationRequestUrl setRedirectUri(String redirectUri) {
/* 153 */     this.redirectUri = redirectUri;
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getScopes() {
/* 163 */     return this.scopes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationRequestUrl setScopes(Collection<String> scopes) {
/* 181 */     this
/* 182 */       .scopes = (scopes == null || !scopes.iterator().hasNext()) ? null : Joiner.on(' ').join(scopes);
/* 183 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getClientId() {
/* 188 */     return this.clientId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationRequestUrl setClientId(String clientId) {
/* 200 */     this.clientId = (String)Preconditions.checkNotNull(clientId);
/* 201 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getState() {
/* 211 */     return this.state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationRequestUrl setState(String state) {
/* 226 */     this.state = state;
/* 227 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationRequestUrl set(String fieldName, Object value) {
/* 232 */     return (AuthorizationRequestUrl)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationRequestUrl clone() {
/* 237 */     return (AuthorizationRequestUrl)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\AuthorizationRequestUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */