package com.google.api.client.auth.oauth2;

import com.google.api.client.util.Beta;
import java.io.IOException;

@Deprecated
@Beta
public interface CredentialStore {
  boolean load(String paramString, Credential paramCredential) throws IOException;
  
  void store(String paramString, Credential paramCredential) throws IOException;
  
  void delete(String paramString, Credential paramCredential) throws IOException;
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\CredentialStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */