/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.HttpMediaType;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpResponseException;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonObjectParser;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import com.google.api.client.util.Strings;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenResponseException
/*     */   extends HttpResponseException
/*     */ {
/*     */   private static final long serialVersionUID = 4020689092957439244L;
/*     */   private final transient TokenErrorResponse details;
/*     */   
/*     */   TokenResponseException(HttpResponseException.Builder builder, TokenErrorResponse details) {
/*  55 */     super(builder);
/*  56 */     this.details = details;
/*     */   }
/*     */ 
/*     */   
/*     */   public final TokenErrorResponse getDetails() {
/*  61 */     return this.details;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TokenResponseException from(JsonFactory jsonFactory, HttpResponse response) {
/*  79 */     HttpResponseException.Builder builder = new HttpResponseException.Builder(response.getStatusCode(), response.getStatusMessage(), response.getHeaders());
/*     */     
/*  81 */     Preconditions.checkNotNull(jsonFactory);
/*  82 */     TokenErrorResponse details = null;
/*  83 */     String detailString = null;
/*  84 */     String contentType = response.getContentType();
/*     */     try {
/*  86 */       if (!response.isSuccessStatusCode() && contentType != null && response.getContent() != null && 
/*  87 */         HttpMediaType.equalsIgnoreParameters("application/json; charset=UTF-8", contentType)) {
/*  88 */         details = (TokenErrorResponse)(new JsonObjectParser(jsonFactory)).parseAndClose(response
/*  89 */             .getContent(), response.getContentCharset(), TokenErrorResponse.class);
/*  90 */         detailString = details.toPrettyString();
/*     */       } else {
/*  92 */         detailString = response.parseAsString();
/*     */       } 
/*  94 */     } catch (IOException exception) {
/*     */       
/*  96 */       exception.printStackTrace();
/*     */     } 
/*     */     
/*  99 */     StringBuilder message = HttpResponseException.computeMessageBuffer(response);
/* 100 */     if (!Strings.isNullOrEmpty(detailString)) {
/* 101 */       message.append(StringUtils.LINE_SEPARATOR).append(detailString);
/* 102 */       builder.setContent(detailString);
/*     */     } 
/* 104 */     builder.setMessage(message.toString());
/* 105 */     return new TokenResponseException(builder, details);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\TokenResponseException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */