/*    */ package com.google.api.client.auth.oauth2;
/*    */ 
/*    */ import com.google.api.client.http.GenericUrl;
/*    */ import com.google.api.client.util.GenericData;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationCodeRequestUrl
/*    */   extends AuthorizationRequestUrl
/*    */ {
/*    */   public AuthorizationCodeRequestUrl(String authorizationServerEncodedUrl, String clientId) {
/* 60 */     super(authorizationServerEncodedUrl, clientId, Collections.singleton("code"));
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationCodeRequestUrl setResponseTypes(Collection<String> responseTypes) {
/* 65 */     return (AuthorizationCodeRequestUrl)super.setResponseTypes(responseTypes);
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationCodeRequestUrl setRedirectUri(String redirectUri) {
/* 70 */     return (AuthorizationCodeRequestUrl)super.setRedirectUri(redirectUri);
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationCodeRequestUrl setScopes(Collection<String> scopes) {
/* 75 */     return (AuthorizationCodeRequestUrl)super.setScopes(scopes);
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationCodeRequestUrl setClientId(String clientId) {
/* 80 */     return (AuthorizationCodeRequestUrl)super.setClientId(clientId);
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationCodeRequestUrl setState(String state) {
/* 85 */     return (AuthorizationCodeRequestUrl)super.setState(state);
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationCodeRequestUrl set(String fieldName, Object value) {
/* 90 */     return (AuthorizationCodeRequestUrl)super.set(fieldName, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationCodeRequestUrl clone() {
/* 95 */     return (AuthorizationCodeRequestUrl)super.clone();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\AuthorizationCodeRequestUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */