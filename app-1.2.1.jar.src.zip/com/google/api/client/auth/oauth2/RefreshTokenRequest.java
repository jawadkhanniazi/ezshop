/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefreshTokenRequest
/*     */   extends TokenRequest
/*     */ {
/*     */   @Key("refresh_token")
/*     */   private String refreshToken;
/*     */   
/*     */   public RefreshTokenRequest(HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl, String refreshToken) {
/*  94 */     super(transport, jsonFactory, tokenServerUrl, "refresh_token");
/*  95 */     setRefreshToken(refreshToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 100 */     return (RefreshTokenRequest)super.setRequestInitializer(requestInitializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 105 */     return (RefreshTokenRequest)super.setTokenServerUrl(tokenServerUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest setScopes(Collection<String> scopes) {
/* 110 */     return (RefreshTokenRequest)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest setGrantType(String grantType) {
/* 115 */     return (RefreshTokenRequest)super.setGrantType(grantType);
/*     */   }
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 120 */     return (RefreshTokenRequest)super.setClientAuthentication(clientAuthentication);
/*     */   }
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest setResponseClass(Class<? extends TokenResponse> responseClass) {
/* 125 */     return (RefreshTokenRequest)super.setResponseClass(responseClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getRefreshToken() {
/* 130 */     return this.refreshToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest setRefreshToken(String refreshToken) {
/* 142 */     this.refreshToken = (String)Preconditions.checkNotNull(refreshToken);
/* 143 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public RefreshTokenRequest set(String fieldName, Object value) {
/* 148 */     return (RefreshTokenRequest)super.set(fieldName, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\RefreshTokenRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */