/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.HttpUnsuccessfulResponseHandler;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.Lists;
/*     */ import com.google.api.client.util.Objects;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Credential
/*     */   implements HttpExecuteInterceptor, HttpRequestInitializer, HttpUnsuccessfulResponseHandler
/*     */ {
/*  90 */   static final Logger LOGGER = Logger.getLogger(Credential.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AccessMethod method;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Clock clock;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String accessToken;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Long expirationTimeMilliseconds;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String refreshToken;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpTransport transport;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpExecuteInterceptor clientAuthentication;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JsonFactory jsonFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String tokenServerEncodedUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Collection<CredentialRefreshListener> refreshListeners;
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpRequestInitializer requestInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential(AccessMethod method) {
/* 178 */     this(new Builder(method));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Credential(Builder builder) {
/* 187 */     this.method = (AccessMethod)Preconditions.checkNotNull(builder.method);
/* 188 */     this.transport = builder.transport;
/* 189 */     this.jsonFactory = builder.jsonFactory;
/* 190 */     this.tokenServerEncodedUrl = (builder.tokenServerUrl == null) ? null : builder.tokenServerUrl.build();
/* 191 */     this.clientAuthentication = builder.clientAuthentication;
/* 192 */     this.requestInitializer = builder.requestInitializer;
/* 193 */     this.refreshListeners = Collections.unmodifiableCollection(builder.refreshListeners);
/* 194 */     this.clock = (Clock)Preconditions.checkNotNull(builder.clock);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void intercept(HttpRequest request) throws IOException {
/* 212 */     this.lock.lock();
/*     */     try {
/* 214 */       Long expiresIn = getExpiresInSeconds();
/*     */       
/* 216 */       if (this.accessToken == null || (expiresIn != null && expiresIn.longValue() <= 60L)) {
/* 217 */         refreshToken();
/* 218 */         if (this.accessToken == null) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */       
/* 223 */       this.method.intercept(request, this.accessToken);
/*     */     } finally {
/* 225 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleResponse(HttpRequest request, HttpResponse response, boolean supportsRetry) {
/* 242 */     boolean refreshToken = false;
/* 243 */     boolean bearer = false;
/*     */     
/* 245 */     List<String> authenticateList = response.getHeaders().getAuthenticateAsList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     if (authenticateList != null) {
/* 252 */       for (String authenticate : authenticateList) {
/* 253 */         if (authenticate.startsWith("Bearer ")) {
/*     */           
/* 255 */           bearer = true;
/* 256 */           refreshToken = BearerToken.INVALID_TOKEN_ERROR.matcher(authenticate).find();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 263 */     if (!bearer) {
/* 264 */       refreshToken = (response.getStatusCode() == 401);
/*     */     }
/*     */     
/* 267 */     if (refreshToken) {
/*     */       try {
/* 269 */         this.lock.lock();
/*     */         
/*     */         try {
/* 272 */           return (!Objects.equal(this.accessToken, this.method.getAccessTokenFromRequest(request)) || 
/* 273 */             refreshToken());
/*     */         } finally {
/* 275 */           this.lock.unlock();
/*     */         } 
/* 277 */       } catch (IOException exception) {
/* 278 */         LOGGER.log(Level.SEVERE, "unable to refresh token", exception);
/*     */       } 
/*     */     }
/* 281 */     return false;
/*     */   }
/*     */   
/*     */   public void initialize(HttpRequest request) throws IOException {
/* 285 */     request.setInterceptor(this);
/* 286 */     request.setUnsuccessfulResponseHandler(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getAccessToken() {
/* 292 */     this.lock.lock();
/*     */     try {
/* 294 */       return this.accessToken;
/*     */     } finally {
/* 296 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential setAccessToken(String accessToken) {
/* 311 */     this.lock.lock();
/*     */     try {
/* 313 */       this.accessToken = accessToken;
/*     */     } finally {
/* 315 */       this.lock.unlock();
/*     */     } 
/* 317 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AccessMethod getMethod() {
/* 325 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Clock getClock() {
/* 333 */     return this.clock;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpTransport getTransport() {
/* 338 */     return this.transport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/* 346 */     return this.jsonFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getTokenServerEncodedUrl() {
/* 351 */     return this.tokenServerEncodedUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getRefreshToken() {
/* 359 */     this.lock.lock();
/*     */     try {
/* 361 */       return this.refreshToken;
/*     */     } finally {
/* 363 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential setRefreshToken(String refreshToken) {
/* 378 */     this.lock.lock();
/*     */     try {
/* 380 */       if (refreshToken != null) {
/* 381 */         Preconditions.checkArgument((this.jsonFactory != null && this.transport != null && this.clientAuthentication != null && this.tokenServerEncodedUrl != null), "Please use the Builder and call setJsonFactory, setTransport, setClientAuthentication and setTokenServerUrl/setTokenServerEncodedUrl");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 386 */       this.refreshToken = refreshToken;
/*     */     } finally {
/* 388 */       this.lock.unlock();
/*     */     } 
/* 390 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Long getExpirationTimeMilliseconds() {
/* 398 */     this.lock.lock();
/*     */     try {
/* 400 */       return this.expirationTimeMilliseconds;
/*     */     } finally {
/* 402 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential setExpirationTimeMilliseconds(Long expirationTimeMilliseconds) {
/* 416 */     this.lock.lock();
/*     */     try {
/* 418 */       this.expirationTimeMilliseconds = expirationTimeMilliseconds;
/*     */     } finally {
/* 420 */       this.lock.unlock();
/*     */     } 
/* 422 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Long getExpiresInSeconds() {
/* 430 */     this.lock.lock();
/*     */     try {
/* 432 */       if (this.expirationTimeMilliseconds == null) {
/* 433 */         return null;
/*     */       }
/* 435 */       return Long.valueOf((this.expirationTimeMilliseconds.longValue() - this.clock.currentTimeMillis()) / 1000L);
/*     */     } finally {
/* 437 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential setExpiresInSeconds(Long expiresIn) {
/* 454 */     return setExpirationTimeMilliseconds((expiresIn == null) ? null : 
/* 455 */         Long.valueOf(this.clock.currentTimeMillis() + expiresIn.longValue() * 1000L));
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpExecuteInterceptor getClientAuthentication() {
/* 460 */     return this.clientAuthentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final HttpRequestInitializer getRequestInitializer() {
/* 468 */     return this.requestInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean refreshToken() throws IOException {
/* 491 */     this.lock.lock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Credential setFromTokenResponse(TokenResponse tokenResponse) {
/* 541 */     setAccessToken(tokenResponse.getAccessToken());
/*     */ 
/*     */     
/* 544 */     if (tokenResponse.getRefreshToken() != null) {
/* 545 */       setRefreshToken(tokenResponse.getRefreshToken());
/*     */     }
/* 547 */     setExpiresInSeconds(tokenResponse.getExpiresInSeconds());
/* 548 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TokenResponse executeRefreshToken() throws IOException {
/* 572 */     if (this.refreshToken == null) {
/* 573 */       return null;
/*     */     }
/* 575 */     return (new RefreshTokenRequest(this.transport, this.jsonFactory, new GenericUrl(this.tokenServerEncodedUrl), this.refreshToken))
/* 576 */       .setClientAuthentication(this.clientAuthentication)
/* 577 */       .setRequestInitializer(this.requestInitializer).execute();
/*     */   }
/*     */ 
/*     */   
/*     */   public final Collection<CredentialRefreshListener> getRefreshListeners() {
/* 582 */     return this.refreshListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     final Credential.AccessMethod method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpTransport transport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JsonFactory jsonFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     GenericUrl tokenServerUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 615 */     Clock clock = Clock.SYSTEM;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpExecuteInterceptor clientAuthentication;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpRequestInitializer requestInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 630 */     Collection<CredentialRefreshListener> refreshListeners = Lists.newArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(Credential.AccessMethod method) {
/* 637 */       this.method = (Credential.AccessMethod)Preconditions.checkNotNull(method);
/*     */     }
/*     */ 
/*     */     
/*     */     public Credential build() {
/* 642 */       return new Credential(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Credential.AccessMethod getMethod() {
/* 650 */       return this.method;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final HttpTransport getTransport() {
/* 658 */       return this.transport;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setTransport(HttpTransport transport) {
/* 671 */       this.transport = transport;
/* 672 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Clock getClock() {
/* 680 */       return this.clock;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 693 */       this.clock = (Clock)Preconditions.checkNotNull(clock);
/* 694 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final JsonFactory getJsonFactory() {
/* 702 */       return this.jsonFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setJsonFactory(JsonFactory jsonFactory) {
/* 715 */       this.jsonFactory = jsonFactory;
/* 716 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final GenericUrl getTokenServerUrl() {
/* 721 */       return this.tokenServerUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 733 */       this.tokenServerUrl = tokenServerUrl;
/* 734 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setTokenServerEncodedUrl(String tokenServerEncodedUrl) {
/* 746 */       this.tokenServerUrl = (tokenServerEncodedUrl == null) ? null : new GenericUrl(tokenServerEncodedUrl);
/*     */       
/* 748 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final HttpExecuteInterceptor getClientAuthentication() {
/* 756 */       return this.clientAuthentication;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 769 */       this.clientAuthentication = clientAuthentication;
/* 770 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final HttpRequestInitializer getRequestInitializer() {
/* 778 */       return this.requestInitializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 791 */       this.requestInitializer = requestInitializer;
/* 792 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder addRefreshListener(CredentialRefreshListener refreshListener) {
/* 806 */       this.refreshListeners.add(Preconditions.checkNotNull(refreshListener));
/* 807 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final Collection<CredentialRefreshListener> getRefreshListeners() {
/* 812 */       return this.refreshListeners;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRefreshListeners(Collection<CredentialRefreshListener> refreshListeners) {
/* 824 */       this.refreshListeners = (Collection<CredentialRefreshListener>)Preconditions.checkNotNull(refreshListeners);
/* 825 */       return this;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface AccessMethod {
/*     */     void intercept(HttpRequest param1HttpRequest, String param1String) throws IOException;
/*     */     
/*     */     String getAccessTokenFromRequest(HttpRequest param1HttpRequest);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\Credential.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */