/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenResponse
/*     */   extends GenericJson
/*     */ {
/*     */   @Key("access_token")
/*     */   private String accessToken;
/*     */   @Key("token_type")
/*     */   private String tokenType;
/*     */   @Key("expires_in")
/*     */   private Long expiresInSeconds;
/*     */   @Key("refresh_token")
/*     */   private String refreshToken;
/*     */   @Key
/*     */   private String scope;
/*     */   
/*     */   public String getAccessToken() {
/*  69 */     return this.accessToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenResponse setAccessToken(String accessToken) {
/*  81 */     this.accessToken = (String)Preconditions.checkNotNull(accessToken);
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTokenType() {
/*  90 */     return this.tokenType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenResponse setTokenType(String tokenType) {
/* 103 */     this.tokenType = (String)Preconditions.checkNotNull(tokenType);
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getExpiresInSeconds() {
/* 112 */     return this.expiresInSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenResponse setExpiresInSeconds(Long expiresInSeconds) {
/* 125 */     this.expiresInSeconds = expiresInSeconds;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRefreshToken() {
/* 134 */     return this.refreshToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenResponse setRefreshToken(String refreshToken) {
/* 147 */     this.refreshToken = refreshToken;
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getScope() {
/* 155 */     return this.scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenResponse setScope(String scope) {
/* 167 */     this.scope = scope;
/* 168 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenResponse set(String fieldName, Object value) {
/* 173 */     return (TokenResponse)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenResponse clone() {
/* 178 */     return (TokenResponse)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\TokenResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */