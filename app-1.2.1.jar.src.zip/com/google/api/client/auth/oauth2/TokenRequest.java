/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestFactory;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.UrlEncodedContent;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonObjectParser;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Joiner;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenRequest
/*     */   extends GenericData
/*     */ {
/*     */   HttpRequestInitializer requestInitializer;
/*     */   HttpExecuteInterceptor clientAuthentication;
/*     */   private final HttpTransport transport;
/*     */   private final JsonFactory jsonFactory;
/*     */   private GenericUrl tokenServerUrl;
/*     */   @Key("scope")
/*     */   private String scopes;
/*     */   @Key("grant_type")
/*     */   private String grantType;
/*     */   protected Class<? extends TokenResponse> responseClass;
/*     */   
/*     */   public TokenRequest(HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl, String grantType) {
/*  99 */     this(transport, jsonFactory, tokenServerUrl, grantType, TokenResponse.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenRequest(HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl, String grantType, Class<? extends TokenResponse> responseClass) {
/* 116 */     this.transport = (HttpTransport)Preconditions.checkNotNull(transport);
/* 117 */     this.jsonFactory = (JsonFactory)Preconditions.checkNotNull(jsonFactory);
/* 118 */     setTokenServerUrl(tokenServerUrl);
/* 119 */     setGrantType(grantType);
/* 120 */     setResponseClass(responseClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpTransport getTransport() {
/* 125 */     return this.transport;
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/* 130 */     return this.jsonFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpRequestInitializer getRequestInitializer() {
/* 135 */     return this.requestInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenRequest setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 147 */     this.requestInitializer = requestInitializer;
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpExecuteInterceptor getClientAuthentication() {
/* 153 */     return this.clientAuthentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenRequest setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 178 */     this.clientAuthentication = clientAuthentication;
/* 179 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final GenericUrl getTokenServerUrl() {
/* 184 */     return this.tokenServerUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenRequest setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 196 */     this.tokenServerUrl = tokenServerUrl;
/* 197 */     Preconditions.checkArgument((tokenServerUrl.getFragment() == null));
/* 198 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getScopes() {
/* 207 */     return this.scopes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenRequest setScopes(Collection<String> scopes) {
/* 225 */     this.scopes = (scopes == null) ? null : Joiner.on(' ').join(scopes);
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getGrantType() {
/* 235 */     return this.grantType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenRequest setGrantType(String grantType) {
/* 249 */     this.grantType = (String)Preconditions.checkNotNull(grantType);
/* 250 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Class<? extends TokenResponse> getResponseClass() {
/* 256 */     return this.responseClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenRequest setResponseClass(Class<? extends TokenResponse> responseClass) {
/* 265 */     this.responseClass = responseClass;
/* 266 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final HttpResponse executeUnparsed() throws IOException {
/* 298 */     HttpRequestFactory requestFactory = this.transport.createRequestFactory(new HttpRequestInitializer()
/*     */         {
/*     */           public void initialize(HttpRequest request) throws IOException {
/* 301 */             if (TokenRequest.this.requestInitializer != null) {
/* 302 */               TokenRequest.this.requestInitializer.initialize(request);
/*     */             }
/* 304 */             final HttpExecuteInterceptor interceptor = request.getInterceptor();
/* 305 */             request.setInterceptor(new HttpExecuteInterceptor() {
/*     */                   public void intercept(HttpRequest request) throws IOException {
/* 307 */                     if (interceptor != null) {
/* 308 */                       interceptor.intercept(request);
/*     */                     }
/* 310 */                     if (TokenRequest.this.clientAuthentication != null) {
/* 311 */                       TokenRequest.this.clientAuthentication.intercept(request);
/*     */                     }
/*     */                   }
/*     */                 });
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 319 */     HttpRequest request = requestFactory.buildPostRequest(this.tokenServerUrl, (HttpContent)new UrlEncodedContent(this));
/* 320 */     request.setParser((ObjectParser)new JsonObjectParser(this.jsonFactory));
/* 321 */     request.setThrowExceptionOnExecuteError(false);
/* 322 */     HttpResponse response = request.execute();
/* 323 */     if (response.isSuccessStatusCode()) {
/* 324 */       return response;
/*     */     }
/* 326 */     throw TokenResponseException.from(this.jsonFactory, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenResponse execute() throws IOException {
/* 346 */     return (TokenResponse)executeUnparsed().parseAs(this.responseClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenRequest set(String fieldName, Object value) {
/* 351 */     return (TokenRequest)super.set(fieldName, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\TokenRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */