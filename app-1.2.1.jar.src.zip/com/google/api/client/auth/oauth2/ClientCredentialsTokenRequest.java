/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientCredentialsTokenRequest
/*     */   extends TokenRequest
/*     */ {
/*     */   public ClientCredentialsTokenRequest(HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl) {
/*  88 */     super(transport, jsonFactory, tokenServerUrl, "client_credentials");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientCredentialsTokenRequest setRequestInitializer(HttpRequestInitializer requestInitializer) {
/*  94 */     return (ClientCredentialsTokenRequest)super.setRequestInitializer(requestInitializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClientCredentialsTokenRequest setTokenServerUrl(GenericUrl tokenServerUrl) {
/*  99 */     return (ClientCredentialsTokenRequest)super.setTokenServerUrl(tokenServerUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClientCredentialsTokenRequest setScopes(Collection<String> scopes) {
/* 104 */     return (ClientCredentialsTokenRequest)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClientCredentialsTokenRequest setGrantType(String grantType) {
/* 109 */     return (ClientCredentialsTokenRequest)super.setGrantType(grantType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientCredentialsTokenRequest setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 115 */     return (ClientCredentialsTokenRequest)super.setClientAuthentication(clientAuthentication);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClientCredentialsTokenRequest set(String fieldName, Object value) {
/* 120 */     return (ClientCredentialsTokenRequest)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClientCredentialsTokenRequest setResponseClass(Class<? extends TokenResponse> responseClass) {
/* 126 */     return (ClientCredentialsTokenRequest)super.setResponseClass(responseClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\ClientCredentialsTokenRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */