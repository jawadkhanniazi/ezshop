/*    */ package com.google.api.client.auth.oauth2;
/*    */ 
/*    */ import com.google.api.client.http.GenericUrl;
/*    */ import com.google.api.client.util.GenericData;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BrowserClientRequestUrl
/*    */   extends AuthorizationRequestUrl
/*    */ {
/*    */   public BrowserClientRequestUrl(String encodedAuthorizationServerUrl, String clientId) {
/* 57 */     super(encodedAuthorizationServerUrl, clientId, Collections.singleton("token"));
/*    */   }
/*    */ 
/*    */   
/*    */   public BrowserClientRequestUrl setResponseTypes(Collection<String> responseTypes) {
/* 62 */     return (BrowserClientRequestUrl)super.setResponseTypes(responseTypes);
/*    */   }
/*    */ 
/*    */   
/*    */   public BrowserClientRequestUrl setRedirectUri(String redirectUri) {
/* 67 */     return (BrowserClientRequestUrl)super.setRedirectUri(redirectUri);
/*    */   }
/*    */ 
/*    */   
/*    */   public BrowserClientRequestUrl setScopes(Collection<String> scopes) {
/* 72 */     return (BrowserClientRequestUrl)super.setScopes(scopes);
/*    */   }
/*    */ 
/*    */   
/*    */   public BrowserClientRequestUrl setClientId(String clientId) {
/* 77 */     return (BrowserClientRequestUrl)super.setClientId(clientId);
/*    */   }
/*    */ 
/*    */   
/*    */   public BrowserClientRequestUrl setState(String state) {
/* 82 */     return (BrowserClientRequestUrl)super.setState(state);
/*    */   }
/*    */ 
/*    */   
/*    */   public BrowserClientRequestUrl set(String fieldName, Object value) {
/* 87 */     return (BrowserClientRequestUrl)super.set(fieldName, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public BrowserClientRequestUrl clone() {
/* 92 */     return (BrowserClientRequestUrl)super.clone();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\BrowserClientRequestUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */