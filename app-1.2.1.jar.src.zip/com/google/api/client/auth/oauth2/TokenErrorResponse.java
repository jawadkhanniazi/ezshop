/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenErrorResponse
/*     */   extends GenericJson
/*     */ {
/*     */   @Key
/*     */   private String error;
/*     */   @Key("error_description")
/*     */   private String errorDescription;
/*     */   @Key("error_uri")
/*     */   private String errorUri;
/*     */   
/*     */   public final String getError() {
/*  64 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenErrorResponse setError(String error) {
/*  79 */     this.error = (String)Preconditions.checkNotNull(error);
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getErrorDescription() {
/*  88 */     return this.errorDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenErrorResponse setErrorDescription(String errorDescription) {
/* 101 */     this.errorDescription = errorDescription;
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getErrorUri() {
/* 111 */     return this.errorUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenErrorResponse setErrorUri(String errorUri) {
/* 125 */     this.errorUri = errorUri;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenErrorResponse set(String fieldName, Object value) {
/* 131 */     return (TokenErrorResponse)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenErrorResponse clone() {
/* 136 */     return (TokenErrorResponse)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\TokenErrorResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */