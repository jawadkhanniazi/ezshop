/*    */ package com.google.api.client.auth.oauth2;
/*    */ 
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ @Beta
/*    */ public final class CredentialStoreRefreshListener
/*    */   implements CredentialRefreshListener
/*    */ {
/*    */   private final CredentialStore credentialStore;
/*    */   private final String userId;
/*    */   
/*    */   public CredentialStoreRefreshListener(String userId, CredentialStore credentialStore) {
/* 51 */     this.userId = (String)Preconditions.checkNotNull(userId);
/* 52 */     this.credentialStore = (CredentialStore)Preconditions.checkNotNull(credentialStore);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTokenResponse(Credential credential, TokenResponse tokenResponse) throws IOException {
/* 57 */     makePersistent(credential);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTokenErrorResponse(Credential credential, TokenErrorResponse tokenErrorResponse) throws IOException {
/* 62 */     makePersistent(credential);
/*    */   }
/*    */ 
/*    */   
/*    */   public CredentialStore getCredentialStore() {
/* 67 */     return this.credentialStore;
/*    */   }
/*    */ 
/*    */   
/*    */   public void makePersistent(Credential credential) throws IOException {
/* 72 */     this.credentialStore.store(this.userId, credential);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\CredentialStoreRefreshListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */