/*    */ package com.google.api.client.auth.oauth2;
/*    */ 
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import com.google.api.client.util.store.DataStore;
/*    */ import com.google.api.client.util.store.DataStoreFactory;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public final class DataStoreCredentialRefreshListener
/*    */   implements CredentialRefreshListener
/*    */ {
/*    */   private final DataStore<StoredCredential> credentialDataStore;
/*    */   private final String userId;
/*    */   
/*    */   public DataStoreCredentialRefreshListener(String userId, DataStoreFactory dataStoreFactory) throws IOException {
/* 64 */     this(userId, StoredCredential.getDefaultDataStore(dataStoreFactory));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataStoreCredentialRefreshListener(String userId, DataStore<StoredCredential> credentialDataStore) {
/* 73 */     this.userId = (String)Preconditions.checkNotNull(userId);
/* 74 */     this.credentialDataStore = (DataStore<StoredCredential>)Preconditions.checkNotNull(credentialDataStore);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTokenResponse(Credential credential, TokenResponse tokenResponse) throws IOException {
/* 79 */     makePersistent(credential);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTokenErrorResponse(Credential credential, TokenErrorResponse tokenErrorResponse) throws IOException {
/* 84 */     makePersistent(credential);
/*    */   }
/*    */ 
/*    */   
/*    */   public DataStore<StoredCredential> getCredentialDataStore() {
/* 89 */     return this.credentialDataStore;
/*    */   }
/*    */ 
/*    */   
/*    */   public void makePersistent(Credential credential) throws IOException {
/* 94 */     this.credentialDataStore.set(this.userId, new StoredCredential(credential));
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\DataStoreCredentialRefreshListener.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */