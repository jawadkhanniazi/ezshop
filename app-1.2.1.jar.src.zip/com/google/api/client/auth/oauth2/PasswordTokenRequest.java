/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PasswordTokenRequest
/*     */   extends TokenRequest
/*     */ {
/*     */   @Key
/*     */   private String username;
/*     */   @Key
/*     */   private String password;
/*     */   
/*     */   public PasswordTokenRequest(HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl, String username, String password) {
/* 101 */     super(transport, jsonFactory, tokenServerUrl, "password");
/* 102 */     setUsername(username);
/* 103 */     setPassword(password);
/*     */   }
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 108 */     return (PasswordTokenRequest)super.setRequestInitializer(requestInitializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 113 */     return (PasswordTokenRequest)super.setTokenServerUrl(tokenServerUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setScopes(Collection<String> scopes) {
/* 118 */     return (PasswordTokenRequest)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setGrantType(String grantType) {
/* 123 */     return (PasswordTokenRequest)super.setGrantType(grantType);
/*     */   }
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 128 */     return (PasswordTokenRequest)super.setClientAuthentication(clientAuthentication);
/*     */   }
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setResponseClass(Class<? extends TokenResponse> responseClass) {
/* 133 */     return (PasswordTokenRequest)super.setResponseClass(responseClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getUsername() {
/* 138 */     return this.username;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setUsername(String username) {
/* 150 */     this.username = (String)Preconditions.checkNotNull(username);
/* 151 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getPassword() {
/* 156 */     return this.password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest setPassword(String password) {
/* 168 */     this.password = (String)Preconditions.checkNotNull(password);
/* 169 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PasswordTokenRequest set(String fieldName, Object value) {
/* 174 */     return (PasswordTokenRequest)super.set(fieldName, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\PasswordTokenRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */