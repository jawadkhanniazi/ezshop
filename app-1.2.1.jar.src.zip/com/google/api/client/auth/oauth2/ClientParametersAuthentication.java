/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.UrlEncodedContent;
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientParametersAuthentication
/*     */   implements HttpRequestInitializer, HttpExecuteInterceptor
/*     */ {
/*     */   private final String clientId;
/*     */   private final String clientSecret;
/*     */   
/*     */   public ClientParametersAuthentication(String clientId, String clientSecret) {
/*  89 */     this.clientId = (String)Preconditions.checkNotNull(clientId);
/*  90 */     this.clientSecret = clientSecret;
/*     */   }
/*     */   
/*     */   public void initialize(HttpRequest request) throws IOException {
/*  94 */     request.setInterceptor(this);
/*     */   }
/*     */   
/*     */   public void intercept(HttpRequest request) throws IOException {
/*  98 */     Map<String, Object> data = Data.mapOf(UrlEncodedContent.getContent(request).getData());
/*  99 */     data.put("client_id", this.clientId);
/* 100 */     if (this.clientSecret != null) {
/* 101 */       data.put("client_secret", this.clientSecret);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getClientId() {
/* 107 */     return this.clientId;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getClientSecret() {
/* 112 */     return this.clientSecret;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\ClientParametersAuthentication.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */