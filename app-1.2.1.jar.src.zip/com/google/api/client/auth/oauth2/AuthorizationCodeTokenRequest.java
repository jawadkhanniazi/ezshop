/*     */ package com.google.api.client.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationCodeTokenRequest
/*     */   extends TokenRequest
/*     */ {
/*     */   @Key
/*     */   private String code;
/*     */   @Key("redirect_uri")
/*     */   private String redirectUri;
/*     */   
/*     */   public AuthorizationCodeTokenRequest(HttpTransport transport, JsonFactory jsonFactory, GenericUrl tokenServerUrl, String code) {
/* 102 */     super(transport, jsonFactory, tokenServerUrl, "authorization_code");
/* 103 */     setCode(code);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 109 */     return (AuthorizationCodeTokenRequest)super.setRequestInitializer(requestInitializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 114 */     return (AuthorizationCodeTokenRequest)super.setTokenServerUrl(tokenServerUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setScopes(Collection<String> scopes) {
/* 119 */     return (AuthorizationCodeTokenRequest)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setGrantType(String grantType) {
/* 124 */     return (AuthorizationCodeTokenRequest)super.setGrantType(grantType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 130 */     return (AuthorizationCodeTokenRequest)super.setClientAuthentication(clientAuthentication);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setResponseClass(Class<? extends TokenResponse> responseClass) {
/* 136 */     return (AuthorizationCodeTokenRequest)super.setResponseClass(responseClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getCode() {
/* 141 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setCode(String code) {
/* 153 */     this.code = (String)Preconditions.checkNotNull(code);
/* 154 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getRedirectUri() {
/* 162 */     return this.redirectUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest setRedirectUri(String redirectUri) {
/* 175 */     this.redirectUri = redirectUri;
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public AuthorizationCodeTokenRequest set(String fieldName, Object value) {
/* 181 */     return (AuthorizationCodeTokenRequest)super.set(fieldName, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\auth\oauth2\AuthorizationCodeTokenRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */