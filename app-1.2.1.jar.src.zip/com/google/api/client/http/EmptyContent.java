/*    */ package com.google.api.client.http;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyContent
/*    */   implements HttpContent
/*    */ {
/*    */   public long getLength() throws IOException {
/* 35 */     return 0L;
/*    */   }
/*    */   
/*    */   public String getType() {
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 43 */     out.flush();
/*    */   }
/*    */   
/*    */   public boolean retrySupported() {
/* 47 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\EmptyContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */