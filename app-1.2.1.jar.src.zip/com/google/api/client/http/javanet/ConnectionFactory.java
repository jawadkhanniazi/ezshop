package com.google.api.client.http.javanet;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public interface ConnectionFactory {
  HttpURLConnection openConnection(URL paramURL) throws IOException, ClassCastException;
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\javanet\ConnectionFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */