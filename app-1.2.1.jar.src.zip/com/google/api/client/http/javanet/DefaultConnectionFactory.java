/*    */ package com.google.api.client.http.javanet;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.Proxy;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultConnectionFactory
/*    */   implements ConnectionFactory
/*    */ {
/*    */   private final Proxy proxy;
/*    */   
/*    */   public DefaultConnectionFactory() {
/* 17 */     this(null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DefaultConnectionFactory(Proxy proxy) {
/* 26 */     this.proxy = proxy;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpURLConnection openConnection(URL url) throws IOException {
/* 31 */     return (this.proxy == null) ? (HttpURLConnection)url.openConnection() : (HttpURLConnection)url.openConnection(this.proxy);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\javanet\DefaultConnectionFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */