/*     */ package com.google.api.client.http.javanet;
/*     */ 
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NetHttpResponse
/*     */   extends LowLevelHttpResponse
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   private final int responseCode;
/*     */   private final String responseMessage;
/*  31 */   private final ArrayList<String> headerNames = new ArrayList<>();
/*  32 */   private final ArrayList<String> headerValues = new ArrayList<>();
/*     */   
/*     */   NetHttpResponse(HttpURLConnection connection) throws IOException {
/*  35 */     this.connection = connection;
/*  36 */     int responseCode = connection.getResponseCode();
/*  37 */     this.responseCode = (responseCode == -1) ? 0 : responseCode;
/*  38 */     this.responseMessage = connection.getResponseMessage();
/*  39 */     List<String> headerNames = this.headerNames;
/*  40 */     List<String> headerValues = this.headerValues;
/*  41 */     for (Map.Entry<String, List<String>> entry : connection.getHeaderFields().entrySet()) {
/*  42 */       String key = entry.getKey();
/*  43 */       if (key != null) {
/*  44 */         for (String value : entry.getValue()) {
/*  45 */           if (value != null) {
/*  46 */             headerNames.add(key);
/*  47 */             headerValues.add(value);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatusCode() {
/*  56 */     return this.responseCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getContent() throws IOException {
/*  81 */     InputStream in = null;
/*     */     try {
/*  83 */       in = this.connection.getInputStream();
/*  84 */     } catch (IOException ioe) {
/*  85 */       in = this.connection.getErrorStream();
/*     */     } 
/*  87 */     return (in == null) ? null : new SizeValidatingInputStream(in);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/*  92 */     return this.connection.getContentEncoding();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/*  97 */     String string = this.connection.getHeaderField("Content-Length");
/*  98 */     return (string == null) ? -1L : Long.parseLong(string);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 103 */     return this.connection.getHeaderField("Content-Type");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getReasonPhrase() {
/* 108 */     return this.responseMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatusLine() {
/* 113 */     String result = this.connection.getHeaderField(0);
/* 114 */     return (result != null && result.startsWith("HTTP/1.")) ? result : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeaderCount() {
/* 119 */     return this.headerNames.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderName(int index) {
/* 124 */     return this.headerNames.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderValue(int index) {
/* 129 */     return this.headerValues.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 139 */     this.connection.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class SizeValidatingInputStream
/*     */     extends FilterInputStream
/*     */   {
/* 149 */     private long bytesRead = 0L;
/*     */     
/*     */     public SizeValidatingInputStream(InputStream in) {
/* 152 */       super(in);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 164 */       int n = this.in.read(b, off, len);
/* 165 */       if (n == -1) {
/* 166 */         throwIfFalseEOF();
/*     */       } else {
/* 168 */         this.bytesRead += n;
/*     */       } 
/* 170 */       return n;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 175 */       int n = this.in.read();
/* 176 */       if (n == -1) {
/* 177 */         throwIfFalseEOF();
/*     */       } else {
/* 179 */         this.bytesRead++;
/*     */       } 
/* 181 */       return n;
/*     */     }
/*     */ 
/*     */     
/*     */     public long skip(long len) throws IOException {
/* 186 */       long n = this.in.skip(len);
/* 187 */       this.bytesRead += n;
/* 188 */       return n;
/*     */     }
/*     */ 
/*     */     
/*     */     private void throwIfFalseEOF() throws IOException {
/* 193 */       long contentLength = NetHttpResponse.this.getContentLength();
/* 194 */       if (contentLength == -1L) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 203 */       if (this.bytesRead != 0L && this.bytesRead < contentLength)
/* 204 */         throw new IOException("Connection closed prematurely: bytesRead = " + this.bytesRead + ", Content-Length = " + contentLength); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\javanet\NetHttpResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */