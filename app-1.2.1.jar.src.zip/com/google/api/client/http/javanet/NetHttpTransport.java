/*     */ package com.google.api.client.http.javanet;
/*     */ 
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.SecurityUtils;
/*     */ import com.google.api.client.util.SslUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import java.util.Arrays;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NetHttpTransport
/*     */   extends HttpTransport
/*     */ {
/*     */   private static Proxy defaultProxy() {
/*  57 */     return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
/*     */ 
/*     */           
/*  60 */           System.getProperty("https.proxyHost"), 
/*  61 */           Integer.parseInt(System.getProperty("https.proxyPort"))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private static final String[] SUPPORTED_METHODS = new String[] { "DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT", "TRACE" };
/*     */   
/*     */   private static final String SHOULD_USE_PROXY_FLAG = "com.google.api.client.should_use_proxy";
/*     */   
/*     */   private final ConnectionFactory connectionFactory;
/*     */   
/*     */   private final SSLSocketFactory sslSocketFactory;
/*     */   
/*     */   private final HostnameVerifier hostnameVerifier;
/*     */   
/*     */   static {
/*  79 */     Arrays.sort((Object[])SUPPORTED_METHODS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NetHttpTransport() {
/*  98 */     this((ConnectionFactory)null, (SSLSocketFactory)null, (HostnameVerifier)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NetHttpTransport(Proxy proxy, SSLSocketFactory sslSocketFactory, HostnameVerifier hostnameVerifier) {
/* 110 */     this(new DefaultConnectionFactory(proxy), sslSocketFactory, hostnameVerifier);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NetHttpTransport(ConnectionFactory connectionFactory, SSLSocketFactory sslSocketFactory, HostnameVerifier hostnameVerifier) {
/* 124 */     this.connectionFactory = getConnectionFactory(connectionFactory);
/* 125 */     this.sslSocketFactory = sslSocketFactory;
/* 126 */     this.hostnameVerifier = hostnameVerifier;
/*     */   }
/*     */   
/*     */   private ConnectionFactory getConnectionFactory(ConnectionFactory connectionFactory) {
/* 130 */     if (connectionFactory == null) {
/* 131 */       if (System.getProperty("com.google.api.client.should_use_proxy") != null) {
/* 132 */         return new DefaultConnectionFactory(defaultProxy());
/*     */       }
/* 134 */       return new DefaultConnectionFactory();
/*     */     } 
/* 136 */     return connectionFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsMethod(String method) {
/* 141 */     return (Arrays.binarySearch((Object[])SUPPORTED_METHODS, method) >= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected NetHttpRequest buildRequest(String method, String url) throws IOException {
/* 146 */     Preconditions.checkArgument(supportsMethod(method), "HTTP method %s not supported", new Object[] { method });
/*     */     
/* 148 */     URL connUrl = new URL(url);
/* 149 */     HttpURLConnection connection = this.connectionFactory.openConnection(connUrl);
/* 150 */     connection.setRequestMethod(method);
/*     */     
/* 152 */     if (connection instanceof HttpsURLConnection) {
/* 153 */       HttpsURLConnection secureConnection = (HttpsURLConnection)connection;
/* 154 */       if (this.hostnameVerifier != null) {
/* 155 */         secureConnection.setHostnameVerifier(this.hostnameVerifier);
/*     */       }
/* 157 */       if (this.sslSocketFactory != null) {
/* 158 */         secureConnection.setSSLSocketFactory(this.sslSocketFactory);
/*     */       }
/*     */     } 
/* 161 */     return new NetHttpRequest(connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private SSLSocketFactory sslSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private HostnameVerifier hostnameVerifier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Proxy proxy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ConnectionFactory connectionFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setProxy(Proxy proxy) {
/* 204 */       this.proxy = proxy;
/* 205 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setConnectionFactory(ConnectionFactory connectionFactory) {
/* 218 */       this.connectionFactory = connectionFactory;
/* 219 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder trustCertificatesFromJavaKeyStore(InputStream keyStoreStream, String storePass) throws GeneralSecurityException, IOException {
/* 238 */       KeyStore trustStore = SecurityUtils.getJavaKeyStore();
/* 239 */       SecurityUtils.loadKeyStore(trustStore, keyStoreStream, storePass);
/* 240 */       return trustCertificates(trustStore);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder trustCertificatesFromStream(InputStream certificateStream) throws GeneralSecurityException, IOException {
/* 258 */       KeyStore trustStore = SecurityUtils.getJavaKeyStore();
/* 259 */       trustStore.load(null, null);
/* 260 */       SecurityUtils.loadKeyStoreFromCertificates(trustStore, 
/* 261 */           SecurityUtils.getX509CertificateFactory(), certificateStream);
/* 262 */       return trustCertificates(trustStore);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder trustCertificates(KeyStore trustStore) throws GeneralSecurityException {
/* 273 */       SSLContext sslContext = SslUtils.getTlsSslContext();
/* 274 */       SslUtils.initSslContext(sslContext, trustStore, SslUtils.getPkixTrustManagerFactory());
/* 275 */       return setSslSocketFactory(sslContext.getSocketFactory());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public Builder doNotValidateCertificate() throws GeneralSecurityException {
/* 289 */       this.hostnameVerifier = SslUtils.trustAllHostnameVerifier();
/* 290 */       this.sslSocketFactory = SslUtils.trustAllSSLContext().getSocketFactory();
/* 291 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SSLSocketFactory getSslSocketFactory() {
/* 296 */       return this.sslSocketFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSslSocketFactory(SSLSocketFactory sslSocketFactory) {
/* 301 */       this.sslSocketFactory = sslSocketFactory;
/* 302 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HostnameVerifier getHostnameVerifier() {
/* 307 */       return this.hostnameVerifier;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setHostnameVerifier(HostnameVerifier hostnameVerifier) {
/* 312 */       this.hostnameVerifier = hostnameVerifier;
/* 313 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public NetHttpTransport build() {
/* 318 */       if (System.getProperty("com.google.api.client.should_use_proxy") != null) {
/* 319 */         setProxy(NetHttpTransport.defaultProxy());
/*     */       }
/* 321 */       return (this.proxy == null) ? new NetHttpTransport(this.connectionFactory, this.sslSocketFactory, this.hostnameVerifier) : new NetHttpTransport(this.proxy, this.sslSocketFactory, this.hostnameVerifier);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\javanet\NetHttpTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */