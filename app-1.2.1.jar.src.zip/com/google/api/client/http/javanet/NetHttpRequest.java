/*     */ package com.google.api.client.http.javanet;
/*     */ 
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StreamingContent;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class NetHttpRequest
/*     */   extends LowLevelHttpRequest
/*     */ {
/*     */   private final HttpURLConnection connection;
/*     */   private int writeTimeout;
/*     */   
/*     */   NetHttpRequest(HttpURLConnection connection) {
/*  42 */     this.connection = connection;
/*  43 */     this.writeTimeout = 0;
/*  44 */     connection.setInstanceFollowRedirects(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addHeader(String name, String value) {
/*  49 */     this.connection.addRequestProperty(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeout(int connectTimeout, int readTimeout) {
/*  54 */     this.connection.setReadTimeout(readTimeout);
/*  55 */     this.connection.setConnectTimeout(connectTimeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWriteTimeout(int writeTimeout) throws IOException {
/*  60 */     this.writeTimeout = writeTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultOutputWriter
/*     */     implements OutputWriter
/*     */   {
/*     */     public void write(OutputStream outputStream, StreamingContent content) throws IOException {
/*  71 */       content.writeTo(outputStream);
/*     */     }
/*     */   }
/*     */   
/*  75 */   private static final OutputWriter DEFAULT_CONNECTION_WRITER = new DefaultOutputWriter();
/*     */ 
/*     */   
/*     */   public LowLevelHttpResponse execute() throws IOException {
/*  79 */     return execute(DEFAULT_CONNECTION_WRITER);
/*     */   }
/*     */   
/*     */   @VisibleForTesting
/*     */   LowLevelHttpResponse execute(OutputWriter outputWriter) throws IOException {
/*  84 */     HttpURLConnection connection = this.connection;
/*     */     
/*  86 */     if (getStreamingContent() != null) {
/*  87 */       String contentType = getContentType();
/*  88 */       if (contentType != null) {
/*  89 */         addHeader("Content-Type", contentType);
/*     */       }
/*  91 */       String contentEncoding = getContentEncoding();
/*  92 */       if (contentEncoding != null) {
/*  93 */         addHeader("Content-Encoding", contentEncoding);
/*     */       }
/*  95 */       long contentLength = getContentLength();
/*  96 */       if (contentLength >= 0L) {
/*  97 */         connection.setRequestProperty("Content-Length", Long.toString(contentLength));
/*     */       }
/*  99 */       String requestMethod = connection.getRequestMethod();
/* 100 */       if ("POST".equals(requestMethod) || "PUT".equals(requestMethod)) {
/* 101 */         connection.setDoOutput(true);
/*     */         
/* 103 */         if (contentLength >= 0L && contentLength <= 2147483647L) {
/* 104 */           connection.setFixedLengthStreamingMode((int)contentLength);
/*     */         } else {
/* 106 */           connection.setChunkedStreamingMode(0);
/*     */         } 
/* 108 */         OutputStream out = connection.getOutputStream();
/*     */         
/* 110 */         boolean threw = true;
/*     */         try {
/* 112 */           writeContentToOutputStream(outputWriter, out);
/*     */           
/* 114 */           threw = false;
/* 115 */         } catch (IOException e) {
/*     */ 
/*     */           
/* 118 */           if (!hasResponse(connection)) {
/* 119 */             throw e;
/*     */           }
/*     */         } finally {
/*     */           try {
/* 123 */             out.close();
/* 124 */           } catch (IOException exception) {
/*     */ 
/*     */ 
/*     */             
/* 128 */             if (!threw) {
/* 129 */               throw exception;
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 136 */         Preconditions.checkArgument((contentLength == 0L), "%s with non-zero content length is not supported", new Object[] { requestMethod });
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 141 */     boolean successfulConnection = false;
/*     */     try {
/* 143 */       connection.connect();
/* 144 */       NetHttpResponse response = new NetHttpResponse(connection);
/* 145 */       successfulConnection = true;
/* 146 */       return response;
/*     */     } finally {
/* 148 */       if (!successfulConnection) {
/* 149 */         connection.disconnect();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasResponse(HttpURLConnection connection) {
/*     */     try {
/* 156 */       return (connection.getResponseCode() > 0);
/* 157 */     } catch (IOException e) {
/*     */       
/* 159 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeContentToOutputStream(final OutputWriter outputWriter, final OutputStream out) throws IOException {
/* 165 */     if (this.writeTimeout == 0) {
/* 166 */       outputWriter.write(out, getStreamingContent());
/*     */     } else {
/*     */       
/* 169 */       final StreamingContent content = getStreamingContent();
/* 170 */       Callable<Boolean> writeContent = new Callable<Boolean>()
/*     */         {
/*     */           public Boolean call() throws IOException
/*     */           {
/* 174 */             outputWriter.write(out, content);
/* 175 */             return Boolean.TRUE;
/*     */           }
/*     */         };
/*     */       
/* 179 */       ExecutorService executor = Executors.newSingleThreadExecutor();
/* 180 */       Future<Boolean> future = executor.submit(new FutureTask<>(writeContent), null);
/* 181 */       executor.shutdown();
/*     */       
/*     */       try {
/* 184 */         future.get(this.writeTimeout, TimeUnit.MILLISECONDS);
/* 185 */       } catch (InterruptedException e) {
/* 186 */         throw new IOException("Socket write interrupted", e);
/* 187 */       } catch (ExecutionException e) {
/* 188 */         throw new IOException("Exception in socket write", e);
/* 189 */       } catch (TimeoutException e) {
/* 190 */         throw new IOException("Socket write timed out", e);
/*     */       } 
/* 192 */       if (!executor.isTerminated())
/* 193 */         executor.shutdown(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   static interface OutputWriter {
/*     */     void write(OutputStream param1OutputStream, StreamingContent param1StreamingContent) throws IOException;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\javanet\NetHttpRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */