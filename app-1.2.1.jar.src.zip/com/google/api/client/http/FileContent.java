/*    */ package com.google.api.client.http;
/*    */ 
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FileContent
/*    */   extends AbstractInputStreamContent
/*    */ {
/*    */   private final File file;
/*    */   
/*    */   public FileContent(String type, File file) {
/* 52 */     super(type);
/* 53 */     this.file = (File)Preconditions.checkNotNull(file);
/*    */   }
/*    */   
/*    */   public long getLength() {
/* 57 */     return this.file.length();
/*    */   }
/*    */   
/*    */   public boolean retrySupported() {
/* 61 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() throws FileNotFoundException {
/* 66 */     return new FileInputStream(this.file);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public File getFile() {
/* 75 */     return this.file;
/*    */   }
/*    */ 
/*    */   
/*    */   public FileContent setType(String type) {
/* 80 */     return (FileContent)super.setType(type);
/*    */   }
/*    */ 
/*    */   
/*    */   public FileContent setCloseInputStream(boolean closeInputStream) {
/* 85 */     return (FileContent)super.setCloseInputStream(closeInputStream);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\FileContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */