/*      */ package com.google.api.client.http;
/*      */ 
/*      */ import com.google.api.client.util.ArrayValueMap;
/*      */ import com.google.api.client.util.Base64;
/*      */ import com.google.api.client.util.ClassInfo;
/*      */ import com.google.api.client.util.Data;
/*      */ import com.google.api.client.util.FieldInfo;
/*      */ import com.google.api.client.util.GenericData;
/*      */ import com.google.api.client.util.Key;
/*      */ import com.google.api.client.util.Preconditions;
/*      */ import com.google.api.client.util.StringUtils;
/*      */ import com.google.api.client.util.Throwables;
/*      */ import com.google.api.client.util.Types;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.EnumSet;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HttpHeaders
/*      */   extends GenericData
/*      */ {
/*      */   @Key("Accept")
/*      */   private List<String> accept;
/*      */   @Key("Accept-Encoding")
/*      */   private List<String> acceptEncoding;
/*      */   @Key("Authorization")
/*      */   private List<String> authorization;
/*      */   @Key("Cache-Control")
/*      */   private List<String> cacheControl;
/*      */   @Key("Content-Encoding")
/*      */   private List<String> contentEncoding;
/*      */   @Key("Content-Length")
/*      */   private List<Long> contentLength;
/*      */   
/*      */   public HttpHeaders() {
/*   57 */     super(EnumSet.of(GenericData.Flags.IGNORE_CASE));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   65 */     this
/*   66 */       .acceptEncoding = new ArrayList<>(Collections.singleton("gzip"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("Content-MD5")
/*      */   private List<String> contentMD5;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("Content-Range")
/*      */   private List<String> contentRange;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("Content-Type")
/*      */   private List<String> contentType;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("Cookie")
/*      */   private List<String> cookie;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("Date")
/*      */   private List<String> date;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("ETag")
/*      */   private List<String> etag;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("Expires")
/*      */   private List<String> expires;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("If-Modified-Since")
/*      */   private List<String> ifModifiedSince;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("If-Match")
/*      */   private List<String> ifMatch;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("If-None-Match")
/*      */   private List<String> ifNoneMatch;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("If-Unmodified-Since")
/*      */   private List<String> ifUnmodifiedSince;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("If-Range")
/*      */   private List<String> ifRange;
/*      */ 
/*      */ 
/*      */   
/*      */   @Key("Last-Modified")
/*      */   private List<String> lastModified;
/*      */ 
/*      */   
/*      */   @Key("Location")
/*      */   private List<String> location;
/*      */ 
/*      */   
/*      */   @Key("MIME-Version")
/*      */   private List<String> mimeVersion;
/*      */ 
/*      */   
/*      */   @Key("Range")
/*      */   private List<String> range;
/*      */ 
/*      */   
/*      */   @Key("Retry-After")
/*      */   private List<String> retryAfter;
/*      */ 
/*      */   
/*      */   @Key("User-Agent")
/*      */   private List<String> userAgent;
/*      */ 
/*      */   
/*      */   @Key("Warning")
/*      */   private List<String> warning;
/*      */ 
/*      */   
/*      */   @Key("WWW-Authenticate")
/*      */   private List<String> authenticate;
/*      */ 
/*      */   
/*      */   @Key("Age")
/*      */   private List<Long> age;
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders clone() {
/*  170 */     return (HttpHeaders)super.clone();
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpHeaders set(String fieldName, Object value) {
/*  175 */     return (HttpHeaders)super.set(fieldName, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getAccept() {
/*  184 */     return getFirstHeaderValue(this.accept);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setAccept(String accept) {
/*  196 */     this.accept = getAsList(accept);
/*  197 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getAcceptEncoding() {
/*  206 */     return getFirstHeaderValue(this.acceptEncoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setAcceptEncoding(String acceptEncoding) {
/*  217 */     this.acceptEncoding = getAsList(acceptEncoding);
/*  218 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getAuthorization() {
/*  227 */     return getFirstHeaderValue(this.authorization);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<String> getAuthorizationAsList() {
/*  236 */     return this.authorization;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setAuthorization(String authorization) {
/*  248 */     return setAuthorization(getAsList(authorization));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setAuthorization(List<String> authorization) {
/*  260 */     this.authorization = authorization;
/*  261 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getCacheControl() {
/*  270 */     return getFirstHeaderValue(this.cacheControl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setCacheControl(String cacheControl) {
/*  282 */     this.cacheControl = getAsList(cacheControl);
/*  283 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getContentEncoding() {
/*  292 */     return getFirstHeaderValue(this.contentEncoding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setContentEncoding(String contentEncoding) {
/*  304 */     this.contentEncoding = getAsList(contentEncoding);
/*  305 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Long getContentLength() {
/*  314 */     return getFirstHeaderValue(this.contentLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setContentLength(Long contentLength) {
/*  326 */     this.contentLength = getAsList(contentLength);
/*  327 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getContentMD5() {
/*  336 */     return getFirstHeaderValue(this.contentMD5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setContentMD5(String contentMD5) {
/*  348 */     this.contentMD5 = getAsList(contentMD5);
/*  349 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getContentRange() {
/*  358 */     return getFirstHeaderValue(this.contentRange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setContentRange(String contentRange) {
/*  370 */     this.contentRange = getAsList(contentRange);
/*  371 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getContentType() {
/*  380 */     return getFirstHeaderValue(this.contentType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setContentType(String contentType) {
/*  392 */     this.contentType = getAsList(contentType);
/*  393 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getCookie() {
/*  404 */     return getFirstHeaderValue(this.cookie);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setCookie(String cookie) {
/*  416 */     this.cookie = getAsList(cookie);
/*  417 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getDate() {
/*  426 */     return getFirstHeaderValue(this.date);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setDate(String date) {
/*  438 */     this.date = getAsList(date);
/*  439 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getETag() {
/*  448 */     return getFirstHeaderValue(this.etag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setETag(String etag) {
/*  460 */     this.etag = getAsList(etag);
/*  461 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getExpires() {
/*  470 */     return getFirstHeaderValue(this.expires);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setExpires(String expires) {
/*  482 */     this.expires = getAsList(expires);
/*  483 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getIfModifiedSince() {
/*  492 */     return getFirstHeaderValue(this.ifModifiedSince);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setIfModifiedSince(String ifModifiedSince) {
/*  504 */     this.ifModifiedSince = getAsList(ifModifiedSince);
/*  505 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getIfMatch() {
/*  514 */     return getFirstHeaderValue(this.ifMatch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setIfMatch(String ifMatch) {
/*  526 */     this.ifMatch = getAsList(ifMatch);
/*  527 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getIfNoneMatch() {
/*  536 */     return getFirstHeaderValue(this.ifNoneMatch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setIfNoneMatch(String ifNoneMatch) {
/*  548 */     this.ifNoneMatch = getAsList(ifNoneMatch);
/*  549 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getIfUnmodifiedSince() {
/*  558 */     return getFirstHeaderValue(this.ifUnmodifiedSince);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setIfUnmodifiedSince(String ifUnmodifiedSince) {
/*  570 */     this.ifUnmodifiedSince = getAsList(ifUnmodifiedSince);
/*  571 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getIfRange() {
/*  580 */     return getFirstHeaderValue(this.ifRange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setIfRange(String ifRange) {
/*  592 */     this.ifRange = getAsList(ifRange);
/*  593 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getLastModified() {
/*  602 */     return getFirstHeaderValue(this.lastModified);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setLastModified(String lastModified) {
/*  614 */     this.lastModified = getAsList(lastModified);
/*  615 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getLocation() {
/*  624 */     return getFirstHeaderValue(this.location);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setLocation(String location) {
/*  636 */     this.location = getAsList(location);
/*  637 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getMimeVersion() {
/*  646 */     return getFirstHeaderValue(this.mimeVersion);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setMimeVersion(String mimeVersion) {
/*  658 */     this.mimeVersion = getAsList(mimeVersion);
/*  659 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getRange() {
/*  668 */     return getFirstHeaderValue(this.range);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setRange(String range) {
/*  680 */     this.range = getAsList(range);
/*  681 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getRetryAfter() {
/*  690 */     return getFirstHeaderValue(this.retryAfter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setRetryAfter(String retryAfter) {
/*  702 */     this.retryAfter = getAsList(retryAfter);
/*  703 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getUserAgent() {
/*  712 */     return getFirstHeaderValue(this.userAgent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setUserAgent(String userAgent) {
/*  724 */     this.userAgent = getAsList(userAgent);
/*  725 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getAuthenticate() {
/*  734 */     return getFirstHeaderValue(this.authenticate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<String> getAuthenticateAsList() {
/*  743 */     return this.authenticate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setAuthenticate(String authenticate) {
/*  755 */     this.authenticate = getAsList(authenticate);
/*  756 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders addWarning(String warning) {
/*  768 */     if (warning == null) {
/*  769 */       return this;
/*      */     }
/*  771 */     if (this.warning == null) {
/*  772 */       this.warning = getAsList(warning);
/*      */     } else {
/*  774 */       this.warning.add(warning);
/*      */     } 
/*  776 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List<String> getWarning() {
/*  785 */     return (this.warning == null) ? null : new ArrayList<>(this.warning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Long getAge() {
/*  794 */     return getFirstHeaderValue(this.age);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setAge(Long age) {
/*  806 */     this.age = getAsList(age);
/*  807 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders setBasicAuthentication(String username, String password) {
/*  821 */     String userPass = (String)Preconditions.checkNotNull(username) + ":" + (String)Preconditions.checkNotNull(password);
/*  822 */     String encoded = Base64.encodeBase64String(StringUtils.getBytesUtf8(userPass));
/*  823 */     return setAuthorization("Basic " + encoded);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addHeader(Logger logger, StringBuilder logbuf, StringBuilder curlbuf, LowLevelHttpRequest lowLevelHttpRequest, String name, Object value, Writer writer) throws IOException {
/*  836 */     if (value == null || Data.isNull(value)) {
/*      */       return;
/*      */     }
/*      */     
/*  840 */     String stringValue = toStringValue(value);
/*      */     
/*  842 */     String loggedStringValue = stringValue;
/*  843 */     if (("Authorization".equalsIgnoreCase(name) || "Cookie".equalsIgnoreCase(name)) && (logger == null || 
/*  844 */       !logger.isLoggable(Level.ALL))) {
/*  845 */       loggedStringValue = "<Not Logged>";
/*      */     }
/*  847 */     if (logbuf != null) {
/*  848 */       logbuf.append(name).append(": ");
/*  849 */       logbuf.append(loggedStringValue);
/*  850 */       logbuf.append(StringUtils.LINE_SEPARATOR);
/*      */     } 
/*  852 */     if (curlbuf != null) {
/*  853 */       curlbuf.append(" -H '").append(name).append(": ").append(loggedStringValue).append("'");
/*      */     }
/*      */     
/*  856 */     if (lowLevelHttpRequest != null) {
/*  857 */       lowLevelHttpRequest.addHeader(name, stringValue);
/*      */     }
/*      */     
/*  860 */     if (writer != null) {
/*  861 */       writer.write(name);
/*  862 */       writer.write(": ");
/*  863 */       writer.write(stringValue);
/*  864 */       writer.write("\r\n");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static String toStringValue(Object headerValue) {
/*  870 */     return (headerValue instanceof Enum) ? 
/*  871 */       FieldInfo.of((Enum)headerValue).getName() : headerValue
/*  872 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void serializeHeaders(HttpHeaders headers, StringBuilder logbuf, StringBuilder curlbuf, Logger logger, LowLevelHttpRequest lowLevelHttpRequest) throws IOException {
/*  893 */     serializeHeaders(headers, logbuf, curlbuf, logger, lowLevelHttpRequest, (Writer)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void serializeHeaders(HttpHeaders headers, StringBuilder logbuf, StringBuilder curlbuf, Logger logger, LowLevelHttpRequest lowLevelHttpRequest, Writer writer) throws IOException {
/*  904 */     HashSet<String> headerNames = new HashSet<>();
/*  905 */     for (Map.Entry<String, Object> headerEntry : (Iterable<Map.Entry<String, Object>>)headers.entrySet()) {
/*  906 */       String name = headerEntry.getKey();
/*  907 */       Preconditions.checkArgument(headerNames
/*  908 */           .add(name), "multiple headers of the same name (headers are case insensitive): %s", new Object[] { name });
/*      */ 
/*      */       
/*  911 */       Object value = headerEntry.getValue();
/*  912 */       if (value != null) {
/*      */         
/*  914 */         String displayName = name;
/*  915 */         FieldInfo fieldInfo = headers.getClassInfo().getFieldInfo(name);
/*  916 */         if (fieldInfo != null) {
/*  917 */           displayName = fieldInfo.getName();
/*      */         }
/*  919 */         Class<? extends Object> valueClass = (Class)value.getClass();
/*  920 */         if (value instanceof Iterable || valueClass.isArray()) {
/*  921 */           for (Object repeatedValue : Types.iterableOf(value)) {
/*  922 */             addHeader(logger, logbuf, curlbuf, lowLevelHttpRequest, displayName, repeatedValue, writer);
/*      */           }
/*      */           continue;
/*      */         } 
/*  926 */         addHeader(logger, logbuf, curlbuf, lowLevelHttpRequest, displayName, value, writer);
/*      */       } 
/*      */     } 
/*      */     
/*  930 */     if (writer != null) {
/*  931 */       writer.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void serializeHeadersForMultipartRequests(HttpHeaders headers, StringBuilder logbuf, Logger logger, Writer writer) throws IOException {
/*  947 */     serializeHeaders(headers, logbuf, (StringBuilder)null, logger, (LowLevelHttpRequest)null, writer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void fromHttpResponse(LowLevelHttpResponse response, StringBuilder logger) throws IOException {
/*  960 */     clear();
/*  961 */     ParseHeaderState state = new ParseHeaderState(this, logger);
/*  962 */     int headerCount = response.getHeaderCount();
/*  963 */     for (int i = 0; i < headerCount; i++) {
/*  964 */       parseHeader(response.getHeaderName(i), response.getHeaderValue(i), state);
/*      */     }
/*  966 */     state.finish();
/*      */   }
/*      */   
/*      */   private static class HeaderParsingFakeLevelHttpRequest
/*      */     extends LowLevelHttpRequest {
/*      */     private final HttpHeaders target;
/*      */     private final HttpHeaders.ParseHeaderState state;
/*      */     
/*      */     HeaderParsingFakeLevelHttpRequest(HttpHeaders target, HttpHeaders.ParseHeaderState state) {
/*  975 */       this.target = target;
/*  976 */       this.state = state;
/*      */     }
/*      */ 
/*      */     
/*      */     public void addHeader(String name, String value) {
/*  981 */       this.target.parseHeader(name, value, this.state);
/*      */     }
/*      */ 
/*      */     
/*      */     public LowLevelHttpResponse execute() throws IOException {
/*  986 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> T getFirstHeaderValue(List<T> internalValue) {
/*  992 */     return (internalValue == null) ? null : internalValue.get(0);
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> List<T> getAsList(T passedValue) {
/*  997 */     if (passedValue == null) {
/*  998 */       return null;
/*      */     }
/* 1000 */     List<T> result = new ArrayList<>();
/* 1001 */     result.add(passedValue);
/* 1002 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFirstHeaderStringValue(String name) {
/* 1013 */     Object value = get(name.toLowerCase(Locale.US));
/* 1014 */     if (value == null) {
/* 1015 */       return null;
/*      */     }
/* 1017 */     Class<? extends Object> valueClass = (Class)value.getClass();
/* 1018 */     if (value instanceof Iterable || valueClass.isArray()) {
/* 1019 */       Iterator iterator = Types.iterableOf(value).iterator(); if (iterator.hasNext()) { Object repeatedValue = iterator.next();
/* 1020 */         return toStringValue(repeatedValue); }
/*      */     
/*      */     } 
/* 1023 */     return toStringValue(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> getHeaderStringValues(String name) {
/* 1034 */     Object value = get(name.toLowerCase(Locale.US));
/* 1035 */     if (value == null) {
/* 1036 */       return Collections.emptyList();
/*      */     }
/* 1038 */     Class<? extends Object> valueClass = (Class)value.getClass();
/* 1039 */     if (value instanceof Iterable || valueClass.isArray()) {
/* 1040 */       List<String> values = new ArrayList<>();
/* 1041 */       for (Object repeatedValue : Types.iterableOf(value)) {
/* 1042 */         values.add(toStringValue(repeatedValue));
/*      */       }
/* 1044 */       return Collections.unmodifiableList(values);
/*      */     } 
/* 1046 */     return Collections.singletonList(toStringValue(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void fromHttpHeaders(HttpHeaders headers) {
/*      */     try {
/* 1057 */       ParseHeaderState state = new ParseHeaderState(this, null);
/* 1058 */       serializeHeaders(headers, (StringBuilder)null, (StringBuilder)null, (Logger)null, new HeaderParsingFakeLevelHttpRequest(this, state));
/*      */       
/* 1060 */       state.finish();
/* 1061 */     } catch (IOException ex) {
/*      */       
/* 1063 */       throw Throwables.propagate(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class ParseHeaderState
/*      */   {
/*      */     final ArrayValueMap arrayValueMap;
/*      */ 
/*      */ 
/*      */     
/*      */     final StringBuilder logger;
/*      */ 
/*      */ 
/*      */     
/*      */     final ClassInfo classInfo;
/*      */ 
/*      */     
/*      */     final List<Type> context;
/*      */ 
/*      */ 
/*      */     
/*      */     public ParseHeaderState(HttpHeaders headers, StringBuilder logger) {
/* 1088 */       Class<? extends HttpHeaders> clazz = (Class)headers.getClass();
/* 1089 */       this.context = Arrays.asList(new Type[] { clazz });
/* 1090 */       this.classInfo = ClassInfo.of(clazz, true);
/* 1091 */       this.logger = logger;
/* 1092 */       this.arrayValueMap = new ArrayValueMap(headers);
/*      */     }
/*      */ 
/*      */     
/*      */     void finish() {
/* 1097 */       this.arrayValueMap.setValues();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   void parseHeader(String headerName, String headerValue, ParseHeaderState state) {
/* 1103 */     List<Type> context = state.context;
/* 1104 */     ClassInfo classInfo = state.classInfo;
/* 1105 */     ArrayValueMap arrayValueMap = state.arrayValueMap;
/* 1106 */     StringBuilder logger = state.logger;
/*      */     
/* 1108 */     if (logger != null) {
/* 1109 */       logger.append(headerName + ": " + headerValue).append(StringUtils.LINE_SEPARATOR);
/*      */     }
/*      */     
/* 1112 */     FieldInfo fieldInfo = classInfo.getFieldInfo(headerName);
/* 1113 */     if (fieldInfo != null) {
/* 1114 */       Type type = Data.resolveWildcardTypeOrTypeVariable(context, fieldInfo.getGenericType());
/*      */       
/* 1116 */       if (Types.isArray(type)) {
/*      */ 
/*      */         
/* 1119 */         Class<?> rawArrayComponentType = Types.getRawArrayComponentType(context, Types.getArrayComponentType(type));
/* 1120 */         arrayValueMap.put(fieldInfo
/* 1121 */             .getField(), rawArrayComponentType, 
/*      */             
/* 1123 */             parseValue(rawArrayComponentType, context, headerValue));
/* 1124 */       } else if (Types.isAssignableToOrFrom(
/* 1125 */           Types.getRawArrayComponentType(context, type), Iterable.class)) {
/*      */ 
/*      */         
/* 1128 */         Collection<Object> collection = (Collection<Object>)fieldInfo.getValue(this);
/* 1129 */         if (collection == null) {
/* 1130 */           collection = Data.newCollectionInstance(type);
/* 1131 */           fieldInfo.setValue(this, collection);
/*      */         } 
/* 1133 */         Type subFieldType = (type == Object.class) ? null : Types.getIterableParameter(type);
/* 1134 */         collection.add(parseValue(subFieldType, context, headerValue));
/*      */       } else {
/*      */         
/* 1137 */         fieldInfo.setValue(this, parseValue(type, context, headerValue));
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1142 */       ArrayList<String> listValue = (ArrayList<String>)get(headerName);
/* 1143 */       if (listValue == null) {
/* 1144 */         listValue = new ArrayList<>();
/* 1145 */         set(headerName, listValue);
/*      */       } 
/* 1147 */       listValue.add(headerValue);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Object parseValue(Type valueType, List<Type> context, String value) {
/* 1152 */     Type resolved = Data.resolveWildcardTypeOrTypeVariable(context, valueType);
/* 1153 */     return Data.parsePrimitiveValue(resolved, value);
/*      */   }
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpHeaders.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */