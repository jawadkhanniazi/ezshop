/*    */ package com.google.api.client.http;
/*    */ 
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import com.google.api.client.util.StreamingContent;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpEncodingStreamingContent
/*    */   implements StreamingContent
/*    */ {
/*    */   private final StreamingContent content;
/*    */   private final HttpEncoding encoding;
/*    */   
/*    */   public HttpEncodingStreamingContent(StreamingContent content, HttpEncoding encoding) {
/* 43 */     this.content = (StreamingContent)Preconditions.checkNotNull(content);
/* 44 */     this.encoding = (HttpEncoding)Preconditions.checkNotNull(encoding);
/*    */   }
/*    */   
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 48 */     this.encoding.encode(this.content, out);
/*    */   }
/*    */ 
/*    */   
/*    */   public StreamingContent getContent() {
/* 53 */     return this.content;
/*    */   }
/*    */ 
/*    */   
/*    */   public HttpEncoding getEncoding() {
/* 58 */     return this.encoding;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpEncodingStreamingContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */