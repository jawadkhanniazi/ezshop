/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StreamingContent;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipartContent
/*     */   extends AbstractHttpContent
/*     */ {
/*     */   static final String NEWLINE = "\r\n";
/*     */   private static final String TWO_DASHES = "--";
/*  50 */   private ArrayList<Part> parts = new ArrayList<>();
/*     */   
/*     */   public MultipartContent() {
/*  53 */     super((new HttpMediaType("multipart/related")).setParameter("boundary", "__END_OF_PART__"));
/*     */   }
/*     */   
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  57 */     Writer writer = new OutputStreamWriter(out, getCharset());
/*  58 */     String boundary = getBoundary();
/*  59 */     for (Part part : this.parts) {
/*  60 */       HttpHeaders headers = (new HttpHeaders()).setAcceptEncoding(null);
/*  61 */       if (part.headers != null) {
/*  62 */         headers.fromHttpHeaders(part.headers);
/*     */       }
/*  64 */       headers
/*  65 */         .setContentEncoding(null)
/*  66 */         .setUserAgent(null)
/*  67 */         .setContentType(null)
/*  68 */         .setContentLength(null)
/*  69 */         .set("Content-Transfer-Encoding", (Object)null);
/*     */       
/*  71 */       HttpContent content = part.content;
/*  72 */       StreamingContent streamingContent = null;
/*  73 */       if (content != null) {
/*  74 */         long contentLength; headers.set("Content-Transfer-Encoding", Arrays.asList(new String[] { "binary" }));
/*  75 */         headers.setContentType(content.getType());
/*  76 */         HttpEncoding encoding = part.encoding;
/*     */         
/*  78 */         if (encoding == null) {
/*  79 */           contentLength = content.getLength();
/*  80 */           streamingContent = content;
/*     */         } else {
/*  82 */           headers.setContentEncoding(encoding.getName());
/*  83 */           streamingContent = new HttpEncodingStreamingContent(content, encoding);
/*  84 */           contentLength = AbstractHttpContent.computeLength(content);
/*     */         } 
/*  86 */         if (contentLength != -1L) {
/*  87 */           headers.setContentLength(Long.valueOf(contentLength));
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*  93 */       writer.write("--");
/*  94 */       writer.write(boundary);
/*  95 */       writer.write("\r\n");
/*     */ 
/*     */       
/*  98 */       HttpHeaders.serializeHeadersForMultipartRequests(headers, null, null, writer);
/*  99 */       if (streamingContent != null) {
/* 100 */         writer.write("\r\n");
/* 101 */         writer.flush();
/*     */         
/* 103 */         streamingContent.writeTo(out);
/*     */       } 
/*     */       
/* 106 */       writer.write("\r\n");
/*     */     } 
/*     */     
/* 109 */     writer.write("--");
/* 110 */     writer.write(boundary);
/* 111 */     writer.write("--");
/* 112 */     writer.write("\r\n");
/* 113 */     writer.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retrySupported() {
/* 118 */     for (Part part : this.parts) {
/* 119 */       if (!part.content.retrySupported()) {
/* 120 */         return false;
/*     */       }
/*     */     } 
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartContent setMediaType(HttpMediaType mediaType) {
/* 128 */     super.setMediaType(mediaType);
/* 129 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Collection<Part> getParts() {
/* 134 */     return Collections.unmodifiableCollection(this.parts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartContent addPart(Part part) {
/* 144 */     this.parts.add(Preconditions.checkNotNull(part));
/* 145 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartContent setParts(Collection<Part> parts) {
/* 155 */     this.parts = new ArrayList<>(parts);
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartContent setContentParts(Collection<? extends HttpContent> contentParts) {
/* 167 */     this.parts = new ArrayList<>(contentParts.size());
/* 168 */     for (HttpContent contentPart : contentParts) {
/* 169 */       addPart(new Part(contentPart));
/*     */     }
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getBoundary() {
/* 176 */     return getMediaType().getParameter("boundary");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartContent setBoundary(String boundary) {
/* 188 */     getMediaType().setParameter("boundary", (String)Preconditions.checkNotNull(boundary));
/* 189 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Part
/*     */   {
/*     */     HttpContent content;
/*     */ 
/*     */ 
/*     */     
/*     */     HttpHeaders headers;
/*     */ 
/*     */     
/*     */     HttpEncoding encoding;
/*     */ 
/*     */ 
/*     */     
/*     */     public Part() {
/* 209 */       this(null);
/*     */     }
/*     */ 
/*     */     
/*     */     public Part(HttpContent content) {
/* 214 */       this(null, content);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Part(HttpHeaders headers, HttpContent content) {
/* 222 */       setHeaders(headers);
/* 223 */       setContent(content);
/*     */     }
/*     */ 
/*     */     
/*     */     public Part setContent(HttpContent content) {
/* 228 */       this.content = content;
/* 229 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpContent getContent() {
/* 234 */       return this.content;
/*     */     }
/*     */ 
/*     */     
/*     */     public Part setHeaders(HttpHeaders headers) {
/* 239 */       this.headers = headers;
/* 240 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 245 */       return this.headers;
/*     */     }
/*     */ 
/*     */     
/*     */     public Part setEncoding(HttpEncoding encoding) {
/* 250 */       this.encoding = encoding;
/* 251 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpEncoding getEncoding() {
/* 256 */       return this.encoding;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\MultipartContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */