/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.FieldInfo;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Types;
/*     */ import com.google.api.client.util.escape.CharEscapers;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlEncodedContent
/*     */   extends AbstractHttpContent
/*     */ {
/*     */   private Object data;
/*     */   
/*     */   public UrlEncodedContent(Object data) {
/*  55 */     super(UrlEncodedParser.MEDIA_TYPE);
/*  56 */     setData(data);
/*     */   }
/*     */   
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  60 */     Writer writer = new BufferedWriter(new OutputStreamWriter(out, getCharset()));
/*  61 */     boolean first = true;
/*  62 */     for (Map.Entry<String, Object> nameValueEntry : (Iterable<Map.Entry<String, Object>>)Data.mapOf(this.data).entrySet()) {
/*  63 */       Object value = nameValueEntry.getValue();
/*  64 */       if (value != null) {
/*  65 */         String name = CharEscapers.escapeUri(nameValueEntry.getKey());
/*  66 */         Class<? extends Object> valueClass = (Class)value.getClass();
/*  67 */         if (value instanceof Iterable || valueClass.isArray()) {
/*  68 */           for (Object repeatedValue : Types.iterableOf(value))
/*  69 */             first = appendParam(first, writer, name, repeatedValue); 
/*     */           continue;
/*     */         } 
/*  72 */         first = appendParam(first, writer, name, value);
/*     */       } 
/*     */     } 
/*     */     
/*  76 */     writer.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public UrlEncodedContent setMediaType(HttpMediaType mediaType) {
/*  81 */     super.setMediaType(mediaType);
/*  82 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getData() {
/*  91 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlEncodedContent setData(Object data) {
/* 103 */     this.data = Preconditions.checkNotNull(data);
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UrlEncodedContent getContent(HttpRequest request) {
/* 119 */     HttpContent content = request.getContent();
/* 120 */     if (content != null) {
/* 121 */       return (UrlEncodedContent)content;
/*     */     }
/* 123 */     UrlEncodedContent result = new UrlEncodedContent(new HashMap<>());
/* 124 */     request.setContent(result);
/* 125 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean appendParam(boolean first, Writer writer, String name, Object value) throws IOException {
/* 131 */     if (value == null || Data.isNull(value)) {
/* 132 */       return first;
/*     */     }
/*     */     
/* 135 */     if (first) {
/* 136 */       first = false;
/*     */     } else {
/* 138 */       writer.write("&");
/*     */     } 
/* 140 */     writer.write(name);
/*     */     
/* 142 */     String stringValue = CharEscapers.escapeUri((value instanceof Enum) ? 
/* 143 */         FieldInfo.of((Enum)value).getName() : value.toString());
/* 144 */     if (stringValue.length() != 0) {
/* 145 */       writer.write("=");
/* 146 */       writer.write(stringValue);
/*     */     } 
/* 148 */     return first;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\UrlEncodedContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */