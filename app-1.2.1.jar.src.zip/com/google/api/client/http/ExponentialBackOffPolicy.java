/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.ExponentialBackOff;
/*     */ import com.google.api.client.util.NanoClock;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ @Beta
/*     */ public class ExponentialBackOffPolicy
/*     */   implements BackOffPolicy
/*     */ {
/*     */   public static final int DEFAULT_INITIAL_INTERVAL_MILLIS = 500;
/*     */   public static final double DEFAULT_RANDOMIZATION_FACTOR = 0.5D;
/*     */   public static final double DEFAULT_MULTIPLIER = 1.5D;
/*     */   public static final int DEFAULT_MAX_INTERVAL_MILLIS = 60000;
/*     */   public static final int DEFAULT_MAX_ELAPSED_TIME_MILLIS = 900000;
/*     */   private final ExponentialBackOff exponentialBackOff;
/*     */   
/*     */   public ExponentialBackOffPolicy() {
/* 113 */     this(new Builder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ExponentialBackOffPolicy(Builder builder) {
/* 121 */     this.exponentialBackOff = builder.exponentialBackOffBuilder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBackOffRequired(int statusCode) {
/* 134 */     switch (statusCode) {
/*     */       case 500:
/*     */       case 503:
/* 137 */         return true;
/*     */     } 
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void reset() {
/* 145 */     this.exponentialBackOff.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getNextBackOffMillis() throws IOException {
/* 161 */     return this.exponentialBackOff.nextBackOffMillis();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getInitialIntervalMillis() {
/* 166 */     return this.exponentialBackOff.getInitialIntervalMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getRandomizationFactor() {
/* 176 */     return this.exponentialBackOff.getRandomizationFactor();
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getCurrentIntervalMillis() {
/* 181 */     return this.exponentialBackOff.getCurrentIntervalMillis();
/*     */   }
/*     */ 
/*     */   
/*     */   public final double getMultiplier() {
/* 186 */     return this.exponentialBackOff.getMultiplier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxIntervalMillis() {
/* 194 */     return this.exponentialBackOff.getMaxIntervalMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxElapsedTimeMillis() {
/* 205 */     return this.exponentialBackOff.getMaxElapsedTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getElapsedTimeMillis() {
/* 215 */     return this.exponentialBackOff.getElapsedTimeMillis();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 220 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @Beta
/*     */   public static class Builder
/*     */   {
/* 236 */     final ExponentialBackOff.Builder exponentialBackOffBuilder = new ExponentialBackOff.Builder();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExponentialBackOffPolicy build() {
/* 242 */       return new ExponentialBackOffPolicy(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getInitialIntervalMillis() {
/* 250 */       return this.exponentialBackOffBuilder.getInitialIntervalMillis();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setInitialIntervalMillis(int initialIntervalMillis) {
/* 261 */       this.exponentialBackOffBuilder.setInitialIntervalMillis(initialIntervalMillis);
/* 262 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final double getRandomizationFactor() {
/* 276 */       return this.exponentialBackOffBuilder.getRandomizationFactor();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRandomizationFactor(double randomizationFactor) {
/* 291 */       this.exponentialBackOffBuilder.setRandomizationFactor(randomizationFactor);
/* 292 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final double getMultiplier() {
/* 300 */       return this.exponentialBackOffBuilder.getMultiplier();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMultiplier(double multiplier) {
/* 311 */       this.exponentialBackOffBuilder.setMultiplier(multiplier);
/* 312 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getMaxIntervalMillis() {
/* 321 */       return this.exponentialBackOffBuilder.getMaxIntervalMillis();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMaxIntervalMillis(int maxIntervalMillis) {
/* 333 */       this.exponentialBackOffBuilder.setMaxIntervalMillis(maxIntervalMillis);
/* 334 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getMaxElapsedTimeMillis() {
/* 346 */       return this.exponentialBackOffBuilder.getMaxElapsedTimeMillis();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMaxElapsedTimeMillis(int maxElapsedTimeMillis) {
/* 361 */       this.exponentialBackOffBuilder.setMaxElapsedTimeMillis(maxElapsedTimeMillis);
/* 362 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final NanoClock getNanoClock() {
/* 371 */       return this.exponentialBackOffBuilder.getNanoClock();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setNanoClock(NanoClock nanoClock) {
/* 383 */       this.exponentialBackOffBuilder.setNanoClock(nanoClock);
/* 384 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\ExponentialBackOffPolicy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */