/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Charsets;
/*     */ import com.google.api.client.util.IOUtils;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractHttpContent
/*     */   implements HttpContent
/*     */ {
/*     */   private HttpMediaType mediaType;
/*  37 */   private long computedLength = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractHttpContent(String mediaType) {
/*  45 */     this((mediaType == null) ? null : new HttpMediaType(mediaType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractHttpContent(HttpMediaType mediaType) {
/*  53 */     this.mediaType = mediaType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLength() throws IOException {
/*  61 */     if (this.computedLength == -1L) {
/*  62 */       this.computedLength = computeLength();
/*     */     }
/*  64 */     return this.computedLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final HttpMediaType getMediaType() {
/*  73 */     return this.mediaType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractHttpContent setMediaType(HttpMediaType mediaType) {
/*  85 */     this.mediaType = mediaType;
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Charset getCharset() {
/*  95 */     return (this.mediaType == null || this.mediaType.getCharsetParameter() == null) ? Charsets.ISO_8859_1 : this.mediaType
/*     */       
/*  97 */       .getCharsetParameter();
/*     */   }
/*     */   
/*     */   public String getType() {
/* 101 */     return (this.mediaType == null) ? null : this.mediaType.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long computeLength() throws IOException {
/* 111 */     return computeLength(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retrySupported() {
/* 116 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long computeLength(HttpContent content) throws IOException {
/* 129 */     if (!content.retrySupported()) {
/* 130 */       return -1L;
/*     */     }
/* 132 */     return IOUtils.computeLength(content);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\AbstractHttpContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */