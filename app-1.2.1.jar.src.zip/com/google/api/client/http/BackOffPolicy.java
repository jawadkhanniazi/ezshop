package com.google.api.client.http;

import com.google.api.client.util.Beta;
import java.io.IOException;

@Deprecated
@Beta
public interface BackOffPolicy {
  public static final long STOP = -1L;
  
  boolean isBackOffRequired(int paramInt);
  
  void reset();
  
  long getNextBackOffMillis() throws IOException;
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\BackOffPolicy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */