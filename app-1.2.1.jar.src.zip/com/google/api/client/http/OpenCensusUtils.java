/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.common.annotations.VisibleForTesting;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import io.opencensus.contrib.http.util.HttpPropagationUtil;
/*     */ import io.opencensus.trace.BlankSpan;
/*     */ import io.opencensus.trace.EndSpanOptions;
/*     */ import io.opencensus.trace.MessageEvent;
/*     */ import io.opencensus.trace.Span;
/*     */ import io.opencensus.trace.Status;
/*     */ import io.opencensus.trace.Tracer;
/*     */ import io.opencensus.trace.Tracing;
/*     */ import io.opencensus.trace.propagation.TextFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class OpenCensusUtils
/*     */ {
/*  46 */   private static final Logger logger = Logger.getLogger(OpenCensusUtils.class.getName());
/*     */ 
/*     */   
/*  49 */   public static final String SPAN_NAME_HTTP_REQUEST_EXECUTE = "Sent." + HttpRequest.class
/*  50 */     .getName() + ".execute";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static final Tracer tracer = Tracing.getTracer();
/*     */ 
/*     */   
/*  59 */   private static final AtomicLong idGenerator = new AtomicLong();
/*     */   
/*     */   private static volatile boolean isRecordEvent = true;
/*     */   
/*     */   @Nullable
/*     */   @VisibleForTesting
/*  65 */   static volatile TextFormat propagationTextFormat = null;
/*     */   @Nullable
/*     */   @VisibleForTesting
/*  68 */   static volatile TextFormat.Setter propagationTextFormatSetter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPropagationTextFormat(@Nullable TextFormat textFormat) {
/*  80 */     propagationTextFormat = textFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setPropagationTextFormatSetter(@Nullable TextFormat.Setter textFormatSetter) {
/*  93 */     propagationTextFormatSetter = textFormatSetter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setIsRecordEvent(boolean recordEvent) {
/* 104 */     isRecordEvent = recordEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Tracer getTracer() {
/* 113 */     return tracer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRecordEvent() {
/* 122 */     return isRecordEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void propagateTracingContext(Span span, HttpHeaders headers) {
/* 133 */     Preconditions.checkArgument((span != null), "span should not be null.");
/* 134 */     Preconditions.checkArgument((headers != null), "headers should not be null.");
/* 135 */     if (propagationTextFormat != null && propagationTextFormatSetter != null && 
/* 136 */       !span.equals(BlankSpan.INSTANCE)) {
/* 137 */       propagationTextFormat.inject(span.getContext(), headers, propagationTextFormatSetter);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EndSpanOptions getEndSpanOptions(@Nullable Integer statusCode) {
/* 150 */     EndSpanOptions.Builder builder = EndSpanOptions.builder();
/* 151 */     if (statusCode == null)
/* 152 */     { builder.setStatus(Status.UNKNOWN); }
/* 153 */     else if (!HttpStatusCodes.isSuccess(statusCode.intValue()))
/* 154 */     { switch (statusCode.intValue())
/*     */       { case 400:
/* 156 */           builder.setStatus(Status.INVALID_ARGUMENT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 179 */           return builder.build();case 401: builder.setStatus(Status.UNAUTHENTICATED); return builder.build();case 403: builder.setStatus(Status.PERMISSION_DENIED); return builder.build();case 404: builder.setStatus(Status.NOT_FOUND); return builder.build();case 412: builder.setStatus(Status.FAILED_PRECONDITION); return builder.build();case 500: builder.setStatus(Status.UNAVAILABLE); return builder.build(); }  builder.setStatus(Status.UNKNOWN); } else { builder.setStatus(Status.OK); }  return builder.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void recordSentMessageEvent(Span span, long size) {
/* 190 */     recordMessageEvent(span, size, MessageEvent.Type.SENT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void recordReceivedMessageEvent(Span span, long size) {
/* 201 */     recordMessageEvent(span, size, MessageEvent.Type.RECEIVED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @VisibleForTesting
/*     */   static void recordMessageEvent(Span span, long size, MessageEvent.Type eventType) {
/* 214 */     Preconditions.checkArgument((span != null), "span should not be null.");
/* 215 */     if (size < 0L) {
/* 216 */       size = 0L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 221 */     MessageEvent event = MessageEvent.builder(eventType, idGenerator.getAndIncrement()).setUncompressedMessageSize(size).build();
/* 222 */     span.addMessageEvent(event);
/*     */   }
/*     */   
/*     */   static {
/*     */     try {
/* 227 */       propagationTextFormat = HttpPropagationUtil.getCloudTraceFormat();
/* 228 */       propagationTextFormatSetter = new TextFormat.Setter<HttpHeaders>()
/*     */         {
/*     */           public void put(HttpHeaders carrier, String key, String value)
/*     */           {
/* 232 */             carrier.set(key, value);
/*     */           }
/*     */         };
/* 235 */     } catch (Exception e) {
/* 236 */       logger.log(Level.WARNING, "Cannot initialize default OpenCensus HTTP propagation text format.", e);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 241 */       Tracing.getExportComponent()
/* 242 */         .getSampledSpanStore()
/* 243 */         .registerSpanNamesForCollection((Collection)ImmutableList.of(SPAN_NAME_HTTP_REQUEST_EXECUTE));
/* 244 */     } catch (Exception e) {
/* 245 */       logger.log(Level.WARNING, "Cannot register default OpenCensus span names for collection.", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\OpenCensusUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */