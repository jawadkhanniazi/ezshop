/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.BackOff;
/*     */ import com.google.api.client.util.BackOffUtils;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Sleeper;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class HttpBackOffIOExceptionHandler
/*     */   implements HttpIOExceptionHandler
/*     */ {
/*     */   private final BackOff backOff;
/*  53 */   private Sleeper sleeper = Sleeper.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpBackOffIOExceptionHandler(BackOff backOff) {
/*  61 */     this.backOff = (BackOff)Preconditions.checkNotNull(backOff);
/*     */   }
/*     */ 
/*     */   
/*     */   public final BackOff getBackOff() {
/*  66 */     return this.backOff;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Sleeper getSleeper() {
/*  71 */     return this.sleeper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpBackOffIOExceptionHandler setSleeper(Sleeper sleeper) {
/*  83 */     this.sleeper = (Sleeper)Preconditions.checkNotNull(sleeper);
/*  84 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleIOException(HttpRequest request, boolean supportsRetry) throws IOException {
/*  94 */     if (!supportsRetry) {
/*  95 */       return false;
/*     */     }
/*     */     try {
/*  98 */       return BackOffUtils.next(this.sleeper, this.backOff);
/*  99 */     } catch (InterruptedException exception) {
/* 100 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpBackOffIOExceptionHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */