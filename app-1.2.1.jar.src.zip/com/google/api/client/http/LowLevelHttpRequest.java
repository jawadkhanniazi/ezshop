/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.StreamingContent;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LowLevelHttpRequest
/*     */ {
/*  35 */   private long contentLength = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String contentEncoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String contentType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StreamingContent streamingContent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void addHeader(String paramString1, String paramString2) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setContentLength(long contentLength) throws IOException {
/*  66 */     this.contentLength = contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getContentLength() {
/*  75 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setContentEncoding(String contentEncoding) throws IOException {
/*  85 */     this.contentEncoding = contentEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getContentEncoding() {
/*  94 */     return this.contentEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setContentType(String contentType) throws IOException {
/* 104 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getContentType() {
/* 113 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setStreamingContent(StreamingContent streamingContent) throws IOException {
/* 123 */     this.streamingContent = streamingContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final StreamingContent getStreamingContent() {
/* 132 */     return this.streamingContent;
/*     */   }
/*     */   
/*     */   public void setTimeout(int connectTimeout, int readTimeout) throws IOException {}
/*     */   
/*     */   public void setWriteTimeout(int writeTimeout) throws IOException {}
/*     */   
/*     */   public abstract LowLevelHttpResponse execute() throws IOException;
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\LowLevelHttpRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */