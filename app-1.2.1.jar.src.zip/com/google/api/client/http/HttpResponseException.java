/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpResponseException
/*     */   extends IOException
/*     */ {
/*     */   private static final long serialVersionUID = -1875819453475890043L;
/*     */   private final int statusCode;
/*     */   private final String statusMessage;
/*     */   private final transient HttpHeaders headers;
/*     */   private final String content;
/*     */   
/*     */   public HttpResponseException(HttpResponse response) {
/*  63 */     this(new Builder(response));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpResponseException(Builder builder) {
/*  71 */     super(builder.message);
/*  72 */     this.statusCode = builder.statusCode;
/*  73 */     this.statusMessage = builder.statusMessage;
/*  74 */     this.headers = builder.headers;
/*  75 */     this.content = builder.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSuccessStatusCode() {
/*  85 */     return HttpStatusCodes.isSuccess(this.statusCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getStatusCode() {
/*  94 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getStatusMessage() {
/* 103 */     return this.statusMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 112 */     return this.headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getContent() {
/* 121 */     return this.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     int statusCode;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String statusMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpHeaders headers;
/*     */ 
/*     */ 
/*     */     
/*     */     String content;
/*     */ 
/*     */ 
/*     */     
/*     */     String message;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(int statusCode, String statusMessage, HttpHeaders headers) {
/* 154 */       setStatusCode(statusCode);
/* 155 */       setStatusMessage(statusMessage);
/* 156 */       setHeaders(headers);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder(HttpResponse response) {
/* 161 */       this(response.getStatusCode(), response.getStatusMessage(), response.getHeaders());
/*     */       
/*     */       try {
/* 164 */         this.content = response.parseAsString();
/* 165 */         if (this.content.length() == 0) {
/* 166 */           this.content = null;
/*     */         }
/* 168 */       } catch (IOException exception) {
/*     */         
/* 170 */         exception.printStackTrace();
/* 171 */       } catch (IllegalArgumentException exception) {
/* 172 */         exception.printStackTrace();
/*     */       } 
/*     */       
/* 175 */       StringBuilder builder = HttpResponseException.computeMessageBuffer(response);
/* 176 */       if (this.content != null) {
/* 177 */         builder.append(StringUtils.LINE_SEPARATOR).append(this.content);
/*     */       }
/* 179 */       this.message = builder.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public final String getMessage() {
/* 184 */       return this.message;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMessage(String message) {
/* 194 */       this.message = message;
/* 195 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final int getStatusCode() {
/* 200 */       return this.statusCode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setStatusCode(int statusCode) {
/* 210 */       Preconditions.checkArgument((statusCode >= 0));
/* 211 */       this.statusCode = statusCode;
/* 212 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final String getStatusMessage() {
/* 217 */       return this.statusMessage;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setStatusMessage(String statusMessage) {
/* 227 */       this.statusMessage = statusMessage;
/* 228 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpHeaders getHeaders() {
/* 233 */       return this.headers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setHeaders(HttpHeaders headers) {
/* 243 */       this.headers = (HttpHeaders)Preconditions.checkNotNull(headers);
/* 244 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final String getContent() {
/* 249 */       return this.content;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setContent(String content) {
/* 259 */       this.content = content;
/* 260 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpResponseException build() {
/* 265 */       return new HttpResponseException(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder computeMessageBuffer(HttpResponse response) {
/* 275 */     StringBuilder builder = new StringBuilder();
/* 276 */     int statusCode = response.getStatusCode();
/* 277 */     if (statusCode != 0) {
/* 278 */       builder.append(statusCode);
/*     */     }
/* 280 */     String statusMessage = response.getStatusMessage();
/* 281 */     if (statusMessage != null) {
/* 282 */       if (statusCode != 0) {
/* 283 */         builder.append(' ');
/*     */       }
/* 285 */       builder.append(statusMessage);
/*     */     } 
/* 287 */     return builder;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpResponseException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */