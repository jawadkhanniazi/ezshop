/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.IOUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractInputStreamContent
/*     */   implements HttpContent
/*     */ {
/*     */   private String type;
/*     */   private boolean closeInputStream = true;
/*     */   
/*     */   public AbstractInputStreamContent(String type) {
/*  55 */     setType(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract InputStream getInputStream() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  69 */     IOUtils.copy(getInputStream(), out, this.closeInputStream);
/*  70 */     out.flush();
/*     */   }
/*     */   
/*     */   public String getType() {
/*  74 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getCloseInputStream() {
/*  84 */     return this.closeInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractInputStreamContent setType(String type) {
/*  93 */     this.type = type;
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractInputStreamContent setCloseInputStream(boolean closeInputStream) {
/* 104 */     this.closeInputStream = closeInputStream;
/* 105 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\AbstractInputStreamContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */