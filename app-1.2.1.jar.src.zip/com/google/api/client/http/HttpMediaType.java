/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpMediaType
/*     */ {
/*  52 */   private String type = "application";
/*     */ 
/*     */   
/*  55 */   private String subType = "octet-stream";
/*     */ 
/*     */   
/*  58 */   private final SortedMap<String, String> parameters = new TreeMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private static final Pattern TYPE_REGEX = Pattern.compile("[\\w!#$&.+\\-\\^_]+|[*]");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private static final Pattern TOKEN_REGEX = Pattern.compile("[\\p{ASCII}&&[^\\p{Cntrl} ;/=\\[\\]\\(\\)\\<\\>\\@\\,\\:\\\"\\?\\=]]+");
/*     */   
/*     */   private static final Pattern FULL_MEDIA_TYPE_REGEX;
/*     */   
/*     */   static {
/*  77 */     String typeOrKey = "[^\\s/=;\"]+";
/*  78 */     String wholeParameterSection = ";.*";
/*     */     
/*  80 */     FULL_MEDIA_TYPE_REGEX = Pattern.compile("\\s*(" + typeOrKey + ")/(" + typeOrKey + ")\\s*(" + wholeParameterSection + ")?", 32);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     String quotedParameterValue = "\"([^\"]*)\"";
/*  96 */     String unquotedParameterValue = "[^\\s;\"]*";
/*  97 */     String parameterValue = quotedParameterValue + "|" + unquotedParameterValue;
/*     */     
/*  99 */     PARAMETER_REGEX = Pattern.compile("\\s*;\\s*(" + typeOrKey + ")=(" + parameterValue + ")");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Pattern PARAMETER_REGEX;
/*     */ 
/*     */ 
/*     */   
/*     */   private String cachedBuildResult;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType(String type, String subType) {
/* 116 */     setType(type);
/* 117 */     setSubType(subType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType(String mediaType) {
/* 126 */     fromString(mediaType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType setType(String type) {
/* 135 */     Preconditions.checkArgument(TYPE_REGEX
/* 136 */         .matcher(type).matches(), "Type contains reserved characters");
/* 137 */     this.type = type;
/* 138 */     this.cachedBuildResult = null;
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/* 144 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType setSubType(String subType) {
/* 153 */     Preconditions.checkArgument(TYPE_REGEX
/* 154 */         .matcher(subType).matches(), "Subtype contains reserved characters");
/* 155 */     this.subType = subType;
/* 156 */     this.cachedBuildResult = null;
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSubType() {
/* 162 */     return this.subType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpMediaType fromString(String combinedType) {
/* 175 */     Matcher matcher = FULL_MEDIA_TYPE_REGEX.matcher(combinedType);
/* 176 */     Preconditions.checkArgument(matcher
/* 177 */         .matches(), "Type must be in the 'maintype/subtype; parameter=value' format");
/*     */     
/* 179 */     setType(matcher.group(1));
/* 180 */     setSubType(matcher.group(2));
/* 181 */     String params = matcher.group(3);
/* 182 */     if (params != null) {
/* 183 */       matcher = PARAMETER_REGEX.matcher(params);
/* 184 */       while (matcher.find()) {
/*     */         
/* 186 */         String key = matcher.group(1);
/* 187 */         String value = matcher.group(3);
/* 188 */         if (value == null) {
/* 189 */           value = matcher.group(2);
/*     */         }
/* 191 */         setParameter(key, value);
/*     */       } 
/*     */     } 
/* 194 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType setParameter(String name, String value) {
/* 204 */     if (value == null) {
/* 205 */       removeParameter(name);
/* 206 */       return this;
/*     */     } 
/*     */     
/* 209 */     Preconditions.checkArgument(TOKEN_REGEX
/* 210 */         .matcher(name).matches(), "Name contains reserved characters");
/* 211 */     this.cachedBuildResult = null;
/* 212 */     this.parameters.put(name.toLowerCase(Locale.US), value);
/* 213 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getParameter(String name) {
/* 222 */     return this.parameters.get(name.toLowerCase(Locale.US));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType removeParameter(String name) {
/* 231 */     this.cachedBuildResult = null;
/* 232 */     this.parameters.remove(name.toLowerCase(Locale.US));
/* 233 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearParameters() {
/* 238 */     this.cachedBuildResult = null;
/* 239 */     this.parameters.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getParameters() {
/* 247 */     return Collections.unmodifiableMap(this.parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean matchesToken(String value) {
/* 255 */     return TOKEN_REGEX.matcher(value).matches();
/*     */   }
/*     */   
/*     */   private static String quoteString(String unquotedString) {
/* 259 */     String escapedString = unquotedString.replace("\\", "\\\\");
/* 260 */     escapedString = escapedString.replace("\"", "\\\"");
/* 261 */     return "\"" + escapedString + "\"";
/*     */   }
/*     */ 
/*     */   
/*     */   public String build() {
/* 266 */     if (this.cachedBuildResult != null) {
/* 267 */       return this.cachedBuildResult;
/*     */     }
/*     */     
/* 270 */     StringBuilder str = new StringBuilder();
/* 271 */     str.append(this.type);
/* 272 */     str.append('/');
/* 273 */     str.append(this.subType);
/* 274 */     if (this.parameters != null) {
/* 275 */       for (Map.Entry<String, String> entry : this.parameters.entrySet()) {
/* 276 */         String value = entry.getValue();
/* 277 */         str.append("; ");
/* 278 */         str.append(entry.getKey());
/* 279 */         str.append("=");
/* 280 */         str.append(!matchesToken(value) ? quoteString(value) : value);
/*     */       } 
/*     */     }
/* 283 */     this.cachedBuildResult = str.toString();
/* 284 */     return this.cachedBuildResult;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 289 */     return build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsIgnoreParameters(HttpMediaType mediaType) {
/* 297 */     return (mediaType != null && 
/* 298 */       getType().equalsIgnoreCase(mediaType.getType()) && 
/* 299 */       getSubType().equalsIgnoreCase(mediaType.getSubType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equalsIgnoreParameters(String mediaTypeA, String mediaTypeB) {
/* 308 */     return ((mediaTypeA == null && mediaTypeB == null) || (mediaTypeA != null && mediaTypeB != null && (new HttpMediaType(mediaTypeA))
/*     */ 
/*     */       
/* 311 */       .equalsIgnoreParameters(new HttpMediaType(mediaTypeB))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType setCharsetParameter(Charset charset) {
/* 320 */     setParameter("charset", (charset == null) ? null : charset.name());
/* 321 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Charset getCharsetParameter() {
/* 326 */     String value = getParameter("charset");
/* 327 */     return (value == null) ? null : Charset.forName(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 332 */     return build().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 337 */     if (!(obj instanceof HttpMediaType)) {
/* 338 */       return false;
/*     */     }
/*     */     
/* 341 */     HttpMediaType otherType = (HttpMediaType)obj;
/*     */     
/* 343 */     return (equalsIgnoreParameters(otherType) && this.parameters.equals(otherType.parameters));
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpMediaType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */