/*    */ package com.google.api.client.http.apache;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.Socket;
/*    */ import java.net.UnknownHostException;
/*    */ import java.security.KeyManagementException;
/*    */ import java.security.KeyStore;
/*    */ import java.security.KeyStoreException;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.security.UnrecoverableKeyException;
/*    */ import javax.net.ssl.SSLContext;
/*    */ import javax.net.ssl.SSLSocket;
/*    */ import javax.net.ssl.SSLSocketFactory;
/*    */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SSLSocketFactoryExtension
/*    */   extends SSLSocketFactory
/*    */ {
/*    */   private final SSLSocketFactory socketFactory;
/*    */   
/*    */   SSLSocketFactoryExtension(SSLContext sslContext) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, KeyStoreException {
/* 44 */     super((KeyStore)null);
/* 45 */     this.socketFactory = sslContext.getSocketFactory();
/*    */   }
/*    */ 
/*    */   
/*    */   public Socket createSocket() throws IOException {
/* 50 */     return this.socketFactory.createSocket();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException, UnknownHostException {
/* 56 */     SSLSocket sslSocket = (SSLSocket)this.socketFactory.createSocket(socket, host, port, autoClose);
/* 57 */     getHostnameVerifier().verify(host, sslSocket);
/* 58 */     return sslSocket;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\apache\SSLSocketFactoryExtension.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */