/*     */ package com.google.api.client.http.apache;
/*     */ 
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.apache.http.Header;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpResponse;
/*     */ import org.apache.http.StatusLine;
/*     */ import org.apache.http.client.methods.HttpRequestBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ApacheHttpResponse
/*     */   extends LowLevelHttpResponse
/*     */ {
/*     */   private final HttpRequestBase request;
/*     */   private final HttpResponse response;
/*     */   private final Header[] allHeaders;
/*     */   
/*     */   ApacheHttpResponse(HttpRequestBase request, HttpResponse response) {
/*  33 */     this.request = request;
/*  34 */     this.response = response;
/*  35 */     this.allHeaders = response.getAllHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatusCode() {
/*  40 */     StatusLine statusLine = this.response.getStatusLine();
/*  41 */     return (statusLine == null) ? 0 : statusLine.getStatusCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContent() throws IOException {
/*  46 */     HttpEntity entity = this.response.getEntity();
/*  47 */     return (entity == null) ? null : entity.getContent();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/*  52 */     HttpEntity entity = this.response.getEntity();
/*  53 */     if (entity != null) {
/*  54 */       Header contentEncodingHeader = entity.getContentEncoding();
/*  55 */       if (contentEncodingHeader != null) {
/*  56 */         return contentEncodingHeader.getValue();
/*     */       }
/*     */     } 
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/*  64 */     HttpEntity entity = this.response.getEntity();
/*  65 */     return (entity == null) ? -1L : entity.getContentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  70 */     HttpEntity entity = this.response.getEntity();
/*  71 */     if (entity != null) {
/*  72 */       Header contentTypeHeader = entity.getContentType();
/*  73 */       if (contentTypeHeader != null) {
/*  74 */         return contentTypeHeader.getValue();
/*     */       }
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getReasonPhrase() {
/*  82 */     StatusLine statusLine = this.response.getStatusLine();
/*  83 */     return (statusLine == null) ? null : statusLine.getReasonPhrase();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatusLine() {
/*  88 */     StatusLine statusLine = this.response.getStatusLine();
/*  89 */     return (statusLine == null) ? null : statusLine.toString();
/*     */   }
/*     */   
/*     */   public String getHeaderValue(String name) {
/*  93 */     return this.response.getLastHeader(name).getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeaderCount() {
/*  98 */     return this.allHeaders.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderName(int index) {
/* 103 */     return this.allHeaders[index].getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderValue(int index) {
/* 108 */     return this.allHeaders[index].getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 118 */     this.request.abort();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\apache\ApacheHttpResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */