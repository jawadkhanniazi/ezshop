/*    */ package com.google.api.client.http.apache;
/*    */ 
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import com.google.api.client.util.StreamingContent;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import org.apache.http.entity.AbstractHttpEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ContentEntity
/*    */   extends AbstractHttpEntity
/*    */ {
/*    */   private final long contentLength;
/*    */   private final StreamingContent streamingContent;
/*    */   
/*    */   ContentEntity(long contentLength, StreamingContent streamingContent) {
/* 38 */     this.contentLength = contentLength;
/* 39 */     this.streamingContent = (StreamingContent)Preconditions.checkNotNull(streamingContent);
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getContent() {
/* 44 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   
/*    */   public long getContentLength() {
/* 49 */     return this.contentLength;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRepeatable() {
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isStreaming() {
/* 59 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 64 */     if (this.contentLength != 0L)
/* 65 */       this.streamingContent.writeTo(out); 
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\apache\ContentEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */