/*    */ package com.google.api.client.http.apache;
/*    */ 
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.net.URI;
/*    */ import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HttpExtensionMethod
/*    */   extends HttpEntityEnclosingRequestBase
/*    */ {
/*    */   private final String methodName;
/*    */   
/*    */   public HttpExtensionMethod(String methodName, String uri) {
/* 34 */     this.methodName = (String)Preconditions.checkNotNull(methodName);
/* 35 */     setURI(URI.create(uri));
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMethod() {
/* 40 */     return this.methodName;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\apache\HttpExtensionMethod.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */