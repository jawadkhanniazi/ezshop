/*     */ package com.google.api.client.http.apache;
/*     */ 
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.SecurityUtils;
/*     */ import com.google.api.client.util.SslUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.ProxySelector;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import org.apache.http.HttpHost;
/*     */ import org.apache.http.HttpVersion;
/*     */ import org.apache.http.ProtocolVersion;
/*     */ import org.apache.http.client.HttpClient;
/*     */ import org.apache.http.client.HttpRequestRetryHandler;
/*     */ import org.apache.http.client.methods.HttpDelete;
/*     */ import org.apache.http.client.methods.HttpGet;
/*     */ import org.apache.http.client.methods.HttpHead;
/*     */ import org.apache.http.client.methods.HttpOptions;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpPut;
/*     */ import org.apache.http.client.methods.HttpRequestBase;
/*     */ import org.apache.http.client.methods.HttpTrace;
/*     */ import org.apache.http.conn.ClientConnectionManager;
/*     */ import org.apache.http.conn.params.ConnManagerParams;
/*     */ import org.apache.http.conn.params.ConnPerRoute;
/*     */ import org.apache.http.conn.params.ConnPerRouteBean;
/*     */ import org.apache.http.conn.params.ConnRouteParams;
/*     */ import org.apache.http.conn.routing.HttpRoutePlanner;
/*     */ import org.apache.http.conn.scheme.PlainSocketFactory;
/*     */ import org.apache.http.conn.scheme.Scheme;
/*     */ import org.apache.http.conn.scheme.SchemeRegistry;
/*     */ import org.apache.http.conn.scheme.SocketFactory;
/*     */ import org.apache.http.conn.ssl.SSLSocketFactory;
/*     */ import org.apache.http.impl.client.DefaultHttpClient;
/*     */ import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
/*     */ import org.apache.http.impl.conn.ProxySelectorRoutePlanner;
/*     */ import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
/*     */ import org.apache.http.params.BasicHttpParams;
/*     */ import org.apache.http.params.HttpConnectionParams;
/*     */ import org.apache.http.params.HttpParams;
/*     */ import org.apache.http.params.HttpProtocolParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class ApacheHttpTransport
/*     */   extends HttpTransport
/*     */ {
/*     */   private final HttpClient httpClient;
/*     */   
/*     */   public ApacheHttpTransport() {
/*  94 */     this((HttpClient)newDefaultHttpClient());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ApacheHttpTransport(HttpClient httpClient) {
/* 119 */     this.httpClient = httpClient;
/* 120 */     HttpParams params = httpClient.getParams();
/* 121 */     if (params == null) {
/* 122 */       params = newDefaultHttpClient().getParams();
/*     */     }
/* 124 */     HttpProtocolParams.setVersion(params, (ProtocolVersion)HttpVersion.HTTP_1_1);
/* 125 */     params.setBooleanParameter("http.protocol.handle-redirects", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DefaultHttpClient newDefaultHttpClient() {
/* 150 */     return newDefaultHttpClient(
/* 151 */         SSLSocketFactory.getSocketFactory(), newDefaultHttpParams(), ProxySelector.getDefault());
/*     */   }
/*     */ 
/*     */   
/*     */   static HttpParams newDefaultHttpParams() {
/* 156 */     BasicHttpParams basicHttpParams = new BasicHttpParams();
/*     */ 
/*     */     
/* 159 */     HttpConnectionParams.setStaleCheckingEnabled((HttpParams)basicHttpParams, false);
/* 160 */     HttpConnectionParams.setSocketBufferSize((HttpParams)basicHttpParams, 8192);
/* 161 */     ConnManagerParams.setMaxTotalConnections((HttpParams)basicHttpParams, 200);
/* 162 */     ConnManagerParams.setMaxConnectionsPerRoute((HttpParams)basicHttpParams, (ConnPerRoute)new ConnPerRouteBean(20));
/* 163 */     return (HttpParams)basicHttpParams;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static DefaultHttpClient newDefaultHttpClient(SSLSocketFactory socketFactory, HttpParams params, ProxySelector proxySelector) {
/* 179 */     SchemeRegistry registry = new SchemeRegistry();
/* 180 */     registry.register(new Scheme("http", (SocketFactory)PlainSocketFactory.getSocketFactory(), 80));
/* 181 */     registry.register(new Scheme("https", (SocketFactory)socketFactory, 443));
/* 182 */     ThreadSafeClientConnManager threadSafeClientConnManager = new ThreadSafeClientConnManager(params, registry);
/* 183 */     DefaultHttpClient defaultHttpClient = new DefaultHttpClient((ClientConnectionManager)threadSafeClientConnManager, params);
/* 184 */     defaultHttpClient.setHttpRequestRetryHandler((HttpRequestRetryHandler)new DefaultHttpRequestRetryHandler(0, false));
/* 185 */     if (proxySelector != null) {
/* 186 */       defaultHttpClient.setRoutePlanner((HttpRoutePlanner)new ProxySelectorRoutePlanner(registry, proxySelector));
/*     */     }
/* 188 */     return defaultHttpClient;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsMethod(String method) {
/* 193 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ApacheHttpRequest buildRequest(String method, String url) {
/*     */     HttpExtensionMethod httpExtensionMethod;
/* 199 */     if (method.equals("DELETE")) {
/* 200 */       HttpDelete httpDelete = new HttpDelete(url);
/* 201 */     } else if (method.equals("GET")) {
/* 202 */       HttpGet httpGet = new HttpGet(url);
/* 203 */     } else if (method.equals("HEAD")) {
/* 204 */       HttpHead httpHead = new HttpHead(url);
/* 205 */     } else if (method.equals("POST")) {
/* 206 */       HttpPost httpPost = new HttpPost(url);
/* 207 */     } else if (method.equals("PUT")) {
/* 208 */       HttpPut httpPut = new HttpPut(url);
/* 209 */     } else if (method.equals("TRACE")) {
/* 210 */       HttpTrace httpTrace = new HttpTrace(url);
/* 211 */     } else if (method.equals("OPTIONS")) {
/* 212 */       HttpOptions httpOptions = new HttpOptions(url);
/*     */     } else {
/* 214 */       httpExtensionMethod = new HttpExtensionMethod(method, url);
/*     */     } 
/* 216 */     return new ApacheHttpRequest(this.httpClient, (HttpRequestBase)httpExtensionMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 227 */     this.httpClient.getConnectionManager().shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpClient getHttpClient() {
/* 236 */     return this.httpClient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/* 249 */     private SSLSocketFactory socketFactory = SSLSocketFactory.getSocketFactory();
/*     */ 
/*     */     
/* 252 */     private HttpParams params = ApacheHttpTransport.newDefaultHttpParams();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 258 */     private ProxySelector proxySelector = ProxySelector.getDefault();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setProxy(HttpHost proxy) {
/* 275 */       ConnRouteParams.setDefaultProxy(this.params, proxy);
/* 276 */       if (proxy != null) {
/* 277 */         this.proxySelector = null;
/*     */       }
/* 279 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setProxySelector(ProxySelector proxySelector) {
/* 291 */       this.proxySelector = proxySelector;
/* 292 */       if (proxySelector != null) {
/* 293 */         ConnRouteParams.setDefaultProxy(this.params, null);
/*     */       }
/* 295 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder trustCertificatesFromJavaKeyStore(InputStream keyStoreStream, String storePass) throws GeneralSecurityException, IOException {
/* 313 */       KeyStore trustStore = SecurityUtils.getJavaKeyStore();
/* 314 */       SecurityUtils.loadKeyStore(trustStore, keyStoreStream, storePass);
/* 315 */       return trustCertificates(trustStore);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder trustCertificatesFromStream(InputStream certificateStream) throws GeneralSecurityException, IOException {
/* 333 */       KeyStore trustStore = SecurityUtils.getJavaKeyStore();
/* 334 */       trustStore.load(null, null);
/* 335 */       SecurityUtils.loadKeyStoreFromCertificates(trustStore, 
/* 336 */           SecurityUtils.getX509CertificateFactory(), certificateStream);
/* 337 */       return trustCertificates(trustStore);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder trustCertificates(KeyStore trustStore) throws GeneralSecurityException {
/* 348 */       SSLContext sslContext = SslUtils.getTlsSslContext();
/* 349 */       SslUtils.initSslContext(sslContext, trustStore, SslUtils.getPkixTrustManagerFactory());
/* 350 */       return setSocketFactory(new SSLSocketFactoryExtension(sslContext));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public Builder doNotValidateCertificate() throws GeneralSecurityException {
/* 364 */       this.socketFactory = new SSLSocketFactoryExtension(SslUtils.trustAllSSLContext());
/* 365 */       this.socketFactory.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
/* 366 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSocketFactory(SSLSocketFactory socketFactory) {
/* 371 */       this.socketFactory = (SSLSocketFactory)Preconditions.checkNotNull(socketFactory);
/* 372 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public SSLSocketFactory getSSLSocketFactory() {
/* 377 */       return this.socketFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public HttpParams getHttpParams() {
/* 382 */       return this.params;
/*     */     }
/*     */ 
/*     */     
/*     */     public ApacheHttpTransport build() {
/* 387 */       return new ApacheHttpTransport((HttpClient)ApacheHttpTransport.newDefaultHttpClient(this.socketFactory, this.params, this.proxySelector));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\apache\ApacheHttpTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */