/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InputStreamContent
/*     */   extends AbstractInputStreamContent
/*     */ {
/*  47 */   private long length = -1L;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean retrySupported;
/*     */ 
/*     */ 
/*     */   
/*     */   private final InputStream inputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStreamContent(String type, InputStream inputStream) {
/*  61 */     super(type);
/*  62 */     this.inputStream = (InputStream)Preconditions.checkNotNull(inputStream);
/*     */   }
/*     */   
/*     */   public long getLength() {
/*  66 */     return this.length;
/*     */   }
/*     */   
/*     */   public boolean retrySupported() {
/*  70 */     return this.retrySupported;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStreamContent setRetrySupported(boolean retrySupported) {
/*  82 */     this.retrySupported = retrySupported;
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() {
/*  88 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStreamContent setType(String type) {
/*  93 */     return (InputStreamContent)super.setType(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStreamContent setCloseInputStream(boolean closeInputStream) {
/*  98 */     return (InputStreamContent)super.setCloseInputStream(closeInputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStreamContent setLength(long length) {
/* 109 */     this.length = length;
/* 110 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\InputStreamContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */