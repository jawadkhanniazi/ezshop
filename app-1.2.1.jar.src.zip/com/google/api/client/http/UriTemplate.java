/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.FieldInfo;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Types;
/*     */ import com.google.api.client.util.escape.CharEscapers;
/*     */ import com.google.common.base.Splitter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UriTemplate
/*     */ {
/*  58 */   static final Map<Character, CompositeOutput> COMPOSITE_PREFIXES = new HashMap<>();
/*     */   private static final String COMPOSITE_NON_EXPLODE_JOINER = ",";
/*     */   
/*     */   static {
/*  62 */     CompositeOutput.values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum CompositeOutput
/*     */   {
/*  71 */     PLUS((String)Character.valueOf('+'), "", (Character)",", false, true),
/*     */ 
/*     */     
/*  74 */     HASH((String)Character.valueOf('#'), "#", (Character)",", false, true),
/*     */ 
/*     */     
/*  77 */     DOT((String)Character.valueOf('.'), ".", (Character)".", false, false),
/*     */ 
/*     */     
/*  80 */     FORWARD_SLASH((String)Character.valueOf('/'), "/", (Character)"/", false, false),
/*     */ 
/*     */     
/*  83 */     SEMI_COLON((String)Character.valueOf(';'), ";", (Character)";", true, false),
/*     */ 
/*     */     
/*  86 */     QUERY((String)Character.valueOf('?'), "?", (Character)"&", true, false),
/*     */ 
/*     */     
/*  89 */     AMP((String)Character.valueOf('&'), "&", (Character)"&", true, false),
/*     */ 
/*     */     
/*  92 */     SIMPLE(null, "", (Character)",", false, false);
/*     */ 
/*     */ 
/*     */     
/*     */     private final Character propertyPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String outputPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String explodeJoiner;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean requiresVarAssignment;
/*     */ 
/*     */     
/*     */     private final boolean reservedExpansion;
/*     */ 
/*     */ 
/*     */     
/*     */     CompositeOutput(Character propertyPrefix, String outputPrefix, String explodeJoiner, boolean requiresVarAssignment, boolean reservedExpansion) {
/* 116 */       this.propertyPrefix = propertyPrefix;
/* 117 */       this.outputPrefix = (String)Preconditions.checkNotNull(outputPrefix);
/* 118 */       this.explodeJoiner = (String)Preconditions.checkNotNull(explodeJoiner);
/* 119 */       this.requiresVarAssignment = requiresVarAssignment;
/* 120 */       this.reservedExpansion = reservedExpansion;
/* 121 */       if (propertyPrefix != null) {
/* 122 */         UriTemplate.COMPOSITE_PREFIXES.put(propertyPrefix, this);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     String getOutputPrefix() {
/* 128 */       return this.outputPrefix;
/*     */     }
/*     */ 
/*     */     
/*     */     String getExplodeJoiner() {
/* 133 */       return this.explodeJoiner;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean requiresVarAssignment() {
/* 140 */       return this.requiresVarAssignment;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int getVarNameStartIndex() {
/* 148 */       return (this.propertyPrefix == null) ? 0 : 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getEncodedValue(String value) {
/*     */       String encodedValue;
/* 160 */       if (this.reservedExpansion) {
/*     */         
/* 162 */         encodedValue = CharEscapers.escapeUriPathWithoutReserved(value);
/*     */       } else {
/* 164 */         encodedValue = CharEscapers.escapeUri(value);
/*     */       } 
/* 166 */       return encodedValue;
/*     */     }
/*     */     
/*     */     boolean getReservedExpansion() {
/* 170 */       return this.reservedExpansion;
/*     */     }
/*     */   }
/*     */   
/*     */   static CompositeOutput getCompositeOutput(String propertyName) {
/* 175 */     CompositeOutput compositeOutput = COMPOSITE_PREFIXES.get(Character.valueOf(propertyName.charAt(0)));
/* 176 */     return (compositeOutput == null) ? CompositeOutput.SIMPLE : compositeOutput;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Object> getMap(Object obj) {
/* 187 */     Map<String, Object> map = new LinkedHashMap<>();
/* 188 */     for (Map.Entry<String, Object> entry : (Iterable<Map.Entry<String, Object>>)Data.mapOf(obj).entrySet()) {
/* 189 */       Object value = entry.getValue();
/* 190 */       if (value != null && !Data.isNull(value)) {
/* 191 */         map.put(entry.getKey(), value);
/*     */       }
/*     */     } 
/* 194 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String expand(String baseUrl, String uriTemplate, Object parameters, boolean addUnusedParamsAsQueryParams) {
/*     */     String pathUri;
/* 219 */     if (uriTemplate.startsWith("/")) {
/*     */       
/* 221 */       GenericUrl url = new GenericUrl(baseUrl);
/* 222 */       url.setRawPath(null);
/* 223 */       pathUri = url.build() + uriTemplate;
/* 224 */     } else if (uriTemplate.startsWith("http://") || uriTemplate.startsWith("https://")) {
/* 225 */       pathUri = uriTemplate;
/*     */     } else {
/* 227 */       pathUri = baseUrl + uriTemplate;
/*     */     } 
/* 229 */     return expand(pathUri, parameters, addUnusedParamsAsQueryParams);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String expand(String pathUri, Object parameters, boolean addUnusedParamsAsQueryParams) {
/* 249 */     Map<String, Object> variableMap = getMap(parameters);
/* 250 */     StringBuilder pathBuf = new StringBuilder();
/* 251 */     int cur = 0;
/* 252 */     int length = pathUri.length();
/* 253 */     while (cur < length) {
/* 254 */       int next = pathUri.indexOf('{', cur);
/* 255 */       if (next == -1) {
/* 256 */         if (cur == 0 && !addUnusedParamsAsQueryParams)
/*     */         {
/* 258 */           return pathUri;
/*     */         }
/* 260 */         pathBuf.append(pathUri.substring(cur));
/*     */         break;
/*     */       } 
/* 263 */       pathBuf.append(pathUri.substring(cur, next));
/* 264 */       int close = pathUri.indexOf('}', next + 2);
/* 265 */       cur = close + 1;
/*     */       
/* 267 */       String templates = pathUri.substring(next + 1, close);
/* 268 */       CompositeOutput compositeOutput = getCompositeOutput(templates);
/*     */       
/* 270 */       ListIterator<String> templateIterator = Splitter.on(',').splitToList(templates).listIterator();
/* 271 */       boolean isFirstParameter = true;
/* 272 */       while (templateIterator.hasNext()) {
/* 273 */         String template = templateIterator.next();
/* 274 */         boolean containsExplodeModifier = template.endsWith("*");
/*     */ 
/*     */         
/* 277 */         int varNameStartIndex = (templateIterator.nextIndex() == 1) ? compositeOutput.getVarNameStartIndex() : 0;
/* 278 */         int varNameEndIndex = template.length();
/* 279 */         if (containsExplodeModifier)
/*     */         {
/* 281 */           varNameEndIndex--;
/*     */         }
/*     */         
/* 284 */         String varName = template.substring(varNameStartIndex, varNameEndIndex);
/*     */         
/* 286 */         Object value = variableMap.remove(varName);
/* 287 */         if (value == null) {
/*     */           continue;
/*     */         }
/*     */         
/* 291 */         if (!isFirstParameter) {
/* 292 */           pathBuf.append(compositeOutput.getExplodeJoiner());
/*     */         } else {
/* 294 */           pathBuf.append(compositeOutput.getOutputPrefix());
/* 295 */           isFirstParameter = false;
/*     */         } 
/* 297 */         if (value instanceof Iterator) {
/*     */           
/* 299 */           Iterator<?> iterator = (Iterator)value;
/* 300 */           value = getListPropertyValue(varName, iterator, containsExplodeModifier, compositeOutput);
/* 301 */         } else if (value instanceof Iterable || value.getClass().isArray()) {
/*     */           
/* 303 */           Iterator<?> iterator = Types.iterableOf(value).iterator();
/* 304 */           value = getListPropertyValue(varName, iterator, containsExplodeModifier, compositeOutput);
/* 305 */         } else if (value.getClass().isEnum()) {
/* 306 */           String name = FieldInfo.of((Enum)value).getName();
/* 307 */           value = getSimpleValue(varName, (name != null) ? name : value.toString(), compositeOutput);
/* 308 */         } else if (!Data.isValueOfPrimitiveType(value)) {
/*     */           
/* 310 */           Map<String, Object> map = getMap(value);
/* 311 */           value = getMapPropertyValue(varName, map, containsExplodeModifier, compositeOutput);
/*     */         } else {
/*     */           
/* 314 */           value = getSimpleValue(varName, value.toString(), compositeOutput);
/*     */         } 
/* 316 */         pathBuf.append(value);
/*     */       } 
/*     */     } 
/* 319 */     if (addUnusedParamsAsQueryParams)
/*     */     {
/* 321 */       GenericUrl.addQueryParams(variableMap.entrySet(), pathBuf);
/*     */     }
/* 323 */     return pathBuf.toString();
/*     */   }
/*     */   
/*     */   private static String getSimpleValue(String name, String value, CompositeOutput compositeOutput) {
/* 327 */     if (compositeOutput.requiresVarAssignment()) {
/* 328 */       return String.format("%s=%s", new Object[] { name, compositeOutput.getEncodedValue(value) });
/*     */     }
/* 330 */     return compositeOutput.getEncodedValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getListPropertyValue(String varName, Iterator<?> iterator, boolean containsExplodeModifier, CompositeOutput compositeOutput) {
/*     */     String joiner;
/* 350 */     if (!iterator.hasNext()) {
/* 351 */       return "";
/*     */     }
/* 353 */     StringBuilder retBuf = new StringBuilder();
/*     */     
/* 355 */     if (containsExplodeModifier) {
/* 356 */       joiner = compositeOutput.getExplodeJoiner();
/*     */     } else {
/* 358 */       joiner = ",";
/* 359 */       if (compositeOutput.requiresVarAssignment()) {
/* 360 */         retBuf.append(CharEscapers.escapeUriPath(varName));
/* 361 */         retBuf.append("=");
/*     */       } 
/*     */     } 
/* 364 */     while (iterator.hasNext()) {
/* 365 */       if (containsExplodeModifier && compositeOutput.requiresVarAssignment()) {
/* 366 */         retBuf.append(CharEscapers.escapeUriPath(varName));
/* 367 */         retBuf.append("=");
/*     */       } 
/* 369 */       retBuf.append(compositeOutput.getEncodedValue(iterator.next().toString()));
/* 370 */       if (iterator.hasNext()) {
/* 371 */         retBuf.append(joiner);
/*     */       }
/*     */     } 
/* 374 */     return retBuf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getMapPropertyValue(String varName, Map<String, Object> map, boolean containsExplodeModifier, CompositeOutput compositeOutput) {
/*     */     String joiner, mapElementsJoiner;
/* 394 */     if (map.isEmpty()) {
/* 395 */       return "";
/*     */     }
/* 397 */     StringBuilder retBuf = new StringBuilder();
/*     */ 
/*     */     
/* 400 */     if (containsExplodeModifier) {
/* 401 */       joiner = compositeOutput.getExplodeJoiner();
/* 402 */       mapElementsJoiner = "=";
/*     */     } else {
/* 404 */       joiner = ",";
/* 405 */       mapElementsJoiner = ",";
/* 406 */       if (compositeOutput.requiresVarAssignment()) {
/* 407 */         retBuf.append(CharEscapers.escapeUriPath(varName));
/* 408 */         retBuf.append("=");
/*     */       } 
/*     */     } 
/* 411 */     Iterator<Map.Entry<String, Object>> mapIterator = map.entrySet().iterator();
/* 412 */     while (mapIterator.hasNext()) {
/* 413 */       Map.Entry<String, Object> entry = mapIterator.next();
/* 414 */       String encodedKey = compositeOutput.getEncodedValue(entry.getKey());
/* 415 */       String encodedValue = compositeOutput.getEncodedValue(entry.getValue().toString());
/* 416 */       retBuf.append(encodedKey);
/* 417 */       retBuf.append(mapElementsJoiner);
/* 418 */       retBuf.append(encodedValue);
/* 419 */       if (mapIterator.hasNext()) {
/* 420 */         retBuf.append(joiner);
/*     */       }
/*     */     } 
/* 423 */     return retBuf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\UriTemplate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */