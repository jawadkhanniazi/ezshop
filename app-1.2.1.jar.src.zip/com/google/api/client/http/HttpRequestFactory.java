/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpRequestFactory
/*     */ {
/*     */   private final HttpTransport transport;
/*     */   private final HttpRequestInitializer initializer;
/*     */   
/*     */   HttpRequestFactory(HttpTransport transport, HttpRequestInitializer initializer) {
/*  51 */     this.transport = transport;
/*  52 */     this.initializer = initializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpTransport getTransport() {
/*  61 */     return this.transport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequestInitializer getInitializer() {
/*  72 */     return this.initializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildRequest(String requestMethod, GenericUrl url, HttpContent content) throws IOException {
/*  86 */     HttpRequest request = this.transport.buildRequest();
/*  87 */     if (this.initializer != null) {
/*  88 */       this.initializer.initialize(request);
/*     */     }
/*  90 */     request.setRequestMethod(requestMethod);
/*  91 */     if (url != null) {
/*  92 */       request.setUrl(url);
/*     */     }
/*  94 */     if (content != null) {
/*  95 */       request.setContent(content);
/*     */     }
/*  97 */     return request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildDeleteRequest(GenericUrl url) throws IOException {
/* 107 */     return buildRequest("DELETE", url, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildGetRequest(GenericUrl url) throws IOException {
/* 117 */     return buildRequest("GET", url, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildPostRequest(GenericUrl url, HttpContent content) throws IOException {
/* 128 */     return buildRequest("POST", url, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildPutRequest(GenericUrl url, HttpContent content) throws IOException {
/* 139 */     return buildRequest("PUT", url, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildPatchRequest(GenericUrl url, HttpContent content) throws IOException {
/* 150 */     return buildRequest("PATCH", url, content);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildHeadRequest(GenericUrl url) throws IOException {
/* 160 */     return buildRequest("HEAD", url, null);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpRequestFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */