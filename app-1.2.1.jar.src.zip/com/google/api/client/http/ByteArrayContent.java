/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ByteArrayContent
/*     */   extends AbstractInputStreamContent
/*     */ {
/*     */   private final byte[] byteArray;
/*     */   private final int offset;
/*     */   private final int length;
/*     */   
/*     */   public ByteArrayContent(String type, byte[] array) {
/*  60 */     this(type, array, 0, array.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayContent(String type, byte[] array, int offset, int length) {
/*  74 */     super(type);
/*  75 */     this.byteArray = (byte[])Preconditions.checkNotNull(array);
/*  76 */     Preconditions.checkArgument((offset >= 0 && length >= 0 && offset + length <= array.length), "offset %s, length %s, array length %s", new Object[] {
/*     */ 
/*     */           
/*  79 */           Integer.valueOf(offset), 
/*  80 */           Integer.valueOf(length), 
/*  81 */           Integer.valueOf(array.length) });
/*  82 */     this.offset = offset;
/*  83 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ByteArrayContent fromString(String type, String contentString) {
/* 105 */     return new ByteArrayContent(type, StringUtils.getBytesUtf8(contentString));
/*     */   }
/*     */   
/*     */   public long getLength() {
/* 109 */     return this.length;
/*     */   }
/*     */   
/*     */   public boolean retrySupported() {
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() {
/* 118 */     return new ByteArrayInputStream(this.byteArray, this.offset, this.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteArrayContent setType(String type) {
/* 123 */     return (ByteArrayContent)super.setType(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteArrayContent setCloseInputStream(boolean closeInputStream) {
/* 128 */     return (ByteArrayContent)super.setCloseInputStream(closeInputStream);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\ByteArrayContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */