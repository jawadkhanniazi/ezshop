/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.ArrayValueMap;
/*     */ import com.google.api.client.util.Charsets;
/*     */ import com.google.api.client.util.ClassInfo;
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.FieldInfo;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Throwables;
/*     */ import com.google.api.client.util.Types;
/*     */ import com.google.api.client.util.escape.CharEscapers;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UrlEncodedParser
/*     */   implements ObjectParser
/*     */ {
/*     */   public static final String CONTENT_TYPE = "application/x-www-form-urlencoded";
/*  74 */   public static final String MEDIA_TYPE = (new HttpMediaType("application/x-www-form-urlencoded"))
/*  75 */     .setCharsetParameter(Charsets.UTF_8).build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parse(String content, Object data) {
/*  85 */     if (content == null) {
/*     */       return;
/*     */     }
/*     */     try {
/*  89 */       parse(new StringReader(content), data);
/*  90 */     } catch (IOException exception) {
/*     */       
/*  92 */       throw Throwables.propagate(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parse(Reader reader, Object data) throws IOException {
/* 117 */     Class<?> clazz = data.getClass();
/* 118 */     ClassInfo classInfo = ClassInfo.of(clazz);
/* 119 */     List<Type> context = Arrays.asList(new Type[] { clazz });
/* 120 */     GenericData genericData = GenericData.class.isAssignableFrom(clazz) ? (GenericData)data : null;
/*     */     
/* 122 */     Map<Object, Object> map = Map.class.isAssignableFrom(clazz) ? (Map<Object, Object>)data : null;
/* 123 */     ArrayValueMap arrayValueMap = new ArrayValueMap(data);
/* 124 */     StringWriter nameWriter = new StringWriter();
/* 125 */     StringWriter valueWriter = new StringWriter();
/* 126 */     boolean readingName = true;
/*     */     while (true) {
/*     */       String name;
/* 129 */       int read = reader.read();
/* 130 */       switch (read) {
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 38:
/* 135 */           name = CharEscapers.decodeUri(nameWriter.toString());
/* 136 */           if (name.length() != 0) {
/* 137 */             String stringValue = CharEscapers.decodeUri(valueWriter.toString());
/*     */             
/* 139 */             FieldInfo fieldInfo = classInfo.getFieldInfo(name);
/* 140 */             if (fieldInfo != null) {
/*     */               
/* 142 */               Type type = Data.resolveWildcardTypeOrTypeVariable(context, fieldInfo.getGenericType());
/*     */               
/* 144 */               if (Types.isArray(type)) {
/*     */ 
/*     */                 
/* 147 */                 Class<?> rawArrayComponentType = Types.getRawArrayComponentType(context, Types.getArrayComponentType(type));
/* 148 */                 arrayValueMap.put(fieldInfo
/* 149 */                     .getField(), rawArrayComponentType, 
/*     */                     
/* 151 */                     parseValue(rawArrayComponentType, context, stringValue));
/* 152 */               } else if (Types.isAssignableToOrFrom(
/* 153 */                   Types.getRawArrayComponentType(context, type), Iterable.class)) {
/*     */ 
/*     */                 
/* 156 */                 Collection<Object> collection = (Collection<Object>)fieldInfo.getValue(data);
/* 157 */                 if (collection == null) {
/* 158 */                   collection = Data.newCollectionInstance(type);
/* 159 */                   fieldInfo.setValue(data, collection);
/*     */                 } 
/* 161 */                 Type subFieldType = (type == Object.class) ? null : Types.getIterableParameter(type);
/* 162 */                 collection.add(parseValue(subFieldType, context, stringValue));
/*     */               } else {
/*     */                 
/* 165 */                 fieldInfo.setValue(data, parseValue(type, context, stringValue));
/*     */               } 
/* 167 */             } else if (map != null) {
/*     */ 
/*     */               
/* 170 */               ArrayList<String> listValue = (ArrayList<String>)map.get(name);
/* 171 */               if (listValue == null) {
/* 172 */                 listValue = new ArrayList<>();
/* 173 */                 if (genericData != null) {
/* 174 */                   genericData.set(name, listValue);
/*     */                 } else {
/* 176 */                   map.put(name, listValue);
/*     */                 } 
/*     */               } 
/* 179 */               listValue.add(stringValue);
/*     */             } 
/*     */           } 
/*     */           
/* 183 */           readingName = true;
/* 184 */           nameWriter = new StringWriter();
/* 185 */           valueWriter = new StringWriter();
/* 186 */           if (read == -1) {
/*     */             break;
/*     */           }
/*     */           continue;
/*     */         case 61:
/* 191 */           if (readingName) {
/*     */             
/* 193 */             readingName = false;
/*     */             continue;
/*     */           } 
/* 196 */           valueWriter.write(read);
/*     */           continue;
/*     */       } 
/*     */ 
/*     */       
/* 201 */       if (readingName) {
/* 202 */         nameWriter.write(read); continue;
/*     */       } 
/* 204 */       valueWriter.write(read);
/*     */     } 
/*     */ 
/*     */     
/* 208 */     arrayValueMap.setValues();
/*     */   }
/*     */   
/*     */   private static Object parseValue(Type valueType, List<Type> context, String value) {
/* 212 */     Type resolved = Data.resolveWildcardTypeOrTypeVariable(context, valueType);
/* 213 */     return Data.parsePrimitiveValue(resolved, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T parseAndClose(InputStream in, Charset charset, Class<T> dataClass) throws IOException {
/* 218 */     InputStreamReader r = new InputStreamReader(in, charset);
/* 219 */     return parseAndClose(r, dataClass);
/*     */   }
/*     */   
/*     */   public Object parseAndClose(InputStream in, Charset charset, Type dataType) throws IOException {
/* 223 */     InputStreamReader r = new InputStreamReader(in, charset);
/* 224 */     return parseAndClose(r, dataType);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T parseAndClose(Reader reader, Class<T> dataClass) throws IOException {
/* 229 */     return (T)parseAndClose(reader, dataClass);
/*     */   }
/*     */   
/*     */   public Object parseAndClose(Reader reader, Type dataType) throws IOException {
/* 233 */     Preconditions.checkArgument(dataType instanceof Class, "dataType has to be of type Class<?>");
/*     */ 
/*     */     
/* 236 */     Object newInstance = Types.newInstance((Class)dataType);
/* 237 */     parse(new BufferedReader(reader), newInstance);
/* 238 */     return newInstance;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\UrlEncodedParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */