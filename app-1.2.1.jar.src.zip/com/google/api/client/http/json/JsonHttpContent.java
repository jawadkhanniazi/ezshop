/*     */ package com.google.api.client.http.json;
/*     */ 
/*     */ import com.google.api.client.http.AbstractHttpContent;
/*     */ import com.google.api.client.http.HttpMediaType;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonGenerator;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonHttpContent
/*     */   extends AbstractHttpContent
/*     */ {
/*     */   private final Object data;
/*     */   private final JsonFactory jsonFactory;
/*     */   private String wrapperKey;
/*     */   
/*     */   public JsonHttpContent(JsonFactory jsonFactory, Object data) {
/*  62 */     super("application/json; charset=UTF-8");
/*  63 */     this.jsonFactory = (JsonFactory)Preconditions.checkNotNull(jsonFactory);
/*  64 */     this.data = Preconditions.checkNotNull(data);
/*     */   }
/*     */   
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  68 */     JsonGenerator generator = this.jsonFactory.createJsonGenerator(out, getCharset());
/*  69 */     if (this.wrapperKey != null) {
/*  70 */       generator.writeStartObject();
/*  71 */       generator.writeFieldName(this.wrapperKey);
/*     */     } 
/*  73 */     generator.serialize(this.data);
/*  74 */     if (this.wrapperKey != null) {
/*  75 */       generator.writeEndObject();
/*     */     }
/*  77 */     generator.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonHttpContent setMediaType(HttpMediaType mediaType) {
/*  82 */     super.setMediaType(mediaType);
/*  83 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getData() {
/*  92 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/* 101 */     return this.jsonFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getWrapperKey() {
/* 110 */     return this.wrapperKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonHttpContent setWrapperKey(String wrapperKey) {
/* 122 */     this.wrapperKey = wrapperKey;
/* 123 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\json\JsonHttpContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */