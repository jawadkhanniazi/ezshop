/*    */ package com.google.api.client.http;
/*    */ 
/*    */ import com.google.api.client.util.StreamingContent;
/*    */ import java.io.BufferedOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.zip.GZIPOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GZipEncoding
/*    */   implements HttpEncoding
/*    */ {
/*    */   public String getName() {
/* 32 */     return "gzip";
/*    */   }
/*    */ 
/*    */   
/*    */   public void encode(StreamingContent content, OutputStream out) throws IOException {
/* 37 */     OutputStream out2 = new BufferedOutputStream(out)
/*    */       {
/*    */ 
/*    */         
/*    */         public void close() throws IOException
/*    */         {
/*    */           try {
/* 44 */             flush();
/* 45 */           } catch (IOException iOException) {}
/*    */         }
/*    */       };
/*    */     
/* 49 */     GZIPOutputStream zipper = new GZIPOutputStream(out2);
/* 50 */     content.writeTo(zipper);
/*    */     
/* 52 */     zipper.close();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\GZipEncoding.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */