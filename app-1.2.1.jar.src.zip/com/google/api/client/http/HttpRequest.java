/*      */ package com.google.api.client.http;
/*      */ 
/*      */ import com.google.api.client.util.Beta;
/*      */ import com.google.api.client.util.ObjectParser;
/*      */ import com.google.api.client.util.Preconditions;
/*      */ import com.google.api.client.util.Sleeper;
/*      */ import com.google.common.util.concurrent.ThreadFactoryBuilder;
/*      */ import io.opencensus.trace.AttributeValue;
/*      */ import io.opencensus.trace.Span;
/*      */ import io.opencensus.trace.Tracer;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Callable;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.FutureTask;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HttpRequest
/*      */ {
/*   57 */   public static final String VERSION = getVersion();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   68 */   public static final String USER_AGENT_SUFFIX = "Google-HTTP-Java-Client/" + VERSION + " (gzip)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int DEFAULT_NUMBER_OF_RETRIES = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpExecuteInterceptor executeInterceptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   86 */   private HttpHeaders headers = new HttpHeaders();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   private HttpHeaders responseHeaders = new HttpHeaders();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   private int numRetries = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   private int contentLoggingLimit = 16384;
/*      */ 
/*      */   
/*      */   private boolean loggingEnabled = true;
/*      */ 
/*      */   
/*      */   private boolean curlLoggingEnabled = true;
/*      */ 
/*      */   
/*      */   private HttpContent content;
/*      */ 
/*      */   
/*      */   private final HttpTransport transport;
/*      */ 
/*      */   
/*      */   private String requestMethod;
/*      */ 
/*      */   
/*      */   private GenericUrl url;
/*      */ 
/*      */   
/*  146 */   private int connectTimeout = 20000;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   private int readTimeout = 20000;
/*      */ 
/*      */   
/*  155 */   private int writeTimeout = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpUnsuccessfulResponseHandler unsuccessfulResponseHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   @Beta
/*      */   private HttpIOExceptionHandler ioExceptionHandler;
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpResponseInterceptor responseInterceptor;
/*      */ 
/*      */ 
/*      */   
/*      */   private ObjectParser objectParser;
/*      */ 
/*      */ 
/*      */   
/*      */   private HttpEncoding encoding;
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Beta
/*      */   private BackOffPolicy backOffPolicy;
/*      */ 
/*      */   
/*      */   private boolean followRedirects = true;
/*      */ 
/*      */   
/*      */   private boolean throwExceptionOnExecuteError = true;
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Beta
/*      */   private boolean retryOnExecuteIOException = false;
/*      */ 
/*      */   
/*      */   private boolean suppressUserAgentSuffix;
/*      */ 
/*      */   
/*  198 */   private Sleeper sleeper = Sleeper.DEFAULT;
/*      */ 
/*      */   
/*  201 */   private final Tracer tracer = OpenCensusUtils.getTracer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean responseReturnRawInputStream = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   HttpRequest(HttpTransport transport, String requestMethod) {
/*  216 */     this.transport = transport;
/*  217 */     setRequestMethod(requestMethod);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpTransport getTransport() {
/*  226 */     return this.transport;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRequestMethod() {
/*  235 */     return this.requestMethod;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setRequestMethod(String requestMethod) {
/*  244 */     Preconditions.checkArgument((requestMethod == null || HttpMediaType.matchesToken(requestMethod)));
/*  245 */     this.requestMethod = requestMethod;
/*  246 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GenericUrl getUrl() {
/*  255 */     return this.url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setUrl(GenericUrl url) {
/*  264 */     this.url = (GenericUrl)Preconditions.checkNotNull(url);
/*  265 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpContent getContent() {
/*  274 */     return this.content;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setContent(HttpContent content) {
/*  283 */     this.content = content;
/*  284 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpEncoding getEncoding() {
/*  293 */     return this.encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setEncoding(HttpEncoding encoding) {
/*  302 */     this.encoding = encoding;
/*  303 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Beta
/*      */   public BackOffPolicy getBackOffPolicy() {
/*  318 */     return this.backOffPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Beta
/*      */   public HttpRequest setBackOffPolicy(BackOffPolicy backOffPolicy) {
/*  333 */     this.backOffPolicy = backOffPolicy;
/*  334 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getContentLoggingLimit() {
/*  352 */     return this.contentLoggingLimit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setContentLoggingLimit(int contentLoggingLimit) {
/*  370 */     Preconditions.checkArgument((contentLoggingLimit >= 0), "The content logging limit must be non-negative.");
/*      */     
/*  372 */     this.contentLoggingLimit = contentLoggingLimit;
/*  373 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLoggingEnabled() {
/*  384 */     return this.loggingEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setLoggingEnabled(boolean loggingEnabled) {
/*  395 */     this.loggingEnabled = loggingEnabled;
/*  396 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCurlLoggingEnabled() {
/*  405 */     return this.curlLoggingEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setCurlLoggingEnabled(boolean curlLoggingEnabled) {
/*  416 */     this.curlLoggingEnabled = curlLoggingEnabled;
/*  417 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConnectTimeout() {
/*  427 */     return this.connectTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setConnectTimeout(int connectTimeout) {
/*  439 */     Preconditions.checkArgument((connectTimeout >= 0));
/*  440 */     this.connectTimeout = connectTimeout;
/*  441 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getReadTimeout() {
/*  453 */     return this.readTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setReadTimeout(int readTimeout) {
/*  463 */     Preconditions.checkArgument((readTimeout >= 0));
/*  464 */     this.readTimeout = readTimeout;
/*  465 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getWriteTimeout() {
/*  476 */     return this.writeTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setWriteTimeout(int writeTimeout) {
/*  485 */     Preconditions.checkArgument((writeTimeout >= 0));
/*  486 */     this.writeTimeout = writeTimeout;
/*  487 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders getHeaders() {
/*  496 */     return this.headers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setHeaders(HttpHeaders headers) {
/*  507 */     this.headers = (HttpHeaders)Preconditions.checkNotNull(headers);
/*  508 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpHeaders getResponseHeaders() {
/*  517 */     return this.responseHeaders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setResponseHeaders(HttpHeaders responseHeaders) {
/*  540 */     this.responseHeaders = (HttpHeaders)Preconditions.checkNotNull(responseHeaders);
/*  541 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpExecuteInterceptor getInterceptor() {
/*  551 */     return this.executeInterceptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setInterceptor(HttpExecuteInterceptor interceptor) {
/*  561 */     this.executeInterceptor = interceptor;
/*  562 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUnsuccessfulResponseHandler getUnsuccessfulResponseHandler() {
/*  571 */     return this.unsuccessfulResponseHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setUnsuccessfulResponseHandler(HttpUnsuccessfulResponseHandler unsuccessfulResponseHandler) {
/*  581 */     this.unsuccessfulResponseHandler = unsuccessfulResponseHandler;
/*  582 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Beta
/*      */   public HttpIOExceptionHandler getIOExceptionHandler() {
/*  593 */     return this.ioExceptionHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Beta
/*      */   public HttpRequest setIOExceptionHandler(HttpIOExceptionHandler ioExceptionHandler) {
/*  604 */     this.ioExceptionHandler = ioExceptionHandler;
/*  605 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpResponseInterceptor getResponseInterceptor() {
/*  614 */     return this.responseInterceptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setResponseInterceptor(HttpResponseInterceptor responseInterceptor) {
/*  623 */     this.responseInterceptor = responseInterceptor;
/*  624 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfRetries() {
/*  636 */     return this.numRetries;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setNumberOfRetries(int numRetries) {
/*  650 */     Preconditions.checkArgument((numRetries >= 0));
/*  651 */     this.numRetries = numRetries;
/*  652 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setParser(ObjectParser parser) {
/*  664 */     this.objectParser = parser;
/*  665 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectParser getParser() {
/*  674 */     return this.objectParser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFollowRedirects() {
/*  683 */     return this.followRedirects;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setFollowRedirects(boolean followRedirects) {
/*  694 */     this.followRedirects = followRedirects;
/*  695 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getThrowExceptionOnExecuteError() {
/*  705 */     return this.throwExceptionOnExecuteError;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setThrowExceptionOnExecuteError(boolean throwExceptionOnExecuteError) {
/*  717 */     this.throwExceptionOnExecuteError = throwExceptionOnExecuteError;
/*  718 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Beta
/*      */   public boolean getRetryOnExecuteIOException() {
/*  733 */     return this.retryOnExecuteIOException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   @Beta
/*      */   public HttpRequest setRetryOnExecuteIOException(boolean retryOnExecuteIOException) {
/*  750 */     this.retryOnExecuteIOException = retryOnExecuteIOException;
/*  751 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getSuppressUserAgentSuffix() {
/*  760 */     return this.suppressUserAgentSuffix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setSuppressUserAgentSuffix(boolean suppressUserAgentSuffix) {
/*  771 */     this.suppressUserAgentSuffix = suppressUserAgentSuffix;
/*  772 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getResponseReturnRawInputStream() {
/*  782 */     return this.responseReturnRawInputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setResponseReturnRawInputStream(boolean responseReturnRawInputStream) {
/*  793 */     this.responseReturnRawInputStream = responseReturnRawInputStream;
/*  794 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpResponse execute() throws IOException {
/*      */     // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_1
/*      */     //   2: aload_0
/*      */     //   3: getfield numRetries : I
/*      */     //   6: iflt -> 13
/*      */     //   9: iconst_1
/*      */     //   10: goto -> 14
/*      */     //   13: iconst_0
/*      */     //   14: invokestatic checkArgument : (Z)V
/*      */     //   17: aload_0
/*      */     //   18: getfield numRetries : I
/*      */     //   21: istore_2
/*      */     //   22: aload_0
/*      */     //   23: getfield backOffPolicy : Lcom/google/api/client/http/BackOffPolicy;
/*      */     //   26: ifnull -> 38
/*      */     //   29: aload_0
/*      */     //   30: getfield backOffPolicy : Lcom/google/api/client/http/BackOffPolicy;
/*      */     //   33: invokeinterface reset : ()V
/*      */     //   38: aconst_null
/*      */     //   39: astore_3
/*      */     //   40: aload_0
/*      */     //   41: getfield requestMethod : Ljava/lang/String;
/*      */     //   44: invokestatic checkNotNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   47: pop
/*      */     //   48: aload_0
/*      */     //   49: getfield url : Lcom/google/api/client/http/GenericUrl;
/*      */     //   52: invokestatic checkNotNull : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   55: pop
/*      */     //   56: aload_0
/*      */     //   57: getfield tracer : Lio/opencensus/trace/Tracer;
/*      */     //   60: getstatic com/google/api/client/http/OpenCensusUtils.SPAN_NAME_HTTP_REQUEST_EXECUTE : Ljava/lang/String;
/*      */     //   63: invokevirtual spanBuilder : (Ljava/lang/String;)Lio/opencensus/trace/SpanBuilder;
/*      */     //   66: invokestatic isRecordEvent : ()Z
/*      */     //   69: invokevirtual setRecordEvents : (Z)Lio/opencensus/trace/SpanBuilder;
/*      */     //   72: invokevirtual startSpan : ()Lio/opencensus/trace/Span;
/*      */     //   75: astore #5
/*      */     //   77: aload #5
/*      */     //   79: new java/lang/StringBuilder
/*      */     //   82: dup
/*      */     //   83: invokespecial <init> : ()V
/*      */     //   86: ldc 'retry #'
/*      */     //   88: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   91: aload_0
/*      */     //   92: getfield numRetries : I
/*      */     //   95: iload_2
/*      */     //   96: isub
/*      */     //   97: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*      */     //   100: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   103: invokevirtual addAnnotation : (Ljava/lang/String;)V
/*      */     //   106: aload_3
/*      */     //   107: ifnull -> 114
/*      */     //   110: aload_3
/*      */     //   111: invokevirtual ignore : ()V
/*      */     //   114: aconst_null
/*      */     //   115: astore_3
/*      */     //   116: aconst_null
/*      */     //   117: astore #4
/*      */     //   119: aload_0
/*      */     //   120: getfield executeInterceptor : Lcom/google/api/client/http/HttpExecuteInterceptor;
/*      */     //   123: ifnull -> 136
/*      */     //   126: aload_0
/*      */     //   127: getfield executeInterceptor : Lcom/google/api/client/http/HttpExecuteInterceptor;
/*      */     //   130: aload_0
/*      */     //   131: invokeinterface intercept : (Lcom/google/api/client/http/HttpRequest;)V
/*      */     //   136: aload_0
/*      */     //   137: getfield url : Lcom/google/api/client/http/GenericUrl;
/*      */     //   140: invokevirtual build : ()Ljava/lang/String;
/*      */     //   143: astore #6
/*      */     //   145: aload #5
/*      */     //   147: ldc 'http.method'
/*      */     //   149: aload_0
/*      */     //   150: getfield requestMethod : Ljava/lang/String;
/*      */     //   153: invokestatic addSpanAttribute : (Lio/opencensus/trace/Span;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   156: aload #5
/*      */     //   158: ldc 'http.host'
/*      */     //   160: aload_0
/*      */     //   161: getfield url : Lcom/google/api/client/http/GenericUrl;
/*      */     //   164: invokevirtual getHost : ()Ljava/lang/String;
/*      */     //   167: invokestatic addSpanAttribute : (Lio/opencensus/trace/Span;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   170: aload #5
/*      */     //   172: ldc 'http.path'
/*      */     //   174: aload_0
/*      */     //   175: getfield url : Lcom/google/api/client/http/GenericUrl;
/*      */     //   178: invokevirtual getRawPath : ()Ljava/lang/String;
/*      */     //   181: invokestatic addSpanAttribute : (Lio/opencensus/trace/Span;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   184: aload #5
/*      */     //   186: ldc 'http.url'
/*      */     //   188: aload #6
/*      */     //   190: invokestatic addSpanAttribute : (Lio/opencensus/trace/Span;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   193: aload_0
/*      */     //   194: getfield transport : Lcom/google/api/client/http/HttpTransport;
/*      */     //   197: aload_0
/*      */     //   198: getfield requestMethod : Ljava/lang/String;
/*      */     //   201: aload #6
/*      */     //   203: invokevirtual buildRequest : (Ljava/lang/String;Ljava/lang/String;)Lcom/google/api/client/http/LowLevelHttpRequest;
/*      */     //   206: astore #7
/*      */     //   208: getstatic com/google/api/client/http/HttpTransport.LOGGER : Ljava/util/logging/Logger;
/*      */     //   211: astore #8
/*      */     //   213: aload_0
/*      */     //   214: getfield loggingEnabled : Z
/*      */     //   217: ifeq -> 235
/*      */     //   220: aload #8
/*      */     //   222: getstatic java/util/logging/Level.CONFIG : Ljava/util/logging/Level;
/*      */     //   225: invokevirtual isLoggable : (Ljava/util/logging/Level;)Z
/*      */     //   228: ifeq -> 235
/*      */     //   231: iconst_1
/*      */     //   232: goto -> 236
/*      */     //   235: iconst_0
/*      */     //   236: istore #9
/*      */     //   238: aconst_null
/*      */     //   239: astore #10
/*      */     //   241: aconst_null
/*      */     //   242: astore #11
/*      */     //   244: iload #9
/*      */     //   246: ifeq -> 343
/*      */     //   249: new java/lang/StringBuilder
/*      */     //   252: dup
/*      */     //   253: invokespecial <init> : ()V
/*      */     //   256: astore #10
/*      */     //   258: aload #10
/*      */     //   260: ldc '-------------- REQUEST  --------------'
/*      */     //   262: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   265: getstatic com/google/api/client/util/StringUtils.LINE_SEPARATOR : Ljava/lang/String;
/*      */     //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   271: pop
/*      */     //   272: aload #10
/*      */     //   274: aload_0
/*      */     //   275: getfield requestMethod : Ljava/lang/String;
/*      */     //   278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   281: bipush #32
/*      */     //   283: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*      */     //   286: aload #6
/*      */     //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   291: getstatic com/google/api/client/util/StringUtils.LINE_SEPARATOR : Ljava/lang/String;
/*      */     //   294: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   297: pop
/*      */     //   298: aload_0
/*      */     //   299: getfield curlLoggingEnabled : Z
/*      */     //   302: ifeq -> 343
/*      */     //   305: new java/lang/StringBuilder
/*      */     //   308: dup
/*      */     //   309: ldc 'curl -v --compressed'
/*      */     //   311: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   314: astore #11
/*      */     //   316: aload_0
/*      */     //   317: getfield requestMethod : Ljava/lang/String;
/*      */     //   320: ldc 'GET'
/*      */     //   322: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   325: ifne -> 343
/*      */     //   328: aload #11
/*      */     //   330: ldc ' -X '
/*      */     //   332: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   335: aload_0
/*      */     //   336: getfield requestMethod : Ljava/lang/String;
/*      */     //   339: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   342: pop
/*      */     //   343: aload_0
/*      */     //   344: getfield headers : Lcom/google/api/client/http/HttpHeaders;
/*      */     //   347: invokevirtual getUserAgent : ()Ljava/lang/String;
/*      */     //   350: astore #12
/*      */     //   352: aload_0
/*      */     //   353: getfield suppressUserAgentSuffix : Z
/*      */     //   356: ifne -> 435
/*      */     //   359: aload #12
/*      */     //   361: ifnonnull -> 388
/*      */     //   364: aload_0
/*      */     //   365: getfield headers : Lcom/google/api/client/http/HttpHeaders;
/*      */     //   368: getstatic com/google/api/client/http/HttpRequest.USER_AGENT_SUFFIX : Ljava/lang/String;
/*      */     //   371: invokevirtual setUserAgent : (Ljava/lang/String;)Lcom/google/api/client/http/HttpHeaders;
/*      */     //   374: pop
/*      */     //   375: aload #5
/*      */     //   377: ldc 'http.user_agent'
/*      */     //   379: getstatic com/google/api/client/http/HttpRequest.USER_AGENT_SUFFIX : Ljava/lang/String;
/*      */     //   382: invokestatic addSpanAttribute : (Lio/opencensus/trace/Span;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   385: goto -> 435
/*      */     //   388: new java/lang/StringBuilder
/*      */     //   391: dup
/*      */     //   392: invokespecial <init> : ()V
/*      */     //   395: aload #12
/*      */     //   397: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   400: ldc ' '
/*      */     //   402: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   405: getstatic com/google/api/client/http/HttpRequest.USER_AGENT_SUFFIX : Ljava/lang/String;
/*      */     //   408: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   411: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   414: astore #13
/*      */     //   416: aload_0
/*      */     //   417: getfield headers : Lcom/google/api/client/http/HttpHeaders;
/*      */     //   420: aload #13
/*      */     //   422: invokevirtual setUserAgent : (Ljava/lang/String;)Lcom/google/api/client/http/HttpHeaders;
/*      */     //   425: pop
/*      */     //   426: aload #5
/*      */     //   428: ldc 'http.user_agent'
/*      */     //   430: aload #13
/*      */     //   432: invokestatic addSpanAttribute : (Lio/opencensus/trace/Span;Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   435: aload #5
/*      */     //   437: aload_0
/*      */     //   438: getfield headers : Lcom/google/api/client/http/HttpHeaders;
/*      */     //   441: invokestatic propagateTracingContext : (Lio/opencensus/trace/Span;Lcom/google/api/client/http/HttpHeaders;)V
/*      */     //   444: aload_0
/*      */     //   445: getfield headers : Lcom/google/api/client/http/HttpHeaders;
/*      */     //   448: aload #10
/*      */     //   450: aload #11
/*      */     //   452: aload #8
/*      */     //   454: aload #7
/*      */     //   456: invokestatic serializeHeaders : (Lcom/google/api/client/http/HttpHeaders;Ljava/lang/StringBuilder;Ljava/lang/StringBuilder;Ljava/util/logging/Logger;Lcom/google/api/client/http/LowLevelHttpRequest;)V
/*      */     //   459: aload_0
/*      */     //   460: getfield suppressUserAgentSuffix : Z
/*      */     //   463: ifne -> 476
/*      */     //   466: aload_0
/*      */     //   467: getfield headers : Lcom/google/api/client/http/HttpHeaders;
/*      */     //   470: aload #12
/*      */     //   472: invokevirtual setUserAgent : (Ljava/lang/String;)Lcom/google/api/client/http/HttpHeaders;
/*      */     //   475: pop
/*      */     //   476: aload_0
/*      */     //   477: getfield content : Lcom/google/api/client/http/HttpContent;
/*      */     //   480: astore #13
/*      */     //   482: aload #13
/*      */     //   484: ifnull -> 499
/*      */     //   487: aload_0
/*      */     //   488: getfield content : Lcom/google/api/client/http/HttpContent;
/*      */     //   491: invokeinterface retrySupported : ()Z
/*      */     //   496: ifeq -> 503
/*      */     //   499: iconst_1
/*      */     //   500: goto -> 504
/*      */     //   503: iconst_0
/*      */     //   504: istore #14
/*      */     //   506: aload #13
/*      */     //   508: ifnull -> 859
/*      */     //   511: aload_0
/*      */     //   512: getfield content : Lcom/google/api/client/http/HttpContent;
/*      */     //   515: invokeinterface getType : ()Ljava/lang/String;
/*      */     //   520: astore #18
/*      */     //   522: iload #9
/*      */     //   524: ifeq -> 548
/*      */     //   527: new com/google/api/client/util/LoggingStreamingContent
/*      */     //   530: dup
/*      */     //   531: aload #13
/*      */     //   533: getstatic com/google/api/client/http/HttpTransport.LOGGER : Ljava/util/logging/Logger;
/*      */     //   536: getstatic java/util/logging/Level.CONFIG : Ljava/util/logging/Level;
/*      */     //   539: aload_0
/*      */     //   540: getfield contentLoggingLimit : I
/*      */     //   543: invokespecial <init> : (Lcom/google/api/client/util/StreamingContent;Ljava/util/logging/Logger;Ljava/util/logging/Level;I)V
/*      */     //   546: astore #13
/*      */     //   548: aload_0
/*      */     //   549: getfield encoding : Lcom/google/api/client/http/HttpEncoding;
/*      */     //   552: ifnonnull -> 572
/*      */     //   555: aconst_null
/*      */     //   556: astore #15
/*      */     //   558: aload_0
/*      */     //   559: getfield content : Lcom/google/api/client/http/HttpContent;
/*      */     //   562: invokeinterface getLength : ()J
/*      */     //   567: lstore #16
/*      */     //   569: goto -> 616
/*      */     //   572: aload_0
/*      */     //   573: getfield encoding : Lcom/google/api/client/http/HttpEncoding;
/*      */     //   576: invokeinterface getName : ()Ljava/lang/String;
/*      */     //   581: astore #15
/*      */     //   583: new com/google/api/client/http/HttpEncodingStreamingContent
/*      */     //   586: dup
/*      */     //   587: aload #13
/*      */     //   589: aload_0
/*      */     //   590: getfield encoding : Lcom/google/api/client/http/HttpEncoding;
/*      */     //   593: invokespecial <init> : (Lcom/google/api/client/util/StreamingContent;Lcom/google/api/client/http/HttpEncoding;)V
/*      */     //   596: astore #13
/*      */     //   598: iload #14
/*      */     //   600: ifeq -> 611
/*      */     //   603: aload #13
/*      */     //   605: invokestatic computeLength : (Lcom/google/api/client/util/StreamingContent;)J
/*      */     //   608: goto -> 614
/*      */     //   611: ldc2_w -1
/*      */     //   614: lstore #16
/*      */     //   616: iload #9
/*      */     //   618: ifeq -> 818
/*      */     //   621: aload #18
/*      */     //   623: ifnull -> 698
/*      */     //   626: new java/lang/StringBuilder
/*      */     //   629: dup
/*      */     //   630: invokespecial <init> : ()V
/*      */     //   633: ldc 'Content-Type: '
/*      */     //   635: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   638: aload #18
/*      */     //   640: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   643: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   646: astore #19
/*      */     //   648: aload #10
/*      */     //   650: aload #19
/*      */     //   652: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   655: getstatic com/google/api/client/util/StringUtils.LINE_SEPARATOR : Ljava/lang/String;
/*      */     //   658: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   661: pop
/*      */     //   662: aload #11
/*      */     //   664: ifnull -> 698
/*      */     //   667: aload #11
/*      */     //   669: new java/lang/StringBuilder
/*      */     //   672: dup
/*      */     //   673: invokespecial <init> : ()V
/*      */     //   676: ldc ' -H ''
/*      */     //   678: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   681: aload #19
/*      */     //   683: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   686: ldc '''
/*      */     //   688: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   691: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   694: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   697: pop
/*      */     //   698: aload #15
/*      */     //   700: ifnull -> 775
/*      */     //   703: new java/lang/StringBuilder
/*      */     //   706: dup
/*      */     //   707: invokespecial <init> : ()V
/*      */     //   710: ldc 'Content-Encoding: '
/*      */     //   712: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   715: aload #15
/*      */     //   717: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   720: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   723: astore #19
/*      */     //   725: aload #10
/*      */     //   727: aload #19
/*      */     //   729: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   732: getstatic com/google/api/client/util/StringUtils.LINE_SEPARATOR : Ljava/lang/String;
/*      */     //   735: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   738: pop
/*      */     //   739: aload #11
/*      */     //   741: ifnull -> 775
/*      */     //   744: aload #11
/*      */     //   746: new java/lang/StringBuilder
/*      */     //   749: dup
/*      */     //   750: invokespecial <init> : ()V
/*      */     //   753: ldc ' -H ''
/*      */     //   755: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   758: aload #19
/*      */     //   760: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   763: ldc '''
/*      */     //   765: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   768: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   771: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   774: pop
/*      */     //   775: lload #16
/*      */     //   777: lconst_0
/*      */     //   778: lcmp
/*      */     //   779: iflt -> 818
/*      */     //   782: new java/lang/StringBuilder
/*      */     //   785: dup
/*      */     //   786: invokespecial <init> : ()V
/*      */     //   789: ldc 'Content-Length: '
/*      */     //   791: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   794: lload #16
/*      */     //   796: invokevirtual append : (J)Ljava/lang/StringBuilder;
/*      */     //   799: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   802: astore #19
/*      */     //   804: aload #10
/*      */     //   806: aload #19
/*      */     //   808: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   811: getstatic com/google/api/client/util/StringUtils.LINE_SEPARATOR : Ljava/lang/String;
/*      */     //   814: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   817: pop
/*      */     //   818: aload #11
/*      */     //   820: ifnull -> 831
/*      */     //   823: aload #11
/*      */     //   825: ldc ' -d '@-''
/*      */     //   827: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   830: pop
/*      */     //   831: aload #7
/*      */     //   833: aload #18
/*      */     //   835: invokevirtual setContentType : (Ljava/lang/String;)V
/*      */     //   838: aload #7
/*      */     //   840: aload #15
/*      */     //   842: invokevirtual setContentEncoding : (Ljava/lang/String;)V
/*      */     //   845: aload #7
/*      */     //   847: lload #16
/*      */     //   849: invokevirtual setContentLength : (J)V
/*      */     //   852: aload #7
/*      */     //   854: aload #13
/*      */     //   856: invokevirtual setStreamingContent : (Lcom/google/api/client/util/StreamingContent;)V
/*      */     //   859: iload #9
/*      */     //   861: ifeq -> 933
/*      */     //   864: aload #8
/*      */     //   866: aload #10
/*      */     //   868: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   871: invokevirtual config : (Ljava/lang/String;)V
/*      */     //   874: aload #11
/*      */     //   876: ifnull -> 933
/*      */     //   879: aload #11
/*      */     //   881: ldc ' -- ''
/*      */     //   883: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   886: pop
/*      */     //   887: aload #11
/*      */     //   889: aload #6
/*      */     //   891: ldc '''
/*      */     //   893: ldc ''"'"''
/*      */     //   895: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*      */     //   898: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   901: pop
/*      */     //   902: aload #11
/*      */     //   904: ldc '''
/*      */     //   906: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   909: pop
/*      */     //   910: aload #13
/*      */     //   912: ifnull -> 923
/*      */     //   915: aload #11
/*      */     //   917: ldc ' << $$$'
/*      */     //   919: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   922: pop
/*      */     //   923: aload #8
/*      */     //   925: aload #11
/*      */     //   927: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   930: invokevirtual config : (Ljava/lang/String;)V
/*      */     //   933: iload #14
/*      */     //   935: ifeq -> 946
/*      */     //   938: iload_2
/*      */     //   939: ifle -> 946
/*      */     //   942: iconst_1
/*      */     //   943: goto -> 947
/*      */     //   946: iconst_0
/*      */     //   947: istore_1
/*      */     //   948: aload #7
/*      */     //   950: aload_0
/*      */     //   951: getfield connectTimeout : I
/*      */     //   954: aload_0
/*      */     //   955: getfield readTimeout : I
/*      */     //   958: invokevirtual setTimeout : (II)V
/*      */     //   961: aload #7
/*      */     //   963: aload_0
/*      */     //   964: getfield writeTimeout : I
/*      */     //   967: invokevirtual setWriteTimeout : (I)V
/*      */     //   970: aload_0
/*      */     //   971: getfield tracer : Lio/opencensus/trace/Tracer;
/*      */     //   974: aload #5
/*      */     //   976: invokevirtual withSpan : (Lio/opencensus/trace/Span;)Lio/opencensus/common/Scope;
/*      */     //   979: astore #15
/*      */     //   981: aload #5
/*      */     //   983: aload #7
/*      */     //   985: invokevirtual getContentLength : ()J
/*      */     //   988: invokestatic recordSentMessageEvent : (Lio/opencensus/trace/Span;J)V
/*      */     //   991: aload #7
/*      */     //   993: invokevirtual execute : ()Lcom/google/api/client/http/LowLevelHttpResponse;
/*      */     //   996: astore #16
/*      */     //   998: aload #16
/*      */     //   1000: ifnull -> 1013
/*      */     //   1003: aload #5
/*      */     //   1005: aload #16
/*      */     //   1007: invokevirtual getContentLength : ()J
/*      */     //   1010: invokestatic recordReceivedMessageEvent : (Lio/opencensus/trace/Span;J)V
/*      */     //   1013: iconst_0
/*      */     //   1014: istore #17
/*      */     //   1016: new com/google/api/client/http/HttpResponse
/*      */     //   1019: dup
/*      */     //   1020: aload_0
/*      */     //   1021: aload #16
/*      */     //   1023: invokespecial <init> : (Lcom/google/api/client/http/HttpRequest;Lcom/google/api/client/http/LowLevelHttpResponse;)V
/*      */     //   1026: astore_3
/*      */     //   1027: iconst_1
/*      */     //   1028: istore #17
/*      */     //   1030: iload #17
/*      */     //   1032: ifne -> 1082
/*      */     //   1035: aload #16
/*      */     //   1037: invokevirtual getContent : ()Ljava/io/InputStream;
/*      */     //   1040: astore #18
/*      */     //   1042: aload #18
/*      */     //   1044: ifnull -> 1052
/*      */     //   1047: aload #18
/*      */     //   1049: invokevirtual close : ()V
/*      */     //   1052: goto -> 1082
/*      */     //   1055: astore #20
/*      */     //   1057: iload #17
/*      */     //   1059: ifne -> 1079
/*      */     //   1062: aload #16
/*      */     //   1064: invokevirtual getContent : ()Ljava/io/InputStream;
/*      */     //   1067: astore #21
/*      */     //   1069: aload #21
/*      */     //   1071: ifnull -> 1079
/*      */     //   1074: aload #21
/*      */     //   1076: invokevirtual close : ()V
/*      */     //   1079: aload #20
/*      */     //   1081: athrow
/*      */     //   1082: aload #15
/*      */     //   1084: invokeinterface close : ()V
/*      */     //   1089: goto -> 1177
/*      */     //   1092: astore #16
/*      */     //   1094: aload_0
/*      */     //   1095: getfield retryOnExecuteIOException : Z
/*      */     //   1098: ifne -> 1134
/*      */     //   1101: aload_0
/*      */     //   1102: getfield ioExceptionHandler : Lcom/google/api/client/http/HttpIOExceptionHandler;
/*      */     //   1105: ifnull -> 1122
/*      */     //   1108: aload_0
/*      */     //   1109: getfield ioExceptionHandler : Lcom/google/api/client/http/HttpIOExceptionHandler;
/*      */     //   1112: aload_0
/*      */     //   1113: iload_1
/*      */     //   1114: invokeinterface handleIOException : (Lcom/google/api/client/http/HttpRequest;Z)Z
/*      */     //   1119: ifne -> 1134
/*      */     //   1122: aload #5
/*      */     //   1124: aconst_null
/*      */     //   1125: invokestatic getEndSpanOptions : (Ljava/lang/Integer;)Lio/opencensus/trace/EndSpanOptions;
/*      */     //   1128: invokevirtual end : (Lio/opencensus/trace/EndSpanOptions;)V
/*      */     //   1131: aload #16
/*      */     //   1133: athrow
/*      */     //   1134: aload #16
/*      */     //   1136: astore #4
/*      */     //   1138: iload #9
/*      */     //   1140: ifeq -> 1155
/*      */     //   1143: aload #8
/*      */     //   1145: getstatic java/util/logging/Level.WARNING : Ljava/util/logging/Level;
/*      */     //   1148: ldc 'exception thrown while executing request'
/*      */     //   1150: aload #16
/*      */     //   1152: invokevirtual log : (Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V
/*      */     //   1155: aload #15
/*      */     //   1157: invokeinterface close : ()V
/*      */     //   1162: goto -> 1177
/*      */     //   1165: astore #22
/*      */     //   1167: aload #15
/*      */     //   1169: invokeinterface close : ()V
/*      */     //   1174: aload #22
/*      */     //   1176: athrow
/*      */     //   1177: iconst_0
/*      */     //   1178: istore #16
/*      */     //   1180: aload_3
/*      */     //   1181: ifnull -> 1323
/*      */     //   1184: aload_3
/*      */     //   1185: invokevirtual isSuccessStatusCode : ()Z
/*      */     //   1188: ifne -> 1323
/*      */     //   1191: iconst_0
/*      */     //   1192: istore #17
/*      */     //   1194: aload_0
/*      */     //   1195: getfield unsuccessfulResponseHandler : Lcom/google/api/client/http/HttpUnsuccessfulResponseHandler;
/*      */     //   1198: ifnull -> 1215
/*      */     //   1201: aload_0
/*      */     //   1202: getfield unsuccessfulResponseHandler : Lcom/google/api/client/http/HttpUnsuccessfulResponseHandler;
/*      */     //   1205: aload_0
/*      */     //   1206: aload_3
/*      */     //   1207: iload_1
/*      */     //   1208: invokeinterface handleResponse : (Lcom/google/api/client/http/HttpRequest;Lcom/google/api/client/http/HttpResponse;Z)Z
/*      */     //   1213: istore #17
/*      */     //   1215: iload #17
/*      */     //   1217: ifne -> 1307
/*      */     //   1220: aload_0
/*      */     //   1221: aload_3
/*      */     //   1222: invokevirtual getStatusCode : ()I
/*      */     //   1225: aload_3
/*      */     //   1226: invokevirtual getHeaders : ()Lcom/google/api/client/http/HttpHeaders;
/*      */     //   1229: invokevirtual handleRedirect : (ILcom/google/api/client/http/HttpHeaders;)Z
/*      */     //   1232: ifeq -> 1241
/*      */     //   1235: iconst_1
/*      */     //   1236: istore #17
/*      */     //   1238: goto -> 1307
/*      */     //   1241: iload_1
/*      */     //   1242: ifeq -> 1307
/*      */     //   1245: aload_0
/*      */     //   1246: getfield backOffPolicy : Lcom/google/api/client/http/BackOffPolicy;
/*      */     //   1249: ifnull -> 1307
/*      */     //   1252: aload_0
/*      */     //   1253: getfield backOffPolicy : Lcom/google/api/client/http/BackOffPolicy;
/*      */     //   1256: aload_3
/*      */     //   1257: invokevirtual getStatusCode : ()I
/*      */     //   1260: invokeinterface isBackOffRequired : (I)Z
/*      */     //   1265: ifeq -> 1307
/*      */     //   1268: aload_0
/*      */     //   1269: getfield backOffPolicy : Lcom/google/api/client/http/BackOffPolicy;
/*      */     //   1272: invokeinterface getNextBackOffMillis : ()J
/*      */     //   1277: lstore #18
/*      */     //   1279: lload #18
/*      */     //   1281: ldc2_w -1
/*      */     //   1284: lcmp
/*      */     //   1285: ifeq -> 1307
/*      */     //   1288: aload_0
/*      */     //   1289: getfield sleeper : Lcom/google/api/client/util/Sleeper;
/*      */     //   1292: lload #18
/*      */     //   1294: invokeinterface sleep : (J)V
/*      */     //   1299: goto -> 1304
/*      */     //   1302: astore #20
/*      */     //   1304: iconst_1
/*      */     //   1305: istore #17
/*      */     //   1307: iload_1
/*      */     //   1308: iload #17
/*      */     //   1310: iand
/*      */     //   1311: istore_1
/*      */     //   1312: iload_1
/*      */     //   1313: ifeq -> 1320
/*      */     //   1316: aload_3
/*      */     //   1317: invokevirtual ignore : ()V
/*      */     //   1320: goto -> 1335
/*      */     //   1323: iload_1
/*      */     //   1324: aload_3
/*      */     //   1325: ifnonnull -> 1332
/*      */     //   1328: iconst_1
/*      */     //   1329: goto -> 1333
/*      */     //   1332: iconst_0
/*      */     //   1333: iand
/*      */     //   1334: istore_1
/*      */     //   1335: iinc #2, -1
/*      */     //   1338: iconst_1
/*      */     //   1339: istore #16
/*      */     //   1341: aload_3
/*      */     //   1342: ifnull -> 1375
/*      */     //   1345: iload #16
/*      */     //   1347: ifne -> 1375
/*      */     //   1350: aload_3
/*      */     //   1351: invokevirtual disconnect : ()V
/*      */     //   1354: goto -> 1375
/*      */     //   1357: astore #23
/*      */     //   1359: aload_3
/*      */     //   1360: ifnull -> 1372
/*      */     //   1363: iload #16
/*      */     //   1365: ifne -> 1372
/*      */     //   1368: aload_3
/*      */     //   1369: invokevirtual disconnect : ()V
/*      */     //   1372: aload #23
/*      */     //   1374: athrow
/*      */     //   1375: iload_1
/*      */     //   1376: ifne -> 77
/*      */     //   1379: aload #5
/*      */     //   1381: aload_3
/*      */     //   1382: ifnonnull -> 1389
/*      */     //   1385: aconst_null
/*      */     //   1386: goto -> 1396
/*      */     //   1389: aload_3
/*      */     //   1390: invokevirtual getStatusCode : ()I
/*      */     //   1393: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   1396: invokestatic getEndSpanOptions : (Ljava/lang/Integer;)Lio/opencensus/trace/EndSpanOptions;
/*      */     //   1399: invokevirtual end : (Lio/opencensus/trace/EndSpanOptions;)V
/*      */     //   1402: aload_3
/*      */     //   1403: ifnonnull -> 1409
/*      */     //   1406: aload #4
/*      */     //   1408: athrow
/*      */     //   1409: aload_0
/*      */     //   1410: getfield responseInterceptor : Lcom/google/api/client/http/HttpResponseInterceptor;
/*      */     //   1413: ifnull -> 1426
/*      */     //   1416: aload_0
/*      */     //   1417: getfield responseInterceptor : Lcom/google/api/client/http/HttpResponseInterceptor;
/*      */     //   1420: aload_3
/*      */     //   1421: invokeinterface interceptResponse : (Lcom/google/api/client/http/HttpResponse;)V
/*      */     //   1426: aload_0
/*      */     //   1427: getfield throwExceptionOnExecuteError : Z
/*      */     //   1430: ifeq -> 1458
/*      */     //   1433: aload_3
/*      */     //   1434: invokevirtual isSuccessStatusCode : ()Z
/*      */     //   1437: ifne -> 1458
/*      */     //   1440: new com/google/api/client/http/HttpResponseException
/*      */     //   1443: dup
/*      */     //   1444: aload_3
/*      */     //   1445: invokespecial <init> : (Lcom/google/api/client/http/HttpResponse;)V
/*      */     //   1448: athrow
/*      */     //   1449: astore #24
/*      */     //   1451: aload_3
/*      */     //   1452: invokevirtual disconnect : ()V
/*      */     //   1455: aload #24
/*      */     //   1457: athrow
/*      */     //   1458: aload_3
/*      */     //   1459: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #833	-> 0
/*      */     //   #834	-> 2
/*      */     //   #835	-> 17
/*      */     //   #836	-> 22
/*      */     //   #838	-> 29
/*      */     //   #840	-> 38
/*      */     //   #843	-> 40
/*      */     //   #844	-> 48
/*      */     //   #846	-> 56
/*      */     //   #848	-> 63
/*      */     //   #849	-> 66
/*      */     //   #850	-> 72
/*      */     //   #852	-> 77
/*      */     //   #854	-> 106
/*      */     //   #855	-> 110
/*      */     //   #858	-> 114
/*      */     //   #859	-> 116
/*      */     //   #862	-> 119
/*      */     //   #863	-> 126
/*      */     //   #866	-> 136
/*      */     //   #867	-> 145
/*      */     //   #868	-> 156
/*      */     //   #869	-> 170
/*      */     //   #870	-> 184
/*      */     //   #872	-> 193
/*      */     //   #873	-> 208
/*      */     //   #874	-> 213
/*      */     //   #875	-> 238
/*      */     //   #876	-> 241
/*      */     //   #878	-> 244
/*      */     //   #879	-> 249
/*      */     //   #880	-> 258
/*      */     //   #881	-> 272
/*      */     //   #882	-> 278
/*      */     //   #883	-> 283
/*      */     //   #884	-> 288
/*      */     //   #885	-> 294
/*      */     //   #888	-> 298
/*      */     //   #889	-> 305
/*      */     //   #890	-> 316
/*      */     //   #891	-> 328
/*      */     //   #896	-> 343
/*      */     //   #897	-> 352
/*      */     //   #898	-> 359
/*      */     //   #899	-> 364
/*      */     //   #900	-> 375
/*      */     //   #902	-> 388
/*      */     //   #903	-> 416
/*      */     //   #904	-> 426
/*      */     //   #907	-> 435
/*      */     //   #910	-> 444
/*      */     //   #911	-> 459
/*      */     //   #913	-> 466
/*      */     //   #917	-> 476
/*      */     //   #918	-> 482
/*      */     //   #919	-> 506
/*      */     //   #922	-> 511
/*      */     //   #924	-> 522
/*      */     //   #925	-> 527
/*      */     //   #930	-> 548
/*      */     //   #931	-> 555
/*      */     //   #932	-> 558
/*      */     //   #934	-> 572
/*      */     //   #935	-> 583
/*      */     //   #936	-> 598
/*      */     //   #939	-> 616
/*      */     //   #940	-> 621
/*      */     //   #941	-> 626
/*      */     //   #942	-> 648
/*      */     //   #943	-> 662
/*      */     //   #944	-> 667
/*      */     //   #947	-> 698
/*      */     //   #948	-> 703
/*      */     //   #949	-> 725
/*      */     //   #950	-> 739
/*      */     //   #951	-> 744
/*      */     //   #954	-> 775
/*      */     //   #955	-> 782
/*      */     //   #956	-> 804
/*      */     //   #960	-> 818
/*      */     //   #961	-> 823
/*      */     //   #964	-> 831
/*      */     //   #965	-> 838
/*      */     //   #966	-> 845
/*      */     //   #967	-> 852
/*      */     //   #970	-> 859
/*      */     //   #971	-> 864
/*      */     //   #972	-> 874
/*      */     //   #973	-> 879
/*      */     //   #974	-> 887
/*      */     //   #975	-> 902
/*      */     //   #976	-> 910
/*      */     //   #977	-> 915
/*      */     //   #979	-> 923
/*      */     //   #985	-> 933
/*      */     //   #988	-> 948
/*      */     //   #989	-> 961
/*      */     //   #993	-> 970
/*      */     //   #994	-> 981
/*      */     //   #996	-> 991
/*      */     //   #997	-> 998
/*      */     //   #998	-> 1003
/*      */     //   #1001	-> 1013
/*      */     //   #1003	-> 1016
/*      */     //   #1004	-> 1027
/*      */     //   #1006	-> 1030
/*      */     //   #1007	-> 1035
/*      */     //   #1008	-> 1042
/*      */     //   #1009	-> 1047
/*      */     //   #1011	-> 1052
/*      */     //   #1006	-> 1055
/*      */     //   #1007	-> 1062
/*      */     //   #1008	-> 1069
/*      */     //   #1009	-> 1074
/*      */     //   #1012	-> 1079
/*      */     //   #1027	-> 1082
/*      */     //   #1028	-> 1089
/*      */     //   #1013	-> 1092
/*      */     //   #1014	-> 1094
/*      */     //   #1016	-> 1114
/*      */     //   #1018	-> 1122
/*      */     //   #1019	-> 1131
/*      */     //   #1022	-> 1134
/*      */     //   #1023	-> 1138
/*      */     //   #1024	-> 1143
/*      */     //   #1027	-> 1155
/*      */     //   #1028	-> 1162
/*      */     //   #1027	-> 1165
/*      */     //   #1028	-> 1174
/*      */     //   #1032	-> 1177
/*      */     //   #1034	-> 1180
/*      */     //   #1035	-> 1191
/*      */     //   #1036	-> 1194
/*      */     //   #1040	-> 1201
/*      */     //   #1042	-> 1215
/*      */     //   #1043	-> 1220
/*      */     //   #1045	-> 1235
/*      */     //   #1046	-> 1241
/*      */     //   #1048	-> 1257
/*      */     //   #1051	-> 1268
/*      */     //   #1052	-> 1279
/*      */     //   #1054	-> 1288
/*      */     //   #1057	-> 1299
/*      */     //   #1055	-> 1302
/*      */     //   #1058	-> 1304
/*      */     //   #1064	-> 1307
/*      */     //   #1066	-> 1312
/*      */     //   #1067	-> 1316
/*      */     //   #1069	-> 1320
/*      */     //   #1071	-> 1323
/*      */     //   #1075	-> 1335
/*      */     //   #1077	-> 1338
/*      */     //   #1079	-> 1341
/*      */     //   #1080	-> 1350
/*      */     //   #1079	-> 1357
/*      */     //   #1080	-> 1368
/*      */     //   #1082	-> 1372
/*      */     //   #1083	-> 1375
/*      */     //   #1084	-> 1379
/*      */     //   #1086	-> 1402
/*      */     //   #1088	-> 1406
/*      */     //   #1091	-> 1409
/*      */     //   #1092	-> 1416
/*      */     //   #1095	-> 1426
/*      */     //   #1097	-> 1440
/*      */     //   #1099	-> 1449
/*      */     //   #1100	-> 1455
/*      */     //   #1102	-> 1458
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   416	19	13	newUserAgent	Ljava/lang/String;
/*      */     //   558	14	15	contentEncoding	Ljava/lang/String;
/*      */     //   569	3	16	contentLength	J
/*      */     //   648	50	19	header	Ljava/lang/String;
/*      */     //   725	50	19	header	Ljava/lang/String;
/*      */     //   804	14	19	header	Ljava/lang/String;
/*      */     //   583	276	15	contentEncoding	Ljava/lang/String;
/*      */     //   616	243	16	contentLength	J
/*      */     //   522	337	18	contentType	Ljava/lang/String;
/*      */     //   1042	10	18	lowLevelContent	Ljava/io/InputStream;
/*      */     //   1069	10	21	lowLevelContent	Ljava/io/InputStream;
/*      */     //   998	84	16	lowLevelHttpResponse	Lcom/google/api/client/http/LowLevelHttpResponse;
/*      */     //   1016	66	17	responseConstructed	Z
/*      */     //   1094	61	16	e	Ljava/io/IOException;
/*      */     //   1279	28	18	backOffTime	J
/*      */     //   1194	126	17	errorHandled	Z
/*      */     //   145	1230	6	urlString	Ljava/lang/String;
/*      */     //   208	1167	7	lowLevelHttpRequest	Lcom/google/api/client/http/LowLevelHttpRequest;
/*      */     //   213	1162	8	logger	Ljava/util/logging/Logger;
/*      */     //   238	1137	9	loggable	Z
/*      */     //   241	1134	10	logbuf	Ljava/lang/StringBuilder;
/*      */     //   244	1131	11	curlbuf	Ljava/lang/StringBuilder;
/*      */     //   352	1023	12	originalUserAgent	Ljava/lang/String;
/*      */     //   482	893	13	streamingContent	Lcom/google/api/client/util/StreamingContent;
/*      */     //   506	869	14	contentRetrySupported	Z
/*      */     //   981	394	15	ws	Lio/opencensus/common/Scope;
/*      */     //   1180	195	16	responseProcessed	Z
/*      */     //   0	1460	0	this	Lcom/google/api/client/http/HttpRequest;
/*      */     //   2	1458	1	retryRequest	Z
/*      */     //   22	1438	2	retriesRemaining	I
/*      */     //   40	1420	3	response	Lcom/google/api/client/http/HttpResponse;
/*      */     //   119	1341	4	executeException	Ljava/io/IOException;
/*      */     //   77	1383	5	span	Lio/opencensus/trace/Span;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   991	1082	1092	java/io/IOException
/*      */     //   991	1082	1165	finally
/*      */     //   1016	1030	1055	finally
/*      */     //   1055	1057	1055	finally
/*      */     //   1092	1155	1165	finally
/*      */     //   1165	1167	1165	finally
/*      */     //   1180	1341	1357	finally
/*      */     //   1288	1299	1302	java/lang/InterruptedException
/*      */     //   1357	1359	1357	finally
/*      */     //   1440	1451	1449	finally
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Beta
/*      */   public Future<HttpResponse> executeAsync(Executor executor) {
/* 1115 */     FutureTask<HttpResponse> future = new FutureTask<>(new Callable<HttpResponse>()
/*      */         {
/*      */           
/*      */           public HttpResponse call() throws Exception
/*      */           {
/* 1120 */             return HttpRequest.this.execute();
/*      */           }
/*      */         });
/* 1123 */     executor.execute(future);
/* 1124 */     return future;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Beta
/*      */   public Future<HttpResponse> executeAsync() {
/* 1137 */     return executeAsync(
/* 1138 */         Executors.newFixedThreadPool(1, (new ThreadFactoryBuilder()).setDaemon(true).build()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean handleRedirect(int statusCode, HttpHeaders responseHeaders) {
/* 1157 */     String redirectLocation = responseHeaders.getLocation();
/* 1158 */     if (getFollowRedirects() && 
/* 1159 */       HttpStatusCodes.isRedirect(statusCode) && redirectLocation != null) {
/*      */ 
/*      */       
/* 1162 */       setUrl(new GenericUrl(this.url.toURL(redirectLocation)));
/*      */       
/* 1164 */       if (statusCode == 303) {
/* 1165 */         setRequestMethod("GET");
/*      */         
/* 1167 */         setContent(null);
/*      */       } 
/*      */       
/* 1170 */       this.headers.setAuthorization((String)null);
/* 1171 */       this.headers.setIfMatch((String)null);
/* 1172 */       this.headers.setIfNoneMatch((String)null);
/* 1173 */       this.headers.setIfModifiedSince((String)null);
/* 1174 */       this.headers.setIfUnmodifiedSince((String)null);
/* 1175 */       this.headers.setIfRange((String)null);
/* 1176 */       return true;
/*      */     } 
/* 1178 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Sleeper getSleeper() {
/* 1187 */     return this.sleeper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpRequest setSleeper(Sleeper sleeper) {
/* 1196 */     this.sleeper = (Sleeper)Preconditions.checkNotNull(sleeper);
/* 1197 */     return this;
/*      */   }
/*      */   
/*      */   private static void addSpanAttribute(Span span, String key, String value) {
/* 1201 */     if (value != null) {
/* 1202 */       span.putAttribute(key, AttributeValue.stringAttributeValue(value));
/*      */     }
/*      */   }
/*      */   
/*      */   private static String getVersion() {
/* 1207 */     String version = HttpRequest.class.getPackage().getImplementationVersion();
/*      */     
/* 1209 */     if (version == null)
/*      */     {
/* 1211 */       try (InputStream inputStream = HttpRequest.class.getResourceAsStream("/google-http-client.properties")) {
/* 1212 */         if (inputStream != null) {
/* 1213 */           Properties properties = new Properties();
/* 1214 */           properties.load(inputStream);
/* 1215 */           version = properties.getProperty("google-http-client.version");
/*      */         } 
/* 1217 */       } catch (IOException iOException) {}
/*      */     }
/*      */ 
/*      */     
/* 1221 */     return version;
/*      */   }
/*      */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */