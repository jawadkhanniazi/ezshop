/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.Charsets;
/*     */ import com.google.api.client.util.IOUtils;
/*     */ import com.google.api.client.util.LoggingInputStream;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpResponse
/*     */ {
/*     */   private InputStream content;
/*     */   private final String contentEncoding;
/*     */   private final String contentType;
/*     */   private final HttpMediaType mediaType;
/*     */   LowLevelHttpResponse response;
/*     */   private final int statusCode;
/*     */   private final String statusMessage;
/*     */   private final HttpRequest request;
/*     */   private final boolean returnRawInputStream;
/*     */   private int contentLoggingLimit;
/*     */   private boolean loggingEnabled;
/*     */   private boolean contentRead;
/*     */   
/*     */   HttpResponse(HttpRequest request, LowLevelHttpResponse response) throws IOException {
/* 108 */     this.request = request;
/* 109 */     this.returnRawInputStream = request.getResponseReturnRawInputStream();
/* 110 */     this.contentLoggingLimit = request.getContentLoggingLimit();
/* 111 */     this.loggingEnabled = request.isLoggingEnabled();
/* 112 */     this.response = response;
/* 113 */     this.contentEncoding = response.getContentEncoding();
/* 114 */     int code = response.getStatusCode();
/* 115 */     this.statusCode = (code < 0) ? 0 : code;
/* 116 */     String message = response.getReasonPhrase();
/* 117 */     this.statusMessage = message;
/* 118 */     Logger logger = HttpTransport.LOGGER;
/* 119 */     boolean loggable = (this.loggingEnabled && logger.isLoggable(Level.CONFIG));
/* 120 */     StringBuilder logbuf = null;
/* 121 */     if (loggable) {
/* 122 */       logbuf = new StringBuilder();
/* 123 */       logbuf.append("-------------- RESPONSE --------------").append(StringUtils.LINE_SEPARATOR);
/* 124 */       String statusLine = response.getStatusLine();
/* 125 */       if (statusLine != null) {
/* 126 */         logbuf.append(statusLine);
/*     */       } else {
/* 128 */         logbuf.append(this.statusCode);
/* 129 */         if (message != null) {
/* 130 */           logbuf.append(' ').append(message);
/*     */         }
/*     */       } 
/* 133 */       logbuf.append(StringUtils.LINE_SEPARATOR);
/*     */     } 
/*     */ 
/*     */     
/* 137 */     request.getResponseHeaders().fromHttpResponse(response, loggable ? logbuf : null);
/*     */ 
/*     */ 
/*     */     
/* 141 */     String contentType = response.getContentType();
/* 142 */     if (contentType == null) {
/* 143 */       contentType = request.getResponseHeaders().getContentType();
/*     */     }
/* 145 */     this.contentType = contentType;
/* 146 */     this.mediaType = (contentType == null) ? null : new HttpMediaType(contentType);
/*     */ 
/*     */     
/* 149 */     if (loggable) {
/* 150 */       logger.config(logbuf.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getContentLoggingLimit() {
/* 169 */     return this.contentLoggingLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponse setContentLoggingLimit(int contentLoggingLimit) {
/* 187 */     Preconditions.checkArgument((contentLoggingLimit >= 0), "The content logging limit must be non-negative.");
/*     */     
/* 189 */     this.contentLoggingLimit = contentLoggingLimit;
/* 190 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLoggingEnabled() {
/* 201 */     return this.loggingEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponse setLoggingEnabled(boolean loggingEnabled) {
/* 212 */     this.loggingEnabled = loggingEnabled;
/* 213 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/* 222 */     return this.contentEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 231 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpMediaType getMediaType() {
/* 241 */     return this.mediaType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpHeaders getHeaders() {
/* 250 */     return this.request.getResponseHeaders();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuccessStatusCode() {
/* 260 */     return HttpStatusCodes.isSuccess(this.statusCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStatusCode() {
/* 269 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatusMessage() {
/* 278 */     return this.statusMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpTransport getTransport() {
/* 287 */     return this.request.getTransport();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest getRequest() {
/* 296 */     return this.request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getContent() throws IOException {
/* 322 */     if (!this.contentRead) {
/* 323 */       InputStream lowLevelResponseContent = this.response.getContent();
/* 324 */       if (lowLevelResponseContent != null) {
/*     */         LoggingInputStream loggingInputStream;
/*     */         
/* 327 */         boolean contentProcessed = false;
/*     */         
/*     */         try {
/* 330 */           String contentEncoding = this.contentEncoding;
/* 331 */           if (!this.returnRawInputStream && contentEncoding != null && contentEncoding
/*     */             
/* 333 */             .contains("gzip")) {
/* 334 */             lowLevelResponseContent = new GZIPInputStream(lowLevelResponseContent);
/*     */           }
/*     */           
/* 337 */           Logger logger = HttpTransport.LOGGER;
/* 338 */           if (this.loggingEnabled && logger.isLoggable(Level.CONFIG)) {
/* 339 */             loggingInputStream = new LoggingInputStream(lowLevelResponseContent, logger, Level.CONFIG, this.contentLoggingLimit);
/*     */           }
/*     */ 
/*     */           
/* 343 */           this.content = (InputStream)loggingInputStream;
/* 344 */           contentProcessed = true;
/* 345 */         } catch (EOFException eOFException) {
/*     */ 
/*     */         
/*     */         } finally {
/* 349 */           if (!contentProcessed) {
/* 350 */             loggingInputStream.close();
/*     */           }
/*     */         } 
/*     */       } 
/* 354 */       this.contentRead = true;
/*     */     } 
/* 356 */     return this.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void download(OutputStream outputStream) throws IOException {
/* 385 */     InputStream inputStream = getContent();
/* 386 */     IOUtils.copy(inputStream, outputStream);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ignore() throws IOException {
/* 391 */     InputStream content = getContent();
/* 392 */     if (content != null) {
/* 393 */       content.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() throws IOException {
/* 404 */     ignore();
/* 405 */     this.response.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T parseAs(Class<T> dataClass) throws IOException {
/* 417 */     if (!hasMessageBody()) {
/* 418 */       return null;
/*     */     }
/* 420 */     return (T)this.request.getParser().parseAndClose(getContent(), getContentCharset(), dataClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasMessageBody() throws IOException {
/* 428 */     int statusCode = getStatusCode();
/* 429 */     if (getRequest().getRequestMethod().equals("HEAD") || statusCode / 100 == 1 || statusCode == 204 || statusCode == 304) {
/*     */ 
/*     */ 
/*     */       
/* 433 */       ignore();
/* 434 */       return false;
/*     */     } 
/* 436 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object parseAs(Type dataType) throws IOException {
/* 447 */     if (!hasMessageBody()) {
/* 448 */       return null;
/*     */     }
/* 450 */     return this.request.getParser().parseAndClose(getContent(), getContentCharset(), dataType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String parseAsString() throws IOException {
/* 468 */     InputStream content = getContent();
/* 469 */     if (content == null) {
/* 470 */       return "";
/*     */     }
/* 472 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 473 */     IOUtils.copy(content, out);
/* 474 */     return out.toString(getContentCharset().name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Charset getContentCharset() {
/* 484 */     return (this.mediaType == null || this.mediaType.getCharsetParameter() == null) ? Charsets.ISO_8859_1 : this.mediaType
/*     */       
/* 486 */       .getCharsetParameter();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\HttpResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */