/*     */ package com.google.api.client.http;
/*     */ 
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.escape.CharEscapers;
/*     */ import com.google.api.client.util.escape.Escaper;
/*     */ import com.google.api.client.util.escape.PercentEscaper;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericUrl
/*     */   extends GenericData
/*     */ {
/*  55 */   private static final Escaper URI_FRAGMENT_ESCAPER = (Escaper)new PercentEscaper("=&-_.!~*'()@:$,;/?:", false);
/*     */ 
/*     */ 
/*     */   
/*     */   private String scheme;
/*     */ 
/*     */   
/*     */   private String host;
/*     */ 
/*     */   
/*     */   private String userInfo;
/*     */ 
/*     */   
/*  68 */   private int port = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> pathParts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fragment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericUrl(String encodedUrl) {
/* 102 */     this(parseURL(encodedUrl));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericUrl(URI uri) {
/* 112 */     this(uri
/* 113 */         .getScheme(), uri
/* 114 */         .getHost(), uri
/* 115 */         .getPort(), uri
/* 116 */         .getRawPath(), uri
/* 117 */         .getRawFragment(), uri
/* 118 */         .getRawQuery(), uri
/* 119 */         .getRawUserInfo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericUrl(URL url) {
/* 129 */     this(url
/* 130 */         .getProtocol(), url
/* 131 */         .getHost(), url
/* 132 */         .getPort(), url
/* 133 */         .getPath(), url
/* 134 */         .getRef(), url
/* 135 */         .getQuery(), url
/* 136 */         .getUserInfo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GenericUrl(String scheme, String host, int port, String path, String fragment, String query, String userInfo) {
/* 147 */     this.scheme = scheme.toLowerCase(Locale.US);
/* 148 */     this.host = host;
/* 149 */     this.port = port;
/* 150 */     this.pathParts = toPathParts(path);
/* 151 */     this.fragment = (fragment != null) ? CharEscapers.decodeUri(fragment) : null;
/* 152 */     if (query != null) {
/* 153 */       UrlEncodedParser.parse(query, this);
/*     */     }
/* 155 */     this.userInfo = (userInfo != null) ? CharEscapers.decodeUri(userInfo) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 161 */     return build().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 166 */     if (this == obj) {
/* 167 */       return true;
/*     */     }
/* 169 */     if (!super.equals(obj) || !(obj instanceof GenericUrl)) {
/* 170 */       return false;
/*     */     }
/* 172 */     GenericUrl other = (GenericUrl)obj;
/*     */     
/* 174 */     return build().equals(other.build());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 179 */     return build();
/*     */   }
/*     */ 
/*     */   
/*     */   public GenericUrl clone() {
/* 184 */     GenericUrl result = (GenericUrl)super.clone();
/* 185 */     if (this.pathParts != null) {
/* 186 */       result.pathParts = new ArrayList<>(this.pathParts);
/*     */     }
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public GenericUrl set(String fieldName, Object value) {
/* 193 */     return (GenericUrl)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getScheme() {
/* 202 */     return this.scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setScheme(String scheme) {
/* 211 */     this.scheme = (String)Preconditions.checkNotNull(scheme);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() {
/* 220 */     return this.host;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHost(String host) {
/* 229 */     this.host = (String)Preconditions.checkNotNull(host);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getUserInfo() {
/* 238 */     return this.userInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setUserInfo(String userInfo) {
/* 247 */     this.userInfo = userInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 256 */     return this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPort(int port) {
/* 265 */     Preconditions.checkArgument((port >= -1), "expected port >= -1");
/* 266 */     this.port = port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getPathParts() {
/* 276 */     return this.pathParts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPathParts(List<String> pathParts) {
/* 292 */     this.pathParts = pathParts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFragment() {
/* 301 */     return this.fragment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setFragment(String fragment) {
/* 310 */     this.fragment = fragment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String build() {
/* 318 */     return buildAuthority() + buildRelativeUrl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String buildAuthority() {
/* 332 */     StringBuilder buf = new StringBuilder();
/* 333 */     buf.append((String)Preconditions.checkNotNull(this.scheme));
/* 334 */     buf.append("://");
/* 335 */     if (this.userInfo != null) {
/* 336 */       buf.append(CharEscapers.escapeUriUserInfo(this.userInfo)).append('@');
/*     */     }
/* 338 */     buf.append((String)Preconditions.checkNotNull(this.host));
/* 339 */     int port = this.port;
/* 340 */     if (port != -1) {
/* 341 */       buf.append(':').append(port);
/*     */     }
/* 343 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String buildRelativeUrl() {
/* 356 */     StringBuilder buf = new StringBuilder();
/* 357 */     if (this.pathParts != null) {
/* 358 */       appendRawPathFromParts(buf);
/*     */     }
/* 360 */     addQueryParams(entrySet(), buf);
/*     */ 
/*     */     
/* 363 */     String fragment = this.fragment;
/* 364 */     if (fragment != null) {
/* 365 */       buf.append('#').append(URI_FRAGMENT_ESCAPER.escape(fragment));
/*     */     }
/* 367 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final URI toURI() {
/* 379 */     return toURI(build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final URL toURL() {
/* 391 */     return parseURL(build());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final URL toURL(String relativeUrl) {
/*     */     try {
/* 405 */       URL url = toURL();
/* 406 */       return new URL(url, relativeUrl);
/* 407 */     } catch (MalformedURLException e) {
/* 408 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getFirst(String name) {
/* 419 */     Object value = get(name);
/* 420 */     if (value instanceof Collection) {
/*     */       
/* 422 */       Collection<Object> collectionValue = (Collection<Object>)value;
/* 423 */       Iterator<Object> iterator = collectionValue.iterator();
/* 424 */       return iterator.hasNext() ? iterator.next() : null;
/*     */     } 
/* 426 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Object> getAll(String name) {
/* 436 */     Object value = get(name);
/* 437 */     if (value == null) {
/* 438 */       return Collections.emptySet();
/*     */     }
/* 440 */     if (value instanceof Collection) {
/*     */       
/* 442 */       Collection<Object> collectionValue = (Collection<Object>)value;
/* 443 */       return Collections.unmodifiableCollection(collectionValue);
/*     */     } 
/* 445 */     return Collections.singleton(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRawPath() {
/* 455 */     List<String> pathParts = this.pathParts;
/* 456 */     if (pathParts == null) {
/* 457 */       return null;
/*     */     }
/* 459 */     StringBuilder buf = new StringBuilder();
/* 460 */     appendRawPathFromParts(buf);
/* 461 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRawPath(String encodedPath) {
/* 470 */     this.pathParts = toPathParts(encodedPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendRawPath(String encodedPath) {
/* 484 */     if (encodedPath != null && encodedPath.length() != 0) {
/* 485 */       List<String> appendedPathParts = toPathParts(encodedPath);
/* 486 */       if (this.pathParts == null || this.pathParts.isEmpty()) {
/* 487 */         this.pathParts = appendedPathParts;
/*     */       } else {
/* 489 */         int size = this.pathParts.size();
/* 490 */         this.pathParts.set(size - 1, (String)this.pathParts.get(size - 1) + (String)appendedPathParts.get(0));
/* 491 */         this.pathParts.addAll(appendedPathParts.subList(1, appendedPathParts.size()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> toPathParts(String encodedPath) {
/* 506 */     if (encodedPath == null || encodedPath.length() == 0) {
/* 507 */       return null;
/*     */     }
/* 509 */     List<String> result = new ArrayList<>();
/* 510 */     int cur = 0;
/* 511 */     boolean notDone = true;
/* 512 */     while (notDone) {
/* 513 */       String sub; int slash = encodedPath.indexOf('/', cur);
/* 514 */       notDone = (slash != -1);
/*     */       
/* 516 */       if (notDone) {
/* 517 */         sub = encodedPath.substring(cur, slash);
/*     */       } else {
/* 519 */         sub = encodedPath.substring(cur);
/*     */       } 
/* 521 */       result.add(CharEscapers.decodeUri(sub));
/* 522 */       cur = slash + 1;
/*     */     } 
/* 524 */     return result;
/*     */   }
/*     */   
/*     */   private void appendRawPathFromParts(StringBuilder buf) {
/* 528 */     int size = this.pathParts.size();
/* 529 */     for (int i = 0; i < size; i++) {
/* 530 */       String pathPart = this.pathParts.get(i);
/* 531 */       if (i != 0) {
/* 532 */         buf.append('/');
/*     */       }
/* 534 */       if (pathPart.length() != 0) {
/* 535 */         buf.append(CharEscapers.escapeUriPath(pathPart));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void addQueryParams(Set<Map.Entry<String, Object>> entrySet, StringBuilder buf) {
/* 543 */     boolean first = true;
/* 544 */     for (Map.Entry<String, Object> nameValueEntry : entrySet) {
/* 545 */       Object value = nameValueEntry.getValue();
/* 546 */       if (value != null) {
/* 547 */         String name = CharEscapers.escapeUriQuery(nameValueEntry.getKey());
/* 548 */         if (value instanceof Collection) {
/* 549 */           Collection<?> collectionValue = (Collection)value;
/* 550 */           for (Object repeatedValue : collectionValue)
/* 551 */             first = appendParam(first, buf, name, repeatedValue); 
/*     */           continue;
/*     */         } 
/* 554 */         first = appendParam(first, buf, name, value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean appendParam(boolean first, StringBuilder buf, String name, Object value) {
/* 561 */     if (first) {
/* 562 */       first = false;
/* 563 */       buf.append('?');
/*     */     } else {
/* 565 */       buf.append('&');
/*     */     } 
/* 567 */     buf.append(name);
/* 568 */     String stringValue = CharEscapers.escapeUriQuery(value.toString());
/* 569 */     if (stringValue.length() != 0) {
/* 570 */       buf.append('=').append(stringValue);
/*     */     }
/* 572 */     return first;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URI toURI(String encodedUrl) {
/*     */     try {
/* 585 */       return new URI(encodedUrl);
/* 586 */     } catch (URISyntaxException e) {
/* 587 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URL parseURL(String encodedUrl) {
/*     */     try {
/* 601 */       return new URL(encodedUrl);
/* 602 */     } catch (MalformedURLException e) {
/* 603 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public GenericUrl() {}
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\GenericUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */