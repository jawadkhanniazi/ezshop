/*    */ package com.google.api.client.http;
/*    */ 
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BasicAuthentication
/*    */   implements HttpRequestInitializer, HttpExecuteInterceptor
/*    */ {
/*    */   private final String username;
/*    */   private final String password;
/*    */   
/*    */   public BasicAuthentication(String username, String password) {
/* 39 */     this.username = (String)Preconditions.checkNotNull(username);
/* 40 */     this.password = (String)Preconditions.checkNotNull(password);
/*    */   }
/*    */   
/*    */   public void initialize(HttpRequest request) throws IOException {
/* 44 */     request.setInterceptor(this);
/*    */   }
/*    */   
/*    */   public void intercept(HttpRequest request) throws IOException {
/* 48 */     request.getHeaders().setBasicAuthentication(this.username, this.password);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 53 */     return this.username;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPassword() {
/* 58 */     return this.password;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\http\BasicAuthentication.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */