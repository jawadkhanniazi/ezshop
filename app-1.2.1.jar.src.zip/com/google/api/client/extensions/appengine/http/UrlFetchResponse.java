/*     */ package com.google.api.client.extensions.appengine.http;
/*     */ 
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import com.google.appengine.api.urlfetch.HTTPHeader;
/*     */ import com.google.appengine.api.urlfetch.HTTPResponse;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UrlFetchResponse
/*     */   extends LowLevelHttpResponse
/*     */ {
/*  26 */   private final ArrayList<String> headerNames = new ArrayList<>();
/*  27 */   private final ArrayList<String> headerValues = new ArrayList<>();
/*     */   private final HTTPResponse fetchResponse;
/*     */   private String contentEncoding;
/*     */   private String contentType;
/*     */   private long contentLength;
/*     */   
/*     */   UrlFetchResponse(HTTPResponse fetchResponse) {
/*  34 */     this.fetchResponse = fetchResponse;
/*  35 */     for (HTTPHeader header : fetchResponse.getHeadersUncombined()) {
/*  36 */       String name = header.getName();
/*  37 */       String value = header.getValue();
/*  38 */       if (name != null && value != null) {
/*  39 */         this.headerNames.add(name);
/*  40 */         this.headerValues.add(value);
/*  41 */         if ("content-type".equalsIgnoreCase(name)) {
/*  42 */           this.contentType = value; continue;
/*  43 */         }  if ("content-encoding".equalsIgnoreCase(name)) {
/*  44 */           this.contentEncoding = value; continue;
/*  45 */         }  if ("content-length".equalsIgnoreCase(name)) {
/*     */           try {
/*  47 */             this.contentLength = Long.parseLong(value);
/*  48 */           } catch (NumberFormatException numberFormatException) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStatusCode() {
/*  58 */     return this.fetchResponse.getResponseCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContent() {
/*  63 */     byte[] content = this.fetchResponse.getContent();
/*  64 */     return (content == null) ? null : new ByteArrayInputStream(content);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/*  69 */     return this.contentEncoding;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/*  74 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/*  79 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReasonPhrase() {
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatusLine() {
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeaderCount() {
/*  96 */     return this.headerNames.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderName(int index) {
/* 101 */     return this.headerNames.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderValue(int index) {
/* 106 */     return this.headerValues.get(index);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\extensions\appengine\http\UrlFetchResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */