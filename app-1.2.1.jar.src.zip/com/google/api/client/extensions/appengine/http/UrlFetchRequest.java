/*    */ package com.google.api.client.extensions.appengine.http;
/*    */ 
/*    */ import com.google.api.client.http.LowLevelHttpRequest;
/*    */ import com.google.api.client.http.LowLevelHttpResponse;
/*    */ import com.google.appengine.api.urlfetch.FetchOptions;
/*    */ import com.google.appengine.api.urlfetch.HTTPHeader;
/*    */ import com.google.appengine.api.urlfetch.HTTPMethod;
/*    */ import com.google.appengine.api.urlfetch.HTTPRequest;
/*    */ import com.google.appengine.api.urlfetch.HTTPResponse;
/*    */ import com.google.appengine.api.urlfetch.URLFetchService;
/*    */ import com.google.appengine.api.urlfetch.URLFetchServiceFactory;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class UrlFetchRequest
/*    */   extends LowLevelHttpRequest
/*    */ {
/*    */   private final HTTPRequest request;
/*    */   
/*    */   UrlFetchRequest(FetchOptions fetchOptions, HTTPMethod method, String url) throws IOException {
/* 36 */     this.request = new HTTPRequest(new URL(url), method, fetchOptions);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addHeader(String name, String value) {
/* 41 */     this.request.addHeader(new HTTPHeader(name, value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setTimeout(int connectTimeout, int readTimeout) {
/* 46 */     this.request
/* 47 */       .getFetchOptions()
/* 48 */       .setDeadline(
/* 49 */         Double.valueOf((connectTimeout == 0 || readTimeout == 0) ? Double.MAX_VALUE : ((connectTimeout + readTimeout) / 1000.0D)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LowLevelHttpResponse execute() throws IOException {
/* 57 */     if (getStreamingContent() != null) {
/* 58 */       String contentType = getContentType();
/* 59 */       if (contentType != null) {
/* 60 */         addHeader("Content-Type", contentType);
/*    */       }
/* 62 */       String contentEncoding = getContentEncoding();
/* 63 */       if (contentEncoding != null) {
/* 64 */         addHeader("Content-Encoding", contentEncoding);
/*    */       }
/* 66 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 67 */       getStreamingContent().writeTo(out);
/* 68 */       byte[] payload = out.toByteArray();
/* 69 */       if (payload.length != 0) {
/* 70 */         this.request.setPayload(payload);
/*    */       }
/*    */     } 
/*    */     
/* 74 */     URLFetchService service = URLFetchServiceFactory.getURLFetchService();
/* 75 */     HTTPResponse response = service.fetch(this.request);
/* 76 */     return new UrlFetchResponse(response);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\extensions\appengine\http\UrlFetchRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */