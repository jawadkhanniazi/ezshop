/*     */ package com.google.api.client.extensions.appengine.http;
/*     */ 
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.appengine.api.urlfetch.FetchOptions;
/*     */ import com.google.appengine.api.urlfetch.HTTPMethod;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UrlFetchTransport
/*     */   extends HttpTransport
/*     */ {
/*     */   enum CertificateValidationBehavior
/*     */   {
/*  53 */     DEFAULT,
/*  54 */     VALIDATE,
/*  55 */     DO_NOT_VALIDATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private static final String[] SUPPORTED_METHODS = new String[] { "DELETE", "GET", "HEAD", "POST", "PUT", "PATCH" };
/*     */ 
/*     */ 
/*     */   
/*     */   private final CertificateValidationBehavior certificateValidationBehavior;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  72 */     Arrays.sort((Object[])SUPPORTED_METHODS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UrlFetchTransport() {
/*  84 */     this(new Builder());
/*     */   }
/*     */ 
/*     */   
/*     */   UrlFetchTransport(Builder builder) {
/*  89 */     this.certificateValidationBehavior = builder.certificateValidationBehavior;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UrlFetchTransport getDefaultInstance() {
/*  98 */     return InstanceHolder.INSTANCE;
/*     */   }
/*     */   
/*     */   static class InstanceHolder
/*     */   {
/* 103 */     static final UrlFetchTransport INSTANCE = new UrlFetchTransport();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsMethod(String method) {
/* 108 */     return (Arrays.binarySearch((Object[])SUPPORTED_METHODS, method) >= 0);
/*     */   }
/*     */   
/*     */   protected UrlFetchRequest buildRequest(String method, String url) throws IOException {
/*     */     HTTPMethod httpMethod;
/* 113 */     Preconditions.checkArgument(supportsMethod(method), "HTTP method %s not supported", new Object[] { method });
/*     */     
/* 115 */     if (method.equals("DELETE")) {
/* 116 */       httpMethod = HTTPMethod.DELETE;
/* 117 */     } else if (method.equals("GET")) {
/* 118 */       httpMethod = HTTPMethod.GET;
/* 119 */     } else if (method.equals("HEAD")) {
/* 120 */       httpMethod = HTTPMethod.HEAD;
/* 121 */     } else if (method.equals("POST")) {
/* 122 */       httpMethod = HTTPMethod.POST;
/* 123 */     } else if (method.equals("PATCH")) {
/* 124 */       httpMethod = HTTPMethod.PATCH;
/*     */     } else {
/* 126 */       httpMethod = HTTPMethod.PUT;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     FetchOptions fetchOptions = FetchOptions.Builder.doNotFollowRedirects().disallowTruncate().validateCertificate();
/* 131 */     switch (this.certificateValidationBehavior) {
/*     */       case VALIDATE:
/* 133 */         fetchOptions.validateCertificate();
/*     */         break;
/*     */       case DO_NOT_VALIDATE:
/* 136 */         fetchOptions.doNotValidateCertificate();
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 141 */     return new UrlFetchRequest(fetchOptions, httpMethod, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/* 154 */     UrlFetchTransport.CertificateValidationBehavior certificateValidationBehavior = UrlFetchTransport.CertificateValidationBehavior.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder doNotValidateCertificate() {
/* 165 */       this.certificateValidationBehavior = UrlFetchTransport.CertificateValidationBehavior.DO_NOT_VALIDATE;
/* 166 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder validateCertificate() {
/* 173 */       this.certificateValidationBehavior = UrlFetchTransport.CertificateValidationBehavior.VALIDATE;
/* 174 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getValidateCertificate() {
/* 179 */       return (this.certificateValidationBehavior == UrlFetchTransport.CertificateValidationBehavior.VALIDATE);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean getDoNotValidateCertificate() {
/* 184 */       return (this.certificateValidationBehavior == UrlFetchTransport.CertificateValidationBehavior.DO_NOT_VALIDATE);
/*     */     }
/*     */ 
/*     */     
/*     */     public UrlFetchTransport build() {
/* 189 */       return new UrlFetchTransport(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\extensions\appengine\http\UrlFetchTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */