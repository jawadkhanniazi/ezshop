/*     */ package com.google.api.client.extensions.appengine.datastore;
/*     */ 
/*     */ import com.google.api.client.util.IOUtils;
/*     */ import com.google.api.client.util.Lists;
/*     */ import com.google.api.client.util.Maps;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Sets;
/*     */ import com.google.api.client.util.store.AbstractDataStore;
/*     */ import com.google.api.client.util.store.AbstractDataStoreFactory;
/*     */ import com.google.api.client.util.store.DataStore;
/*     */ import com.google.api.client.util.store.DataStoreFactory;
/*     */ import com.google.api.client.util.store.DataStoreUtils;
/*     */ import com.google.appengine.api.datastore.Blob;
/*     */ import com.google.appengine.api.datastore.DatastoreService;
/*     */ import com.google.appengine.api.datastore.DatastoreServiceFactory;
/*     */ import com.google.appengine.api.datastore.Entity;
/*     */ import com.google.appengine.api.datastore.EntityNotFoundException;
/*     */ import com.google.appengine.api.datastore.Key;
/*     */ import com.google.appengine.api.datastore.KeyFactory;
/*     */ import com.google.appengine.api.datastore.Query;
/*     */ import com.google.appengine.api.memcache.Expiration;
/*     */ import com.google.appengine.api.memcache.MemcacheService;
/*     */ import com.google.appengine.api.memcache.MemcacheServiceFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AppEngineDataStoreFactory
/*     */   extends AbstractDataStoreFactory
/*     */ {
/*     */   final boolean disableMemcache;
/*     */   final Expiration memcacheExpiration;
/*     */   
/*     */   protected <V extends Serializable> DataStore<V> createDataStore(String id) throws IOException {
/*  73 */     return (DataStore)new AppEngineDataStore<>(this, id);
/*     */   }
/*     */   
/*     */   public AppEngineDataStoreFactory() {
/*  77 */     this(new Builder());
/*     */   }
/*     */ 
/*     */   
/*     */   public AppEngineDataStoreFactory(Builder builder) {
/*  82 */     this.disableMemcache = builder.disableMemcache;
/*  83 */     this.memcacheExpiration = builder.memcacheExpiration;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getDisableMemcache() {
/*  88 */     return this.disableMemcache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AppEngineDataStoreFactory getDefaultInstance() {
/*  96 */     return InstanceHolder.INSTANCE;
/*     */   }
/*     */   
/*     */   static class InstanceHolder
/*     */   {
/* 101 */     static final AppEngineDataStoreFactory INSTANCE = new AppEngineDataStoreFactory();
/*     */   }
/*     */   
/*     */   static class AppEngineDataStore<V extends Serializable>
/*     */     extends AbstractDataStore<V>
/*     */   {
/* 107 */     private final Lock lock = new ReentrantLock();
/*     */ 
/*     */     
/*     */     private static final String FIELD_VALUE = "value";
/*     */ 
/*     */     
/*     */     private final MemcacheService memcache;
/*     */ 
/*     */     
/*     */     private final DatastoreService dataStoreService;
/*     */     
/*     */     final Expiration memcacheExpiration;
/*     */ 
/*     */     
/*     */     AppEngineDataStore(AppEngineDataStoreFactory dataStoreFactory, String id) {
/* 122 */       super((DataStoreFactory)dataStoreFactory, id);
/* 123 */       this
/* 124 */         .memcache = dataStoreFactory.disableMemcache ? null : MemcacheServiceFactory.getMemcacheService(id);
/* 125 */       this.memcacheExpiration = dataStoreFactory.memcacheExpiration;
/* 126 */       this.dataStoreService = DatastoreServiceFactory.getDatastoreService();
/*     */     }
/*     */ 
/*     */     
/*     */     private V deserialize(Entity entity) throws IOException {
/* 131 */       Blob blob = (Blob)entity.getProperty("value");
/* 132 */       return (V)IOUtils.deserialize(blob.getBytes());
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<String> keySet() throws IOException {
/* 137 */       this.lock.lock();
/*     */       
/*     */       try {
/* 140 */         Set<String> result = Sets.newHashSet();
/* 141 */         for (Entity entity : query(true)) {
/* 142 */           result.add(entity.getKey().getName());
/*     */         }
/* 144 */         return Collections.unmodifiableSet(result);
/*     */       } finally {
/* 146 */         this.lock.unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<V> values() throws IOException {
/* 152 */       this.lock.lock();
/*     */ 
/*     */       
/*     */       try {
/* 156 */         if (this.memcache != null) {
/* 157 */           this.memcache.clearAll();
/*     */         }
/* 159 */         List<V> result = Lists.newArrayList();
/* 160 */         Map<String, V> map = (this.memcache != null) ? Maps.newHashMap() : null;
/* 161 */         for (Entity entity : query(false)) {
/* 162 */           V value = deserialize(entity);
/* 163 */           result.add(value);
/* 164 */           if (map != null) {
/* 165 */             map.put(entity.getKey().getName(), value);
/*     */           }
/*     */         } 
/* 168 */         if (this.memcache != null) {
/* 169 */           this.memcache.putAll(map, this.memcacheExpiration);
/*     */         }
/* 171 */         return Collections.unmodifiableList(result);
/*     */       } finally {
/* 173 */         this.lock.unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public V get(String key) throws IOException {
/* 179 */       if (key == null) {
/* 180 */         return null;
/*     */       }
/* 182 */       this.lock.lock(); try {
/*     */         Entity entity;
/* 184 */         if (this.memcache != null && this.memcache.contains(key)) {
/*     */           
/* 186 */           Serializable serializable = (Serializable)this.memcache.get(key);
/* 187 */           return (V)serializable;
/*     */         } 
/* 189 */         Key dataKey = KeyFactory.createKey(getId(), key);
/*     */         
/*     */         try {
/* 192 */           entity = this.dataStoreService.get(dataKey);
/* 193 */         } catch (EntityNotFoundException exception) {
/* 194 */           if (this.memcache != null) {
/* 195 */             this.memcache.delete(key);
/*     */           }
/* 197 */           return null;
/*     */         } 
/* 199 */         V result = deserialize(entity);
/* 200 */         if (this.memcache != null) {
/* 201 */           this.memcache.put(key, result, this.memcacheExpiration);
/*     */         }
/* 203 */         return result;
/*     */       } finally {
/* 205 */         this.lock.unlock();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public AppEngineDataStore<V> set(String key, V value) throws IOException {
/* 211 */       Preconditions.checkNotNull(key);
/* 212 */       Preconditions.checkNotNull(value);
/* 213 */       this.lock.lock();
/*     */       try {
/* 215 */         Entity entity = new Entity(getId(), key);
/* 216 */         entity.setUnindexedProperty("value", new Blob(IOUtils.serialize(value)));
/* 217 */         this.dataStoreService.put(entity);
/* 218 */         if (this.memcache != null) {
/* 219 */           this.memcache.put(key, value, this.memcacheExpiration);
/*     */         }
/*     */       } finally {
/* 222 */         this.lock.unlock();
/*     */       } 
/* 224 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public DataStore<V> delete(String key) throws IOException {
/* 229 */       if (key == null) {
/* 230 */         return (DataStore<V>)this;
/*     */       }
/* 232 */       this.lock.lock();
/*     */       try {
/* 234 */         this.dataStoreService.delete(new Key[] { KeyFactory.createKey(getId(), key) });
/* 235 */         if (this.memcache != null) {
/* 236 */           this.memcache.delete(key);
/*     */         }
/*     */       } finally {
/* 239 */         this.lock.unlock();
/*     */       } 
/* 241 */       return (DataStore<V>)this;
/*     */     }
/*     */ 
/*     */     
/*     */     public AppEngineDataStore<V> clear() throws IOException {
/* 246 */       this.lock.lock();
/*     */       try {
/* 248 */         if (this.memcache != null) {
/* 249 */           this.memcache.clearAll();
/*     */         }
/*     */         
/* 252 */         List<Key> keys = Lists.newArrayList();
/* 253 */         for (Entity entity : query(true)) {
/* 254 */           keys.add(entity.getKey());
/*     */         }
/* 256 */         this.dataStoreService.delete(keys);
/*     */       } finally {
/* 258 */         this.lock.unlock();
/*     */       } 
/* 260 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public AppEngineDataStoreFactory getDataStoreFactory() {
/* 265 */       return (AppEngineDataStoreFactory)super.getDataStoreFactory();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 270 */       return DataStoreUtils.toString((DataStore)this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Iterable<Entity> query(boolean keysOnly) {
/* 280 */       Query query = new Query(getId());
/* 281 */       if (keysOnly) {
/* 282 */         query.setKeysOnly();
/*     */       }
/* 284 */       return this.dataStoreService.prepare(query).asIterable();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     boolean disableMemcache;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Expiration memcacheExpiration;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean getDisableMemcache() {
/* 305 */       return this.disableMemcache;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setDisableMemcache(boolean disableMemcache) {
/* 315 */       this.disableMemcache = disableMemcache;
/* 316 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final Expiration getMemcacheExpiration() {
/* 321 */       return this.memcacheExpiration;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMemcacheExpiration(Expiration memcacheExpiration) {
/* 331 */       this.memcacheExpiration = memcacheExpiration;
/* 332 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public AppEngineDataStoreFactory build() {
/* 337 */       return new AppEngineDataStoreFactory(this);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\extensions\appengine\datastore\AppEngineDataStoreFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */