/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import com.google.common.io.BaseEncoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Base64
/*     */ {
/*     */   public static byte[] encodeBase64(byte[] binaryData) {
/*  36 */     return StringUtils.getBytesUtf8(encodeBase64String(binaryData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeBase64String(byte[] binaryData) {
/*  46 */     if (binaryData == null) {
/*  47 */       return null;
/*     */     }
/*  49 */     return BaseEncoding.base64().encode(binaryData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] encodeBase64URLSafe(byte[] binaryData) {
/*  61 */     return StringUtils.getBytesUtf8(encodeBase64URLSafeString(binaryData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeBase64URLSafeString(byte[] binaryData) {
/*  72 */     if (binaryData == null) {
/*  73 */       return null;
/*     */     }
/*  75 */     return BaseEncoding.base64Url().omitPadding().encode(binaryData);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeBase64(byte[] base64Data) {
/*  86 */     return decodeBase64(StringUtils.newStringUtf8(base64Data));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decodeBase64(String base64String) {
/*  97 */     if (base64String == null) {
/*  98 */       return null;
/*     */     }
/*     */     try {
/* 101 */       return BaseEncoding.base64().decode(base64String);
/* 102 */     } catch (IllegalArgumentException e) {
/* 103 */       if (e.getCause() instanceof BaseEncoding.DecodingException) {
/* 104 */         return BaseEncoding.base64Url().decode(base64String.trim());
/*     */       }
/* 106 */       throw e;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Base64.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */