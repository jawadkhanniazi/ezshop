/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface BackOff
/*    */ {
/*    */   public static final long STOP = -1L;
/*    */   
/* 54 */   public static final BackOff ZERO_BACKOFF = new BackOff()
/*    */     {
/*    */       public void reset() throws IOException {}
/*    */ 
/*    */       
/*    */       public long nextBackOffMillis() throws IOException {
/* 60 */         return 0L;
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   public static final BackOff STOP_BACKOFF = new BackOff()
/*    */     {
/*    */       public void reset() throws IOException {}
/*    */ 
/*    */       
/*    */       public long nextBackOffMillis() throws IOException {
/* 74 */         return -1L;
/*    */       }
/*    */     };
/*    */   
/*    */   void reset() throws IOException;
/*    */   
/*    */   long nextBackOffMillis() throws IOException;
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\BackOff.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */