/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public final class PemReader
/*     */ {
/*  53 */   private static final Pattern BEGIN_PATTERN = Pattern.compile("-----BEGIN ([A-Z ]+)-----");
/*  54 */   private static final Pattern END_PATTERN = Pattern.compile("-----END ([A-Z ]+)-----");
/*     */ 
/*     */   
/*     */   private BufferedReader reader;
/*     */ 
/*     */   
/*     */   public PemReader(Reader reader) {
/*  61 */     this.reader = new BufferedReader(reader);
/*     */   }
/*     */ 
/*     */   
/*     */   public Section readNextSection() throws IOException {
/*  66 */     return readNextSection(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Section readNextSection(String titleToLookFor) throws IOException {
/*  76 */     String title = null;
/*  77 */     StringBuilder keyBuilder = null;
/*     */     while (true) {
/*  79 */       String line = this.reader.readLine();
/*  80 */       if (line == null) {
/*  81 */         Preconditions.checkArgument((title == null), "missing end tag (%s)", new Object[] { title });
/*  82 */         return null;
/*     */       } 
/*  84 */       if (keyBuilder == null) {
/*  85 */         Matcher matcher = BEGIN_PATTERN.matcher(line);
/*  86 */         if (matcher.matches()) {
/*  87 */           String curTitle = matcher.group(1);
/*  88 */           if (titleToLookFor == null || curTitle.equals(titleToLookFor)) {
/*  89 */             keyBuilder = new StringBuilder();
/*  90 */             title = curTitle;
/*     */           } 
/*     */         }  continue;
/*     */       } 
/*  94 */       Matcher m = END_PATTERN.matcher(line);
/*  95 */       if (m.matches()) {
/*  96 */         String endTitle = m.group(1);
/*  97 */         Preconditions.checkArgument(endTitle
/*  98 */             .equals(title), "end tag (%s) doesn't match begin tag (%s)", new Object[] { endTitle, title });
/*  99 */         return new Section(title, Base64.decodeBase64(keyBuilder.toString()));
/*     */       } 
/* 101 */       keyBuilder.append(line);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Section readFirstSectionAndClose(Reader reader) throws IOException {
/* 113 */     return readFirstSectionAndClose(reader, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Section readFirstSectionAndClose(Reader reader, String titleToLookFor) throws IOException {
/* 126 */     PemReader pemReader = new PemReader(reader);
/*     */     try {
/* 128 */       return pemReader.readNextSection(titleToLookFor);
/*     */     } finally {
/* 130 */       pemReader.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 140 */     this.reader.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Section
/*     */   {
/*     */     private final String title;
/*     */ 
/*     */ 
/*     */     
/*     */     private final byte[] base64decodedBytes;
/*     */ 
/*     */ 
/*     */     
/*     */     Section(String title, byte[] base64decodedBytes) {
/* 157 */       this.title = Preconditions.<String>checkNotNull(title);
/* 158 */       this.base64decodedBytes = Preconditions.<byte[]>checkNotNull(base64decodedBytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getTitle() {
/* 163 */       return this.title;
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getBase64DecodedBytes() {
/* 168 */       return this.base64decodedBytes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\PemReader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */