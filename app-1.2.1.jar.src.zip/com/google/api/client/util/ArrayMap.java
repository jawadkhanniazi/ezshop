/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayMap<K, V>
/*     */   extends AbstractMap<K, V>
/*     */   implements Cloneable
/*     */ {
/*     */   int size;
/*     */   private Object[] data;
/*     */   
/*     */   public static <K, V> ArrayMap<K, V> create() {
/*  52 */     return new ArrayMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> ArrayMap<K, V> create(int initialCapacity) {
/*  60 */     ArrayMap<K, V> result = create();
/*  61 */     result.ensureCapacity(initialCapacity);
/*  62 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <K, V> ArrayMap<K, V> of(Object... keyValuePairs) {
/*  76 */     ArrayMap<K, V> result = create(1);
/*  77 */     int length = keyValuePairs.length;
/*  78 */     if (1 == length % 2) {
/*  79 */       throw new IllegalArgumentException("missing value for last key: " + keyValuePairs[length - 1]);
/*     */     }
/*     */     
/*  82 */     result.size = keyValuePairs.length / 2;
/*  83 */     Object[] data = result.data = new Object[length];
/*  84 */     System.arraycopy(keyValuePairs, 0, data, 0, length);
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int size() {
/*  91 */     return this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public final K getKey(int index) {
/*  96 */     if (index < 0 || index >= this.size) {
/*  97 */       return null;
/*     */     }
/*     */     
/* 100 */     K result = (K)this.data[index << 1];
/* 101 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public final V getValue(int index) {
/* 106 */     if (index < 0 || index >= this.size) {
/* 107 */       return null;
/*     */     }
/* 109 */     return valueAtDataIndex(1 + (index << 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V set(int index, K key, V value) {
/* 123 */     if (index < 0) {
/* 124 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 126 */     int minSize = index + 1;
/* 127 */     ensureCapacity(minSize);
/* 128 */     int dataIndex = index << 1;
/* 129 */     V result = valueAtDataIndex(dataIndex + 1);
/* 130 */     setData(dataIndex, key, value);
/* 131 */     if (minSize > this.size) {
/* 132 */       this.size = minSize;
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V set(int index, V value) {
/* 144 */     int size = this.size;
/* 145 */     if (index < 0 || index >= size) {
/* 146 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 148 */     int valueDataIndex = 1 + (index << 1);
/* 149 */     V result = valueAtDataIndex(valueDataIndex);
/* 150 */     this.data[valueDataIndex] = value;
/* 151 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void add(K key, V value) {
/* 161 */     set(this.size, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V remove(int index) {
/* 170 */     return removeFromDataIndexOfKey(index << 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean containsKey(Object key) {
/* 176 */     return (-2 != getDataIndexOfKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getIndexOfKey(K key) {
/* 181 */     return getDataIndexOfKey(key) >> 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V get(Object key) {
/* 190 */     return valueAtDataIndex(getDataIndexOfKey(key) + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V put(K key, V value) {
/* 200 */     int index = getIndexOfKey(key);
/* 201 */     if (index == -1) {
/* 202 */       index = this.size;
/*     */     }
/* 204 */     return set(index, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final V remove(Object key) {
/* 214 */     return removeFromDataIndexOfKey(getDataIndexOfKey(key));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void trim() {
/* 219 */     setDataCapacity(this.size << 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void ensureCapacity(int minCapacity) {
/* 224 */     if (minCapacity < 0) {
/* 225 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 227 */     Object[] data = this.data;
/* 228 */     int minDataCapacity = minCapacity << 1;
/* 229 */     int oldDataCapacity = (data == null) ? 0 : data.length;
/* 230 */     if (minDataCapacity > oldDataCapacity) {
/* 231 */       int newDataCapacity = oldDataCapacity / 2 * 3 + 1;
/* 232 */       if (newDataCapacity % 2 != 0) {
/* 233 */         newDataCapacity++;
/*     */       }
/* 235 */       if (newDataCapacity < minDataCapacity) {
/* 236 */         newDataCapacity = minDataCapacity;
/*     */       }
/* 238 */       setDataCapacity(newDataCapacity);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setDataCapacity(int newDataCapacity) {
/* 243 */     if (newDataCapacity == 0) {
/* 244 */       this.data = null;
/*     */       return;
/*     */     } 
/* 247 */     int size = this.size;
/* 248 */     Object[] oldData = this.data;
/* 249 */     if (size == 0 || newDataCapacity != oldData.length) {
/* 250 */       Object[] newData = this.data = new Object[newDataCapacity];
/* 251 */       if (size != 0) {
/* 252 */         System.arraycopy(oldData, 0, newData, 0, size << 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setData(int dataIndexOfKey, K key, V value) {
/* 258 */     Object[] data = this.data;
/* 259 */     data[dataIndexOfKey] = key;
/* 260 */     data[dataIndexOfKey + 1] = value;
/*     */   }
/*     */   
/*     */   private V valueAtDataIndex(int dataIndex) {
/* 264 */     if (dataIndex < 0) {
/* 265 */       return null;
/*     */     }
/*     */     
/* 268 */     V result = (V)this.data[dataIndex];
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getDataIndexOfKey(Object key) {
/* 274 */     int dataSize = this.size << 1;
/* 275 */     Object[] data = this.data;
/* 276 */     for (int i = 0; i < dataSize; i += 2) {
/* 277 */       Object k = data[i];
/* 278 */       if ((key == null) ? (k == null) : key.equals(k)) {
/* 279 */         return i;
/*     */       }
/*     */     } 
/* 282 */     return -2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private V removeFromDataIndexOfKey(int dataIndexOfKey) {
/* 290 */     int dataSize = this.size << 1;
/* 291 */     if (dataIndexOfKey < 0 || dataIndexOfKey >= dataSize) {
/* 292 */       return null;
/*     */     }
/* 294 */     V result = valueAtDataIndex(dataIndexOfKey + 1);
/* 295 */     Object[] data = this.data;
/* 296 */     int moved = dataSize - dataIndexOfKey - 2;
/* 297 */     if (moved != 0) {
/* 298 */       System.arraycopy(data, dataIndexOfKey + 2, data, dataIndexOfKey, moved);
/*     */     }
/* 300 */     this.size--;
/* 301 */     setData(dataSize - 2, null, null);
/* 302 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 307 */     this.size = 0;
/* 308 */     this.data = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean containsValue(Object value) {
/* 313 */     int dataSize = this.size << 1;
/* 314 */     Object[] data = this.data;
/* 315 */     for (int i = 1; i < dataSize; i += 2) {
/* 316 */       Object v = data[i];
/* 317 */       if ((value == null) ? (v == null) : value.equals(v)) {
/* 318 */         return true;
/*     */       }
/*     */     } 
/* 321 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Set<Map.Entry<K, V>> entrySet() {
/* 326 */     return new EntrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayMap<K, V> clone() {
/*     */     try {
/* 333 */       ArrayMap<K, V> result = (ArrayMap<K, V>)super.clone();
/* 334 */       Object[] data = this.data;
/* 335 */       if (data != null) {
/* 336 */         int length = data.length;
/* 337 */         Object[] resultData = result.data = new Object[length];
/* 338 */         System.arraycopy(data, 0, resultData, 0, length);
/*     */       } 
/* 340 */       return result;
/* 341 */     } catch (CloneNotSupportedException e) {
/*     */       
/* 343 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   final class EntrySet
/*     */     extends AbstractSet<Map.Entry<K, V>>
/*     */   {
/*     */     public Iterator<Map.Entry<K, V>> iterator() {
/* 351 */       return new ArrayMap.EntryIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 356 */       return ArrayMap.this.size;
/*     */     }
/*     */   }
/*     */   
/*     */   final class EntryIterator
/*     */     implements Iterator<Map.Entry<K, V>> {
/*     */     private boolean removed;
/*     */     private int nextIndex;
/*     */     
/*     */     public boolean hasNext() {
/* 366 */       return (this.nextIndex < ArrayMap.this.size);
/*     */     }
/*     */     
/*     */     public Map.Entry<K, V> next() {
/* 370 */       int index = this.nextIndex;
/* 371 */       if (index == ArrayMap.this.size) {
/* 372 */         throw new NoSuchElementException();
/*     */       }
/* 374 */       this.nextIndex++;
/* 375 */       this.removed = false;
/* 376 */       return new ArrayMap.Entry(index);
/*     */     }
/*     */     
/*     */     public void remove() {
/* 380 */       int index = this.nextIndex - 1;
/* 381 */       if (this.removed || index < 0) {
/* 382 */         throw new IllegalArgumentException();
/*     */       }
/* 384 */       ArrayMap.this.remove(index);
/* 385 */       this.nextIndex--;
/* 386 */       this.removed = true;
/*     */     }
/*     */   }
/*     */   
/*     */   final class Entry
/*     */     implements Map.Entry<K, V> {
/*     */     private int index;
/*     */     
/*     */     Entry(int index) {
/* 395 */       this.index = index;
/*     */     }
/*     */     
/*     */     public K getKey() {
/* 399 */       return (K)ArrayMap.this.getKey(this.index);
/*     */     }
/*     */     
/*     */     public V getValue() {
/* 403 */       return (V)ArrayMap.this.getValue(this.index);
/*     */     }
/*     */     
/*     */     public V setValue(V value) {
/* 407 */       return (V)ArrayMap.this.set(this.index, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 412 */       K key = getKey();
/* 413 */       V value = getValue();
/* 414 */       return ((key != null) ? key.hashCode() : 0) ^ ((value != null) ? value.hashCode() : 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 419 */       if (this == obj) {
/* 420 */         return true;
/*     */       }
/* 422 */       if (!(obj instanceof Map.Entry)) {
/* 423 */         return false;
/*     */       }
/* 425 */       Map.Entry<?, ?> other = (Map.Entry<?, ?>)obj;
/* 426 */       return (Objects.equal(getKey(), other.getKey()) && Objects.equal(getValue(), other.getValue()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\ArrayMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */