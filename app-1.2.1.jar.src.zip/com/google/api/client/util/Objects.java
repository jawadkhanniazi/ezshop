/*     */ package com.google.api.client.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Objects
/*     */ {
/*     */   public static boolean equal(Object a, Object b) {
/*  39 */     return com.google.common.base.Objects.equal(a, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ToStringHelper toStringHelper(Object self) {
/*  80 */     return new ToStringHelper(self.getClass().getSimpleName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class ToStringHelper
/*     */   {
/*     */     private final String className;
/*  87 */     private ValueHolder holderHead = new ValueHolder();
/*  88 */     private ValueHolder holderTail = this.holderHead;
/*     */     
/*     */     private boolean omitNullValues;
/*     */     
/*     */     ToStringHelper(String className) {
/*  93 */       this.className = className;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ToStringHelper omitNullValues() {
/* 102 */       this.omitNullValues = true;
/* 103 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ToStringHelper add(String name, Object value) {
/* 112 */       return addHolder(name, value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 118 */       boolean omitNullValuesSnapshot = this.omitNullValues;
/* 119 */       String nextSeparator = "";
/* 120 */       StringBuilder builder = (new StringBuilder(32)).append(this.className).append('{');
/* 121 */       ValueHolder valueHolder = this.holderHead.next;
/* 122 */       for (; valueHolder != null; 
/* 123 */         valueHolder = valueHolder.next) {
/* 124 */         if (!omitNullValuesSnapshot || valueHolder.value != null) {
/* 125 */           builder.append(nextSeparator);
/* 126 */           nextSeparator = ", ";
/*     */           
/* 128 */           if (valueHolder.name != null) {
/* 129 */             builder.append(valueHolder.name).append('=');
/*     */           }
/* 131 */           builder.append(valueHolder.value);
/*     */         } 
/*     */       } 
/* 134 */       return builder.append('}').toString();
/*     */     }
/*     */     
/*     */     private ValueHolder addHolder() {
/* 138 */       ValueHolder valueHolder = new ValueHolder();
/* 139 */       this.holderTail = this.holderTail.next = valueHolder;
/* 140 */       return valueHolder;
/*     */     }
/*     */     
/*     */     private ToStringHelper addHolder(String name, Object value) {
/* 144 */       ValueHolder valueHolder = addHolder();
/* 145 */       valueHolder.value = value;
/* 146 */       valueHolder.name = Preconditions.<String>checkNotNull(name);
/* 147 */       return this;
/*     */     }
/*     */     
/*     */     private static final class ValueHolder {
/*     */       String name;
/*     */       Object value;
/*     */       ValueHolder next;
/*     */       
/*     */       private ValueHolder() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Objects.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */