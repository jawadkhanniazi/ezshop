/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Charsets
/*    */ {
/* 32 */   public static final Charset UTF_8 = Charset.forName("UTF-8");
/*    */ 
/*    */   
/* 35 */   public static final Charset ISO_8859_1 = Charset.forName("ISO-8859-1");
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Charsets.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */