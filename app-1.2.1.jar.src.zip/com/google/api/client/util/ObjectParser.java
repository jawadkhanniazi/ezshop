package com.google.api.client.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.Charset;

public interface ObjectParser {
  <T> T parseAndClose(InputStream paramInputStream, Charset paramCharset, Class<T> paramClass) throws IOException;
  
  Object parseAndClose(InputStream paramInputStream, Charset paramCharset, Type paramType) throws IOException;
  
  <T> T parseAndClose(Reader paramReader, Class<T> paramClass) throws IOException;
  
  Object parseAndClose(Reader paramReader, Type paramType) throws IOException;
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\ObjectParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */