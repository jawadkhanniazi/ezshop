/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ByteArrayStreamingContent
/*    */   implements StreamingContent
/*    */ {
/*    */   private final byte[] byteArray;
/*    */   private final int offset;
/*    */   private final int length;
/*    */   
/*    */   public ByteArrayStreamingContent(byte[] byteArray) {
/* 41 */     this(byteArray, 0, byteArray.length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteArrayStreamingContent(byte[] byteArray, int offset, int length) {
/* 50 */     this.byteArray = Preconditions.<byte[]>checkNotNull(byteArray);
/* 51 */     Preconditions.checkArgument((offset >= 0 && length >= 0 && offset + length <= byteArray.length));
/* 52 */     this.offset = offset;
/* 53 */     this.length = length;
/*    */   }
/*    */   
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 57 */     out.write(this.byteArray, this.offset, this.length);
/* 58 */     out.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\ByteArrayStreamingContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */