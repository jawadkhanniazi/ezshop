/*    */ package com.google.api.client.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Sleeper
/*    */ {
/* 38 */   public static final Sleeper DEFAULT = new Sleeper()
/*    */     {
/*    */       public void sleep(long millis) throws InterruptedException
/*    */       {
/* 42 */         Thread.sleep(millis);
/*    */       }
/*    */     };
/*    */   
/*    */   void sleep(long paramLong) throws InterruptedException;
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Sleeper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */