/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExponentialBackOff
/*     */   implements BackOff
/*     */ {
/*     */   public static final int DEFAULT_INITIAL_INTERVAL_MILLIS = 500;
/*     */   public static final double DEFAULT_RANDOMIZATION_FACTOR = 0.5D;
/*     */   public static final double DEFAULT_MULTIPLIER = 1.5D;
/*     */   public static final int DEFAULT_MAX_INTERVAL_MILLIS = 60000;
/*     */   public static final int DEFAULT_MAX_ELAPSED_TIME_MILLIS = 900000;
/*     */   private int currentIntervalMillis;
/*     */   private final int initialIntervalMillis;
/*     */   private final double randomizationFactor;
/*     */   private final double multiplier;
/*     */   private final int maxIntervalMillis;
/*     */   long startTimeNanos;
/*     */   private final int maxElapsedTimeMillis;
/*     */   private final NanoClock nanoClock;
/*     */   
/*     */   public ExponentialBackOff() {
/* 137 */     this(new Builder());
/*     */   }
/*     */ 
/*     */   
/*     */   protected ExponentialBackOff(Builder builder) {
/* 142 */     this.initialIntervalMillis = builder.initialIntervalMillis;
/* 143 */     this.randomizationFactor = builder.randomizationFactor;
/* 144 */     this.multiplier = builder.multiplier;
/* 145 */     this.maxIntervalMillis = builder.maxIntervalMillis;
/* 146 */     this.maxElapsedTimeMillis = builder.maxElapsedTimeMillis;
/* 147 */     this.nanoClock = builder.nanoClock;
/* 148 */     Preconditions.checkArgument((this.initialIntervalMillis > 0));
/* 149 */     Preconditions.checkArgument((0.0D <= this.randomizationFactor && this.randomizationFactor < 1.0D));
/* 150 */     Preconditions.checkArgument((this.multiplier >= 1.0D));
/* 151 */     Preconditions.checkArgument((this.maxIntervalMillis >= this.initialIntervalMillis));
/* 152 */     Preconditions.checkArgument((this.maxElapsedTimeMillis > 0));
/* 153 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void reset() {
/* 158 */     this.currentIntervalMillis = this.initialIntervalMillis;
/* 159 */     this.startTimeNanos = this.nanoClock.nanoTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long nextBackOffMillis() throws IOException {
/* 172 */     if (getElapsedTimeMillis() > this.maxElapsedTimeMillis) {
/* 173 */       return -1L;
/*     */     }
/*     */     
/* 176 */     int randomizedInterval = getRandomValueFromInterval(this.randomizationFactor, Math.random(), this.currentIntervalMillis);
/* 177 */     incrementCurrentInterval();
/* 178 */     return randomizedInterval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getRandomValueFromInterval(double randomizationFactor, double random, int currentIntervalMillis) {
/* 187 */     double delta = randomizationFactor * currentIntervalMillis;
/* 188 */     double minInterval = currentIntervalMillis - delta;
/* 189 */     double maxInterval = currentIntervalMillis + delta;
/*     */ 
/*     */ 
/*     */     
/* 193 */     int randomValue = (int)(minInterval + random * (maxInterval - minInterval + 1.0D));
/* 194 */     return randomValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getInitialIntervalMillis() {
/* 199 */     return this.initialIntervalMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double getRandomizationFactor() {
/* 209 */     return this.randomizationFactor;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getCurrentIntervalMillis() {
/* 214 */     return this.currentIntervalMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public final double getMultiplier() {
/* 219 */     return this.multiplier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxIntervalMillis() {
/* 227 */     return this.maxIntervalMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getMaxElapsedTimeMillis() {
/* 238 */     return this.maxElapsedTimeMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getElapsedTimeMillis() {
/* 248 */     return (this.nanoClock.nanoTime() - this.startTimeNanos) / 1000000L;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void incrementCurrentInterval() {
/* 254 */     if (this.currentIntervalMillis >= this.maxIntervalMillis / this.multiplier) {
/* 255 */       this.currentIntervalMillis = this.maxIntervalMillis;
/*     */     } else {
/* 257 */       this.currentIntervalMillis = (int)(this.currentIntervalMillis * this.multiplier);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/* 269 */     int initialIntervalMillis = 500;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     double randomizationFactor = 0.5D;
/*     */ 
/*     */     
/* 280 */     double multiplier = 1.5D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 286 */     int maxIntervalMillis = 60000;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 293 */     int maxElapsedTimeMillis = 900000;
/*     */ 
/*     */     
/* 296 */     NanoClock nanoClock = NanoClock.SYSTEM;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ExponentialBackOff build() {
/* 302 */       return new ExponentialBackOff(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getInitialIntervalMillis() {
/* 310 */       return this.initialIntervalMillis;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setInitialIntervalMillis(int initialIntervalMillis) {
/* 321 */       this.initialIntervalMillis = initialIntervalMillis;
/* 322 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final double getRandomizationFactor() {
/* 336 */       return this.randomizationFactor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRandomizationFactor(double randomizationFactor) {
/* 351 */       this.randomizationFactor = randomizationFactor;
/* 352 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final double getMultiplier() {
/* 360 */       return this.multiplier;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMultiplier(double multiplier) {
/* 371 */       this.multiplier = multiplier;
/* 372 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getMaxIntervalMillis() {
/* 381 */       return this.maxIntervalMillis;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMaxIntervalMillis(int maxIntervalMillis) {
/* 393 */       this.maxIntervalMillis = maxIntervalMillis;
/* 394 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getMaxElapsedTimeMillis() {
/* 406 */       return this.maxElapsedTimeMillis;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMaxElapsedTimeMillis(int maxElapsedTimeMillis) {
/* 421 */       this.maxElapsedTimeMillis = maxElapsedTimeMillis;
/* 422 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final NanoClock getNanoClock() {
/* 427 */       return this.nanoClock;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setNanoClock(NanoClock nanoClock) {
/* 437 */       this.nanoClock = Preconditions.<NanoClock>checkNotNull(nanoClock);
/* 438 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\ExponentialBackOff.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */