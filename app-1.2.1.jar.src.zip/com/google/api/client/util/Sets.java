/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Sets
/*    */ {
/*    */   public static <E> HashSet<E> newHashSet() {
/* 34 */     return new HashSet<>();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <E extends Comparable<?>> TreeSet<E> newTreeSet() {
/* 42 */     return new TreeSet<>();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Sets.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */