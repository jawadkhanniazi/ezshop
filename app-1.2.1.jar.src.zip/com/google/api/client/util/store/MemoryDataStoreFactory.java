/*    */ package com.google.api.client.util.store;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MemoryDataStoreFactory
/*    */   extends AbstractDataStoreFactory
/*    */ {
/*    */   protected <V extends Serializable> DataStore<V> createDataStore(String id) throws IOException {
/* 32 */     return new MemoryDataStore<>(this, id);
/*    */   }
/*    */ 
/*    */   
/*    */   public static MemoryDataStoreFactory getDefaultInstance() {
/* 37 */     return InstanceHolder.INSTANCE;
/*    */   }
/*    */   
/*    */   static class InstanceHolder
/*    */   {
/* 42 */     static final MemoryDataStoreFactory INSTANCE = new MemoryDataStoreFactory();
/*    */   }
/*    */   
/*    */   static class MemoryDataStore<V extends Serializable>
/*    */     extends AbstractMemoryDataStore<V> {
/*    */     MemoryDataStore(MemoryDataStoreFactory dataStore, String id) {
/* 48 */       super(dataStore, id);
/*    */     }
/*    */ 
/*    */     
/*    */     public MemoryDataStoreFactory getDataStoreFactory() {
/* 53 */       return (MemoryDataStoreFactory)super.getDataStoreFactory();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\store\MemoryDataStoreFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */