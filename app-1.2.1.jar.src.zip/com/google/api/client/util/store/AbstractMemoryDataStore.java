/*     */ package com.google.api.client.util.store;
/*     */ 
/*     */ import com.google.api.client.util.IOUtils;
/*     */ import com.google.api.client.util.Lists;
/*     */ import com.google.api.client.util.Maps;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractMemoryDataStore<V extends Serializable>
/*     */   extends AbstractDataStore<V>
/*     */ {
/*  41 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */   
/*  44 */   protected HashMap<String, byte[]> keyValueMap = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractMemoryDataStore(DataStoreFactory dataStoreFactory, String id) {
/*  51 */     super(dataStoreFactory, id);
/*     */   }
/*     */   
/*     */   public final Set<String> keySet() throws IOException {
/*  55 */     this.lock.lock();
/*     */     try {
/*  57 */       return (Set)Collections.unmodifiableSet(this.keyValueMap.keySet());
/*     */     } finally {
/*  59 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final Collection<V> values() throws IOException {
/*  64 */     this.lock.lock();
/*     */     try {
/*  66 */       List<V> result = Lists.newArrayList();
/*  67 */       for (byte[] bytes : this.keyValueMap.values()) {
/*  68 */         result.add((V)IOUtils.deserialize(bytes));
/*     */       }
/*  70 */       return Collections.unmodifiableList(result);
/*     */     } finally {
/*  72 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final V get(String key) throws IOException {
/*  77 */     if (key == null) {
/*  78 */       return null;
/*     */     }
/*  80 */     this.lock.lock();
/*     */     try {
/*  82 */       return (V)IOUtils.deserialize(this.keyValueMap.get(key));
/*     */     } finally {
/*  84 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public final DataStore<V> set(String key, V value) throws IOException {
/*  89 */     Preconditions.checkNotNull(key);
/*  90 */     Preconditions.checkNotNull(value);
/*  91 */     this.lock.lock();
/*     */     try {
/*  93 */       this.keyValueMap.put(key, IOUtils.serialize(value));
/*  94 */       save();
/*     */     } finally {
/*  96 */       this.lock.unlock();
/*     */     } 
/*  98 */     return this;
/*     */   }
/*     */   
/*     */   public DataStore<V> delete(String key) throws IOException {
/* 102 */     if (key == null) {
/* 103 */       return this;
/*     */     }
/* 105 */     this.lock.lock();
/*     */     try {
/* 107 */       this.keyValueMap.remove(key);
/* 108 */       save();
/*     */     } finally {
/* 110 */       this.lock.unlock();
/*     */     } 
/* 112 */     return this;
/*     */   }
/*     */   
/*     */   public final DataStore<V> clear() throws IOException {
/* 116 */     this.lock.lock();
/*     */     try {
/* 118 */       this.keyValueMap.clear();
/* 119 */       save();
/*     */     } finally {
/* 121 */       this.lock.unlock();
/*     */     } 
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(String key) throws IOException {
/* 128 */     if (key == null) {
/* 129 */       return false;
/*     */     }
/* 131 */     this.lock.lock();
/*     */     try {
/* 133 */       return this.keyValueMap.containsKey(key);
/*     */     } finally {
/* 135 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsValue(V value) throws IOException {
/* 141 */     if (value == null) {
/* 142 */       return false;
/*     */     }
/* 144 */     this.lock.lock();
/*     */     try {
/* 146 */       byte[] serialized = IOUtils.serialize(value);
/* 147 */       for (byte[] bytes : this.keyValueMap.values()) {
/* 148 */         if (Arrays.equals(serialized, bytes)) {
/* 149 */           return true;
/*     */         }
/*     */       } 
/* 152 */       return false;
/*     */     } finally {
/* 154 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() throws IOException {
/* 160 */     this.lock.lock();
/*     */     try {
/* 162 */       return this.keyValueMap.isEmpty();
/*     */     } finally {
/* 164 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() throws IOException {
/* 170 */     this.lock.lock();
/*     */     try {
/* 172 */       return this.keyValueMap.size();
/*     */     } finally {
/* 174 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 187 */     return DataStoreUtils.toString(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\store\AbstractMemoryDataStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */