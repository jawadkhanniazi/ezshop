/*    */ package com.google.api.client.util.store;
/*    */ 
/*    */ import com.google.api.client.util.Maps;
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.io.IOException;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.locks.Lock;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDataStoreFactory
/*    */   implements DataStoreFactory
/*    */ {
/* 35 */   private final Lock lock = new ReentrantLock();
/*    */ 
/*    */   
/* 38 */   private final Map<String, DataStore<? extends Serializable>> dataStoreMap = Maps.newHashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   private static final Pattern ID_PATTERN = Pattern.compile("\\w{1,30}");
/*    */   
/*    */   public final <V extends Serializable> DataStore<V> getDataStore(String id) throws IOException {
/* 47 */     Preconditions.checkArgument(ID_PATTERN
/* 48 */         .matcher(id).matches(), "%s does not match pattern %s", new Object[] { id, ID_PATTERN });
/* 49 */     this.lock.lock();
/*    */     
/*    */     try {
/* 52 */       DataStore<V> dataStore = (DataStore<V>)this.dataStoreMap.get(id);
/* 53 */       if (dataStore == null) {
/* 54 */         dataStore = createDataStore(id);
/* 55 */         this.dataStoreMap.put(id, dataStore);
/*    */       } 
/* 57 */       return dataStore;
/*    */     } finally {
/* 59 */       this.lock.unlock();
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract <V extends Serializable> DataStore<V> createDataStore(String paramString) throws IOException;
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\store\AbstractDataStoreFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */