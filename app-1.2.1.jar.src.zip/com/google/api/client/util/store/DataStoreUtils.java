/*    */ package com.google.api.client.util.store;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DataStoreUtils
/*    */ {
/*    */   public static String toString(DataStore<?> dataStore) {
/*    */     try {
/* 39 */       StringBuilder sb = new StringBuilder();
/* 40 */       sb.append('{');
/* 41 */       boolean first = true;
/* 42 */       for (String key : dataStore.keySet()) {
/* 43 */         if (first) {
/* 44 */           first = false;
/*    */         } else {
/* 46 */           sb.append(", ");
/*    */         } 
/* 48 */         sb.append(key).append('=').append(dataStore.get(key));
/*    */       } 
/* 50 */       return sb.append('}').toString();
/* 51 */     } catch (IOException e) {
/* 52 */       throw new RuntimeException(e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\store\DataStoreUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */