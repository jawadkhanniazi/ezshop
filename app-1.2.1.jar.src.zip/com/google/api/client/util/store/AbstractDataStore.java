/*    */ package com.google.api.client.util.store;
/*    */ 
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.io.IOException;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractDataStore<V extends Serializable>
/*    */   implements DataStore<V>
/*    */ {
/*    */   private final DataStoreFactory dataStoreFactory;
/*    */   private final String id;
/*    */   
/*    */   protected AbstractDataStore(DataStoreFactory dataStoreFactory, String id) {
/* 43 */     this.dataStoreFactory = (DataStoreFactory)Preconditions.checkNotNull(dataStoreFactory);
/* 44 */     this.id = (String)Preconditions.checkNotNull(id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataStoreFactory getDataStoreFactory() {
/* 54 */     return this.dataStoreFactory;
/*    */   }
/*    */   
/*    */   public final String getId() {
/* 58 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean containsKey(String key) throws IOException {
/* 67 */     return (get(key) != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean containsValue(V value) throws IOException {
/* 76 */     return values().contains(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEmpty() throws IOException {
/* 85 */     return (size() == 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int size() throws IOException {
/* 94 */     return keySet().size();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\store\AbstractDataStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */