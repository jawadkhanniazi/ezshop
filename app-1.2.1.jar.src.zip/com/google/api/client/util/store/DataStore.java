package com.google.api.client.util.store;

import java.io.IOException;
import java.util.Collection;
import java.util.Set;

public interface DataStore<V extends java.io.Serializable> {
  DataStoreFactory getDataStoreFactory();
  
  String getId();
  
  int size() throws IOException;
  
  boolean isEmpty() throws IOException;
  
  boolean containsKey(String paramString) throws IOException;
  
  boolean containsValue(V paramV) throws IOException;
  
  Set<String> keySet() throws IOException;
  
  Collection<V> values() throws IOException;
  
  V get(String paramString) throws IOException;
  
  DataStore<V> set(String paramString, V paramV) throws IOException;
  
  DataStore<V> clear() throws IOException;
  
  DataStore<V> delete(String paramString) throws IOException;
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\store\DataStore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */