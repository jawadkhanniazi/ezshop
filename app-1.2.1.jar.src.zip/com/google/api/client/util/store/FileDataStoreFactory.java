/*     */ package com.google.api.client.util.store;
/*     */ 
/*     */ import com.google.api.client.util.IOUtils;
/*     */ import com.google.api.client.util.Maps;
/*     */ import com.google.common.base.StandardSystemProperty;
/*     */ import com.google.common.collect.ImmutableList;
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.AclEntry;
/*     */ import java.nio.file.attribute.AclEntryPermission;
/*     */ import java.nio.file.attribute.AclEntryType;
/*     */ import java.nio.file.attribute.AclFileAttributeView;
/*     */ import java.nio.file.attribute.PosixFilePermission;
/*     */ import java.nio.file.attribute.UserPrincipal;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileDataStoreFactory
/*     */   extends AbstractDataStoreFactory
/*     */ {
/*  53 */   private static final Logger LOGGER = Logger.getLogger(FileDataStoreFactory.class.getName());
/*     */   
/*  55 */   private static final boolean IS_WINDOWS = StandardSystemProperty.OS_NAME.value()
/*  56 */     .startsWith("WINDOWS");
/*     */ 
/*     */   
/*     */   private final File dataDirectory;
/*     */ 
/*     */   
/*     */   public FileDataStoreFactory(File dataDirectory) throws IOException {
/*  63 */     dataDirectory = dataDirectory.getCanonicalFile();
/*  64 */     this.dataDirectory = dataDirectory;
/*     */     
/*  66 */     if (IOUtils.isSymbolicLink(dataDirectory)) {
/*  67 */       throw new IOException("unable to use a symbolic link: " + dataDirectory);
/*     */     }
/*     */     
/*  70 */     if (!dataDirectory.exists() && !dataDirectory.mkdirs()) {
/*  71 */       throw new IOException("unable to create directory: " + dataDirectory);
/*     */     }
/*     */     
/*  74 */     if (IS_WINDOWS) {
/*  75 */       setPermissionsToOwnerOnlyWindows(dataDirectory);
/*     */     } else {
/*  77 */       setPermissionsToOwnerOnly(dataDirectory);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final File getDataDirectory() {
/*  83 */     return this.dataDirectory;
/*     */   }
/*     */ 
/*     */   
/*     */   protected <V extends Serializable> DataStore<V> createDataStore(String id) throws IOException {
/*  88 */     return new FileDataStore<>(this, this.dataDirectory, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class FileDataStore<V extends Serializable>
/*     */     extends AbstractMemoryDataStore<V>
/*     */   {
/*     */     private final File dataFile;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     FileDataStore(FileDataStoreFactory dataStore, File dataDirectory, String id) throws IOException {
/* 104 */       super(dataStore, id);
/* 105 */       this.dataFile = new File(dataDirectory, id);
/*     */       
/* 107 */       if (IOUtils.isSymbolicLink(this.dataFile)) {
/* 108 */         throw new IOException("unable to use a symbolic link: " + this.dataFile);
/*     */       }
/*     */       
/* 111 */       if (this.dataFile.createNewFile()) {
/* 112 */         this.keyValueMap = Maps.newHashMap();
/*     */         
/* 114 */         save();
/*     */       } else {
/*     */         
/* 117 */         this.keyValueMap = (HashMap<String, byte[]>)IOUtils.deserialize(new FileInputStream(this.dataFile));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void save() throws IOException {
/* 123 */       IOUtils.serialize(this.keyValueMap, new FileOutputStream(this.dataFile));
/*     */     }
/*     */ 
/*     */     
/*     */     public FileDataStoreFactory getDataStoreFactory() {
/* 128 */       return (FileDataStoreFactory)super.getDataStoreFactory();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setPermissionsToOwnerOnly(File file) throws IOException {
/* 140 */     Set<PosixFilePermission> permissions = new HashSet();
/* 141 */     permissions.add(PosixFilePermission.OWNER_READ);
/* 142 */     permissions.add(PosixFilePermission.OWNER_WRITE);
/* 143 */     permissions.add(PosixFilePermission.OWNER_EXECUTE);
/*     */     try {
/* 145 */       Files.setPosixFilePermissions(Paths.get(file.getAbsolutePath(), new String[0]), permissions);
/* 146 */     } catch (UnsupportedOperationException exception) {
/* 147 */       LOGGER.warning("Unable to set permissions for " + file + ", because you are running on a non-POSIX file system.");
/*     */     }
/* 149 */     catch (SecurityException securityException) {
/*     */     
/* 151 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void setPermissionsToOwnerOnlyWindows(File file) throws IOException {
/* 157 */     Path path = Paths.get(file.getAbsolutePath(), new String[0]);
/*     */     
/* 159 */     UserPrincipal owner = path.getFileSystem().getUserPrincipalLookupService().lookupPrincipalByName("OWNER@");
/*     */ 
/*     */     
/* 162 */     AclFileAttributeView view = Files.<AclFileAttributeView>getFileAttributeView(path, AclFileAttributeView.class, new java.nio.file.LinkOption[0]);
/*     */ 
/*     */     
/* 165 */     ImmutableSet immutableSet = ImmutableSet.of(AclEntryPermission.APPEND_DATA, AclEntryPermission.DELETE, AclEntryPermission.DELETE_CHILD, AclEntryPermission.READ_ACL, AclEntryPermission.READ_ATTRIBUTES, AclEntryPermission.READ_DATA, (Object[])new AclEntryPermission[] { AclEntryPermission.READ_NAMED_ATTRS, AclEntryPermission.SYNCHRONIZE, AclEntryPermission.WRITE_ACL, AclEntryPermission.WRITE_ATTRIBUTES, AclEntryPermission.WRITE_DATA, AclEntryPermission.WRITE_NAMED_ATTRS, AclEntryPermission.WRITE_OWNER });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     AclEntry entry = AclEntry.newBuilder().setType(AclEntryType.ALLOW).setPrincipal(owner).setPermissions((Set<AclEntryPermission>)immutableSet).build();
/*     */ 
/*     */     
/* 189 */     view.setAcl((List<AclEntry>)ImmutableList.of(entry));
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\store\FileDataStoreFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */