/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOUtils
/*     */ {
/*     */   public static void copy(InputStream inputStream, OutputStream outputStream) throws IOException {
/*  59 */     copy(inputStream, outputStream, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copy(InputStream inputStream, OutputStream outputStream, boolean closeInputStream) throws IOException {
/*     */     try {
/*  87 */       ByteStreams.copy(inputStream, outputStream);
/*     */     } finally {
/*  89 */       if (closeInputStream) {
/*  90 */         inputStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long computeLength(StreamingContent content) throws IOException {
/* 102 */     ByteCountingOutputStream countingStream = new ByteCountingOutputStream();
/*     */     try {
/* 104 */       content.writeTo(countingStream);
/*     */     } finally {
/* 106 */       countingStream.close();
/*     */     } 
/* 108 */     return countingStream.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] serialize(Object value) throws IOException {
/* 118 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 119 */     serialize(value, out);
/* 120 */     return out.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void serialize(Object value, OutputStream outputStream) throws IOException {
/*     */     try {
/* 132 */       (new ObjectOutputStream(outputStream)).writeObject(value);
/*     */     } finally {
/* 134 */       outputStream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S extends java.io.Serializable> S deserialize(byte[] bytes) throws IOException {
/* 146 */     if (bytes == null) {
/* 147 */       return null;
/*     */     }
/* 149 */     return deserialize(new ByteArrayInputStream(bytes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <S extends java.io.Serializable> S deserialize(InputStream inputStream) throws IOException {
/*     */     try {
/* 162 */       return (S)(new ObjectInputStream(inputStream)).readObject();
/* 163 */     } catch (ClassNotFoundException exception) {
/* 164 */       IOException ioe = new IOException("Failed to deserialize object");
/* 165 */       ioe.initCause(exception);
/* 166 */       throw ioe;
/*     */     } finally {
/* 168 */       inputStream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSymbolicLink(File file) throws IOException {
/*     */     try {
/* 181 */       Class<?> filesClass = Class.forName("java.nio.file.Files");
/* 182 */       Class<?> pathClass = Class.forName("java.nio.file.Path");
/* 183 */       Object path = File.class.getMethod("toPath", new Class[0]).invoke(file, new Object[0]);
/* 184 */       return ((Boolean)filesClass.getMethod("isSymbolicLink", new Class[] { pathClass }).invoke(null, new Object[] { path
/* 185 */           })).booleanValue();
/* 186 */     } catch (InvocationTargetException exception) {
/* 187 */       Throwable cause = exception.getCause();
/* 188 */       Throwables.propagateIfPossible(cause, IOException.class);
/*     */       
/* 190 */       throw new RuntimeException(cause);
/* 191 */     } catch (ClassNotFoundException classNotFoundException) {
/*     */     
/* 193 */     } catch (IllegalArgumentException illegalArgumentException) {
/*     */     
/* 195 */     } catch (SecurityException securityException) {
/*     */     
/* 197 */     } catch (IllegalAccessException illegalAccessException) {
/*     */     
/* 199 */     } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     if (File.separatorChar == '\\') {
/* 205 */       return false;
/*     */     }
/* 207 */     File canonical = file;
/* 208 */     if (file.getParent() != null) {
/* 209 */       canonical = new File(file.getParentFile().getCanonicalFile(), file.getName());
/*     */     }
/* 211 */     return !canonical.getCanonicalFile().equals(canonical.getAbsoluteFile());
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\IOUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */