/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ByteStreams
/*     */ {
/*     */   private static final int BUF_SIZE = 4096;
/*     */   
/*     */   public static long copy(InputStream from, OutputStream to) throws IOException {
/*  44 */     Preconditions.checkNotNull(from);
/*  45 */     Preconditions.checkNotNull(to);
/*  46 */     byte[] buf = new byte[4096];
/*  47 */     long total = 0L;
/*     */     while (true) {
/*  49 */       int r = from.read(buf);
/*  50 */       if (r == -1) {
/*     */         break;
/*     */       }
/*  53 */       to.write(buf, 0, r);
/*  54 */       total += r;
/*     */     } 
/*  56 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InputStream limit(InputStream in, long limit) {
/*  67 */     return new LimitedInputStream(in, limit);
/*     */   }
/*     */   
/*     */   private static final class LimitedInputStream
/*     */     extends FilterInputStream {
/*     */     private long left;
/*  73 */     private long mark = -1L;
/*     */     
/*     */     LimitedInputStream(InputStream in, long limit) {
/*  76 */       super(in);
/*  77 */       Preconditions.checkNotNull(in);
/*  78 */       Preconditions.checkArgument((limit >= 0L), "limit must be non-negative");
/*  79 */       this.left = limit;
/*     */     }
/*     */ 
/*     */     
/*     */     public int available() throws IOException {
/*  84 */       return (int)Math.min(this.in.available(), this.left);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized void mark(int readLimit) {
/*  90 */       this.in.mark(readLimit);
/*  91 */       this.mark = this.left;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/*  96 */       if (this.left == 0L) {
/*  97 */         return -1;
/*     */       }
/*     */       
/* 100 */       int result = this.in.read();
/* 101 */       if (result != -1) {
/* 102 */         this.left--;
/*     */       }
/* 104 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 109 */       if (this.left == 0L) {
/* 110 */         return -1;
/*     */       }
/*     */       
/* 113 */       len = (int)Math.min(len, this.left);
/* 114 */       int result = this.in.read(b, off, len);
/* 115 */       if (result != -1) {
/* 116 */         this.left -= result;
/*     */       }
/* 118 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void reset() throws IOException {
/* 123 */       if (!this.in.markSupported()) {
/* 124 */         throw new IOException("Mark not supported");
/*     */       }
/* 126 */       if (this.mark == -1L) {
/* 127 */         throw new IOException("Mark not set");
/*     */       }
/*     */       
/* 130 */       this.in.reset();
/* 131 */       this.left = this.mark;
/*     */     }
/*     */ 
/*     */     
/*     */     public long skip(long n) throws IOException {
/* 136 */       n = Math.min(n, this.left);
/* 137 */       long skipped = this.in.skip(n);
/* 138 */       this.left -= skipped;
/* 139 */       return skipped;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int read(InputStream in, byte[] b, int off, int len) throws IOException {
/* 166 */     Preconditions.checkNotNull(in);
/* 167 */     Preconditions.checkNotNull(b);
/* 168 */     if (len < 0) {
/* 169 */       throw new IndexOutOfBoundsException("len is negative");
/*     */     }
/* 171 */     int total = 0;
/* 172 */     while (total < len) {
/* 173 */       int result = in.read(b, off + total, len - total);
/* 174 */       if (result == -1) {
/*     */         break;
/*     */       }
/* 177 */       total += result;
/*     */     } 
/* 179 */     return total;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\ByteStreams.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */