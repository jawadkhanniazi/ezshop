/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Lists
/*    */ {
/*    */   public static <E> ArrayList<E> newArrayList() {
/* 35 */     return new ArrayList<>();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <E> ArrayList<E> newArrayListWithCapacity(int initialArraySize) {
/* 49 */     return new ArrayList<>(initialArraySize);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <E> ArrayList<E> newArrayList(Iterable<? extends E> elements) {
/* 59 */     return (elements instanceof java.util.Collection) ? new ArrayList<>(
/* 60 */         Collections2.cast(elements)) : 
/* 61 */       newArrayList(elements.iterator());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <E> ArrayList<E> newArrayList(Iterator<? extends E> elements) {
/* 71 */     ArrayList<E> list = newArrayList();
/* 72 */     while (elements.hasNext()) {
/* 73 */       list.add(elements.next());
/*    */     }
/* 75 */     return list;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Lists.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */