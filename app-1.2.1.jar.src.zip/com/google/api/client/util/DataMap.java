/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DataMap
/*     */   extends AbstractMap<String, Object>
/*     */ {
/*     */   final Object object;
/*     */   final ClassInfo classInfo;
/*     */   
/*     */   DataMap(Object object, boolean ignoreCase) {
/*  42 */     this.object = object;
/*  43 */     this.classInfo = ClassInfo.of(object.getClass(), ignoreCase);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntrySet entrySet() {
/*  48 */     return new EntrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  53 */     return (get(key) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/*  58 */     if (!(key instanceof String)) {
/*  59 */       return null;
/*     */     }
/*  61 */     FieldInfo fieldInfo = this.classInfo.getFieldInfo((String)key);
/*  62 */     if (fieldInfo == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     return fieldInfo.getValue(this.object);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object put(String key, Object value) {
/*  70 */     FieldInfo fieldInfo = this.classInfo.getFieldInfo(key);
/*  71 */     Preconditions.checkNotNull(fieldInfo, "no field of key " + key);
/*  72 */     Object oldValue = fieldInfo.getValue(this.object);
/*  73 */     fieldInfo.setValue(this.object, Preconditions.checkNotNull(value));
/*  74 */     return oldValue;
/*     */   }
/*     */ 
/*     */   
/*     */   final class EntrySet
/*     */     extends AbstractSet<Map.Entry<String, Object>>
/*     */   {
/*     */     public DataMap.EntryIterator iterator() {
/*  82 */       return new DataMap.EntryIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/*  87 */       int result = 0;
/*  88 */       for (String name : DataMap.this.classInfo.names) {
/*  89 */         if (DataMap.this.classInfo.getFieldInfo(name).getValue(DataMap.this.object) != null) {
/*  90 */           result++;
/*     */         }
/*     */       } 
/*  93 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/*  98 */       for (String name : DataMap.this.classInfo.names) {
/*  99 */         DataMap.this.classInfo.getFieldInfo(name).setValue(DataMap.this.object, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 105 */       for (String name : DataMap.this.classInfo.names) {
/* 106 */         if (DataMap.this.classInfo.getFieldInfo(name).getValue(DataMap.this.object) != null) {
/* 107 */           return false;
/*     */         }
/*     */       } 
/* 110 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final class EntryIterator
/*     */     implements Iterator<Map.Entry<String, Object>>
/*     */   {
/* 121 */     private int nextKeyIndex = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private FieldInfo nextFieldInfo;
/*     */ 
/*     */ 
/*     */     
/*     */     private Object nextFieldValue;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isRemoved;
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isComputed;
/*     */ 
/*     */ 
/*     */     
/*     */     private FieldInfo currentFieldInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 148 */       if (!this.isComputed) {
/* 149 */         this.isComputed = true;
/* 150 */         this.nextFieldValue = null;
/* 151 */         while (this.nextFieldValue == null && ++this.nextKeyIndex < DataMap.this.classInfo.names.size()) {
/* 152 */           this.nextFieldInfo = DataMap.this.classInfo.getFieldInfo(DataMap.this.classInfo.names.get(this.nextKeyIndex));
/* 153 */           this.nextFieldValue = this.nextFieldInfo.getValue(DataMap.this.object);
/*     */         } 
/*     */       } 
/* 156 */       return (this.nextFieldValue != null);
/*     */     }
/*     */     
/*     */     public Map.Entry<String, Object> next() {
/* 160 */       if (!hasNext()) {
/* 161 */         throw new NoSuchElementException();
/*     */       }
/* 163 */       this.currentFieldInfo = this.nextFieldInfo;
/* 164 */       Object currentFieldValue = this.nextFieldValue;
/* 165 */       this.isComputed = false;
/* 166 */       this.isRemoved = false;
/* 167 */       this.nextFieldInfo = null;
/* 168 */       this.nextFieldValue = null;
/* 169 */       return new DataMap.Entry(this.currentFieldInfo, currentFieldValue);
/*     */     }
/*     */     
/*     */     public void remove() {
/* 173 */       Preconditions.checkState((this.currentFieldInfo != null && !this.isRemoved));
/* 174 */       this.isRemoved = true;
/* 175 */       this.currentFieldInfo.setValue(DataMap.this.object, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final class Entry
/*     */     implements Map.Entry<String, Object>
/*     */   {
/*     */     private Object fieldValue;
/*     */ 
/*     */ 
/*     */     
/*     */     private final FieldInfo fieldInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Entry(FieldInfo fieldInfo, Object fieldValue) {
/* 196 */       this.fieldInfo = fieldInfo;
/* 197 */       this.fieldValue = Preconditions.checkNotNull(fieldValue);
/*     */     }
/*     */     
/*     */     public String getKey() {
/* 201 */       String result = this.fieldInfo.getName();
/* 202 */       if (DataMap.this.classInfo.getIgnoreCase()) {
/* 203 */         result = result.toLowerCase(Locale.US);
/*     */       }
/* 205 */       return result;
/*     */     }
/*     */     
/*     */     public Object getValue() {
/* 209 */       return this.fieldValue;
/*     */     }
/*     */     
/*     */     public Object setValue(Object value) {
/* 213 */       Object oldValue = this.fieldValue;
/* 214 */       this.fieldValue = Preconditions.checkNotNull(value);
/* 215 */       this.fieldInfo.setValue(DataMap.this.object, value);
/* 216 */       return oldValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 221 */       return getKey().hashCode() ^ getValue().hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 226 */       if (this == obj) {
/* 227 */         return true;
/*     */       }
/* 229 */       if (!(obj instanceof Map.Entry)) {
/* 230 */         return false;
/*     */       }
/* 232 */       Map.Entry<?, ?> other = (Map.Entry<?, ?>)obj;
/* 233 */       return (getKey().equals(other.getKey()) && getValue().equals(other.getValue()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\DataMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */