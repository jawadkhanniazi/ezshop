/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LoggingStreamingContent
/*    */   implements StreamingContent
/*    */ {
/*    */   private final StreamingContent content;
/*    */   private final int contentLoggingLimit;
/*    */   private final Level loggingLevel;
/*    */   private final Logger logger;
/*    */   
/*    */   public LoggingStreamingContent(StreamingContent content, Logger logger, Level loggingLevel, int contentLoggingLimit) {
/* 53 */     this.content = content;
/* 54 */     this.logger = logger;
/* 55 */     this.loggingLevel = loggingLevel;
/* 56 */     this.contentLoggingLimit = contentLoggingLimit;
/*    */   }
/*    */   
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 60 */     LoggingOutputStream loggableOutputStream = new LoggingOutputStream(out, this.logger, this.loggingLevel, this.contentLoggingLimit);
/*    */     
/*    */     try {
/* 63 */       this.content.writeTo(loggableOutputStream);
/*    */     } finally {
/*    */       
/* 66 */       loggableOutputStream.getLogStream().close();
/*    */     } 
/* 68 */     out.flush();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\LoggingStreamingContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */