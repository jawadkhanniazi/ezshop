/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingByteArrayOutputStream
/*     */   extends ByteArrayOutputStream
/*     */ {
/*     */   private int bytesWritten;
/*     */   private final int maximumBytesToLog;
/*     */   private boolean closed;
/*     */   private final Level loggingLevel;
/*     */   private final Logger logger;
/*     */   
/*     */   public LoggingByteArrayOutputStream(Logger logger, Level loggingLevel, int maximumBytesToLog) {
/*  61 */     this.logger = Preconditions.<Logger>checkNotNull(logger);
/*  62 */     this.loggingLevel = Preconditions.<Level>checkNotNull(loggingLevel);
/*  63 */     Preconditions.checkArgument((maximumBytesToLog >= 0));
/*  64 */     this.maximumBytesToLog = maximumBytesToLog;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void write(int b) {
/*  69 */     Preconditions.checkArgument(!this.closed);
/*  70 */     this.bytesWritten++;
/*  71 */     if (this.count < this.maximumBytesToLog) {
/*  72 */       super.write(b);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void write(byte[] b, int off, int len) {
/*  78 */     Preconditions.checkArgument(!this.closed);
/*  79 */     this.bytesWritten += len;
/*  80 */     if (this.count < this.maximumBytesToLog) {
/*  81 */       int end = this.count + len;
/*  82 */       if (end > this.maximumBytesToLog) {
/*  83 */         len += this.maximumBytesToLog - end;
/*     */       }
/*  85 */       super.write(b, off, len);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws IOException {
/*  92 */     if (!this.closed) {
/*     */       
/*  94 */       if (this.bytesWritten != 0) {
/*     */         
/*  96 */         StringBuilder buf = (new StringBuilder()).append("Total: ");
/*  97 */         appendBytes(buf, this.bytesWritten);
/*  98 */         if (this.count != 0 && this.count < this.bytesWritten) {
/*  99 */           buf.append(" (logging first ");
/* 100 */           appendBytes(buf, this.count);
/* 101 */           buf.append(")");
/*     */         } 
/* 103 */         this.logger.config(buf.toString());
/*     */         
/* 105 */         if (this.count != 0)
/*     */         {
/* 107 */           this.logger.log(this.loggingLevel, 
/*     */               
/* 109 */               toString("UTF-8").replaceAll("[\\x00-\\x09\\x0B\\x0C\\x0E-\\x1F\\x7F]", " "));
/*     */         }
/*     */       } 
/* 112 */       this.closed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getMaximumBytesToLog() {
/* 118 */     return this.maximumBytesToLog;
/*     */   }
/*     */ 
/*     */   
/*     */   public final synchronized int getBytesWritten() {
/* 123 */     return this.bytesWritten;
/*     */   }
/*     */   
/*     */   private static void appendBytes(StringBuilder buf, int x) {
/* 127 */     if (x == 1) {
/* 128 */       buf.append("1 byte");
/*     */     } else {
/* 130 */       buf.append(NumberFormat.getInstance().format(x)).append(" bytes");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\LoggingByteArrayOutputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */