/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingOutputStream
/*    */   extends FilterOutputStream
/*    */ {
/*    */   private final LoggingByteArrayOutputStream logStream;
/*    */   
/*    */   public LoggingOutputStream(OutputStream outputStream, Logger logger, Level loggingLevel, int contentLoggingLimit) {
/* 44 */     super(outputStream);
/* 45 */     this.logStream = new LoggingByteArrayOutputStream(logger, loggingLevel, contentLoggingLimit);
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(int b) throws IOException {
/* 50 */     this.out.write(b);
/* 51 */     this.logStream.write(b);
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(byte[] b, int off, int len) throws IOException {
/* 56 */     this.out.write(b, off, len);
/* 57 */     this.logStream.write(b, off, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 62 */     this.logStream.close();
/* 63 */     super.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public final LoggingByteArrayOutputStream getLogStream() {
/* 68 */     return this.logStream;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\LoggingOutputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */