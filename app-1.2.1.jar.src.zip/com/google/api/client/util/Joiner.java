/*    */ package com.google.api.client.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Joiner
/*    */ {
/*    */   private final com.google.common.base.Joiner wrapped;
/*    */   
/*    */   public static Joiner on(char separator) {
/* 35 */     return new Joiner(com.google.common.base.Joiner.on(separator));
/*    */   }
/*    */ 
/*    */   
/*    */   private Joiner(com.google.common.base.Joiner wrapped) {
/* 40 */     this.wrapped = wrapped;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final String join(Iterable<?> parts) {
/* 48 */     return this.wrapped.join(parts);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Joiner.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */