/*    */ package com.google.api.client.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public final class BackOffUtils
/*    */ {
/*    */   public static boolean next(Sleeper sleeper, BackOff backOff) throws InterruptedException, IOException {
/* 44 */     long backOffTime = backOff.nextBackOffMillis();
/* 45 */     if (backOffTime == -1L) {
/* 46 */       return false;
/*    */     }
/* 48 */     sleeper.sleep(backOffTime);
/* 49 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\BackOffUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */