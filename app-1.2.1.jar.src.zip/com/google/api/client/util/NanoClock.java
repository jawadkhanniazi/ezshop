/*    */ package com.google.api.client.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface NanoClock
/*    */ {
/* 37 */   public static final NanoClock SYSTEM = new NanoClock()
/*    */     {
/*    */       public long nanoTime() {
/* 40 */         return System.nanoTime();
/*    */       }
/*    */     };
/*    */   
/*    */   long nanoTime();
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\NanoClock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */