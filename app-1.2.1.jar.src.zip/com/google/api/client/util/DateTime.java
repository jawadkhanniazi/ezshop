/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import com.google.common.base.Strings;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Objects;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateTime
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  42 */   private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String RFC3339_REGEX = "(\\d{4})-(\\d{2})-(\\d{2})([Tt](\\d{2}):(\\d{2}):(\\d{2})(\\.\\d{1,9})?)?([Zz]|([+-])(\\d{2}):(\\d{2}))?";
/*     */ 
/*     */ 
/*     */   
/*  50 */   private static final Pattern RFC3339_PATTERN = Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2})([Tt](\\d{2}):(\\d{2}):(\\d{2})(\\.\\d{1,9})?)?([Zz]|([+-])(\\d{2}):(\\d{2}))?");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final long value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean dateOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int tzShift;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(Date date, TimeZone zone) {
/*  73 */     this(false, date.getTime(), (zone == null) ? null : Integer.valueOf(zone.getOffset(date.getTime()) / 60000));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(long value) {
/*  85 */     this(false, value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(Date value) {
/*  97 */     this(value.getTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(long value, int tzShift) {
/* 108 */     this(false, value, Integer.valueOf(tzShift));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(boolean dateOnly, long value, Integer tzShift) {
/* 121 */     this.dateOnly = dateOnly;
/* 122 */     this.value = value;
/* 123 */     this
/* 124 */       .tzShift = dateOnly ? 0 : ((tzShift == null) ? (TimeZone.getDefault().getOffset(value) / 60000) : tzShift.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(String value) {
/* 145 */     DateTime dateTime = parseRfc3339(value);
/* 146 */     this.dateOnly = dateTime.dateOnly;
/* 147 */     this.value = dateTime.value;
/* 148 */     this.tzShift = dateTime.tzShift;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getValue() {
/* 160 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDateOnly() {
/* 169 */     return this.dateOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTimeZoneShift() {
/* 178 */     return this.tzShift;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toStringRfc3339() {
/* 183 */     StringBuilder sb = new StringBuilder();
/* 184 */     Calendar dateTime = new GregorianCalendar(GMT);
/* 185 */     long localTime = this.value + this.tzShift * 60000L;
/* 186 */     dateTime.setTimeInMillis(localTime);
/*     */     
/* 188 */     appendInt(sb, dateTime.get(1), 4);
/* 189 */     sb.append('-');
/* 190 */     appendInt(sb, dateTime.get(2) + 1, 2);
/* 191 */     sb.append('-');
/* 192 */     appendInt(sb, dateTime.get(5), 2);
/* 193 */     if (!this.dateOnly) {
/*     */       
/* 195 */       sb.append('T');
/* 196 */       appendInt(sb, dateTime.get(11), 2);
/* 197 */       sb.append(':');
/* 198 */       appendInt(sb, dateTime.get(12), 2);
/* 199 */       sb.append(':');
/* 200 */       appendInt(sb, dateTime.get(13), 2);
/*     */       
/* 202 */       if (dateTime.isSet(14)) {
/* 203 */         sb.append('.');
/* 204 */         appendInt(sb, dateTime.get(14), 3);
/*     */       } 
/*     */       
/* 207 */       if (this.tzShift == 0) {
/* 208 */         sb.append('Z');
/*     */       } else {
/* 210 */         int absTzShift = this.tzShift;
/* 211 */         if (this.tzShift > 0) {
/* 212 */           sb.append('+');
/*     */         } else {
/* 214 */           sb.append('-');
/* 215 */           absTzShift = -absTzShift;
/*     */         } 
/*     */         
/* 218 */         int tzHours = absTzShift / 60;
/* 219 */         int tzMinutes = absTzShift % 60;
/* 220 */         appendInt(sb, tzHours, 2);
/* 221 */         sb.append(':');
/* 222 */         appendInt(sb, tzMinutes, 2);
/*     */       } 
/*     */     } 
/* 225 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 230 */     return toStringRfc3339();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 241 */     if (o == this) {
/* 242 */       return true;
/*     */     }
/* 244 */     if (!(o instanceof DateTime)) {
/* 245 */       return false;
/*     */     }
/* 247 */     DateTime other = (DateTime)o;
/* 248 */     return (this.dateOnly == other.dateOnly && this.value == other.value && this.tzShift == other.tzShift);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 253 */     return Arrays.hashCode(new long[] { this.value, this.dateOnly ? 1L : 0L, this.tzShift });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DateTime parseRfc3339(String str) throws NumberFormatException {
/* 277 */     return parseRfc3339WithNanoSeconds(str).toDateTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecondsAndNanos parseRfc3339ToSecondsAndNanos(String str) throws IllegalArgumentException {
/* 290 */     return parseRfc3339WithNanoSeconds(str).toSecondsAndNanos();
/*     */   }
/*     */   
/*     */   public static final class SecondsAndNanos
/*     */     implements Serializable {
/*     */     private final long seconds;
/*     */     private final int nanos;
/*     */     
/*     */     public static SecondsAndNanos ofSecondsAndNanos(long seconds, int nanos) {
/* 299 */       return new SecondsAndNanos(seconds, nanos);
/*     */     }
/*     */     
/*     */     private SecondsAndNanos(long seconds, int nanos) {
/* 303 */       this.seconds = seconds;
/* 304 */       this.nanos = nanos;
/*     */     }
/*     */     
/*     */     public long getSeconds() {
/* 308 */       return this.seconds;
/*     */     }
/*     */     
/*     */     public int getNanos() {
/* 312 */       return this.nanos;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 317 */       if (this == o) {
/* 318 */         return true;
/*     */       }
/* 320 */       if (o == null || getClass() != o.getClass()) {
/* 321 */         return false;
/*     */       }
/* 323 */       SecondsAndNanos that = (SecondsAndNanos)o;
/* 324 */       return (this.seconds == that.seconds && this.nanos == that.nanos);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 329 */       return Objects.hash(new Object[] { Long.valueOf(this.seconds), Integer.valueOf(this.nanos) });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 334 */       return String.format("Seconds: %d, Nanos: %d", new Object[] { Long.valueOf(this.seconds), Integer.valueOf(this.nanos) });
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Rfc3339ParseResult
/*     */     implements Serializable {
/*     */     private final long seconds;
/*     */     private final int nanos;
/*     */     private final boolean timeGiven;
/*     */     private final Integer tzShift;
/*     */     
/*     */     private Rfc3339ParseResult(long seconds, int nanos, boolean timeGiven, Integer tzShift) {
/* 346 */       this.seconds = seconds;
/* 347 */       this.nanos = nanos;
/* 348 */       this.timeGiven = timeGiven;
/* 349 */       this.tzShift = tzShift;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private DateTime toDateTime() {
/* 357 */       long seconds = TimeUnit.SECONDS.toMillis(this.seconds);
/* 358 */       long nanos = TimeUnit.NANOSECONDS.toMillis(this.nanos);
/* 359 */       return new DateTime(!this.timeGiven, seconds + nanos, this.tzShift);
/*     */     }
/*     */     
/*     */     private DateTime.SecondsAndNanos toSecondsAndNanos() {
/* 363 */       return new DateTime.SecondsAndNanos(this.seconds, this.nanos);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static Rfc3339ParseResult parseRfc3339WithNanoSeconds(String str) throws NumberFormatException {
/* 369 */     Matcher matcher = RFC3339_PATTERN.matcher(str);
/* 370 */     if (!matcher.matches()) {
/* 371 */       throw new NumberFormatException("Invalid date/time format: " + str);
/*     */     }
/*     */     
/* 374 */     int year = Integer.parseInt(matcher.group(1));
/* 375 */     int month = Integer.parseInt(matcher.group(2)) - 1;
/* 376 */     int day = Integer.parseInt(matcher.group(3));
/* 377 */     boolean isTimeGiven = (matcher.group(4) != null);
/* 378 */     String tzShiftRegexGroup = matcher.group(9);
/* 379 */     boolean isTzShiftGiven = (tzShiftRegexGroup != null);
/* 380 */     int hourOfDay = 0;
/* 381 */     int minute = 0;
/* 382 */     int second = 0;
/* 383 */     int nanoseconds = 0;
/* 384 */     Integer tzShiftInteger = null;
/*     */     
/* 386 */     if (isTzShiftGiven && !isTimeGiven) {
/* 387 */       throw new NumberFormatException("Invalid date/time format, cannot specify time zone shift without specifying time: " + str);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 393 */     if (isTimeGiven) {
/* 394 */       hourOfDay = Integer.parseInt(matcher.group(5));
/* 395 */       minute = Integer.parseInt(matcher.group(6));
/* 396 */       second = Integer.parseInt(matcher.group(7));
/* 397 */       if (matcher.group(8) != null) {
/* 398 */         String fraction = Strings.padEnd(matcher.group(8).substring(1), 9, '0');
/* 399 */         nanoseconds = Integer.parseInt(fraction);
/*     */       } 
/*     */     } 
/* 402 */     Calendar dateTime = new GregorianCalendar(GMT);
/* 403 */     dateTime.set(year, month, day, hourOfDay, minute, second);
/* 404 */     long value = dateTime.getTimeInMillis();
/*     */     
/* 406 */     if (isTimeGiven && isTzShiftGiven) {
/* 407 */       if (Character.toUpperCase(tzShiftRegexGroup.charAt(0)) != 'Z') {
/*     */ 
/*     */         
/* 410 */         int tzShift = Integer.parseInt(matcher.group(11)) * 60 + Integer.parseInt(matcher.group(12));
/* 411 */         if (matcher.group(10).charAt(0) == '-') {
/* 412 */           tzShift = -tzShift;
/*     */         }
/* 414 */         value -= tzShift * 60000L;
/* 415 */         tzShiftInteger = Integer.valueOf(tzShift);
/*     */       } else {
/* 417 */         tzShiftInteger = Integer.valueOf(0);
/*     */       } 
/*     */     }
/*     */     
/* 421 */     long secondsSinceEpoch = value / 1000L;
/* 422 */     return new Rfc3339ParseResult(secondsSinceEpoch, nanoseconds, isTimeGiven, tzShiftInteger);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void appendInt(StringBuilder sb, int num, int numDigits) {
/* 427 */     if (num < 0) {
/* 428 */       sb.append('-');
/* 429 */       num = -num;
/*     */     } 
/* 431 */     int x = num;
/* 432 */     while (x > 0) {
/* 433 */       x /= 10;
/* 434 */       numDigits--;
/*     */     } 
/* 436 */     for (int i = 0; i < numDigits; i++) {
/* 437 */       sb.append('0');
/*     */     }
/* 439 */     if (num != 0)
/* 440 */       sb.append(num); 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\DateTime.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */