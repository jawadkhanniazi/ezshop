/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.KeyManagerFactory;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SslUtils
/*     */ {
/*     */   public static SSLContext getSslContext() throws NoSuchAlgorithmException {
/*  44 */     return SSLContext.getInstance("SSL");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SSLContext getTlsSslContext() throws NoSuchAlgorithmException {
/*  53 */     return SSLContext.getInstance("TLS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TrustManagerFactory getDefaultTrustManagerFactory() throws NoSuchAlgorithmException {
/*  63 */     return TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TrustManagerFactory getPkixTrustManagerFactory() throws NoSuchAlgorithmException {
/*  72 */     return TrustManagerFactory.getInstance("PKIX");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyManagerFactory getDefaultKeyManagerFactory() throws NoSuchAlgorithmException {
/*  81 */     return KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyManagerFactory getPkixKeyManagerFactory() throws NoSuchAlgorithmException {
/*  90 */     return KeyManagerFactory.getInstance("PKIX");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SSLContext initSslContext(SSLContext sslContext, KeyStore trustStore, TrustManagerFactory trustManagerFactory) throws GeneralSecurityException {
/* 107 */     trustManagerFactory.init(trustStore);
/* 108 */     sslContext.init(null, trustManagerFactory.getTrustManagers(), null);
/* 109 */     return sslContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static SSLContext trustAllSSLContext() throws GeneralSecurityException {
/* 121 */     TrustManager[] trustAllCerts = { new X509TrustManager()
/*     */         {
/*     */           public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */ 
/*     */ 
/*     */           
/*     */           public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {}
/*     */ 
/*     */ 
/*     */           
/*     */           public X509Certificate[] getAcceptedIssuers() {
/* 132 */             return null;
/*     */           }
/*     */         } };
/*     */     
/* 136 */     SSLContext context = getTlsSslContext();
/* 137 */     context.init(null, trustAllCerts, null);
/* 138 */     return context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static HostnameVerifier trustAllHostnameVerifier() {
/* 150 */     return new HostnameVerifier()
/*     */       {
/*     */         public boolean verify(String arg0, SSLSession arg1) {
/* 153 */           return true;
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\SslUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */