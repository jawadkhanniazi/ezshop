/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import com.google.common.base.Ascii;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldInfo
/*     */ {
/*  39 */   private static final Map<Field, FieldInfo> CACHE = new WeakHashMap<>();
/*     */   
/*     */   private final boolean isPrimitive;
/*     */   
/*     */   private final Field field;
/*     */   
/*     */   private final Method[] setters;
/*     */   
/*     */   private final String name;
/*     */   
/*     */   public static FieldInfo of(Enum<?> enumValue) {
/*     */     try {
/*  51 */       FieldInfo result = of(enumValue.getClass().getField(enumValue.name()));
/*  52 */       Preconditions.checkArgument((result != null), "enum constant missing @Value or @NullValue annotation: %s", new Object[] { enumValue });
/*     */       
/*  54 */       return result;
/*  55 */     } catch (NoSuchFieldException e) {
/*     */       
/*  57 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FieldInfo of(Field field) {
/*  69 */     if (field == null) {
/*  70 */       return null;
/*     */     }
/*  72 */     synchronized (CACHE) {
/*  73 */       FieldInfo fieldInfo = CACHE.get(field);
/*  74 */       boolean isEnumContant = field.isEnumConstant();
/*  75 */       if (fieldInfo == null && (isEnumContant || !Modifier.isStatic(field.getModifiers()))) {
/*     */         String fieldName;
/*  77 */         if (isEnumContant) {
/*     */           
/*  79 */           Value value = field.<Value>getAnnotation(Value.class);
/*  80 */           if (value != null) {
/*  81 */             fieldName = value.value();
/*     */           } else {
/*     */             
/*  84 */             NullValue nullValue = field.<NullValue>getAnnotation(NullValue.class);
/*  85 */             if (nullValue != null) {
/*  86 */               fieldName = null;
/*     */             } else {
/*     */               
/*  89 */               return null;
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/*  94 */           Key key = field.<Key>getAnnotation(Key.class);
/*  95 */           if (key == null)
/*     */           {
/*  97 */             return null;
/*     */           }
/*  99 */           fieldName = key.value();
/* 100 */           field.setAccessible(true);
/*     */         } 
/* 102 */         if ("##default".equals(fieldName)) {
/* 103 */           fieldName = field.getName();
/*     */         }
/* 105 */         fieldInfo = new FieldInfo(field, fieldName);
/* 106 */         CACHE.put(field, fieldInfo);
/*     */       } 
/* 108 */       return fieldInfo;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FieldInfo(Field field, String name) {
/* 130 */     this.field = field;
/* 131 */     this.name = (name == null) ? null : name.intern();
/* 132 */     this.isPrimitive = Data.isPrimitive(getType());
/* 133 */     this.setters = settersMethodForField(field);
/*     */   }
/*     */ 
/*     */   
/*     */   private Method[] settersMethodForField(Field field) {
/* 138 */     List<Method> methods = new ArrayList<>();
/* 139 */     for (Method method : field.getDeclaringClass().getDeclaredMethods()) {
/* 140 */       if (Ascii.toLowerCase(method.getName()).equals("set" + Ascii.toLowerCase(field.getName())) && (method
/* 141 */         .getParameterTypes()).length == 1) {
/* 142 */         methods.add(method);
/*     */       }
/*     */     } 
/* 145 */     return methods.<Method>toArray(new Method[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Field getField() {
/* 154 */     return this.field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 167 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType() {
/* 176 */     return this.field.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getGenericType() {
/* 186 */     return this.field.getGenericType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFinal() {
/* 195 */     return Modifier.isFinal(this.field.getModifiers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrimitive() {
/* 204 */     return this.isPrimitive;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue(Object obj) {
/* 209 */     return getFieldValue(this.field, obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Object obj, Object value) {
/* 219 */     if (this.setters.length > 0) {
/* 220 */       for (Method method : this.setters) {
/* 221 */         if (value == null || method.getParameterTypes()[0].isAssignableFrom(value.getClass())) {
/*     */           try {
/* 223 */             method.invoke(obj, new Object[] { value });
/*     */             return;
/* 225 */           } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {}
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 231 */     setFieldValue(this.field, obj, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public ClassInfo getClassInfo() {
/* 236 */     return ClassInfo.of(this.field.getDeclaringClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public <T extends Enum<T>> T enumValue() {
/* 241 */     return Enum.valueOf((Class)this.field.getDeclaringClass(), this.field.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object getFieldValue(Field field, Object obj) {
/*     */     try {
/* 247 */       return field.get(obj);
/* 248 */     } catch (IllegalAccessException e) {
/* 249 */       throw new IllegalArgumentException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setFieldValue(Field field, Object obj, Object value) {
/* 260 */     if (Modifier.isFinal(field.getModifiers())) {
/* 261 */       Object finalValue = getFieldValue(field, obj);
/* 262 */       if ((value == null) ? (finalValue != null) : !value.equals(finalValue)) {
/* 263 */         throw new IllegalArgumentException("expected final value <" + finalValue + "> but was <" + value + "> on " + field
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 269 */             .getName() + " field in " + obj
/*     */             
/* 271 */             .getClass().getName());
/*     */       }
/*     */     } else {
/*     */       try {
/* 275 */         field.set(obj, value);
/* 276 */       } catch (SecurityException e) {
/* 277 */         throw new IllegalArgumentException(e);
/* 278 */       } catch (IllegalAccessException e) {
/* 279 */         throw new IllegalArgumentException(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\FieldInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */