/*     */ package com.google.api.client.util.escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PercentEscaper
/*     */   extends UnicodeEscaper
/*     */ {
/*     */   public static final String SAFECHARS_URLENCODER = "-_.*";
/*     */   public static final String SAFEPATHCHARS_URLENCODER = "-_.!~*'()@:$&,;=";
/*     */   public static final String SAFE_PLUS_RESERVED_CHARS_URLENCODER = "-_.!~*'()@:$&,;=+/?";
/*     */   public static final String SAFEUSERINFOCHARS_URLENCODER = "-_.!~*'():$&,;=";
/*     */   public static final String SAFEQUERYSTRINGCHARS_URLENCODER = "-_.!~*'()@:$,;/?:";
/*  90 */   private static final char[] URI_ESCAPED_SPACE = new char[] { '+' };
/*     */   
/*  92 */   private static final char[] UPPER_HEX_DIGITS = "0123456789ABCDEF".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean plusForSpace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean[] safeOctets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PercentEscaper(String safeChars, boolean plusForSpace) {
/* 115 */     if (safeChars.matches(".*[0-9A-Za-z].*")) {
/* 116 */       throw new IllegalArgumentException("Alphanumeric characters are always 'safe' and should not be explicitly specified");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 121 */     if (plusForSpace && safeChars.contains(" ")) {
/* 122 */       throw new IllegalArgumentException("plusForSpace cannot be specified when space is a 'safe' character");
/*     */     }
/*     */     
/* 125 */     if (safeChars.contains("%")) {
/* 126 */       throw new IllegalArgumentException("The '%' character cannot be specified as 'safe'");
/*     */     }
/* 128 */     this.plusForSpace = plusForSpace;
/* 129 */     this.safeOctets = createSafeOctets(safeChars);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean[] createSafeOctets(String safeChars) {
/* 138 */     int maxChar = 122;
/* 139 */     char[] safeCharArray = safeChars.toCharArray();
/* 140 */     for (char c1 : safeCharArray) {
/* 141 */       maxChar = Math.max(c1, maxChar);
/*     */     }
/* 143 */     boolean[] octets = new boolean[maxChar + 1]; int c;
/* 144 */     for (c = 48; c <= 57; c++) {
/* 145 */       octets[c] = true;
/*     */     }
/* 147 */     for (c = 65; c <= 90; c++) {
/* 148 */       octets[c] = true;
/*     */     }
/* 150 */     for (c = 97; c <= 122; c++) {
/* 151 */       octets[c] = true;
/*     */     }
/* 153 */     for (char c1 : safeCharArray) {
/* 154 */       octets[c1] = true;
/*     */     }
/* 156 */     return octets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int nextEscapeIndex(CharSequence csq, int index, int end) {
/* 165 */     for (; index < end; index++) {
/* 166 */       char c = csq.charAt(index);
/* 167 */       if (c >= this.safeOctets.length || !this.safeOctets[c]) {
/*     */         break;
/*     */       }
/*     */     } 
/* 171 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String escape(String s) {
/* 180 */     int slen = s.length();
/* 181 */     for (int index = 0; index < slen; index++) {
/* 182 */       char c = s.charAt(index);
/* 183 */       if (c >= this.safeOctets.length || !this.safeOctets[c]) {
/* 184 */         return escapeSlow(s, index);
/*     */       }
/*     */     } 
/* 187 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected char[] escape(int cp) {
/* 195 */     if (cp < this.safeOctets.length && this.safeOctets[cp])
/* 196 */       return null; 
/* 197 */     if (cp == 32 && this.plusForSpace)
/* 198 */       return URI_ESCAPED_SPACE; 
/* 199 */     if (cp <= 127) {
/*     */ 
/*     */       
/* 202 */       char[] dest = new char[3];
/* 203 */       dest[0] = '%';
/* 204 */       dest[2] = UPPER_HEX_DIGITS[cp & 0xF];
/* 205 */       dest[1] = UPPER_HEX_DIGITS[cp >>> 4];
/* 206 */       return dest;
/* 207 */     }  if (cp <= 2047) {
/*     */ 
/*     */       
/* 210 */       char[] dest = new char[6];
/* 211 */       dest[0] = '%';
/* 212 */       dest[3] = '%';
/* 213 */       dest[5] = UPPER_HEX_DIGITS[cp & 0xF];
/* 214 */       cp >>>= 4;
/* 215 */       dest[4] = UPPER_HEX_DIGITS[0x8 | cp & 0x3];
/* 216 */       cp >>>= 2;
/* 217 */       dest[2] = UPPER_HEX_DIGITS[cp & 0xF];
/* 218 */       cp >>>= 4;
/* 219 */       dest[1] = UPPER_HEX_DIGITS[0xC | cp];
/* 220 */       return dest;
/* 221 */     }  if (cp <= 65535) {
/*     */ 
/*     */       
/* 224 */       char[] dest = new char[9];
/* 225 */       dest[0] = '%';
/* 226 */       dest[1] = 'E';
/* 227 */       dest[3] = '%';
/* 228 */       dest[6] = '%';
/* 229 */       dest[8] = UPPER_HEX_DIGITS[cp & 0xF];
/* 230 */       cp >>>= 4;
/* 231 */       dest[7] = UPPER_HEX_DIGITS[0x8 | cp & 0x3];
/* 232 */       cp >>>= 2;
/* 233 */       dest[5] = UPPER_HEX_DIGITS[cp & 0xF];
/* 234 */       cp >>>= 4;
/* 235 */       dest[4] = UPPER_HEX_DIGITS[0x8 | cp & 0x3];
/* 236 */       cp >>>= 2;
/* 237 */       dest[2] = UPPER_HEX_DIGITS[cp];
/* 238 */       return dest;
/* 239 */     }  if (cp <= 1114111) {
/* 240 */       char[] dest = new char[12];
/*     */ 
/*     */       
/* 243 */       dest[0] = '%';
/* 244 */       dest[1] = 'F';
/* 245 */       dest[3] = '%';
/* 246 */       dest[6] = '%';
/* 247 */       dest[9] = '%';
/* 248 */       dest[11] = UPPER_HEX_DIGITS[cp & 0xF];
/* 249 */       cp >>>= 4;
/* 250 */       dest[10] = UPPER_HEX_DIGITS[0x8 | cp & 0x3];
/* 251 */       cp >>>= 2;
/* 252 */       dest[8] = UPPER_HEX_DIGITS[cp & 0xF];
/* 253 */       cp >>>= 4;
/* 254 */       dest[7] = UPPER_HEX_DIGITS[0x8 | cp & 0x3];
/* 255 */       cp >>>= 2;
/* 256 */       dest[5] = UPPER_HEX_DIGITS[cp & 0xF];
/* 257 */       cp >>>= 4;
/* 258 */       dest[4] = UPPER_HEX_DIGITS[0x8 | cp & 0x3];
/* 259 */       cp >>>= 2;
/* 260 */       dest[2] = UPPER_HEX_DIGITS[cp & 0x7];
/* 261 */       return dest;
/*     */     } 
/*     */     
/* 264 */     throw new IllegalArgumentException("Invalid unicode character value " + cp);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\escape\PercentEscaper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */