/*     */ package com.google.api.client.util.escape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UnicodeEscaper
/*     */   extends Escaper
/*     */ {
/*     */   private static final int DEST_PAD = 32;
/*     */   
/*     */   protected abstract char[] escape(int paramInt);
/*     */   
/*     */   protected abstract int nextEscapeIndex(CharSequence paramCharSequence, int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract String escape(String paramString);
/*     */   
/*     */   protected final String escapeSlow(String s, int index) {
/* 120 */     int end = s.length();
/*     */ 
/*     */     
/* 123 */     char[] dest = Platform.charBufferFromThreadLocal();
/* 124 */     int destIndex = 0;
/* 125 */     int unescapedChunkStart = 0;
/*     */     
/* 127 */     while (index < end) {
/* 128 */       int cp = codePointAt(s, index, end);
/* 129 */       if (cp < 0) {
/* 130 */         throw new IllegalArgumentException("Trailing high surrogate at end of input");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 135 */       char[] escaped = escape(cp);
/* 136 */       int nextIndex = index + (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/* 137 */       if (escaped != null) {
/* 138 */         int i = index - unescapedChunkStart;
/*     */ 
/*     */ 
/*     */         
/* 142 */         int sizeNeeded = destIndex + i + escaped.length;
/* 143 */         if (dest.length < sizeNeeded) {
/* 144 */           int destLength = sizeNeeded + end - index + 32;
/* 145 */           dest = growBuffer(dest, destIndex, destLength);
/*     */         } 
/*     */         
/* 148 */         if (i > 0) {
/* 149 */           s.getChars(unescapedChunkStart, index, dest, destIndex);
/* 150 */           destIndex += i;
/*     */         } 
/* 152 */         if (escaped.length > 0) {
/* 153 */           System.arraycopy(escaped, 0, dest, destIndex, escaped.length);
/* 154 */           destIndex += escaped.length;
/*     */         } 
/*     */         
/* 157 */         unescapedChunkStart = nextIndex;
/*     */       } 
/* 159 */       index = nextEscapeIndex(s, nextIndex, end);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 164 */     int charsSkipped = end - unescapedChunkStart;
/* 165 */     if (charsSkipped > 0) {
/* 166 */       int endIndex = destIndex + charsSkipped;
/* 167 */       if (dest.length < endIndex) {
/* 168 */         dest = growBuffer(dest, destIndex, endIndex);
/*     */       }
/* 170 */       s.getChars(unescapedChunkStart, end, dest, destIndex);
/* 171 */       destIndex = endIndex;
/*     */     } 
/* 173 */     return new String(dest, 0, destIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int codePointAt(CharSequence seq, int index, int end) {
/* 208 */     if (index < end) {
/* 209 */       char c1 = seq.charAt(index++);
/* 210 */       if (c1 < '?' || c1 > '?')
/*     */       {
/* 212 */         return c1; } 
/* 213 */       if (c1 <= '?') {
/*     */         
/* 215 */         if (index == end) {
/* 216 */           return -c1;
/*     */         }
/*     */         
/* 219 */         char c2 = seq.charAt(index);
/* 220 */         if (Character.isLowSurrogate(c2)) {
/* 221 */           return Character.toCodePoint(c1, c2);
/*     */         }
/* 223 */         throw new IllegalArgumentException("Expected low surrogate but got char '" + c2 + "' with value " + c2 + " at index " + index);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 231 */       throw new IllegalArgumentException("Unexpected low surrogate character '" + c1 + "' with value " + c1 + " at index " + (index - 1));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     throw new IndexOutOfBoundsException("Index exceeds specified range");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] growBuffer(char[] dest, int index, int size) {
/* 248 */     char[] copy = new char[size];
/* 249 */     if (index > 0) {
/* 250 */       System.arraycopy(dest, 0, copy, 0, index);
/*     */     }
/* 252 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\escape\UnicodeEscaper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */