/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityUtils
/*     */ {
/*     */   public static KeyStore getDefaultKeyStore() throws KeyStoreException {
/*  47 */     return KeyStore.getInstance(KeyStore.getDefaultType());
/*     */   }
/*     */ 
/*     */   
/*     */   public static KeyStore getJavaKeyStore() throws KeyStoreException {
/*  52 */     return KeyStore.getInstance("JKS");
/*     */   }
/*     */ 
/*     */   
/*     */   public static KeyStore getPkcs12KeyStore() throws KeyStoreException {
/*  57 */     return KeyStore.getInstance("PKCS12");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadKeyStore(KeyStore keyStore, InputStream keyStream, String storePass) throws IOException, GeneralSecurityException {
/*     */     try {
/*  78 */       keyStore.load(keyStream, storePass.toCharArray());
/*     */     } finally {
/*  80 */       keyStream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrivateKey getPrivateKey(KeyStore keyStore, String alias, String keyPass) throws GeneralSecurityException {
/*  94 */     return (PrivateKey)keyStore.getKey(alias, keyPass.toCharArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrivateKey loadPrivateKeyFromKeyStore(KeyStore keyStore, InputStream keyStream, String storePass, String alias, String keyPass) throws IOException, GeneralSecurityException {
/* 111 */     loadKeyStore(keyStore, keyStream, storePass);
/* 112 */     return getPrivateKey(keyStore, alias, keyPass);
/*     */   }
/*     */ 
/*     */   
/*     */   public static KeyFactory getRsaKeyFactory() throws NoSuchAlgorithmException {
/* 117 */     return KeyFactory.getInstance("RSA");
/*     */   }
/*     */ 
/*     */   
/*     */   public static Signature getSha1WithRsaSignatureAlgorithm() throws NoSuchAlgorithmException {
/* 122 */     return Signature.getInstance("SHA1withRSA");
/*     */   }
/*     */ 
/*     */   
/*     */   public static Signature getSha256WithRsaSignatureAlgorithm() throws NoSuchAlgorithmException {
/* 127 */     return Signature.getInstance("SHA256withRSA");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] sign(Signature signatureAlgorithm, PrivateKey privateKey, byte[] contentBytes) throws InvalidKeyException, SignatureException {
/* 141 */     signatureAlgorithm.initSign(privateKey);
/* 142 */     signatureAlgorithm.update(contentBytes);
/* 143 */     return signatureAlgorithm.sign();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean verify(Signature signatureAlgorithm, PublicKey publicKey, byte[] signatureBytes, byte[] contentBytes) throws InvalidKeyException, SignatureException {
/* 158 */     signatureAlgorithm.initVerify(publicKey);
/* 159 */     signatureAlgorithm.update(contentBytes);
/*     */     
/*     */     try {
/* 162 */       return signatureAlgorithm.verify(signatureBytes);
/* 163 */     } catch (SignatureException e) {
/* 164 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static X509Certificate verify(Signature signatureAlgorithm, X509TrustManager trustManager, List<String> certChainBase64, byte[] signatureBytes, byte[] contentBytes) throws InvalidKeyException, SignatureException {
/*     */     CertificateFactory certificateFactory;
/*     */     try {
/* 189 */       certificateFactory = getX509CertificateFactory();
/* 190 */     } catch (CertificateException e) {
/* 191 */       return null;
/*     */     } 
/* 193 */     X509Certificate[] certificates = new X509Certificate[certChainBase64.size()];
/* 194 */     int currentCert = 0;
/* 195 */     for (String certBase64 : certChainBase64) {
/* 196 */       byte[] certDer = Base64.decodeBase64(certBase64);
/* 197 */       ByteArrayInputStream bis = new ByteArrayInputStream(certDer);
/*     */       try {
/* 199 */         Certificate cert = certificateFactory.generateCertificate(bis);
/* 200 */         if (!(cert instanceof X509Certificate)) {
/* 201 */           return null;
/*     */         }
/* 203 */         certificates[currentCert++] = (X509Certificate)cert;
/* 204 */       } catch (CertificateException e) {
/* 205 */         return null;
/*     */       } 
/*     */     } 
/*     */     try {
/* 209 */       trustManager.checkServerTrusted(certificates, "RSA");
/* 210 */     } catch (CertificateException e) {
/* 211 */       return null;
/*     */     } 
/* 213 */     PublicKey pubKey = certificates[0].getPublicKey();
/* 214 */     if (verify(signatureAlgorithm, pubKey, signatureBytes, contentBytes)) {
/* 215 */       return certificates[0];
/*     */     }
/* 217 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static CertificateFactory getX509CertificateFactory() throws CertificateException {
/* 222 */     return CertificateFactory.getInstance("X.509");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadKeyStoreFromCertificates(KeyStore keyStore, CertificateFactory certificateFactory, InputStream certificateStream) throws GeneralSecurityException {
/* 249 */     int i = 0;
/* 250 */     for (Certificate cert : certificateFactory.generateCertificates(certificateStream)) {
/* 251 */       keyStore.setCertificateEntry(String.valueOf(i), cert);
/* 252 */       i++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\SecurityUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */