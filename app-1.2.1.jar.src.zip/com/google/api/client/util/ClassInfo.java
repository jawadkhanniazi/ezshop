/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClassInfo
/*     */ {
/*  41 */   private static final ConcurrentMap<Class<?>, ClassInfo> CACHE = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  45 */   private static final ConcurrentMap<Class<?>, ClassInfo> CACHE_IGNORE_CASE = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Class<?> clazz;
/*     */ 
/*     */   
/*     */   private final boolean ignoreCase;
/*     */ 
/*     */   
/*  55 */   private final IdentityHashMap<String, FieldInfo> nameToFieldInfoMap = new IdentityHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<String> names;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassInfo of(Class<?> underlyingClass) {
/*  71 */     return of(underlyingClass, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassInfo of(Class<?> underlyingClass, boolean ignoreCase) {
/*  83 */     if (underlyingClass == null) {
/*  84 */       return null;
/*     */     }
/*  86 */     ConcurrentMap<Class<?>, ClassInfo> cache = ignoreCase ? CACHE_IGNORE_CASE : CACHE;
/*     */     
/*     */     ClassInfo v, newValue;
/*     */     
/*  90 */     return ((v = cache.get(underlyingClass)) == null && (newValue = new ClassInfo(underlyingClass, ignoreCase)) != null && (
/*     */       
/*  92 */       v = cache.putIfAbsent(underlyingClass, newValue)) == null) ? newValue : v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getUnderlyingClass() {
/* 103 */     return this.clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getIgnoreCase() {
/* 112 */     return this.ignoreCase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldInfo getFieldInfo(String name) {
/* 122 */     if (name != null) {
/* 123 */       if (this.ignoreCase) {
/* 124 */         name = name.toLowerCase(Locale.US);
/*     */       }
/* 126 */       name = name.intern();
/*     */     } 
/* 128 */     return this.nameToFieldInfoMap.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Field getField(String name) {
/* 138 */     FieldInfo fieldInfo = getFieldInfo(name);
/* 139 */     return (fieldInfo == null) ? null : fieldInfo.getField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnum() {
/* 148 */     return this.clazz.isEnum();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getNames() {
/* 156 */     return this.names;
/*     */   }
/*     */   
/*     */   private ClassInfo(Class<?> srcClass, boolean ignoreCase) {
/* 160 */     this.clazz = srcClass;
/* 161 */     this.ignoreCase = ignoreCase;
/* 162 */     Preconditions.checkArgument((!ignoreCase || 
/* 163 */         !srcClass.isEnum()), "cannot ignore case on an enum: " + srcClass);
/*     */     
/* 165 */     TreeSet<String> nameSet = new TreeSet<>(new Comparator<String>()
/*     */         {
/*     */           public int compare(String s0, String s1)
/*     */           {
/* 169 */             return Objects.equal(s0, s1) ? 0 : ((s0 == null) ? -1 : ((s1 == null) ? 1 : s0
/*     */               
/* 171 */               .compareTo(s1)));
/*     */           }
/*     */         });
/*     */     
/* 175 */     for (Field field : srcClass.getDeclaredFields()) {
/* 176 */       FieldInfo fieldInfo = FieldInfo.of(field);
/* 177 */       if (fieldInfo != null) {
/*     */ 
/*     */         
/* 180 */         String fieldName = fieldInfo.getName();
/* 181 */         if (ignoreCase) {
/* 182 */           fieldName = fieldName.toLowerCase(Locale.US).intern();
/*     */         }
/* 184 */         FieldInfo conflictingFieldInfo = this.nameToFieldInfoMap.get(fieldName);
/* 185 */         Preconditions.checkArgument((conflictingFieldInfo == null), "two fields have the same %sname <%s>: %s and %s", new Object[] { ignoreCase ? "case-insensitive " : "", fieldName, field, (conflictingFieldInfo == null) ? null : conflictingFieldInfo
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 191 */               .getField() });
/* 192 */         this.nameToFieldInfoMap.put(fieldName, fieldInfo);
/* 193 */         nameSet.add(fieldName);
/*     */       } 
/*     */     } 
/* 196 */     Class<?> superClass = srcClass.getSuperclass();
/* 197 */     if (superClass != null) {
/* 198 */       ClassInfo superClassInfo = of(superClass, ignoreCase);
/* 199 */       nameSet.addAll(superClassInfo.names);
/* 200 */       for (Map.Entry<String, FieldInfo> e : superClassInfo.nameToFieldInfoMap.entrySet()) {
/* 201 */         String name = e.getKey();
/* 202 */         if (!this.nameToFieldInfoMap.containsKey(name)) {
/* 203 */           this.nameToFieldInfoMap.put(name, e.getValue());
/*     */         }
/*     */       } 
/*     */     } 
/* 207 */     this
/*     */ 
/*     */       
/* 210 */       .names = nameSet.isEmpty() ? Collections.<String>emptyList() : Collections.<String>unmodifiableList(new ArrayList<>(nameSet));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<FieldInfo> getFieldInfos() {
/* 223 */     return Collections.unmodifiableCollection(this.nameToFieldInfoMap.values());
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\ClassInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */