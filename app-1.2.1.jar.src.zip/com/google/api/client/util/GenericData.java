/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericData
/*     */   extends AbstractMap<String, Object>
/*     */   implements Cloneable
/*     */ {
/*  46 */   Map<String, Object> unknownFields = ArrayMap.create();
/*     */ 
/*     */ 
/*     */   
/*     */   final ClassInfo classInfo;
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericData() {
/*  55 */     this(EnumSet.noneOf(Flags.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Flags
/*     */   {
/*  66 */     IGNORE_CASE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericData(EnumSet<Flags> flags) {
/*  74 */     this.classInfo = ClassInfo.of(getClass(), flags.contains(Flags.IGNORE_CASE));
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object get(Object name) {
/*  79 */     if (!(name instanceof String)) {
/*  80 */       return null;
/*     */     }
/*  82 */     String fieldName = (String)name;
/*  83 */     FieldInfo fieldInfo = this.classInfo.getFieldInfo(fieldName);
/*  84 */     if (fieldInfo != null) {
/*  85 */       return fieldInfo.getValue(this);
/*     */     }
/*  87 */     if (this.classInfo.getIgnoreCase()) {
/*  88 */       fieldName = fieldName.toLowerCase(Locale.US);
/*     */     }
/*  90 */     return this.unknownFields.get(fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object put(String fieldName, Object value) {
/*  95 */     FieldInfo fieldInfo = this.classInfo.getFieldInfo(fieldName);
/*  96 */     if (fieldInfo != null) {
/*  97 */       Object oldValue = fieldInfo.getValue(this);
/*  98 */       fieldInfo.setValue(this, value);
/*  99 */       return oldValue;
/*     */     } 
/* 101 */     if (this.classInfo.getIgnoreCase()) {
/* 102 */       fieldName = fieldName.toLowerCase(Locale.US);
/*     */     }
/* 104 */     return this.unknownFields.put(fieldName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericData set(String fieldName, Object value) {
/* 116 */     FieldInfo fieldInfo = this.classInfo.getFieldInfo(fieldName);
/* 117 */     if (fieldInfo != null) {
/* 118 */       fieldInfo.setValue(this, value);
/*     */     } else {
/* 120 */       if (this.classInfo.getIgnoreCase()) {
/* 121 */         fieldName = fieldName.toLowerCase(Locale.US);
/*     */       }
/* 123 */       this.unknownFields.put(fieldName, value);
/*     */     } 
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void putAll(Map<? extends String, ?> map) {
/* 130 */     for (Map.Entry<? extends String, ?> entry : map.entrySet()) {
/* 131 */       set(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object remove(Object name) {
/* 137 */     if (!(name instanceof String)) {
/* 138 */       return null;
/*     */     }
/* 140 */     String fieldName = (String)name;
/* 141 */     FieldInfo fieldInfo = this.classInfo.getFieldInfo(fieldName);
/* 142 */     if (fieldInfo != null) {
/* 143 */       throw new UnsupportedOperationException();
/*     */     }
/* 145 */     if (this.classInfo.getIgnoreCase()) {
/* 146 */       fieldName = fieldName.toLowerCase(Locale.US);
/*     */     }
/* 148 */     return this.unknownFields.remove(fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/* 153 */     return new EntrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericData clone() {
/*     */     try {
/* 164 */       GenericData result = (GenericData)super.clone();
/* 165 */       Data.deepCopy(this, result);
/* 166 */       result.unknownFields = Data.<Map<String, Object>>clone(this.unknownFields);
/* 167 */       return result;
/* 168 */     } catch (CloneNotSupportedException e) {
/* 169 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Map<String, Object> getUnknownKeys() {
/* 179 */     return this.unknownFields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setUnknownKeys(Map<String, Object> unknownFields) {
/* 188 */     this.unknownFields = unknownFields;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 193 */     if (o == this) {
/* 194 */       return true;
/*     */     }
/* 196 */     if (o == null || !(o instanceof GenericData)) {
/* 197 */       return false;
/*     */     }
/* 199 */     GenericData that = (GenericData)o;
/* 200 */     return (super.equals(that) && Objects.equals(this.classInfo, that.classInfo));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 205 */     return Objects.hash(new Object[] { Integer.valueOf(super.hashCode()), this.classInfo });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 210 */     return "GenericData{classInfo=" + this.classInfo.names + ", " + super.toString() + "}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ClassInfo getClassInfo() {
/* 219 */     return this.classInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final class EntrySet
/*     */     extends AbstractSet<Map.Entry<String, Object>>
/*     */   {
/* 228 */     private final DataMap.EntrySet dataEntrySet = (new DataMap(GenericData.this, GenericData.this.classInfo.getIgnoreCase())).entrySet();
/*     */ 
/*     */ 
/*     */     
/*     */     public Iterator<Map.Entry<String, Object>> iterator() {
/* 233 */       return new GenericData.EntryIterator(this.dataEntrySet);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 238 */       return GenericData.this.unknownFields.size() + this.dataEntrySet.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 243 */       GenericData.this.unknownFields.clear();
/* 244 */       this.dataEntrySet.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final class EntryIterator
/*     */     implements Iterator<Map.Entry<String, Object>>
/*     */   {
/*     */     private boolean startedUnknown;
/*     */ 
/*     */     
/*     */     private final Iterator<Map.Entry<String, Object>> fieldIterator;
/*     */ 
/*     */     
/*     */     private final Iterator<Map.Entry<String, Object>> unknownIterator;
/*     */ 
/*     */ 
/*     */     
/*     */     EntryIterator(DataMap.EntrySet dataEntrySet) {
/* 264 */       this.fieldIterator = dataEntrySet.iterator();
/* 265 */       this.unknownIterator = GenericData.this.unknownFields.entrySet().iterator();
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 269 */       return (this.fieldIterator.hasNext() || this.unknownIterator.hasNext());
/*     */     }
/*     */     
/*     */     public Map.Entry<String, Object> next() {
/* 273 */       if (!this.startedUnknown) {
/* 274 */         if (this.fieldIterator.hasNext()) {
/* 275 */           return this.fieldIterator.next();
/*     */         }
/* 277 */         this.startedUnknown = true;
/*     */       } 
/* 279 */       return this.unknownIterator.next();
/*     */     }
/*     */     
/*     */     public void remove() {
/* 283 */       if (this.startedUnknown) {
/* 284 */         this.unknownIterator.remove();
/*     */       }
/* 286 */       this.fieldIterator.remove();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\GenericData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */