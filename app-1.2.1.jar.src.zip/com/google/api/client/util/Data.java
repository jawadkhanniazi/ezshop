/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Data
/*     */ {
/*  48 */   public static final Boolean NULL_BOOLEAN = new Boolean(true);
/*     */ 
/*     */   
/*  51 */   public static final String NULL_STRING = new String();
/*     */ 
/*     */   
/*  54 */   public static final Character NULL_CHARACTER = new Character(false);
/*     */ 
/*     */   
/*  57 */   public static final Byte NULL_BYTE = new Byte((byte)0);
/*     */ 
/*     */   
/*  60 */   public static final Short NULL_SHORT = new Short((short)0);
/*     */ 
/*     */   
/*  63 */   public static final Integer NULL_INTEGER = new Integer(0);
/*     */ 
/*     */   
/*  66 */   public static final Float NULL_FLOAT = new Float(0.0F);
/*     */ 
/*     */   
/*  69 */   public static final Long NULL_LONG = new Long(0L);
/*     */ 
/*     */   
/*  72 */   public static final Double NULL_DOUBLE = new Double(0.0D);
/*     */ 
/*     */   
/*  75 */   public static final BigInteger NULL_BIG_INTEGER = new BigInteger("0");
/*     */ 
/*     */   
/*  78 */   public static final BigDecimal NULL_BIG_DECIMAL = new BigDecimal("0");
/*     */ 
/*     */   
/*  81 */   public static final DateTime NULL_DATE_TIME = new DateTime(0L);
/*     */ 
/*     */   
/*  84 */   private static final ConcurrentHashMap<Class<?>, Object> NULL_CACHE = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  89 */     NULL_CACHE.put(Boolean.class, NULL_BOOLEAN);
/*  90 */     NULL_CACHE.put(String.class, NULL_STRING);
/*  91 */     NULL_CACHE.put(Character.class, NULL_CHARACTER);
/*  92 */     NULL_CACHE.put(Byte.class, NULL_BYTE);
/*  93 */     NULL_CACHE.put(Short.class, NULL_SHORT);
/*  94 */     NULL_CACHE.put(Integer.class, NULL_INTEGER);
/*  95 */     NULL_CACHE.put(Float.class, NULL_FLOAT);
/*  96 */     NULL_CACHE.put(Long.class, NULL_LONG);
/*  97 */     NULL_CACHE.put(Double.class, NULL_DOUBLE);
/*  98 */     NULL_CACHE.put(BigInteger.class, NULL_BIG_INTEGER);
/*  99 */     NULL_CACHE.put(BigDecimal.class, NULL_BIG_DECIMAL);
/* 100 */     NULL_CACHE.put(DateTime.class, NULL_DATE_TIME);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T nullOf(Class<T> objClass) {
/* 116 */     Object result = NULL_CACHE.get(objClass);
/* 117 */     if (result == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       Object newValue = createNullInstance(objClass);
/* 124 */       result = NULL_CACHE.putIfAbsent(objClass, newValue);
/* 125 */       if (result == null) {
/* 126 */         result = newValue;
/*     */       }
/*     */     } 
/*     */     
/* 130 */     T tResult = (T)result;
/* 131 */     return tResult;
/*     */   }
/*     */   
/*     */   private static Object createNullInstance(Class<?> objClass) {
/* 135 */     if (objClass.isArray()) {
/*     */       
/* 137 */       int dims = 0;
/* 138 */       Class<?> componentType = objClass;
/*     */       while (true) {
/* 140 */         componentType = componentType.getComponentType();
/* 141 */         dims++;
/* 142 */         if (!componentType.isArray())
/* 143 */           return Array.newInstance(componentType, new int[dims]); 
/*     */       } 
/* 145 */     }  if (objClass.isEnum()) {
/*     */       
/* 147 */       FieldInfo fieldInfo = ClassInfo.of(objClass).getFieldInfo(null);
/* 148 */       Preconditions.checkNotNull(fieldInfo, "enum missing constant with @NullValue annotation: %s", new Object[] { objClass });
/*     */ 
/*     */       
/* 151 */       Enum e = fieldInfo.enumValue();
/* 152 */       return e;
/*     */     } 
/*     */     
/* 155 */     return Types.newInstance(objClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNull(Object object) {
/* 167 */     return (object != null && object == NULL_CACHE.get(object.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> mapOf(Object data) {
/* 188 */     if (data == null || isNull(data)) {
/* 189 */       return Collections.emptyMap();
/*     */     }
/* 191 */     if (data instanceof Map) {
/*     */       
/* 193 */       Map<String, Object> map = (Map<String, Object>)data;
/* 194 */       return map;
/*     */     } 
/* 196 */     Map<String, Object> result = new DataMap(data, false);
/* 197 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T clone(T data) {
/*     */     T copy;
/* 216 */     if (data == null || isPrimitive(data.getClass())) {
/* 217 */       return data;
/*     */     }
/* 219 */     if (data instanceof GenericData) {
/* 220 */       return (T)((GenericData)data).clone();
/*     */     }
/*     */     
/* 223 */     Class<?> dataClass = data.getClass();
/* 224 */     if (dataClass.isArray())
/* 225 */     { copy = (T)Array.newInstance(dataClass.getComponentType(), Array.getLength(data)); }
/* 226 */     else if (data instanceof ArrayMap)
/* 227 */     { ArrayMap arrayMap = ((ArrayMap)data).clone(); }
/* 228 */     else { if ("java.util.Arrays$ArrayList".equals(dataClass.getName())) {
/*     */ 
/*     */ 
/*     */         
/* 232 */         Object[] arrayCopy = ((List)data).toArray();
/* 233 */         deepCopy(arrayCopy, arrayCopy);
/* 234 */         return (T)Arrays.asList(arrayCopy);
/*     */       } 
/*     */       
/* 237 */       copy = Types.newInstance((Class)dataClass); }
/*     */     
/* 239 */     deepCopy(data, copy);
/* 240 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deepCopy(Object src, Object dest) {
/* 270 */     Class<?> srcClass = src.getClass();
/* 271 */     Preconditions.checkArgument((srcClass == dest.getClass()));
/* 272 */     if (srcClass.isArray()) {
/*     */       
/* 274 */       Preconditions.checkArgument((Array.getLength(src) == Array.getLength(dest)));
/* 275 */       int index = 0;
/* 276 */       for (Object value : Types.iterableOf(src)) {
/* 277 */         Array.set(dest, index++, clone(value));
/*     */       }
/* 279 */     } else if (Collection.class.isAssignableFrom(srcClass)) {
/*     */ 
/*     */       
/* 282 */       Collection<Object> srcCollection = (Collection<Object>)src;
/* 283 */       if (ArrayList.class.isAssignableFrom(srcClass)) {
/*     */         
/* 285 */         ArrayList<Object> destArrayList = (ArrayList<Object>)dest;
/* 286 */         destArrayList.ensureCapacity(srcCollection.size());
/*     */       } 
/*     */       
/* 289 */       Collection<Object> destCollection = (Collection<Object>)dest;
/* 290 */       for (Object srcValue : srcCollection) {
/* 291 */         destCollection.add(clone(srcValue));
/*     */       }
/*     */     } else {
/*     */       
/* 295 */       boolean isGenericData = GenericData.class.isAssignableFrom(srcClass);
/* 296 */       if (isGenericData || !Map.class.isAssignableFrom(srcClass)) {
/*     */         
/* 298 */         ClassInfo classInfo = isGenericData ? ((GenericData)src).classInfo : ClassInfo.of(srcClass);
/* 299 */         for (String fieldName : classInfo.names) {
/* 300 */           FieldInfo fieldInfo = classInfo.getFieldInfo(fieldName);
/*     */           
/* 302 */           if (!fieldInfo.isFinal())
/*     */           {
/* 304 */             if (!isGenericData || !fieldInfo.isPrimitive()) {
/* 305 */               Object srcValue = fieldInfo.getValue(src);
/* 306 */               if (srcValue != null) {
/* 307 */                 fieldInfo.setValue(dest, clone(srcValue));
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/* 312 */       } else if (ArrayMap.class.isAssignableFrom(srcClass)) {
/*     */ 
/*     */         
/* 315 */         ArrayMap<Object, Object> destMap = (ArrayMap<Object, Object>)dest;
/*     */         
/* 317 */         ArrayMap<Object, Object> srcMap = (ArrayMap<Object, Object>)src;
/* 318 */         int size = srcMap.size();
/* 319 */         for (int i = 0; i < size; i++) {
/* 320 */           Object srcValue = srcMap.getValue(i);
/* 321 */           destMap.set(i, clone(srcValue));
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 326 */         Map<String, Object> destMap = (Map<String, Object>)dest;
/*     */         
/* 328 */         Map<String, Object> srcMap = (Map<String, Object>)src;
/* 329 */         for (Map.Entry<String, Object> srcEntry : srcMap.entrySet()) {
/* 330 */           destMap.put(srcEntry.getKey(), clone(srcEntry.getValue()));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrimitive(Type type) {
/* 350 */     if (type instanceof WildcardType) {
/* 351 */       type = Types.getBound((WildcardType)type);
/*     */     }
/* 353 */     if (!(type instanceof Class)) {
/* 354 */       return false;
/*     */     }
/* 356 */     Class<?> typeClass = (Class)type;
/* 357 */     return (typeClass.isPrimitive() || typeClass == Character.class || typeClass == String.class || typeClass == Integer.class || typeClass == Long.class || typeClass == Short.class || typeClass == Byte.class || typeClass == Float.class || typeClass == Double.class || typeClass == BigInteger.class || typeClass == BigDecimal.class || typeClass == DateTime.class || typeClass == Boolean.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValueOfPrimitiveType(Object fieldValue) {
/* 377 */     return (fieldValue == null || isPrimitive(fieldValue.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object parsePrimitiveValue(Type type, String stringValue) {
/* 410 */     Class<?> primitiveClass = (type instanceof Class) ? (Class)type : null;
/* 411 */     if (type == null || primitiveClass != null) {
/* 412 */       if (primitiveClass == Void.class) {
/* 413 */         return null;
/*     */       }
/* 415 */       if (stringValue == null || primitiveClass == null || primitiveClass
/*     */         
/* 417 */         .isAssignableFrom(String.class)) {
/* 418 */         return stringValue;
/*     */       }
/* 420 */       if (primitiveClass == Character.class || primitiveClass == char.class) {
/* 421 */         if (stringValue.length() != 1) {
/* 422 */           throw new IllegalArgumentException("expected type Character/char but got " + primitiveClass);
/*     */         }
/*     */         
/* 425 */         return Character.valueOf(stringValue.charAt(0));
/*     */       } 
/* 427 */       if (primitiveClass == Boolean.class || primitiveClass == boolean.class) {
/* 428 */         return Boolean.valueOf(stringValue);
/*     */       }
/* 430 */       if (primitiveClass == Byte.class || primitiveClass == byte.class) {
/* 431 */         return Byte.valueOf(stringValue);
/*     */       }
/* 433 */       if (primitiveClass == Short.class || primitiveClass == short.class) {
/* 434 */         return Short.valueOf(stringValue);
/*     */       }
/* 436 */       if (primitiveClass == Integer.class || primitiveClass == int.class) {
/* 437 */         return Integer.valueOf(stringValue);
/*     */       }
/* 439 */       if (primitiveClass == Long.class || primitiveClass == long.class) {
/* 440 */         return Long.valueOf(stringValue);
/*     */       }
/* 442 */       if (primitiveClass == Float.class || primitiveClass == float.class) {
/* 443 */         return Float.valueOf(stringValue);
/*     */       }
/* 445 */       if (primitiveClass == Double.class || primitiveClass == double.class) {
/* 446 */         return Double.valueOf(stringValue);
/*     */       }
/* 448 */       if (primitiveClass == DateTime.class) {
/* 449 */         return DateTime.parseRfc3339(stringValue);
/*     */       }
/* 451 */       if (primitiveClass == BigInteger.class) {
/* 452 */         return new BigInteger(stringValue);
/*     */       }
/* 454 */       if (primitiveClass == BigDecimal.class) {
/* 455 */         return new BigDecimal(stringValue);
/*     */       }
/* 457 */       if (primitiveClass.isEnum()) {
/* 458 */         if (!(ClassInfo.of(primitiveClass)).names.contains(stringValue)) {
/* 459 */           throw new IllegalArgumentException(
/* 460 */               String.format("given enum name %s not part of enumeration", new Object[] { stringValue }));
/*     */         }
/*     */         
/* 463 */         Enum result = ClassInfo.of(primitiveClass).getFieldInfo(stringValue).enumValue();
/* 464 */         return result;
/*     */       } 
/*     */     } 
/* 467 */     throw new IllegalArgumentException("expected primitive class, but got: " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<Object> newCollectionInstance(Type type) {
/* 489 */     if (type instanceof WildcardType) {
/* 490 */       type = Types.getBound((WildcardType)type);
/*     */     }
/* 492 */     if (type instanceof ParameterizedType) {
/* 493 */       type = ((ParameterizedType)type).getRawType();
/*     */     }
/* 495 */     Class<?> collectionClass = (type instanceof Class) ? (Class)type : null;
/* 496 */     if (type == null || type instanceof java.lang.reflect.GenericArrayType || (collectionClass != null && (collectionClass
/*     */ 
/*     */       
/* 499 */       .isArray() || collectionClass.isAssignableFrom(ArrayList.class)))) {
/* 500 */       return new ArrayList();
/*     */     }
/* 502 */     if (collectionClass == null) {
/* 503 */       throw new IllegalArgumentException("unable to create new instance of type: " + type);
/*     */     }
/* 505 */     if (collectionClass.isAssignableFrom(HashSet.class)) {
/* 506 */       return new HashSet();
/*     */     }
/* 508 */     if (collectionClass.isAssignableFrom(TreeSet.class)) {
/* 509 */       return new TreeSet();
/*     */     }
/*     */     
/* 512 */     Collection<Object> result = (Collection<Object>)Types.newInstance(collectionClass);
/* 513 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, Object> newMapInstance(Class<?> mapClass) {
/* 532 */     if (mapClass == null || mapClass.isAssignableFrom(ArrayMap.class)) {
/* 533 */       return ArrayMap.create();
/*     */     }
/* 535 */     if (mapClass.isAssignableFrom(TreeMap.class)) {
/* 536 */       return new TreeMap<>();
/*     */     }
/*     */     
/* 539 */     Map<String, Object> result = (Map<String, Object>)Types.newInstance(mapClass);
/* 540 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type resolveWildcardTypeOrTypeVariable(List<Type> context, Type type) {
/* 556 */     if (type instanceof WildcardType) {
/* 557 */       type = Types.getBound((WildcardType)type);
/*     */     }
/*     */     
/* 560 */     while (type instanceof TypeVariable) {
/*     */       
/* 562 */       Type resolved = Types.resolveTypeVariable(context, (TypeVariable)type);
/* 563 */       if (resolved != null) {
/* 564 */         type = resolved;
/*     */       }
/*     */       
/* 567 */       if (type instanceof TypeVariable) {
/* 568 */         type = ((TypeVariable)type).getBounds()[0];
/*     */       }
/*     */     } 
/*     */     
/* 572 */     return type;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Data.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */