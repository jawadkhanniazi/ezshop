/*     */ package com.google.api.client.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.GenericDeclaration;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Types
/*     */ {
/*     */   public static ParameterizedType getSuperParameterizedType(Type type, Class<?> superClass) {
/*  54 */     if (type instanceof Class || type instanceof ParameterizedType)
/*     */     {
/*  56 */       label29: while (type != null && type != Object.class) {
/*     */         Class<?> rawType;
/*  58 */         if (type instanceof Class) {
/*     */           
/*  60 */           rawType = (Class)type;
/*     */         } else {
/*     */           
/*  63 */           ParameterizedType parameterizedType = (ParameterizedType)type;
/*  64 */           rawType = getRawClass(parameterizedType);
/*     */           
/*  66 */           if (rawType == superClass)
/*     */           {
/*  68 */             return parameterizedType;
/*     */           }
/*  70 */           if (superClass.isInterface()) {
/*  71 */             for (Type interfaceType : rawType.getGenericInterfaces()) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  76 */               Class<?> interfaceClass = (interfaceType instanceof Class) ? (Class)interfaceType : getRawClass((ParameterizedType)interfaceType);
/*  77 */               if (superClass.isAssignableFrom(interfaceClass)) {
/*  78 */                 type = interfaceType;
/*     */                 
/*     */                 continue label29;
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*  85 */         type = rawType.getGenericSuperclass();
/*     */       } 
/*     */     }
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAssignableToOrFrom(Class<?> classToCheck, Class<?> anotherClass) {
/*  98 */     return (classToCheck.isAssignableFrom(anotherClass) || anotherClass
/*  99 */       .isAssignableFrom(classToCheck));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T newInstance(Class<T> clazz) {
/*     */     try {
/* 113 */       return clazz.newInstance();
/* 114 */     } catch (IllegalAccessException e) {
/* 115 */       throw handleExceptionForNewInstance(e, clazz);
/* 116 */     } catch (InstantiationException e) {
/* 117 */       throw handleExceptionForNewInstance(e, clazz);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static IllegalArgumentException handleExceptionForNewInstance(Exception e, Class<?> clazz) {
/* 124 */     StringBuilder buf = (new StringBuilder("unable to create new instance of class ")).append(clazz.getName());
/* 125 */     ArrayList<String> reasons = new ArrayList<>();
/* 126 */     if (clazz.isArray()) {
/* 127 */       reasons.add("because it is an array");
/* 128 */     } else if (clazz.isPrimitive()) {
/* 129 */       reasons.add("because it is primitive");
/* 130 */     } else if (clazz == Void.class) {
/* 131 */       reasons.add("because it is void");
/*     */     } else {
/* 133 */       if (Modifier.isInterface(clazz.getModifiers())) {
/* 134 */         reasons.add("because it is an interface");
/* 135 */       } else if (Modifier.isAbstract(clazz.getModifiers())) {
/* 136 */         reasons.add("because it is abstract");
/*     */       } 
/* 138 */       if (clazz.getEnclosingClass() != null && !Modifier.isStatic(clazz.getModifiers())) {
/* 139 */         reasons.add("because it is not static");
/*     */       }
/*     */       
/* 142 */       if (!Modifier.isPublic(clazz.getModifiers())) {
/* 143 */         reasons.add("possibly because it is not public");
/*     */       } else {
/*     */         try {
/* 146 */           clazz.getConstructor(new Class[0]);
/* 147 */         } catch (NoSuchMethodException e1) {
/* 148 */           reasons.add("because it has no accessible default constructor");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 153 */     boolean and = false;
/* 154 */     for (String reason : reasons) {
/* 155 */       if (and) {
/* 156 */         buf.append(" and");
/*     */       } else {
/* 158 */         and = true;
/*     */       } 
/* 160 */       buf.append(" ").append(reason);
/*     */     } 
/* 162 */     return new IllegalArgumentException(buf.toString(), e);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isArray(Type type) {
/* 167 */     return (type instanceof GenericArrayType || (type instanceof Class && ((Class)type)
/* 168 */       .isArray()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getArrayComponentType(Type array) {
/* 180 */     return (array instanceof GenericArrayType) ? ((GenericArrayType)array)
/* 181 */       .getGenericComponentType() : ((Class)array)
/* 182 */       .getComponentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getRawClass(ParameterizedType parameterType) {
/* 193 */     return (Class)parameterType.getRawType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getBound(WildcardType wildcardType) {
/* 203 */     Type[] lowerBounds = wildcardType.getLowerBounds();
/* 204 */     if (lowerBounds.length != 0) {
/* 205 */       return lowerBounds[0];
/*     */     }
/* 207 */     return wildcardType.getUpperBounds()[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type resolveTypeVariable(List<Type> context, TypeVariable<?> typeVariable) {
/* 225 */     GenericDeclaration genericDeclaration = (GenericDeclaration)typeVariable.getGenericDeclaration();
/* 226 */     if (genericDeclaration instanceof Class) {
/* 227 */       Class<?> rawGenericDeclaration = (Class)genericDeclaration;
/*     */       
/* 229 */       int contextIndex = context.size();
/* 230 */       ParameterizedType parameterizedType = null;
/* 231 */       while (parameterizedType == null && --contextIndex >= 0)
/*     */       {
/* 233 */         parameterizedType = getSuperParameterizedType(context.get(contextIndex), rawGenericDeclaration);
/*     */       }
/* 235 */       if (parameterizedType != null) {
/*     */         
/* 237 */         TypeVariable[] arrayOfTypeVariable = (TypeVariable[])genericDeclaration.getTypeParameters();
/* 238 */         int index = 0;
/* 239 */         for (; index < arrayOfTypeVariable.length; index++) {
/* 240 */           TypeVariable<?> typeParameter = arrayOfTypeVariable[index];
/* 241 */           if (typeParameter.equals(typeVariable)) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 246 */         Type result = parameterizedType.getActualTypeArguments()[index];
/* 247 */         if (result instanceof TypeVariable) {
/*     */           
/* 249 */           Type resolve = resolveTypeVariable(context, (TypeVariable)result);
/* 250 */           if (resolve != null) {
/* 251 */             return resolve;
/*     */           }
/*     */         } 
/*     */         
/* 255 */         return result;
/*     */       } 
/*     */     } 
/* 258 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getRawArrayComponentType(List<Type> context, Type componentType) {
/* 271 */     if (componentType instanceof TypeVariable) {
/* 272 */       componentType = resolveTypeVariable(context, (TypeVariable)componentType);
/*     */     }
/* 274 */     if (componentType instanceof GenericArrayType) {
/* 275 */       Class<?> raw = getRawArrayComponentType(context, getArrayComponentType(componentType));
/* 276 */       return Array.newInstance(raw, 0).getClass();
/*     */     } 
/* 278 */     if (componentType instanceof Class) {
/* 279 */       return (Class)componentType;
/*     */     }
/* 281 */     if (componentType instanceof ParameterizedType) {
/* 282 */       return getRawClass((ParameterizedType)componentType);
/*     */     }
/* 284 */     Preconditions.checkArgument((componentType == null), "wildcard type is not supported: %s", new Object[] { componentType });
/*     */     
/* 286 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getIterableParameter(Type iterableType) {
/* 299 */     return getActualParameterAtPosition(iterableType, Iterable.class, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getMapValueParameter(Type mapType) {
/* 312 */     return getActualParameterAtPosition(mapType, Map.class, 1);
/*     */   }
/*     */   
/*     */   private static Type getActualParameterAtPosition(Type type, Class<?> superClass, int position) {
/* 316 */     ParameterizedType parameterizedType = getSuperParameterizedType(type, superClass);
/* 317 */     if (parameterizedType == null) {
/* 318 */       return null;
/*     */     }
/* 320 */     Type valueType = parameterizedType.getActualTypeArguments()[position];
/*     */ 
/*     */     
/* 323 */     if (valueType instanceof TypeVariable) {
/* 324 */       Type resolve = resolveTypeVariable(Arrays.asList(new Type[] { type }, ), (TypeVariable)valueType);
/* 325 */       if (resolve != null) {
/* 326 */         return resolve;
/*     */       }
/*     */     } 
/* 329 */     return valueType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Iterable<T> iterableOf(final Object value) {
/* 344 */     if (value instanceof Iterable) {
/* 345 */       return (Iterable<T>)value;
/*     */     }
/* 347 */     Class<?> valueClass = value.getClass();
/* 348 */     Preconditions.checkArgument(valueClass.isArray(), "not an array or Iterable: %s", new Object[] { valueClass });
/* 349 */     Class<?> subClass = valueClass.getComponentType();
/* 350 */     if (!subClass.isPrimitive()) {
/* 351 */       return Arrays.asList((T[])value);
/*     */     }
/* 353 */     return new Iterable<T>()
/*     */       {
/*     */         public Iterator<T> iterator() {
/* 356 */           return new Iterator()
/*     */             {
/* 358 */               final int length = Array.getLength(value);
/* 359 */               int index = 0;
/*     */               
/*     */               public boolean hasNext() {
/* 362 */                 return (this.index < this.length);
/*     */               }
/*     */               
/*     */               public T next() {
/* 366 */                 if (!hasNext()) {
/* 367 */                   throw new NoSuchElementException();
/*     */                 }
/* 369 */                 return (T)Array.get(value, this.index++);
/*     */               }
/*     */               
/*     */               public void remove() {
/* 373 */                 throw new UnsupportedOperationException();
/*     */               }
/*     */             };
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object toArray(Collection<?> collection, Class<?> componentType) {
/* 389 */     if (componentType.isPrimitive()) {
/* 390 */       Object array = Array.newInstance(componentType, collection.size());
/* 391 */       int index = 0;
/* 392 */       for (Object value : collection) {
/* 393 */         Array.set(array, index++, value);
/*     */       }
/* 395 */       return array;
/*     */     } 
/* 397 */     return collection.toArray((Object[])Array.newInstance(componentType, collection.size()));
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\clien\\util\Types.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */