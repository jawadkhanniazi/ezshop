/*     */ package com.google.api.client.testing.json;
/*     */ 
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonParser;
/*     */ import com.google.api.client.json.JsonToken;
/*     */ import com.google.api.client.util.Beta;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockJsonParser
/*     */   extends JsonParser
/*     */ {
/*     */   private boolean isClosed;
/*     */   private final JsonFactory factory;
/*     */   
/*     */   MockJsonParser(JsonFactory factory) {
/*  42 */     this.factory = factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonFactory getFactory() {
/*  47 */     return this.factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  52 */     this.isClosed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonToken nextToken() throws IOException {
/*  57 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonToken getCurrentToken() {
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCurrentName() throws IOException {
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() throws IOException {
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByteValue() throws IOException {
/*  82 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShortValue() throws IOException {
/*  87 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntValue() throws IOException {
/*  92 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatValue() throws IOException {
/*  97 */     return 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongValue() throws IOException {
/* 102 */     return 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoubleValue() throws IOException {
/* 107 */     return 0.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public BigInteger getBigIntegerValue() throws IOException {
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 126 */     return this.isClosed;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\json\MockJsonParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */