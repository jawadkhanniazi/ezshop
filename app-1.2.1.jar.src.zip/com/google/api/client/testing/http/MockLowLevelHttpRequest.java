/*     */ package com.google.api.client.testing.http;
/*     */ 
/*     */ import com.google.api.client.http.HttpMediaType;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Charsets;
/*     */ import com.google.api.client.util.IOUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockLowLevelHttpRequest
/*     */   extends LowLevelHttpRequest
/*     */ {
/*     */   private String url;
/*  52 */   private final Map<String, List<String>> headersMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private MockLowLevelHttpResponse response = new MockLowLevelHttpResponse();
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpRequest() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpRequest(String url) {
/*  68 */     this.url = url;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addHeader(String name, String value) throws IOException {
/*  73 */     name = name.toLowerCase(Locale.US);
/*  74 */     List<String> values = this.headersMap.get(name);
/*  75 */     if (values == null) {
/*  76 */       values = new ArrayList<>();
/*  77 */       this.headersMap.put(name, values);
/*     */     } 
/*  79 */     values.add(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public LowLevelHttpResponse execute() throws IOException {
/*  84 */     return this.response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/*  93 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getHeaders() {
/* 105 */     return Collections.unmodifiableMap(this.headersMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFirstHeaderValue(String name) {
/* 115 */     List<String> values = this.headersMap.get(name.toLowerCase(Locale.US));
/* 116 */     return (values == null) ? null : values.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getHeaderValues(String name) {
/* 126 */     List<String> values = this.headersMap.get(name.toLowerCase(Locale.US));
/* 127 */     return (values == null) ? Collections.<String>emptyList() : Collections.<String>unmodifiableList(values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpRequest setUrl(String url) {
/* 136 */     this.url = url;
/* 137 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentAsString() throws IOException {
/* 148 */     if (getStreamingContent() == null) {
/* 149 */       return "";
/*     */     }
/*     */     
/* 152 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 153 */     getStreamingContent().writeTo(out);
/*     */     
/* 155 */     String contentEncoding = getContentEncoding();
/* 156 */     if (contentEncoding != null && contentEncoding.contains("gzip")) {
/*     */       
/* 158 */       InputStream contentInputStream = new GZIPInputStream(new ByteArrayInputStream(out.toByteArray()));
/* 159 */       out = new ByteArrayOutputStream();
/* 160 */       IOUtils.copy(contentInputStream, out);
/*     */     } 
/*     */     
/* 163 */     String contentType = getContentType();
/* 164 */     HttpMediaType mediaType = (contentType != null) ? new HttpMediaType(contentType) : null;
/*     */ 
/*     */ 
/*     */     
/* 168 */     Charset charset = (mediaType == null || mediaType.getCharsetParameter() == null) ? Charsets.ISO_8859_1 : mediaType.getCharsetParameter();
/* 169 */     return out.toString(charset.name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse getResponse() {
/* 178 */     return this.response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpRequest setResponse(MockLowLevelHttpResponse response) {
/* 187 */     this.response = response;
/* 188 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\http\MockLowLevelHttpRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */