/*     */ package com.google.api.client.testing.http;
/*     */ 
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockHttpContent
/*     */   implements HttpContent
/*     */ {
/*  36 */   private long length = -1L;
/*     */ 
/*     */   
/*     */   private String type;
/*     */ 
/*     */   
/*  42 */   private byte[] content = new byte[0];
/*     */   
/*     */   public long getLength() throws IOException {
/*  45 */     return this.length;
/*     */   }
/*     */   
/*     */   public String getType() {
/*  49 */     return this.type;
/*     */   }
/*     */   
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  53 */     out.write(this.content);
/*  54 */     out.flush();
/*     */   }
/*     */   
/*     */   public boolean retrySupported() {
/*  58 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getContent() {
/*  67 */     return this.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockHttpContent setContent(byte[] content) {
/*  78 */     this.content = (byte[])Preconditions.checkNotNull(content);
/*  79 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockHttpContent setLength(long length) {
/*  90 */     Preconditions.checkArgument((length >= -1L));
/*  91 */     this.length = length;
/*  92 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockHttpContent setType(String type) {
/* 101 */     this.type = type;
/* 102 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\http\MockHttpContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */