/*     */ package com.google.api.client.testing.http;
/*     */ 
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockHttpTransport
/*     */   extends HttpTransport
/*     */ {
/*     */   private Set<String> supportedMethods;
/*     */   private MockLowLevelHttpRequest lowLevelHttpRequest;
/*     */   private MockLowLevelHttpResponse lowLevelHttpResponse;
/*     */   
/*     */   public MockHttpTransport() {}
/*     */   
/*     */   protected MockHttpTransport(Builder builder) {
/*  61 */     this.supportedMethods = builder.supportedMethods;
/*  62 */     this.lowLevelHttpRequest = builder.lowLevelHttpRequest;
/*  63 */     this.lowLevelHttpResponse = builder.lowLevelHttpResponse;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsMethod(String method) throws IOException {
/*  68 */     return (this.supportedMethods == null || this.supportedMethods.contains(method));
/*     */   }
/*     */ 
/*     */   
/*     */   public LowLevelHttpRequest buildRequest(String method, String url) throws IOException {
/*  73 */     Preconditions.checkArgument(supportsMethod(method), "HTTP method %s not supported", new Object[] { method });
/*  74 */     if (this.lowLevelHttpRequest != null) {
/*  75 */       return this.lowLevelHttpRequest;
/*     */     }
/*  77 */     this.lowLevelHttpRequest = new MockLowLevelHttpRequest(url);
/*  78 */     if (this.lowLevelHttpResponse != null) {
/*  79 */       this.lowLevelHttpRequest.setResponse(this.lowLevelHttpResponse);
/*     */     }
/*  81 */     return this.lowLevelHttpRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Set<String> getSupportedMethods() {
/*  89 */     return (this.supportedMethods == null) ? null : Collections.<String>unmodifiableSet(this.supportedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MockLowLevelHttpRequest getLowLevelHttpRequest() {
/*  99 */     return this.lowLevelHttpRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */   {
/*     */     Set<String> supportedMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MockLowLevelHttpRequest lowLevelHttpRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MockLowLevelHttpResponse lowLevelHttpResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MockHttpTransport build() {
/* 138 */       return new MockHttpTransport(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Set<String> getSupportedMethods() {
/* 145 */       return this.supportedMethods;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder setSupportedMethods(Set<String> supportedMethods) {
/* 152 */       this.supportedMethods = supportedMethods;
/* 153 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder setLowLevelHttpRequest(MockLowLevelHttpRequest lowLevelHttpRequest) {
/* 167 */       Preconditions.checkState((this.lowLevelHttpResponse == null), "Cannnot set a low level HTTP request when a low level HTTP response has been set.");
/*     */ 
/*     */       
/* 170 */       this.lowLevelHttpRequest = lowLevelHttpRequest;
/* 171 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final MockLowLevelHttpRequest getLowLevelHttpRequest() {
/* 181 */       return this.lowLevelHttpRequest;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Builder setLowLevelHttpResponse(MockLowLevelHttpResponse lowLevelHttpResponse) {
/* 195 */       Preconditions.checkState((this.lowLevelHttpRequest == null), "Cannot set a low level HTTP response when a low level HTTP request has been set.");
/*     */ 
/*     */       
/* 198 */       this.lowLevelHttpResponse = lowLevelHttpResponse;
/* 199 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MockLowLevelHttpResponse getLowLevelHttpResponse() {
/* 209 */       return this.lowLevelHttpResponse;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\http\MockHttpTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */