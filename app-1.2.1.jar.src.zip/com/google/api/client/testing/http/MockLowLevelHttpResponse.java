/*     */ package com.google.api.client.testing.http;
/*     */ 
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import com.google.api.client.testing.util.TestableByteArrayInputStream;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockLowLevelHttpResponse
/*     */   extends LowLevelHttpResponse
/*     */ {
/*     */   private InputStream content;
/*     */   private String contentType;
/*  46 */   private int statusCode = 200;
/*     */ 
/*     */   
/*     */   private String reasonPhrase;
/*     */ 
/*     */   
/*  52 */   private List<String> headerNames = new ArrayList<>();
/*     */ 
/*     */   
/*  55 */   private List<String> headerValues = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private String contentEncoding;
/*     */ 
/*     */   
/*  61 */   private long contentLength = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDisconnected;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse addHeader(String name, String value) {
/*  73 */     this.headerNames.add(Preconditions.checkNotNull(name));
/*  74 */     this.headerValues.add(Preconditions.checkNotNull(value));
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setContent(String stringContent) {
/*  87 */     return (stringContent == null) ? 
/*  88 */       setZeroContent() : 
/*  89 */       setContent(StringUtils.getBytesUtf8(stringContent));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setContent(byte[] byteContent) {
/* 102 */     if (byteContent == null) {
/* 103 */       return setZeroContent();
/*     */     }
/* 105 */     this.content = (InputStream)new TestableByteArrayInputStream(byteContent);
/* 106 */     setContentLength(byteContent.length);
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setZeroContent() {
/* 117 */     this.content = null;
/* 118 */     setContentLength(0L);
/* 119 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContent() throws IOException {
/* 124 */     return this.content;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentEncoding() {
/* 129 */     return this.contentEncoding;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getContentLength() {
/* 134 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getContentType() {
/* 139 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeaderCount() {
/* 144 */     return this.headerNames.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderName(int index) {
/* 149 */     return this.headerNames.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderValue(int index) {
/* 154 */     return this.headerValues.get(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getReasonPhrase() {
/* 159 */     return this.reasonPhrase;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStatusCode() {
/* 164 */     return this.statusCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatusLine() {
/* 169 */     StringBuilder buf = new StringBuilder();
/* 170 */     buf.append(this.statusCode);
/* 171 */     if (this.reasonPhrase != null) {
/* 172 */       buf.append(this.reasonPhrase);
/*     */     }
/* 174 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<String> getHeaderNames() {
/* 183 */     return this.headerNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setHeaderNames(List<String> headerNames) {
/* 194 */     this.headerNames = (List<String>)Preconditions.checkNotNull(headerNames);
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<String> getHeaderValues() {
/* 206 */     return this.headerValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setHeaderValues(List<String> headerValues) {
/* 215 */     this.headerValues = (List<String>)Preconditions.checkNotNull(headerValues);
/* 216 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setContent(InputStream content) {
/* 225 */     this.content = content;
/* 226 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setContentType(String contentType) {
/* 235 */     this.contentType = contentType;
/* 236 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setContentEncoding(String contentEncoding) {
/* 245 */     this.contentEncoding = contentEncoding;
/* 246 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setContentLength(long contentLength) {
/* 257 */     this.contentLength = contentLength;
/* 258 */     Preconditions.checkArgument((contentLength >= -1L));
/* 259 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setStatusCode(int statusCode) {
/* 270 */     this.statusCode = statusCode;
/* 271 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockLowLevelHttpResponse setReasonPhrase(String reasonPhrase) {
/* 280 */     this.reasonPhrase = reasonPhrase;
/* 281 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void disconnect() throws IOException {
/* 286 */     this.isDisconnected = true;
/* 287 */     super.disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDisconnected() {
/* 296 */     return this.isDisconnected;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\http\MockLowLevelHttpResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */