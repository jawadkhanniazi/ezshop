/*    */ package com.google.api.client.testing.http;
/*    */ 
/*    */ import com.google.api.client.http.HttpRequest;
/*    */ import com.google.api.client.http.HttpResponse;
/*    */ import com.google.api.client.http.HttpUnsuccessfulResponseHandler;
/*    */ import com.google.api.client.util.Beta;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class MockHttpUnsuccessfulResponseHandler
/*    */   implements HttpUnsuccessfulResponseHandler
/*    */ {
/*    */   private boolean isCalled;
/*    */   private boolean successfullyHandleResponse;
/*    */   
/*    */   public MockHttpUnsuccessfulResponseHandler(boolean successfullyHandleResponse) {
/* 44 */     this.successfullyHandleResponse = successfullyHandleResponse;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCalled() {
/* 49 */     return this.isCalled;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean handleResponse(HttpRequest request, HttpResponse response, boolean supportsRetry) throws IOException {
/* 54 */     this.isCalled = true;
/* 55 */     return this.successfullyHandleResponse;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\http\MockHttpUnsuccessfulResponseHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */