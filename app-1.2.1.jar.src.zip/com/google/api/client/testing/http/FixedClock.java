/*    */ package com.google.api.client.testing.http;
/*    */ 
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Clock;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class FixedClock
/*    */   implements Clock
/*    */ {
/*    */   private AtomicLong currentTime;
/*    */   
/*    */   public FixedClock() {
/* 36 */     this(0L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FixedClock(long startTime) {
/* 45 */     this.currentTime = new AtomicLong(startTime);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FixedClock setTime(long newTime) {
/* 54 */     this.currentTime.set(newTime);
/* 55 */     return this;
/*    */   }
/*    */   
/*    */   public long currentTimeMillis() {
/* 59 */     return this.currentTime.get();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\http\FixedClock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */