/*     */ package com.google.api.client.testing.http.javanet;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockHttpURLConnection
/*     */   extends HttpURLConnection
/*     */ {
/*     */   private boolean doOutputCalled;
/*  50 */   private OutputStream outputStream = new ByteArrayOutputStream(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  58 */   public static final byte[] INPUT_BUF = new byte[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  66 */   public static final byte[] ERROR_BUF = new byte[5];
/*     */ 
/*     */   
/*  69 */   private InputStream inputStream = null;
/*     */ 
/*     */   
/*  72 */   private InputStream errorStream = null;
/*     */   
/*  74 */   private Map<String, List<String>> headers = new LinkedHashMap<>();
/*     */ 
/*     */   
/*     */   public MockHttpURLConnection(URL u) {
/*  78 */     super(u);
/*     */   }
/*     */ 
/*     */   
/*     */   public void disconnect() {}
/*     */ 
/*     */   
/*     */   public boolean usingProxy() {
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connect() throws IOException {}
/*     */ 
/*     */   
/*     */   public int getResponseCode() throws IOException {
/*  94 */     return this.responseCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDoOutput(boolean dooutput) {
/*  99 */     this.doOutputCalled = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 104 */     if (this.outputStream != null) {
/* 105 */       return this.outputStream;
/*     */     }
/* 107 */     return super.getOutputStream();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean doOutputCalled() {
/* 112 */     return this.doOutputCalled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockHttpURLConnection setOutputStream(OutputStream outputStream) {
/* 122 */     this.outputStream = outputStream;
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MockHttpURLConnection setResponseCode(int responseCode) {
/* 128 */     Preconditions.checkArgument((responseCode >= -1));
/* 129 */     this.responseCode = responseCode;
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockHttpURLConnection addHeader(String name, String value) {
/* 139 */     Preconditions.checkNotNull(name);
/* 140 */     Preconditions.checkNotNull(value);
/* 141 */     if (this.headers.containsKey(name)) {
/* 142 */       ((List<String>)this.headers.get(name)).add(value);
/*     */     } else {
/* 144 */       List<String> values = new ArrayList<>();
/* 145 */       values.add(value);
/* 146 */       this.headers.put(name, values);
/*     */     } 
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockHttpURLConnection setInputStream(InputStream is) {
/* 159 */     Preconditions.checkNotNull(is);
/* 160 */     if (this.inputStream == null) {
/* 161 */       this.inputStream = is;
/*     */     }
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockHttpURLConnection setErrorStream(InputStream is) {
/* 174 */     Preconditions.checkNotNull(is);
/* 175 */     if (this.errorStream == null) {
/* 176 */       this.errorStream = is;
/*     */     }
/* 178 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/* 183 */     if (this.responseCode < 400) {
/* 184 */       return this.inputStream;
/*     */     }
/* 186 */     throw new IOException();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getErrorStream() {
/* 191 */     return this.errorStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getHeaderFields() {
/* 196 */     return this.headers;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHeaderField(String name) {
/* 201 */     List<String> values = this.headers.get(name);
/* 202 */     return (values == null) ? null : values.get(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testing\http\javanet\MockHttpURLConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */