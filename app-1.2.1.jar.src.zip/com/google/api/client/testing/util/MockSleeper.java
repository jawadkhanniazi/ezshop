/*    */ package com.google.api.client.testing.util;
/*    */ 
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Sleeper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class MockSleeper
/*    */   implements Sleeper
/*    */ {
/*    */   private int count;
/*    */   private long lastMillis;
/*    */   
/*    */   public void sleep(long millis) throws InterruptedException {
/* 42 */     this.count++;
/* 43 */     this.lastMillis = millis;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getCount() {
/* 48 */     return this.count;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final long getLastMillis() {
/* 56 */     return this.lastMillis;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testin\\util\MockSleeper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */