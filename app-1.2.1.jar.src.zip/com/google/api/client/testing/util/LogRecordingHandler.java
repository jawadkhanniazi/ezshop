/*    */ package com.google.api.client.testing.util;
/*    */ 
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Lists;
/*    */ import java.util.List;
/*    */ import java.util.logging.Handler;
/*    */ import java.util.logging.LogRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class LogRecordingHandler
/*    */   extends Handler
/*    */ {
/* 34 */   private final List<LogRecord> records = Lists.newArrayList();
/*    */ 
/*    */   
/*    */   public void publish(LogRecord record) {
/* 38 */     this.records.add(record);
/*    */   }
/*    */ 
/*    */   
/*    */   public void flush() {}
/*    */ 
/*    */   
/*    */   public void close() throws SecurityException {}
/*    */ 
/*    */   
/*    */   public List<String> messages() {
/* 49 */     List<String> result = Lists.newArrayList();
/* 50 */     for (LogRecord record : this.records) {
/* 51 */       result.add(record.getMessage());
/*    */     }
/* 53 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testin\\util\LogRecordingHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */