/*    */ package com.google.api.client.testing.util;
/*    */ 
/*    */ import com.google.api.client.util.BackOff;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class MockBackOff
/*    */   implements BackOff
/*    */ {
/*    */   private long backOffMillis;
/* 38 */   private int maxTries = 10;
/*    */   
/*    */   private int numTries;
/*    */ 
/*    */   
/*    */   public void reset() throws IOException {
/* 44 */     this.numTries = 0;
/*    */   }
/*    */   
/*    */   public long nextBackOffMillis() throws IOException {
/* 48 */     if (this.numTries >= this.maxTries || this.backOffMillis == -1L) {
/* 49 */       return -1L;
/*    */     }
/* 51 */     this.numTries++;
/* 52 */     return this.backOffMillis;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MockBackOff setBackOffMillis(long backOffMillis) {
/* 62 */     Preconditions.checkArgument((backOffMillis == -1L || backOffMillis >= 0L));
/* 63 */     this.backOffMillis = backOffMillis;
/* 64 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MockBackOff setMaxTries(int maxTries) {
/* 74 */     Preconditions.checkArgument((maxTries >= 0));
/* 75 */     this.maxTries = maxTries;
/* 76 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getMaxTries() {
/* 81 */     return this.maxTries;
/*    */   }
/*    */ 
/*    */   
/*    */   public final int getNumberOfTries() {
/* 86 */     return this.numTries;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\testin\\util\MockBackOff.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */