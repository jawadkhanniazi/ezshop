/*     */ package com.google.api.client.json;
/*     */ 
/*     */ import com.google.api.client.util.Charsets;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonFactory
/*     */ {
/*     */   public abstract JsonParser createJsonParser(InputStream paramInputStream) throws IOException;
/*     */   
/*     */   public abstract JsonParser createJsonParser(InputStream paramInputStream, Charset paramCharset) throws IOException;
/*     */   
/*     */   public abstract JsonParser createJsonParser(String paramString) throws IOException;
/*     */   
/*     */   public abstract JsonParser createJsonParser(Reader paramReader) throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createJsonGenerator(OutputStream paramOutputStream, Charset paramCharset) throws IOException;
/*     */   
/*     */   public abstract JsonGenerator createJsonGenerator(Writer paramWriter) throws IOException;
/*     */   
/*     */   public final JsonObjectParser createJsonObjectParser() {
/*  98 */     return new JsonObjectParser(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString(Object item) throws IOException {
/* 109 */     return toString(item, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toPrettyString(Object item) throws IOException {
/* 125 */     return toString(item, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] toByteArray(Object item) throws IOException {
/* 137 */     return toByteStream(item, false).toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toString(Object item, boolean pretty) throws IOException {
/* 149 */     return toByteStream(item, pretty).toString("UTF-8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ByteArrayOutputStream toByteStream(Object item, boolean pretty) throws IOException {
/* 161 */     ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
/* 162 */     JsonGenerator generator = createJsonGenerator(byteStream, Charsets.UTF_8);
/* 163 */     if (pretty) {
/* 164 */       generator.enablePrettyPrint();
/*     */     }
/* 166 */     generator.serialize(item);
/* 167 */     generator.flush();
/* 168 */     return byteStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T fromString(String value, Class<T> destinationClass) throws IOException {
/* 182 */     return createJsonParser(value).parse(destinationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T fromInputStream(InputStream inputStream, Class<T> destinationClass) throws IOException {
/* 199 */     return createJsonParser(inputStream).parseAndClose(destinationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T fromInputStream(InputStream inputStream, Charset charset, Class<T> destinationClass) throws IOException {
/* 215 */     return createJsonParser(inputStream, charset).parseAndClose(destinationClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T fromReader(Reader reader, Class<T> destinationClass) throws IOException {
/* 229 */     return createJsonParser(reader).parseAndClose(destinationClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\JsonFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */