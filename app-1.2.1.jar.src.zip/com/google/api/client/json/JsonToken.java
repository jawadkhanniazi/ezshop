/*    */ package com.google.api.client.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JsonToken
/*    */ {
/* 26 */   START_ARRAY,
/*    */ 
/*    */   
/* 29 */   END_ARRAY,
/*    */ 
/*    */   
/* 32 */   START_OBJECT,
/*    */ 
/*    */   
/* 35 */   END_OBJECT,
/*    */ 
/*    */   
/* 38 */   FIELD_NAME,
/*    */ 
/*    */   
/* 41 */   VALUE_STRING,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   VALUE_NUMBER_INT,
/*    */ 
/*    */   
/* 50 */   VALUE_NUMBER_FLOAT,
/*    */ 
/*    */   
/* 53 */   VALUE_TRUE,
/*    */ 
/*    */   
/* 56 */   VALUE_FALSE,
/*    */ 
/*    */   
/* 59 */   VALUE_NULL,
/*    */ 
/*    */   
/* 62 */   NOT_AVAILABLE;
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\JsonToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */