/*     */ package com.google.api.client.json.jackson2;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonGenerator;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JacksonGenerator
/*     */   extends JsonGenerator
/*     */ {
/*     */   private final JsonGenerator generator;
/*     */   private final JacksonFactory factory;
/*     */   
/*     */   public JacksonFactory getFactory() {
/*  35 */     return this.factory;
/*     */   }
/*     */   
/*     */   JacksonGenerator(JacksonFactory factory, JsonGenerator generator) {
/*  39 */     this.factory = factory;
/*  40 */     this.generator = generator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  45 */     this.generator.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  50 */     this.generator.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean state) throws IOException {
/*  55 */     this.generator.writeBoolean(state);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEndArray() throws IOException {
/*  60 */     this.generator.writeEndArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEndObject() throws IOException {
/*  65 */     this.generator.writeEndObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFieldName(String name) throws IOException {
/*  70 */     this.generator.writeFieldName(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNull() throws IOException {
/*  75 */     this.generator.writeNull();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(int v) throws IOException {
/*  80 */     this.generator.writeNumber(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(long v) throws IOException {
/*  85 */     this.generator.writeNumber(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(BigInteger v) throws IOException {
/*  90 */     this.generator.writeNumber(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(double v) throws IOException {
/*  95 */     this.generator.writeNumber(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(float v) throws IOException {
/* 100 */     this.generator.writeNumber(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(BigDecimal v) throws IOException {
/* 105 */     this.generator.writeNumber(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(String encodedValue) throws IOException {
/* 110 */     this.generator.writeNumber(encodedValue);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartArray() throws IOException {
/* 115 */     this.generator.writeStartArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartObject() throws IOException {
/* 120 */     this.generator.writeStartObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeString(String value) throws IOException {
/* 125 */     this.generator.writeString(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void enablePrettyPrint() throws IOException {
/* 130 */     this.generator.useDefaultPrettyPrinter();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\jackson2\JacksonGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */