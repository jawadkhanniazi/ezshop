/*     */ package com.google.api.client.json.jackson2;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonGenerator;
/*     */ import com.google.api.client.json.JsonParser;
/*     */ import com.google.api.client.json.JsonToken;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JacksonFactory
/*     */   extends JsonFactory
/*     */ {
/*     */   private final JsonFactory factory;
/*     */   
/*     */   public JacksonFactory() {
/*  41 */     this.factory = new JsonFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     this.factory.configure(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JacksonFactory getDefaultInstance() {
/*  57 */     return InstanceHolder.INSTANCE;
/*     */   }
/*     */   
/*     */   static class InstanceHolder
/*     */   {
/*  62 */     static final JacksonFactory INSTANCE = new JacksonFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator createJsonGenerator(OutputStream out, Charset enc) throws IOException {
/*  67 */     return new JacksonGenerator(this, this.factory
/*  68 */         .createJsonGenerator(out, JsonEncoding.UTF8));
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator createJsonGenerator(Writer writer) throws IOException {
/*  73 */     return new JacksonGenerator(this, this.factory.createJsonGenerator(writer));
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser createJsonParser(Reader reader) throws IOException {
/*  78 */     Preconditions.checkNotNull(reader);
/*  79 */     return new JacksonParser(this, this.factory.createJsonParser(reader));
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser createJsonParser(InputStream in) throws IOException {
/*  84 */     Preconditions.checkNotNull(in);
/*  85 */     return new JacksonParser(this, this.factory.createJsonParser(in));
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser createJsonParser(InputStream in, Charset charset) throws IOException {
/*  90 */     Preconditions.checkNotNull(in);
/*  91 */     return new JacksonParser(this, this.factory.createJsonParser(in));
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser createJsonParser(String value) throws IOException {
/*  96 */     Preconditions.checkNotNull(value);
/*  97 */     return new JacksonParser(this, this.factory.createJsonParser(value));
/*     */   }
/*     */   
/*     */   static JsonToken convert(JsonToken token) {
/* 101 */     if (token == null) {
/* 102 */       return null;
/*     */     }
/* 104 */     switch (token) {
/*     */       case END_ARRAY:
/* 106 */         return JsonToken.END_ARRAY;
/*     */       case START_ARRAY:
/* 108 */         return JsonToken.START_ARRAY;
/*     */       case END_OBJECT:
/* 110 */         return JsonToken.END_OBJECT;
/*     */       case START_OBJECT:
/* 112 */         return JsonToken.START_OBJECT;
/*     */       case VALUE_FALSE:
/* 114 */         return JsonToken.VALUE_FALSE;
/*     */       case VALUE_TRUE:
/* 116 */         return JsonToken.VALUE_TRUE;
/*     */       case VALUE_NULL:
/* 118 */         return JsonToken.VALUE_NULL;
/*     */       case VALUE_STRING:
/* 120 */         return JsonToken.VALUE_STRING;
/*     */       case VALUE_NUMBER_FLOAT:
/* 122 */         return JsonToken.VALUE_NUMBER_FLOAT;
/*     */       case VALUE_NUMBER_INT:
/* 124 */         return JsonToken.VALUE_NUMBER_INT;
/*     */       case FIELD_NAME:
/* 126 */         return JsonToken.FIELD_NAME;
/*     */     } 
/* 128 */     return JsonToken.NOT_AVAILABLE;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\jackson2\JacksonFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */