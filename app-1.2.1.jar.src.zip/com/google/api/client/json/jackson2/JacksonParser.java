/*     */ package com.google.api.client.json.jackson2;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonParser;
/*     */ import com.google.api.client.json.JsonToken;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JacksonParser
/*     */   extends JsonParser
/*     */ {
/*     */   private final JsonParser parser;
/*     */   private final JacksonFactory factory;
/*     */   
/*     */   public JacksonFactory getFactory() {
/*  37 */     return this.factory;
/*     */   }
/*     */   
/*     */   JacksonParser(JacksonFactory factory, JsonParser parser) {
/*  41 */     this.factory = factory;
/*  42 */     this.parser = parser;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  47 */     this.parser.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonToken nextToken() throws IOException {
/*  52 */     return JacksonFactory.convert(this.parser.nextToken());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCurrentName() throws IOException {
/*  57 */     return this.parser.getCurrentName();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonToken getCurrentToken() {
/*  62 */     return JacksonFactory.convert(this.parser.getCurrentToken());
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/*  67 */     this.parser.skipChildren();
/*  68 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() throws IOException {
/*  73 */     return this.parser.getText();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByteValue() throws IOException {
/*  78 */     return this.parser.getByteValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatValue() throws IOException {
/*  83 */     return this.parser.getFloatValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntValue() throws IOException {
/*  88 */     return this.parser.getIntValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShortValue() throws IOException {
/*  93 */     return this.parser.getShortValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public BigInteger getBigIntegerValue() throws IOException {
/*  98 */     return this.parser.getBigIntegerValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 103 */     return this.parser.getDecimalValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoubleValue() throws IOException {
/* 108 */     return this.parser.getDoubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongValue() throws IOException {
/* 113 */     return this.parser.getLongValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\jackson2\JacksonParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */