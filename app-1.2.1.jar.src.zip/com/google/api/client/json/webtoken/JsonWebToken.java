/*     */ package com.google.api.client.json.webtoken;
/*     */ 
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Objects;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonWebToken
/*     */ {
/*     */   private final Header header;
/*     */   private final Payload payload;
/*     */   
/*     */   public JsonWebToken(Header header, Payload payload) {
/*  45 */     this.header = (Header)Preconditions.checkNotNull(header);
/*  46 */     this.payload = (Payload)Preconditions.checkNotNull(payload);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Header
/*     */     extends GenericJson
/*     */   {
/*     */     @Key("typ")
/*     */     private String type;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("cty")
/*     */     private String contentType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getType() {
/*  71 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setType(String type) {
/*  82 */       this.type = type;
/*  83 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getContentType() {
/*  91 */       return this.contentType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setContentType(String contentType) {
/* 102 */       this.contentType = contentType;
/* 103 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Header set(String fieldName, Object value) {
/* 108 */       return (Header)super.set(fieldName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Header clone() {
/* 113 */       return (Header)super.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Payload
/*     */     extends GenericJson
/*     */   {
/*     */     @Key("exp")
/*     */     private Long expirationTimeSeconds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("nbf")
/*     */     private Long notBeforeTimeSeconds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("iat")
/*     */     private Long issuedAtTimeSeconds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("iss")
/*     */     private String issuer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("aud")
/*     */     private Object audience;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("jti")
/*     */     private String jwtId;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("typ")
/*     */     private String type;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("sub")
/*     */     private String subject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Long getExpirationTimeSeconds() {
/* 179 */       return this.expirationTimeSeconds;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setExpirationTimeSeconds(Long expirationTimeSeconds) {
/* 190 */       this.expirationTimeSeconds = expirationTimeSeconds;
/* 191 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Long getNotBeforeTimeSeconds() {
/* 199 */       return this.notBeforeTimeSeconds;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setNotBeforeTimeSeconds(Long notBeforeTimeSeconds) {
/* 210 */       this.notBeforeTimeSeconds = notBeforeTimeSeconds;
/* 211 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Long getIssuedAtTimeSeconds() {
/* 219 */       return this.issuedAtTimeSeconds;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setIssuedAtTimeSeconds(Long issuedAtTimeSeconds) {
/* 230 */       this.issuedAtTimeSeconds = issuedAtTimeSeconds;
/* 231 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getIssuer() {
/* 239 */       return this.issuer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setIssuer(String issuer) {
/* 250 */       this.issuer = issuer;
/* 251 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Object getAudience() {
/* 259 */       return this.audience;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final List<String> getAudienceAsList() {
/* 268 */       if (this.audience == null) {
/* 269 */         return Collections.emptyList();
/*     */       }
/* 271 */       if (this.audience instanceof String) {
/* 272 */         return Collections.singletonList((String)this.audience);
/*     */       }
/* 274 */       return (List<String>)this.audience;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setAudience(Object audience) {
/* 285 */       this.audience = audience;
/* 286 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getJwtId() {
/* 294 */       return this.jwtId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setJwtId(String jwtId) {
/* 304 */       this.jwtId = jwtId;
/* 305 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getType() {
/* 313 */       return this.type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setType(String type) {
/* 324 */       this.type = type;
/* 325 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getSubject() {
/* 333 */       return this.subject;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setSubject(String subject) {
/* 344 */       this.subject = subject;
/* 345 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload set(String fieldName, Object value) {
/* 350 */       return (Payload)super.set(fieldName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload clone() {
/* 355 */       return (Payload)super.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 361 */     return Objects.toStringHelper(this).add("header", this.header).add("payload", this.payload).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Header getHeader() {
/* 371 */     return this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Payload getPayload() {
/* 381 */     return this.payload;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\webtoken\JsonWebToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */