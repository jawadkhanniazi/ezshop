/*     */ package com.google.api.client.json.webtoken;
/*     */ 
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.Base64;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.SecurityUtils;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonWebSignature
/*     */   extends JsonWebToken
/*     */ {
/*     */   private final byte[] signatureBytes;
/*     */   private final byte[] signedContentBytes;
/*     */   
/*     */   public JsonWebSignature(Header header, JsonWebToken.Payload payload, byte[] signatureBytes, byte[] signedContentBytes) {
/*  74 */     super(header, payload);
/*  75 */     this.signatureBytes = (byte[])Preconditions.checkNotNull(signatureBytes);
/*  76 */     this.signedContentBytes = (byte[])Preconditions.checkNotNull(signedContentBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Header
/*     */     extends JsonWebToken.Header
/*     */   {
/*     */     @Key("alg")
/*     */     private String algorithm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("jku")
/*     */     private String jwkUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("jwk")
/*     */     private String jwk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("kid")
/*     */     private String keyId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("x5u")
/*     */     private String x509Url;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("x5t")
/*     */     private String x509Thumbprint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("x5c")
/*     */     private ArrayList<String> x509Certificates;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("crit")
/*     */     private List<String> critical;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setType(String type) {
/* 150 */       super.setType(type);
/* 151 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getAlgorithm() {
/* 159 */       return this.algorithm;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setAlgorithm(String algorithm) {
/* 170 */       this.algorithm = algorithm;
/* 171 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getJwkUrl() {
/* 180 */       return this.jwkUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setJwkUrl(String jwkUrl) {
/* 192 */       this.jwkUrl = jwkUrl;
/* 193 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getJwk() {
/* 201 */       return this.jwk;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setJwk(String jwk) {
/* 212 */       this.jwk = jwk;
/* 213 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getKeyId() {
/* 221 */       return this.keyId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setKeyId(String keyId) {
/* 232 */       this.keyId = keyId;
/* 233 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getX509Url() {
/* 242 */       return this.x509Url;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setX509Url(String x509Url) {
/* 254 */       this.x509Url = x509Url;
/* 255 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getX509Thumbprint() {
/* 264 */       return this.x509Thumbprint;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setX509Thumbprint(String x509Thumbprint) {
/* 276 */       this.x509Thumbprint = x509Thumbprint;
/* 277 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final List<String> getX509Certificates() {
/* 288 */       return new ArrayList<>(this.x509Certificates);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setX509Certificates(List<String> x509Certificates) {
/* 302 */       this.x509Certificates = new ArrayList<>(x509Certificates);
/* 303 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final List<String> getCritical() {
/* 313 */       if (this.critical == null || this.critical.isEmpty()) {
/* 314 */         return null;
/*     */       }
/* 316 */       return new ArrayList<>(this.critical);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Header setCritical(List<String> critical) {
/* 329 */       this.critical = new ArrayList<>(critical);
/* 330 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Header set(String fieldName, Object value) {
/* 335 */       return (Header)super.set(fieldName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Header clone() {
/* 340 */       return (Header)super.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Header getHeader() {
/* 346 */     return (Header)super.getHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean verifySignature(PublicKey publicKey) throws GeneralSecurityException {
/* 360 */     Signature signatureAlg = null;
/* 361 */     String algorithm = getHeader().getAlgorithm();
/* 362 */     if ("RS256".equals(algorithm)) {
/* 363 */       signatureAlg = SecurityUtils.getSha256WithRsaSignatureAlgorithm();
/*     */     } else {
/* 365 */       return false;
/*     */     } 
/* 367 */     return SecurityUtils.verify(signatureAlg, publicKey, this.signatureBytes, this.signedContentBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final X509Certificate verifySignature(X509TrustManager trustManager) throws GeneralSecurityException {
/* 388 */     List<String> x509Certificates = getHeader().getX509Certificates();
/* 389 */     if (x509Certificates == null || x509Certificates.isEmpty()) {
/* 390 */       return null;
/*     */     }
/* 392 */     String algorithm = getHeader().getAlgorithm();
/* 393 */     Signature signatureAlg = null;
/* 394 */     if ("RS256".equals(algorithm)) {
/* 395 */       signatureAlg = SecurityUtils.getSha256WithRsaSignatureAlgorithm();
/*     */     } else {
/* 397 */       return null;
/*     */     } 
/* 399 */     return SecurityUtils.verify(signatureAlg, trustManager, x509Certificates, this.signatureBytes, this.signedContentBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final X509Certificate verifySignature() throws GeneralSecurityException {
/* 420 */     X509TrustManager trustManager = getDefaultX509TrustManager();
/* 421 */     if (trustManager == null) {
/* 422 */       return null;
/*     */     }
/* 424 */     return verifySignature(trustManager);
/*     */   }
/*     */ 
/*     */   
/*     */   private static X509TrustManager getDefaultX509TrustManager() {
/*     */     try {
/* 430 */       TrustManagerFactory factory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
/* 431 */       factory.init((KeyStore)null);
/* 432 */       for (TrustManager manager : factory.getTrustManagers()) {
/* 433 */         if (manager instanceof X509TrustManager) {
/* 434 */           return (X509TrustManager)manager;
/*     */         }
/*     */       } 
/* 437 */       return null;
/* 438 */     } catch (NoSuchAlgorithmException e) {
/* 439 */       return null;
/* 440 */     } catch (KeyStoreException e) {
/* 441 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final byte[] getSignatureBytes() {
/* 447 */     return Arrays.copyOf(this.signatureBytes, this.signatureBytes.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public final byte[] getSignedContentBytes() {
/* 452 */     return Arrays.copyOf(this.signedContentBytes, this.signedContentBytes.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonWebSignature parse(JsonFactory jsonFactory, String tokenString) throws IOException {
/* 464 */     return parser(jsonFactory).parse(tokenString);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Parser parser(JsonFactory jsonFactory) {
/* 469 */     return new Parser(jsonFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Parser
/*     */   {
/*     */     private final JsonFactory jsonFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 483 */     private Class<? extends JsonWebSignature.Header> headerClass = JsonWebSignature.Header.class;
/*     */ 
/*     */     
/* 486 */     private Class<? extends JsonWebToken.Payload> payloadClass = JsonWebToken.Payload.class;
/*     */ 
/*     */     
/*     */     public Parser(JsonFactory jsonFactory) {
/* 490 */       this.jsonFactory = (JsonFactory)Preconditions.checkNotNull(jsonFactory);
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<? extends JsonWebSignature.Header> getHeaderClass() {
/* 495 */       return this.headerClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public Parser setHeaderClass(Class<? extends JsonWebSignature.Header> headerClass) {
/* 500 */       this.headerClass = headerClass;
/* 501 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<? extends JsonWebToken.Payload> getPayloadClass() {
/* 506 */       return this.payloadClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public Parser setPayloadClass(Class<? extends JsonWebToken.Payload> payloadClass) {
/* 511 */       this.payloadClass = payloadClass;
/* 512 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonFactory getJsonFactory() {
/* 517 */       return this.jsonFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonWebSignature parse(String tokenString) throws IOException {
/* 528 */       int firstDot = tokenString.indexOf('.');
/* 529 */       Preconditions.checkArgument((firstDot != -1));
/* 530 */       byte[] headerBytes = Base64.decodeBase64(tokenString.substring(0, firstDot));
/* 531 */       int secondDot = tokenString.indexOf('.', firstDot + 1);
/* 532 */       Preconditions.checkArgument((secondDot != -1));
/* 533 */       Preconditions.checkArgument((tokenString.indexOf('.', secondDot + 1) == -1));
/*     */       
/* 535 */       byte[] payloadBytes = Base64.decodeBase64(tokenString.substring(firstDot + 1, secondDot));
/* 536 */       byte[] signatureBytes = Base64.decodeBase64(tokenString.substring(secondDot + 1));
/* 537 */       byte[] signedContentBytes = StringUtils.getBytesUtf8(tokenString.substring(0, secondDot));
/*     */ 
/*     */       
/* 540 */       JsonWebSignature.Header header = (JsonWebSignature.Header)this.jsonFactory.fromInputStream(new ByteArrayInputStream(headerBytes), this.headerClass);
/* 541 */       Preconditions.checkArgument((header.getAlgorithm() != null));
/*     */       
/* 543 */       JsonWebToken.Payload payload = (JsonWebToken.Payload)this.jsonFactory.fromInputStream(new ByteArrayInputStream(payloadBytes), this.payloadClass);
/* 544 */       return new JsonWebSignature(header, payload, signatureBytes, signedContentBytes);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String signUsingRsaSha256(PrivateKey privateKey, JsonFactory jsonFactory, Header header, JsonWebToken.Payload payload) throws GeneralSecurityException, IOException {
/* 570 */     String content = Base64.encodeBase64URLSafeString(jsonFactory.toByteArray(header)) + "." + Base64.encodeBase64URLSafeString(jsonFactory.toByteArray(payload));
/* 571 */     byte[] contentBytes = StringUtils.getBytesUtf8(content);
/*     */     
/* 573 */     byte[] signature = SecurityUtils.sign(
/* 574 */         SecurityUtils.getSha256WithRsaSignatureAlgorithm(), privateKey, contentBytes);
/* 575 */     return content + "." + Base64.encodeBase64URLSafeString(signature);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\webtoken\JsonWebSignature.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */