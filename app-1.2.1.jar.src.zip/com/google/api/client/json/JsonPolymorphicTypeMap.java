package com.google.api.client.json;

import com.google.api.client.util.Beta;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Beta
public @interface JsonPolymorphicTypeMap {
  TypeDef[] typeDefinitions();
  
  @Target({ElementType.FIELD})
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface TypeDef {
    String key();
    
    Class<?> ref();
  }
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\JsonPolymorphicTypeMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */