/*     */ package com.google.api.client.json.gson;
/*     */ 
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonGenerator;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GsonGenerator
/*     */   extends JsonGenerator
/*     */ {
/*     */   private final JsonWriter writer;
/*     */   private final GsonFactory factory;
/*     */   
/*     */   GsonGenerator(GsonFactory factory, JsonWriter writer) {
/*  37 */     this.factory = factory;
/*  38 */     this.writer = writer;
/*     */     
/*  40 */     writer.setLenient(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  45 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  50 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonFactory getFactory() {
/*  55 */     return this.factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeBoolean(boolean state) throws IOException {
/*  60 */     this.writer.value(state);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEndArray() throws IOException {
/*  65 */     this.writer.endArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeEndObject() throws IOException {
/*  70 */     this.writer.endObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeFieldName(String name) throws IOException {
/*  75 */     this.writer.name(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNull() throws IOException {
/*  80 */     this.writer.nullValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(int v) throws IOException {
/*  85 */     this.writer.value(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(long v) throws IOException {
/*  90 */     this.writer.value(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(BigInteger v) throws IOException {
/*  95 */     this.writer.value(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(double v) throws IOException {
/* 100 */     this.writer.value(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(float v) throws IOException {
/* 105 */     this.writer.value(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(BigDecimal v) throws IOException {
/* 110 */     this.writer.value(v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StringNumber
/*     */     extends Number
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private final String encodedValue;
/*     */ 
/*     */     
/*     */     StringNumber(String encodedValue) {
/* 124 */       this.encodedValue = encodedValue;
/*     */     }
/*     */ 
/*     */     
/*     */     public double doubleValue() {
/* 129 */       return 0.0D;
/*     */     }
/*     */ 
/*     */     
/*     */     public float floatValue() {
/* 134 */       return 0.0F;
/*     */     }
/*     */ 
/*     */     
/*     */     public int intValue() {
/* 139 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public long longValue() {
/* 144 */       return 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 149 */       return this.encodedValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeNumber(String encodedValue) throws IOException {
/* 155 */     this.writer.value(new StringNumber(encodedValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartArray() throws IOException {
/* 160 */     this.writer.beginArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeStartObject() throws IOException {
/* 165 */     this.writer.beginObject();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeString(String value) throws IOException {
/* 170 */     this.writer.value(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void enablePrettyPrint() throws IOException {
/* 175 */     this.writer.setIndent("  ");
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\gson\GsonGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */