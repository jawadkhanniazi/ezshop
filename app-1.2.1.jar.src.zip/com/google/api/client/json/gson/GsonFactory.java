/*    */ package com.google.api.client.json.gson;
/*    */ 
/*    */ import com.google.api.client.json.JsonFactory;
/*    */ import com.google.api.client.json.JsonGenerator;
/*    */ import com.google.api.client.json.JsonParser;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Charsets;
/*    */ import com.google.gson.stream.JsonReader;
/*    */ import com.google.gson.stream.JsonWriter;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.StringReader;
/*    */ import java.io.Writer;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GsonFactory
/*    */   extends JsonFactory
/*    */ {
/*    */   @Beta
/*    */   public static GsonFactory getDefaultInstance() {
/* 52 */     return InstanceHolder.INSTANCE;
/*    */   }
/*    */   
/*    */   @Beta
/*    */   static class InstanceHolder
/*    */   {
/* 58 */     static final GsonFactory INSTANCE = new GsonFactory();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonParser createJsonParser(InputStream in) {
/* 65 */     return createJsonParser(new InputStreamReader(in, Charsets.UTF_8));
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonParser createJsonParser(InputStream in, Charset charset) {
/* 70 */     if (charset == null) {
/* 71 */       return createJsonParser(in);
/*    */     }
/* 73 */     return createJsonParser(new InputStreamReader(in, charset));
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonParser createJsonParser(String value) {
/* 78 */     return createJsonParser(new StringReader(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonParser createJsonParser(Reader reader) {
/* 83 */     return new GsonParser(this, new JsonReader(reader));
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonGenerator createJsonGenerator(OutputStream out, Charset enc) {
/* 88 */     return createJsonGenerator(new OutputStreamWriter(out, enc));
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonGenerator createJsonGenerator(Writer writer) {
/* 93 */     return new GsonGenerator(this, new JsonWriter(writer));
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\gson\GsonFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */