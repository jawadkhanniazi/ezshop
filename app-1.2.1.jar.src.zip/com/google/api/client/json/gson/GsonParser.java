/*     */ package com.google.api.client.json.gson;
/*     */ 
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonParser;
/*     */ import com.google.api.client.json.JsonToken;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.google.gson.stream.JsonToken;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GsonParser
/*     */   extends JsonParser
/*     */ {
/*     */   private final JsonReader reader;
/*     */   private final GsonFactory factory;
/*  40 */   private List<String> currentNameStack = new ArrayList<>();
/*     */   private JsonToken currentToken;
/*     */   private String currentText;
/*     */   
/*     */   GsonParser(GsonFactory factory, JsonReader reader) {
/*  45 */     this.factory = factory;
/*  46 */     this.reader = reader;
/*     */     
/*  48 */     reader.setLenient(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  53 */     this.reader.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCurrentName() {
/*  58 */     return this.currentNameStack.isEmpty() ? null : this.currentNameStack.get(this.currentNameStack.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonToken getCurrentToken() {
/*  63 */     return this.currentToken;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonFactory getFactory() {
/*  68 */     return this.factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getByteValue() {
/*  73 */     checkNumber();
/*  74 */     return Byte.parseByte(this.currentText);
/*     */   }
/*     */ 
/*     */   
/*     */   public short getShortValue() {
/*  79 */     checkNumber();
/*  80 */     return Short.parseShort(this.currentText);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntValue() {
/*  85 */     checkNumber();
/*  86 */     return Integer.parseInt(this.currentText);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatValue() {
/*  91 */     checkNumber();
/*  92 */     return Float.parseFloat(this.currentText);
/*     */   }
/*     */ 
/*     */   
/*     */   public BigInteger getBigIntegerValue() {
/*  97 */     checkNumber();
/*  98 */     return new BigInteger(this.currentText);
/*     */   }
/*     */ 
/*     */   
/*     */   public BigDecimal getDecimalValue() {
/* 103 */     checkNumber();
/* 104 */     return new BigDecimal(this.currentText);
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoubleValue() {
/* 109 */     checkNumber();
/* 110 */     return Double.parseDouble(this.currentText);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongValue() {
/* 115 */     checkNumber();
/* 116 */     return Long.parseLong(this.currentText);
/*     */   }
/*     */   
/*     */   private void checkNumber() {
/* 120 */     Preconditions.checkArgument((this.currentToken == JsonToken.VALUE_NUMBER_INT || this.currentToken == JsonToken.VALUE_NUMBER_FLOAT));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 126 */     return this.currentText;
/*     */   }
/*     */   
/*     */   public JsonToken nextToken() throws IOException {
/*     */     JsonToken peek;
/* 131 */     if (this.currentToken != null) {
/* 132 */       switch (this.currentToken) {
/*     */         case BEGIN_ARRAY:
/* 134 */           this.reader.beginArray();
/* 135 */           this.currentNameStack.add(null);
/*     */           break;
/*     */         case END_ARRAY:
/* 138 */           this.reader.beginObject();
/* 139 */           this.currentNameStack.add(null);
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     try {
/* 149 */       peek = this.reader.peek();
/* 150 */     } catch (EOFException e) {
/* 151 */       peek = JsonToken.END_DOCUMENT;
/*     */     } 
/* 153 */     switch (peek)
/*     */     { case BEGIN_ARRAY:
/* 155 */         this.currentText = "[";
/* 156 */         this.currentToken = JsonToken.START_ARRAY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 208 */         return this.currentToken;case END_ARRAY: this.currentText = "]"; this.currentToken = JsonToken.END_ARRAY; this.currentNameStack.remove(this.currentNameStack.size() - 1); this.reader.endArray(); return this.currentToken;case BEGIN_OBJECT: this.currentText = "{"; this.currentToken = JsonToken.START_OBJECT; return this.currentToken;case END_OBJECT: this.currentText = "}"; this.currentToken = JsonToken.END_OBJECT; this.currentNameStack.remove(this.currentNameStack.size() - 1); this.reader.endObject(); return this.currentToken;case BOOLEAN: if (this.reader.nextBoolean()) { this.currentText = "true"; this.currentToken = JsonToken.VALUE_TRUE; } else { this.currentText = "false"; this.currentToken = JsonToken.VALUE_FALSE; }  return this.currentToken;case NULL: this.currentText = "null"; this.currentToken = JsonToken.VALUE_NULL; this.reader.nextNull(); return this.currentToken;case STRING: this.currentText = this.reader.nextString(); this.currentToken = JsonToken.VALUE_STRING; return this.currentToken;case NUMBER: this.currentText = this.reader.nextString(); this.currentToken = (this.currentText.indexOf('.') == -1) ? JsonToken.VALUE_NUMBER_INT : JsonToken.VALUE_NUMBER_FLOAT; return this.currentToken;case NAME: this.currentText = this.reader.nextName(); this.currentToken = JsonToken.FIELD_NAME; this.currentNameStack.set(this.currentNameStack.size() - 1, this.currentText); return this.currentToken; }  this.currentText = null; this.currentToken = null; return this.currentToken;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/* 213 */     if (this.currentToken != null) {
/* 214 */       switch (this.currentToken) {
/*     */         case BEGIN_ARRAY:
/* 216 */           this.reader.skipValue();
/* 217 */           this.currentText = "]";
/* 218 */           this.currentToken = JsonToken.END_ARRAY;
/*     */           break;
/*     */         case END_ARRAY:
/* 221 */           this.reader.skipValue();
/* 222 */           this.currentText = "}";
/* 223 */           this.currentToken = JsonToken.END_OBJECT;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     }
/* 229 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\gson\GsonParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */