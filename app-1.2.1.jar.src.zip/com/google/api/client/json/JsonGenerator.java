/*     */ package com.google.api.client.json;
/*     */ 
/*     */ import com.google.api.client.util.ClassInfo;
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.DateTime;
/*     */ import com.google.api.client.util.FieldInfo;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Types;
/*     */ import java.io.Closeable;
/*     */ import java.io.Flushable;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonGenerator
/*     */   implements Closeable, Flushable
/*     */ {
/*     */   public abstract JsonFactory getFactory();
/*     */   
/*     */   public abstract void flush() throws IOException;
/*     */   
/*     */   public abstract void close() throws IOException;
/*     */   
/*     */   public abstract void writeStartArray() throws IOException;
/*     */   
/*     */   public abstract void writeEndArray() throws IOException;
/*     */   
/*     */   public abstract void writeStartObject() throws IOException;
/*     */   
/*     */   public abstract void writeEndObject() throws IOException;
/*     */   
/*     */   public abstract void writeFieldName(String paramString) throws IOException;
/*     */   
/*     */   public abstract void writeNull() throws IOException;
/*     */   
/*     */   public abstract void writeString(String paramString) throws IOException;
/*     */   
/*     */   public abstract void writeBoolean(boolean paramBoolean) throws IOException;
/*     */   
/*     */   public abstract void writeNumber(int paramInt) throws IOException;
/*     */   
/*     */   public abstract void writeNumber(long paramLong) throws IOException;
/*     */   
/*     */   public abstract void writeNumber(BigInteger paramBigInteger) throws IOException;
/*     */   
/*     */   public abstract void writeNumber(float paramFloat) throws IOException;
/*     */   
/*     */   public abstract void writeNumber(double paramDouble) throws IOException;
/*     */   
/*     */   public abstract void writeNumber(BigDecimal paramBigDecimal) throws IOException;
/*     */   
/*     */   public abstract void writeNumber(String paramString) throws IOException;
/*     */   
/*     */   public final void serialize(Object value) throws IOException {
/* 105 */     serialize(false, value);
/*     */   }
/*     */   
/*     */   private void serialize(boolean isJsonString, Object value) throws IOException {
/* 109 */     if (value == null) {
/*     */       return;
/*     */     }
/* 112 */     Class<?> valueClass = value.getClass();
/* 113 */     if (Data.isNull(value)) {
/* 114 */       writeNull();
/* 115 */     } else if (value instanceof String) {
/* 116 */       writeString((String)value);
/* 117 */     } else if (value instanceof Number) {
/* 118 */       if (isJsonString) {
/* 119 */         writeString(value.toString());
/* 120 */       } else if (value instanceof BigDecimal) {
/* 121 */         writeNumber((BigDecimal)value);
/* 122 */       } else if (value instanceof BigInteger) {
/* 123 */         writeNumber((BigInteger)value);
/* 124 */       } else if (value instanceof Long) {
/* 125 */         writeNumber(((Long)value).longValue());
/* 126 */       } else if (value instanceof Float) {
/* 127 */         float floatValue = ((Number)value).floatValue();
/* 128 */         Preconditions.checkArgument((!Float.isInfinite(floatValue) && !Float.isNaN(floatValue)));
/* 129 */         writeNumber(floatValue);
/* 130 */       } else if (value instanceof Integer || value instanceof Short || value instanceof Byte) {
/* 131 */         writeNumber(((Number)value).intValue());
/*     */       } else {
/* 133 */         double doubleValue = ((Number)value).doubleValue();
/* 134 */         Preconditions.checkArgument((!Double.isInfinite(doubleValue) && !Double.isNaN(doubleValue)));
/* 135 */         writeNumber(doubleValue);
/*     */       } 
/* 137 */     } else if (value instanceof Boolean) {
/* 138 */       writeBoolean(((Boolean)value).booleanValue());
/* 139 */     } else if (value instanceof DateTime) {
/* 140 */       writeString(((DateTime)value).toStringRfc3339());
/* 141 */     } else if ((value instanceof Iterable || valueClass.isArray()) && !(value instanceof Map) && !(value instanceof com.google.api.client.util.GenericData)) {
/*     */ 
/*     */       
/* 144 */       writeStartArray();
/* 145 */       for (Object o : Types.iterableOf(value)) {
/* 146 */         serialize(isJsonString, o);
/*     */       }
/* 148 */       writeEndArray();
/* 149 */     } else if (valueClass.isEnum()) {
/* 150 */       String name = FieldInfo.of((Enum)value).getName();
/* 151 */       if (name == null) {
/* 152 */         writeNull();
/*     */       } else {
/* 154 */         writeString(name);
/*     */       } 
/*     */     } else {
/* 157 */       writeStartObject();
/*     */       
/* 159 */       boolean isMapNotGenericData = (value instanceof Map && !(value instanceof com.google.api.client.util.GenericData));
/* 160 */       ClassInfo classInfo = isMapNotGenericData ? null : ClassInfo.of(valueClass);
/* 161 */       for (Map.Entry<String, Object> entry : (Iterable<Map.Entry<String, Object>>)Data.mapOf(value).entrySet()) {
/* 162 */         Object fieldValue = entry.getValue();
/* 163 */         if (fieldValue != null) {
/* 164 */           boolean isJsonStringForField; String fieldName = entry.getKey();
/*     */           
/* 166 */           if (isMapNotGenericData) {
/* 167 */             isJsonStringForField = isJsonString;
/*     */           } else {
/* 169 */             Field field = classInfo.getField(fieldName);
/* 170 */             isJsonStringForField = (field != null && field.getAnnotation(JsonString.class) != null);
/*     */           } 
/* 172 */           writeFieldName(fieldName);
/* 173 */           serialize(isJsonStringForField, fieldValue);
/*     */         } 
/*     */       } 
/* 176 */       writeEndObject();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void enablePrettyPrint() throws IOException {}
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\JsonGenerator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */