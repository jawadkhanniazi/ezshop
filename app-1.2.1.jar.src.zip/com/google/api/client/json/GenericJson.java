/*    */ package com.google.api.client.json;
/*    */ 
/*    */ import com.google.api.client.util.GenericData;
/*    */ import com.google.api.client.util.Throwables;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenericJson
/*    */   extends GenericData
/*    */   implements Cloneable
/*    */ {
/*    */   private JsonFactory jsonFactory;
/*    */   
/*    */   public final JsonFactory getFactory() {
/* 47 */     return this.jsonFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setFactory(JsonFactory factory) {
/* 56 */     this.jsonFactory = factory;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 61 */     if (this.jsonFactory != null) {
/*    */       try {
/* 63 */         return this.jsonFactory.toString(this);
/* 64 */       } catch (IOException e) {
/* 65 */         throw Throwables.propagate(e);
/*    */       } 
/*    */     }
/* 68 */     return super.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toPrettyString() throws IOException {
/* 78 */     if (this.jsonFactory != null) {
/* 79 */       return this.jsonFactory.toPrettyString(this);
/*    */     }
/* 81 */     return super.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public GenericJson clone() {
/* 86 */     return (GenericJson)super.clone();
/*    */   }
/*    */ 
/*    */   
/*    */   public GenericJson set(String fieldName, Object value) {
/* 91 */     return (GenericJson)super.set(fieldName, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\GenericJson.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */