/*     */ package com.google.api.client.json;
/*     */ 
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Sets;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonObjectParser
/*     */   implements ObjectParser
/*     */ {
/*     */   private final JsonFactory jsonFactory;
/*     */   private final Set<String> wrapperKeys;
/*     */   
/*     */   public JsonObjectParser(JsonFactory jsonFactory) {
/*  58 */     this(new Builder(jsonFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonObjectParser(Builder builder) {
/*  66 */     this.jsonFactory = builder.jsonFactory;
/*  67 */     this.wrapperKeys = new HashSet<>(builder.wrapperKeys);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T parseAndClose(InputStream in, Charset charset, Class<T> dataClass) throws IOException {
/*  73 */     return (T)parseAndClose(in, charset, dataClass);
/*     */   }
/*     */   
/*     */   public Object parseAndClose(InputStream in, Charset charset, Type dataType) throws IOException {
/*  77 */     JsonParser parser = this.jsonFactory.createJsonParser(in, charset);
/*  78 */     initializeParser(parser);
/*  79 */     return parser.parse(dataType, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T parseAndClose(Reader reader, Class<T> dataClass) throws IOException {
/*  84 */     return (T)parseAndClose(reader, dataClass);
/*     */   }
/*     */   
/*     */   public Object parseAndClose(Reader reader, Type dataType) throws IOException {
/*  88 */     JsonParser parser = this.jsonFactory.createJsonParser(reader);
/*  89 */     initializeParser(parser);
/*  90 */     return parser.parse(dataType, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/*  95 */     return this.jsonFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getWrapperKeys() {
/* 104 */     return Collections.unmodifiableSet(this.wrapperKeys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeParser(JsonParser parser) throws IOException {
/* 113 */     if (this.wrapperKeys.isEmpty()) {
/*     */       return;
/*     */     }
/* 116 */     boolean failed = true;
/*     */     try {
/* 118 */       String match = parser.skipToKey(this.wrapperKeys);
/* 119 */       Preconditions.checkArgument((match != null && parser
/* 120 */           .getCurrentToken() != JsonToken.END_OBJECT), "wrapper key(s) not found: %s", new Object[] { this.wrapperKeys });
/*     */ 
/*     */       
/* 123 */       failed = false;
/*     */     } finally {
/* 125 */       if (failed) {
/* 126 */         parser.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     final JsonFactory jsonFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     Collection<String> wrapperKeys = Sets.newHashSet();
/*     */ 
/*     */     
/*     */     public Builder(JsonFactory jsonFactory) {
/* 148 */       this.jsonFactory = (JsonFactory)Preconditions.checkNotNull(jsonFactory);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonObjectParser build() {
/* 153 */       return new JsonObjectParser(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public final JsonFactory getJsonFactory() {
/* 158 */       return this.jsonFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public final Collection<String> getWrapperKeys() {
/* 163 */       return this.wrapperKeys;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setWrapperKeys(Collection<String> wrapperKeys) {
/* 173 */       this.wrapperKeys = wrapperKeys;
/* 174 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\JsonObjectParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */