/*     */ package com.google.api.client.json;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.ClassInfo;
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.FieldInfo;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Sets;
/*     */ import com.google.api.client.util.Types;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonParser
/*     */   implements Closeable
/*     */ {
/*  67 */   private static WeakHashMap<Class<?>, Field> cachedTypemapFields = new WeakHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*  71 */   private static final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonFactory getFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void close() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonToken nextToken() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonToken getCurrentToken();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getCurrentName() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonParser skipChildren() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getText() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte getByteValue() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract short getShortValue() throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getIntValue() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract float getFloatValue() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract long getLongValue() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract double getDoubleValue() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BigInteger getBigIntegerValue() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract BigDecimal getDecimalValue() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T parseAndClose(Class<T> destinationClass) throws IOException {
/* 146 */     return parseAndClose(destinationClass, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final <T> T parseAndClose(Class<T> destinationClass, CustomizeJsonParser customizeParser) throws IOException {
/*     */     try {
/* 164 */       return (T)parse((Class)destinationClass, customizeParser);
/*     */     } finally {
/* 166 */       close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void skipToKey(String keyToFind) throws IOException {
/* 181 */     skipToKey(Collections.singleton(keyToFind));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String skipToKey(Set<String> keysToFind) throws IOException {
/* 197 */     JsonToken curToken = startParsingObjectOrArray();
/* 198 */     while (curToken == JsonToken.FIELD_NAME) {
/* 199 */       String key = getText();
/* 200 */       nextToken();
/* 201 */       if (keysToFind.contains(key)) {
/* 202 */         return key;
/*     */       }
/* 204 */       skipChildren();
/* 205 */       curToken = nextToken();
/*     */     } 
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private JsonToken startParsing() throws IOException {
/* 212 */     JsonToken currentToken = getCurrentToken();
/*     */     
/* 214 */     if (currentToken == null) {
/* 215 */       currentToken = nextToken();
/*     */     }
/* 217 */     Preconditions.checkArgument((currentToken != null), "no JSON input found");
/* 218 */     return currentToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JsonToken startParsingObjectOrArray() throws IOException {
/* 232 */     JsonToken currentToken = startParsing();
/* 233 */     switch (currentToken) {
/*     */       case START_OBJECT:
/* 235 */         currentToken = nextToken();
/* 236 */         Preconditions.checkArgument((currentToken == JsonToken.FIELD_NAME || currentToken == JsonToken.END_OBJECT), currentToken);
/*     */         break;
/*     */ 
/*     */       
/*     */       case START_ARRAY:
/* 241 */         currentToken = nextToken();
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 246 */     return currentToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void parseAndClose(Object destination) throws IOException {
/* 260 */     parseAndClose(destination, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final void parseAndClose(Object destination, CustomizeJsonParser customizeParser) throws IOException {
/*     */     try {
/* 278 */       parse(destination, customizeParser);
/*     */     } finally {
/* 280 */       close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T parse(Class<T> destinationClass) throws IOException {
/* 298 */     return parse(destinationClass, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final <T> T parse(Class<T> destinationClass, CustomizeJsonParser customizeParser) throws IOException {
/* 320 */     T result = (T)parse(destinationClass, false, customizeParser);
/* 321 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object parse(Type dataType, boolean close) throws IOException {
/* 337 */     return parse(dataType, close, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public Object parse(Type dataType, boolean close, CustomizeJsonParser customizeParser) throws IOException {
/*     */     try {
/* 359 */       if (!Void.class.equals(dataType)) {
/* 360 */         startParsing();
/*     */       }
/* 362 */       return parseValue(null, dataType, new ArrayList<>(), null, customizeParser, true);
/*     */     } finally {
/* 364 */       if (close) {
/* 365 */         close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void parse(Object destination) throws IOException {
/* 381 */     parse(destination, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final void parse(Object destination, CustomizeJsonParser customizeParser) throws IOException {
/* 399 */     ArrayList<Type> context = new ArrayList<>();
/* 400 */     context.add(destination.getClass());
/* 401 */     parse(context, destination, customizeParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parse(ArrayList<Type> context, Object destination, CustomizeJsonParser customizeParser) throws IOException {
/* 415 */     if (destination instanceof GenericJson) {
/* 416 */       ((GenericJson)destination).setFactory(getFactory());
/*     */     }
/* 418 */     JsonToken curToken = startParsingObjectOrArray();
/* 419 */     Class<?> destinationClass = destination.getClass();
/* 420 */     ClassInfo classInfo = ClassInfo.of(destinationClass);
/* 421 */     boolean isGenericData = GenericData.class.isAssignableFrom(destinationClass);
/* 422 */     if (!isGenericData && Map.class.isAssignableFrom(destinationClass)) {
/*     */ 
/*     */ 
/*     */       
/* 426 */       Map<String, Object> destinationMap = (Map<String, Object>)destination;
/* 427 */       parseMap(null, destinationMap, 
/*     */ 
/*     */           
/* 430 */           Types.getMapValueParameter(destinationClass), context, customizeParser);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 435 */     while (curToken == JsonToken.FIELD_NAME) {
/* 436 */       String key = getText();
/* 437 */       nextToken();
/*     */       
/* 439 */       if (customizeParser != null && customizeParser.stopAt(destination, key)) {
/*     */         return;
/*     */       }
/*     */       
/* 443 */       FieldInfo fieldInfo = classInfo.getFieldInfo(key);
/* 444 */       if (fieldInfo != null) {
/*     */         
/* 446 */         if (fieldInfo.isFinal() && !fieldInfo.isPrimitive()) {
/* 447 */           throw new IllegalArgumentException("final array/object fields are not supported");
/*     */         }
/* 449 */         Field field = fieldInfo.getField();
/* 450 */         int contextSize = context.size();
/* 451 */         context.add(field.getGenericType());
/*     */         
/* 453 */         Object fieldValue = parseValue(field, fieldInfo
/* 454 */             .getGenericType(), context, destination, customizeParser, true);
/* 455 */         context.remove(contextSize);
/* 456 */         fieldInfo.setValue(destination, fieldValue);
/* 457 */       } else if (isGenericData) {
/*     */         
/* 459 */         GenericData object = (GenericData)destination;
/* 460 */         object.set(key, parseValue(null, null, context, destination, customizeParser, true));
/*     */       } else {
/*     */         
/* 463 */         if (customizeParser != null) {
/* 464 */           customizeParser.handleUnrecognizedKey(destination, key);
/*     */         }
/* 466 */         skipChildren();
/*     */       } 
/* 468 */       curToken = nextToken();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> Collection<T> parseArrayAndClose(Class<?> destinationCollectionClass, Class<T> destinationItemClass) throws IOException {
/* 484 */     return parseArrayAndClose(destinationCollectionClass, destinationItemClass, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final <T> Collection<T> parseArrayAndClose(Class<?> destinationCollectionClass, Class<T> destinationItemClass, CustomizeJsonParser customizeParser) throws IOException {
/*     */     try {
/* 505 */       return parseArray(destinationCollectionClass, destinationItemClass, customizeParser);
/*     */     } finally {
/* 507 */       close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> void parseArrayAndClose(Collection<? super T> destinationCollection, Class<T> destinationItemClass) throws IOException {
/* 523 */     parseArrayAndClose(destinationCollection, destinationItemClass, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final <T> void parseArrayAndClose(Collection<? super T> destinationCollection, Class<T> destinationItemClass, CustomizeJsonParser customizeParser) throws IOException {
/*     */     try {
/* 543 */       parseArray(destinationCollection, destinationItemClass, customizeParser);
/*     */     } finally {
/* 545 */       close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> Collection<T> parseArray(Class<?> destinationCollectionClass, Class<T> destinationItemClass) throws IOException {
/* 560 */     return parseArray(destinationCollectionClass, destinationItemClass, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final <T> Collection<T> parseArray(Class<?> destinationCollectionClass, Class<T> destinationItemClass, CustomizeJsonParser customizeParser) throws IOException {
/* 582 */     Collection<T> destinationCollection = Data.newCollectionInstance(destinationCollectionClass);
/* 583 */     parseArray(destinationCollection, destinationItemClass, customizeParser);
/* 584 */     return destinationCollection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> void parseArray(Collection<? super T> destinationCollection, Class<T> destinationItemClass) throws IOException {
/* 598 */     parseArray(destinationCollection, destinationItemClass, (CustomizeJsonParser)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final <T> void parseArray(Collection<? super T> destinationCollection, Class<T> destinationItemClass, CustomizeJsonParser customizeParser) throws IOException {
/* 617 */     parseArray(null, destinationCollection, destinationItemClass, new ArrayList<>(), customizeParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> void parseArray(Field fieldContext, Collection<T> destinationCollection, Type destinationItemType, ArrayList<Type> context, CustomizeJsonParser customizeParser) throws IOException {
/* 638 */     JsonToken curToken = startParsingObjectOrArray();
/* 639 */     while (curToken != JsonToken.END_ARRAY) {
/*     */ 
/*     */ 
/*     */       
/* 643 */       T parsedValue = (T)parseValue(fieldContext, destinationItemType, context, destinationCollection, customizeParser, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 650 */       destinationCollection.add(parsedValue);
/* 651 */       curToken = nextToken();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseMap(Field fieldContext, Map<String, Object> destinationMap, Type valueType, ArrayList<Type> context, CustomizeJsonParser customizeParser) throws IOException {
/* 672 */     JsonToken curToken = startParsingObjectOrArray();
/* 673 */     while (curToken == JsonToken.FIELD_NAME) {
/* 674 */       String key = getText();
/* 675 */       nextToken();
/*     */       
/* 677 */       if (customizeParser != null && customizeParser.stopAt(destinationMap, key)) {
/*     */         return;
/*     */       }
/*     */       
/* 681 */       Object value = parseValue(fieldContext, valueType, context, destinationMap, customizeParser, true);
/* 682 */       destinationMap.put(key, value);
/* 683 */       curToken = nextToken();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Object parseValue(Field fieldContext, Type valueType, ArrayList<Type> context, Object destination, CustomizeJsonParser customizeParser, boolean handlePolymorphic) throws IOException {
/* 708 */     valueType = Data.resolveWildcardTypeOrTypeVariable(context, valueType);
/*     */     
/* 710 */     Class<?> valueClass = (valueType instanceof Class) ? (Class)valueType : null;
/* 711 */     if (valueType instanceof ParameterizedType) {
/* 712 */       valueClass = Types.getRawClass((ParameterizedType)valueType);
/*     */     }
/*     */     
/* 715 */     if (valueClass == Void.class) {
/* 716 */       skipChildren();
/* 717 */       return null;
/*     */     } 
/*     */     
/* 720 */     JsonToken token = getCurrentToken(); try {
/*     */       boolean isArray; Collection<Object> collectionValue; Type subType; Field typemapField; Object newInstance; boolean isMap; int contextSize; Object typeValueObject; String typeValue; JsonPolymorphicTypeMap typeMap; Class<?> typeClass; JsonFactory factory; JsonParser parser; String text;
/* 722 */       switch (getCurrentToken()) {
/*     */         case START_ARRAY:
/*     */         case END_ARRAY:
/* 725 */           isArray = Types.isArray(valueType);
/* 726 */           Preconditions.checkArgument((valueType == null || isArray || (valueClass != null && 
/*     */ 
/*     */               
/* 729 */               Types.isAssignableToOrFrom(valueClass, Collection.class))), "expected collection or array type but got %s", new Object[] { valueType });
/*     */ 
/*     */           
/* 732 */           collectionValue = null;
/* 733 */           if (customizeParser != null && fieldContext != null) {
/* 734 */             collectionValue = customizeParser.newInstanceForArray(destination, fieldContext);
/*     */           }
/* 736 */           if (collectionValue == null) {
/* 737 */             collectionValue = Data.newCollectionInstance(valueType);
/*     */           }
/* 739 */           subType = null;
/* 740 */           if (isArray) {
/* 741 */             subType = Types.getArrayComponentType(valueType);
/* 742 */           } else if (valueClass != null && Iterable.class.isAssignableFrom(valueClass)) {
/* 743 */             subType = Types.getIterableParameter(valueType);
/*     */           } 
/* 745 */           subType = Data.resolveWildcardTypeOrTypeVariable(context, subType);
/* 746 */           parseArray(fieldContext, collectionValue, subType, context, customizeParser);
/* 747 */           if (isArray) {
/* 748 */             return Types.toArray(collectionValue, Types.getRawArrayComponentType(context, subType));
/*     */           }
/* 750 */           return collectionValue;
/*     */         case START_OBJECT:
/*     */         case FIELD_NAME:
/*     */         case END_OBJECT:
/* 754 */           Preconditions.checkArgument(
/* 755 */               !Types.isArray(valueType), "expected object or map type but got %s", new Object[] { valueType });
/*     */           
/* 757 */           typemapField = handlePolymorphic ? getCachedTypemapFieldFor(valueClass) : null;
/* 758 */           newInstance = null;
/* 759 */           if (valueClass != null && customizeParser != null) {
/* 760 */             newInstance = customizeParser.newInstanceForObject(destination, valueClass);
/*     */           }
/* 762 */           isMap = (valueClass != null && Types.isAssignableToOrFrom(valueClass, Map.class));
/* 763 */           if (typemapField != null) {
/* 764 */             newInstance = new GenericJson();
/* 765 */           } else if (newInstance == null) {
/*     */             
/* 767 */             if (isMap || valueClass == null) {
/* 768 */               newInstance = Data.newMapInstance(valueClass);
/*     */             } else {
/* 770 */               newInstance = Types.newInstance(valueClass);
/*     */             } 
/*     */           } 
/* 773 */           contextSize = context.size();
/* 774 */           if (valueType != null) {
/* 775 */             context.add(valueType);
/*     */           }
/* 777 */           if (isMap && !GenericData.class.isAssignableFrom(valueClass)) {
/*     */ 
/*     */             
/* 780 */             Type subValueType = Map.class.isAssignableFrom(valueClass) ? Types.getMapValueParameter(valueType) : null;
/*     */             
/* 782 */             if (subValueType != null) {
/*     */               
/* 784 */               Map<String, Object> destinationMap = (Map<String, Object>)newInstance;
/* 785 */               parseMap(fieldContext, destinationMap, subValueType, context, customizeParser);
/* 786 */               return newInstance;
/*     */             } 
/*     */           } 
/* 789 */           parse(context, newInstance, customizeParser);
/* 790 */           if (valueType != null) {
/* 791 */             context.remove(contextSize);
/*     */           }
/* 793 */           if (typemapField == null) {
/* 794 */             return newInstance;
/*     */           }
/*     */ 
/*     */           
/* 798 */           typeValueObject = ((GenericJson)newInstance).get(typemapField.getName());
/* 799 */           Preconditions.checkArgument((typeValueObject != null), "No value specified for @JsonPolymorphicTypeMap field");
/*     */           
/* 801 */           typeValue = typeValueObject.toString();
/* 802 */           typeMap = typemapField.<JsonPolymorphicTypeMap>getAnnotation(JsonPolymorphicTypeMap.class);
/* 803 */           typeClass = null;
/* 804 */           for (JsonPolymorphicTypeMap.TypeDef typeDefinition : typeMap.typeDefinitions()) {
/* 805 */             if (typeDefinition.key().equals(typeValue)) {
/* 806 */               typeClass = typeDefinition.ref();
/*     */               break;
/*     */             } 
/*     */           } 
/* 810 */           Preconditions.checkArgument((typeClass != null), "No TypeDef annotation found with key: " + typeValue);
/*     */           
/* 812 */           factory = getFactory();
/*     */           
/* 814 */           parser = factory.createJsonParser(factory.toString(newInstance));
/* 815 */           parser.startParsing();
/* 816 */           return parser.parseValue(fieldContext, typeClass, context, null, null, false);
/*     */         case VALUE_TRUE:
/*     */         case VALUE_FALSE:
/* 819 */           Preconditions.checkArgument((valueType == null || valueClass == boolean.class || (valueClass != null && valueClass
/*     */ 
/*     */               
/* 822 */               .isAssignableFrom(Boolean.class))), "expected type Boolean or boolean but got %s", new Object[] { valueType });
/*     */ 
/*     */           
/* 825 */           return (token == JsonToken.VALUE_TRUE) ? Boolean.TRUE : Boolean.FALSE;
/*     */         case VALUE_NUMBER_FLOAT:
/*     */         case VALUE_NUMBER_INT:
/* 828 */           Preconditions.checkArgument((fieldContext == null || fieldContext
/* 829 */               .getAnnotation(JsonString.class) == null), "number type formatted as a JSON number cannot use @JsonString annotation");
/*     */           
/* 831 */           if (valueClass == null || valueClass.isAssignableFrom(BigDecimal.class)) {
/* 832 */             return getDecimalValue();
/*     */           }
/* 834 */           if (valueClass == BigInteger.class) {
/* 835 */             return getBigIntegerValue();
/*     */           }
/* 837 */           if (valueClass == Double.class || valueClass == double.class) {
/* 838 */             return Double.valueOf(getDoubleValue());
/*     */           }
/* 840 */           if (valueClass == Long.class || valueClass == long.class) {
/* 841 */             return Long.valueOf(getLongValue());
/*     */           }
/* 843 */           if (valueClass == Float.class || valueClass == float.class) {
/* 844 */             return Float.valueOf(getFloatValue());
/*     */           }
/* 846 */           if (valueClass == Integer.class || valueClass == int.class) {
/* 847 */             return Integer.valueOf(getIntValue());
/*     */           }
/* 849 */           if (valueClass == Short.class || valueClass == short.class) {
/* 850 */             return Short.valueOf(getShortValue());
/*     */           }
/* 852 */           if (valueClass == Byte.class || valueClass == byte.class) {
/* 853 */             return Byte.valueOf(getByteValue());
/*     */           }
/* 855 */           throw new IllegalArgumentException("expected numeric type but got " + valueType);
/*     */         
/*     */         case VALUE_STRING:
/* 858 */           text = getText().trim().toLowerCase(Locale.US);
/*     */ 
/*     */ 
/*     */           
/* 862 */           if ((valueClass != float.class && valueClass != Float.class && valueClass != double.class && valueClass != Double.class) || (
/*     */             
/* 864 */             !text.equals("nan") && !text.equals("infinity") && !text.equals("-infinity"))) {
/* 865 */             Preconditions.checkArgument((valueClass == null || 
/*     */                 
/* 867 */                 !Number.class.isAssignableFrom(valueClass) || (fieldContext != null && fieldContext
/* 868 */                 .getAnnotation(JsonString.class) != null)), "number field formatted as a JSON string must use the @JsonString annotation");
/*     */           }
/*     */           
/* 871 */           return Data.parsePrimitiveValue(valueType, getText());
/*     */         case VALUE_NULL:
/* 873 */           Preconditions.checkArgument((valueClass == null || 
/* 874 */               !valueClass.isPrimitive()), "primitive number field but found a JSON null");
/*     */           
/* 876 */           if (valueClass != null && 0 != (valueClass
/* 877 */             .getModifiers() & 0x600)) {
/* 878 */             if (Types.isAssignableToOrFrom(valueClass, Collection.class)) {
/* 879 */               return Data.nullOf(Data.newCollectionInstance(valueType).getClass());
/*     */             }
/* 881 */             if (Types.isAssignableToOrFrom(valueClass, Map.class)) {
/* 882 */               return Data.nullOf(Data.newMapInstance(valueClass).getClass());
/*     */             }
/*     */           } 
/* 885 */           return Data.nullOf(Types.getRawArrayComponentType(context, valueType));
/*     */       } 
/* 887 */       throw new IllegalArgumentException("unexpected JSON node type: " + token);
/*     */     }
/* 889 */     catch (IllegalArgumentException e) {
/*     */       
/* 891 */       StringBuilder contextStringBuilder = new StringBuilder();
/* 892 */       String currentName = getCurrentName();
/* 893 */       if (currentName != null) {
/* 894 */         contextStringBuilder.append("key ").append(currentName);
/*     */       }
/* 896 */       if (fieldContext != null) {
/* 897 */         if (currentName != null) {
/* 898 */           contextStringBuilder.append(", ");
/*     */         }
/* 900 */         contextStringBuilder.append("field ").append(fieldContext);
/*     */       } 
/* 902 */       throw new IllegalArgumentException(contextStringBuilder.toString(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Field getCachedTypemapFieldFor(Class<?> key) {
/* 917 */     if (key == null) {
/* 918 */       return null;
/*     */     }
/* 920 */     lock.lock();
/*     */ 
/*     */     
/*     */     try {
/* 924 */       if (cachedTypemapFields.containsKey(key)) {
/* 925 */         return cachedTypemapFields.get(key);
/*     */       }
/*     */       
/* 928 */       Field value = null;
/* 929 */       Collection<FieldInfo> fieldInfos = ClassInfo.of(key).getFieldInfos();
/* 930 */       for (FieldInfo fieldInfo : fieldInfos) {
/* 931 */         Field field = fieldInfo.getField();
/*     */         
/* 933 */         JsonPolymorphicTypeMap typemapAnnotation = field.<JsonPolymorphicTypeMap>getAnnotation(JsonPolymorphicTypeMap.class);
/* 934 */         if (typemapAnnotation != null) {
/* 935 */           Preconditions.checkArgument((value == null), "Class contains more than one field with @JsonPolymorphicTypeMap annotation: %s", new Object[] { key });
/*     */ 
/*     */ 
/*     */           
/* 939 */           Preconditions.checkArgument(
/* 940 */               Data.isPrimitive(field.getType()), "Field which has the @JsonPolymorphicTypeMap, %s, is not a supported type: %s", new Object[] { key, field
/*     */ 
/*     */                 
/* 943 */                 .getType() });
/* 944 */           value = field;
/*     */           
/* 946 */           JsonPolymorphicTypeMap.TypeDef[] typeDefs = typemapAnnotation.typeDefinitions();
/* 947 */           HashSet<String> typeDefKeys = Sets.newHashSet();
/* 948 */           Preconditions.checkArgument((typeDefs.length > 0), "@JsonPolymorphicTypeMap must have at least one @TypeDef");
/*     */           
/* 950 */           for (JsonPolymorphicTypeMap.TypeDef typeDef : typeDefs) {
/* 951 */             Preconditions.checkArgument(typeDefKeys
/* 952 */                 .add(typeDef.key()), "Class contains two @TypeDef annotations with identical key: %s", new Object[] { typeDef
/*     */                   
/* 954 */                   .key() });
/*     */           } 
/*     */         } 
/*     */       } 
/* 958 */       cachedTypemapFields.put(key, value);
/* 959 */       return value;
/*     */     } finally {
/* 961 */       lock.unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\JsonParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */