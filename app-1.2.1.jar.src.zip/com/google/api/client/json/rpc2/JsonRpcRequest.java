/*     */ package com.google.api.client.json.rpc2;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class JsonRpcRequest
/*     */   extends GenericData
/*     */ {
/*     */   @Key
/*  34 */   private final String jsonrpc = "2.0";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Key
/*     */   private Object id;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Key
/*     */   private String method;
/*     */ 
/*     */ 
/*     */   
/*     */   @Key
/*     */   private Object params;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVersion() {
/*  57 */     return "2.0";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getId() {
/*  67 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setId(Object id) {
/*  77 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMethod() {
/*  86 */     return this.method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMethod(String method) {
/*  95 */     this.method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getParameters() {
/* 105 */     return this.params;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameters(Object parameters) {
/* 115 */     this.params = parameters;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonRpcRequest set(String fieldName, Object value) {
/* 120 */     return (JsonRpcRequest)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonRpcRequest clone() {
/* 125 */     return (JsonRpcRequest)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\json\rpc2\JsonRpcRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */