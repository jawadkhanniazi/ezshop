/*     */ package com.google.api.client.googleapis.compute;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.BearerToken;
/*     */ import com.google.api.client.auth.oauth2.Credential;
/*     */ import com.google.api.client.auth.oauth2.CredentialRefreshListener;
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.googleapis.auth.oauth2.OAuth2Utils;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonObjectParser;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class ComputeCredential
/*     */   extends Credential
/*     */ {
/*  64 */   public static final String TOKEN_SERVER_ENCODED_URL = OAuth2Utils.getMetadataServerUrl() + "/computeMetadata/v1/instance/service-accounts/default/token";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComputeCredential(HttpTransport transport, JsonFactory jsonFactory) {
/*  72 */     this(new Builder(transport, jsonFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ComputeCredential(Builder builder) {
/*  79 */     super(builder);
/*     */   }
/*     */ 
/*     */   
/*     */   protected TokenResponse executeRefreshToken() throws IOException {
/*  84 */     GenericUrl tokenUrl = new GenericUrl(getTokenServerEncodedUrl());
/*  85 */     HttpRequest request = getTransport().createRequestFactory().buildGetRequest(tokenUrl);
/*  86 */     request.setParser((ObjectParser)new JsonObjectParser(getJsonFactory()));
/*  87 */     request.getHeaders().set("Metadata-Flavor", "Google");
/*  88 */     return (TokenResponse)request.execute().parseAs(TokenResponse.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */     extends Credential.Builder
/*     */   {
/*     */     public Builder(HttpTransport transport, JsonFactory jsonFactory) {
/* 107 */       super(BearerToken.authorizationHeaderAccessMethod());
/* 108 */       setTransport(transport);
/* 109 */       setJsonFactory(jsonFactory);
/* 110 */       setTokenServerEncodedUrl(ComputeCredential.TOKEN_SERVER_ENCODED_URL);
/*     */     }
/*     */ 
/*     */     
/*     */     public ComputeCredential build() {
/* 115 */       return new ComputeCredential(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setTransport(HttpTransport transport) {
/* 120 */       return (Builder)super.setTransport((HttpTransport)Preconditions.checkNotNull(transport));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 125 */       return (Builder)super.setClock(clock);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setJsonFactory(JsonFactory jsonFactory) {
/* 130 */       return (Builder)super.setJsonFactory((JsonFactory)Preconditions.checkNotNull(jsonFactory));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 135 */       return (Builder)super.setTokenServerUrl((GenericUrl)Preconditions.checkNotNull(tokenServerUrl));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setTokenServerEncodedUrl(String tokenServerEncodedUrl) {
/* 140 */       return (Builder)super.setTokenServerEncodedUrl(
/* 141 */           (String)Preconditions.checkNotNull(tokenServerEncodedUrl));
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 146 */       Preconditions.checkArgument((clientAuthentication == null));
/* 147 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 152 */       return (Builder)super.setRequestInitializer(requestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addRefreshListener(CredentialRefreshListener refreshListener) {
/* 157 */       return (Builder)super.addRefreshListener(refreshListener);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRefreshListeners(Collection<CredentialRefreshListener> refreshListeners) {
/* 162 */       return (Builder)super.setRefreshListeners(refreshListeners);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\compute\ComputeCredential.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */