/*    */ package com.google.api.client.googleapis.util;
/*    */ 
/*    */ import com.google.api.client.http.HttpTransport;
/*    */ import com.google.api.client.http.javanet.NetHttpTransport;
/*    */ import com.google.api.client.json.JsonFactory;
/*    */ import com.google.api.client.json.jackson2.JacksonFactory;
/*    */ import com.google.api.client.util.Beta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public final class Utils
/*    */ {
/*    */   public static JsonFactory getDefaultJsonFactory() {
/* 36 */     return JsonFactoryInstanceHolder.INSTANCE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static class JsonFactoryInstanceHolder
/*    */   {
/* 44 */     static final JsonFactory INSTANCE = (JsonFactory)new JacksonFactory();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static HttpTransport getDefaultTransport() {
/* 51 */     return TransportInstanceHolder.INSTANCE;
/*    */   }
/*    */   
/*    */   private static class TransportInstanceHolder {
/* 55 */     static final HttpTransport INSTANCE = (HttpTransport)new NetHttpTransport();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapi\\util\Utils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */