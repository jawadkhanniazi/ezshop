/*     */ package com.google.api.client.googleapis;
/*     */ 
/*     */ import com.google.api.client.http.EmptyContent;
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.UrlEncodedContent;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodOverride
/*     */   implements HttpExecuteInterceptor, HttpRequestInitializer
/*     */ {
/*     */   public static final String HEADER = "X-HTTP-Method-Override";
/*     */   static final int MAX_URL_LENGTH = 2048;
/*     */   private final boolean overrideAllMethods;
/*     */   
/*     */   public MethodOverride() {
/*  81 */     this(false);
/*     */   }
/*     */   
/*     */   MethodOverride(boolean overrideAllMethods) {
/*  85 */     this.overrideAllMethods = overrideAllMethods;
/*     */   }
/*     */   
/*     */   public void initialize(HttpRequest request) {
/*  89 */     request.setInterceptor(this);
/*     */   }
/*     */   
/*     */   public void intercept(HttpRequest request) throws IOException {
/*  93 */     if (overrideThisMethod(request)) {
/*  94 */       String requestMethod = request.getRequestMethod();
/*  95 */       request.setRequestMethod("POST");
/*  96 */       request.getHeaders().set("X-HTTP-Method-Override", requestMethod);
/*  97 */       if (requestMethod.equals("GET")) {
/*     */         
/*  99 */         request.setContent((HttpContent)new UrlEncodedContent(request.getUrl().clone()));
/*     */         
/* 101 */         request.getUrl().clear();
/* 102 */       } else if (request.getContent() == null) {
/*     */         
/* 104 */         request.setContent((HttpContent)new EmptyContent());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean overrideThisMethod(HttpRequest request) throws IOException {
/* 110 */     String requestMethod = request.getRequestMethod();
/* 111 */     if (requestMethod.equals("POST")) {
/* 112 */       return false;
/*     */     }
/* 114 */     if (requestMethod.equals("GET") ? (request
/* 115 */       .getUrl().build().length() > 2048) : this.overrideAllMethods) {
/* 116 */       return true;
/*     */     }
/* 118 */     return !request.getTransport().supportsMethod(requestMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private boolean overrideAllMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodOverride build() {
/* 137 */       return new MethodOverride(this.overrideAllMethods);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean getOverrideAllMethods() {
/* 145 */       return this.overrideAllMethods;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setOverrideAllMethods(boolean overrideAllMethods) {
/* 157 */       this.overrideAllMethods = overrideAllMethods;
/* 158 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\MethodOverride.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */