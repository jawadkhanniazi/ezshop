/*     */ package com.google.api.client.googleapis.media;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpHeaders;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestFactory;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.common.base.MoreObjects;
/*     */ import com.google.common.io.ByteStreams;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MediaHttpDownloader
/*     */ {
/*     */   public static final int MAXIMUM_CHUNK_SIZE = 33554432;
/*     */   private final HttpRequestFactory requestFactory;
/*     */   private final HttpTransport transport;
/*     */   
/*     */   public enum DownloadState
/*     */   {
/*  66 */     NOT_STARTED,
/*     */ 
/*     */     
/*  69 */     MEDIA_IN_PROGRESS,
/*     */ 
/*     */     
/*  72 */     MEDIA_COMPLETE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean directDownloadEnabled = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MediaHttpDownloaderProgressListener progressListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private int chunkSize = 33554432;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long mediaContentLength;
/*     */ 
/*     */ 
/*     */   
/* 113 */   private DownloadState downloadState = DownloadState.NOT_STARTED;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long bytesDownloaded;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   private long lastBytePos = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpDownloader(HttpTransport transport, HttpRequestInitializer httpRequestInitializer) {
/* 136 */     this.transport = (HttpTransport)Preconditions.checkNotNull(transport);
/* 137 */     this
/* 138 */       .requestFactory = (httpRequestInitializer == null) ? transport.createRequestFactory() : transport.createRequestFactory(httpRequestInitializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void download(GenericUrl requestUrl, OutputStream outputStream) throws IOException {
/* 157 */     download(requestUrl, null, outputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void download(GenericUrl requestUrl, HttpHeaders requestHeaders, OutputStream outputStream) throws IOException {
/* 179 */     Preconditions.checkArgument((this.downloadState == DownloadState.NOT_STARTED));
/* 180 */     requestUrl.put("alt", "media");
/*     */     
/* 182 */     if (this.directDownloadEnabled) {
/* 183 */       updateStateAndNotifyListener(DownloadState.MEDIA_IN_PROGRESS);
/*     */       
/* 185 */       HttpResponse response = executeCurrentRequest(this.lastBytePos, requestUrl, requestHeaders, outputStream);
/*     */       
/* 187 */       this
/* 188 */         .mediaContentLength = ((Long)MoreObjects.firstNonNull(response.getHeaders().getContentLength(), Long.valueOf(this.mediaContentLength))).longValue();
/* 189 */       this.bytesDownloaded = this.mediaContentLength;
/* 190 */       updateStateAndNotifyListener(DownloadState.MEDIA_COMPLETE);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     while (true) {
/* 196 */       long currentRequestLastBytePos = this.bytesDownloaded + this.chunkSize - 1L;
/* 197 */       if (this.lastBytePos != -1L)
/*     */       {
/* 199 */         currentRequestLastBytePos = Math.min(this.lastBytePos, currentRequestLastBytePos);
/*     */       }
/* 201 */       HttpResponse response = executeCurrentRequest(currentRequestLastBytePos, requestUrl, requestHeaders, outputStream);
/*     */ 
/*     */       
/* 204 */       String contentRange = response.getHeaders().getContentRange();
/* 205 */       long nextByteIndex = getNextByteIndex(contentRange);
/* 206 */       setMediaContentLength(contentRange);
/*     */ 
/*     */       
/* 209 */       if (this.lastBytePos != -1L && this.lastBytePos <= nextByteIndex) {
/*     */         
/* 211 */         this.bytesDownloaded = this.lastBytePos;
/* 212 */         updateStateAndNotifyListener(DownloadState.MEDIA_COMPLETE);
/*     */         
/*     */         return;
/*     */       } 
/* 216 */       if (this.mediaContentLength <= nextByteIndex) {
/*     */         
/* 218 */         this.bytesDownloaded = this.mediaContentLength;
/* 219 */         updateStateAndNotifyListener(DownloadState.MEDIA_COMPLETE);
/*     */         
/*     */         return;
/*     */       } 
/* 223 */       this.bytesDownloaded = nextByteIndex;
/* 224 */       updateStateAndNotifyListener(DownloadState.MEDIA_IN_PROGRESS);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse executeCurrentRequest(long currentRequestLastBytePos, GenericUrl requestUrl, HttpHeaders requestHeaders, OutputStream outputStream) throws IOException {
/* 240 */     HttpRequest request = this.requestFactory.buildGetRequest(requestUrl);
/*     */     
/* 242 */     if (requestHeaders != null) {
/* 243 */       request.getHeaders().putAll((Map)requestHeaders);
/*     */     }
/*     */     
/* 246 */     if (this.bytesDownloaded != 0L || currentRequestLastBytePos != -1L) {
/* 247 */       StringBuilder rangeHeader = new StringBuilder();
/* 248 */       rangeHeader.append("bytes=").append(this.bytesDownloaded).append("-");
/* 249 */       if (currentRequestLastBytePos != -1L) {
/* 250 */         rangeHeader.append(currentRequestLastBytePos);
/*     */       }
/* 252 */       request.getHeaders().setRange(rangeHeader.toString());
/*     */     } 
/*     */     
/* 255 */     HttpResponse response = request.execute();
/*     */     try {
/* 257 */       ByteStreams.copy(response.getContent(), outputStream);
/*     */     } finally {
/* 259 */       response.disconnect();
/*     */     } 
/* 261 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getNextByteIndex(String rangeHeader) {
/* 273 */     if (rangeHeader == null) {
/* 274 */       return 0L;
/*     */     }
/* 276 */     return Long.parseLong(rangeHeader
/* 277 */         .substring(rangeHeader.indexOf('-') + 1, rangeHeader.indexOf('/'))) + 1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpDownloader setBytesDownloaded(long bytesDownloaded) {
/* 296 */     Preconditions.checkArgument((bytesDownloaded >= 0L));
/* 297 */     this.bytesDownloaded = bytesDownloaded;
/* 298 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpDownloader setContentRange(long firstBytePos, long lastBytePos) {
/* 314 */     Preconditions.checkArgument((lastBytePos >= firstBytePos));
/* 315 */     setBytesDownloaded(firstBytePos);
/* 316 */     this.lastBytePos = lastBytePos;
/* 317 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MediaHttpDownloader setContentRange(long firstBytePos, int lastBytePos) {
/* 325 */     return setContentRange(firstBytePos, lastBytePos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setMediaContentLength(String rangeHeader) {
/* 336 */     if (rangeHeader == null) {
/*     */       return;
/*     */     }
/* 339 */     if (this.mediaContentLength == 0L) {
/* 340 */       this.mediaContentLength = Long.parseLong(rangeHeader.substring(rangeHeader.indexOf('/') + 1));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDirectDownloadEnabled() {
/* 351 */     return this.directDownloadEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpDownloader setDirectDownloadEnabled(boolean directDownloadEnabled) {
/* 361 */     this.directDownloadEnabled = directDownloadEnabled;
/* 362 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpDownloader setProgressListener(MediaHttpDownloaderProgressListener progressListener) {
/* 370 */     this.progressListener = progressListener;
/* 371 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpDownloaderProgressListener getProgressListener() {
/* 378 */     return this.progressListener;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpTransport getTransport() {
/* 383 */     return this.transport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpDownloader setChunkSize(int chunkSize) {
/* 395 */     Preconditions.checkArgument((chunkSize > 0 && chunkSize <= 33554432));
/* 396 */     this.chunkSize = chunkSize;
/* 397 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChunkSize() {
/* 405 */     return this.chunkSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getNumBytesDownloaded() {
/* 414 */     return this.bytesDownloaded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLastBytePosition() {
/* 425 */     return this.lastBytePos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateStateAndNotifyListener(DownloadState downloadState) throws IOException {
/* 434 */     this.downloadState = downloadState;
/* 435 */     if (this.progressListener != null) {
/* 436 */       this.progressListener.progressChanged(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DownloadState getDownloadState() {
/* 446 */     return this.downloadState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getProgress() {
/* 456 */     return (this.mediaContentLength == 0L) ? 0.0D : (this.bytesDownloaded / this.mediaContentLength);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\media\MediaHttpDownloader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */