/*    */ package com.google.api.client.googleapis.media;
/*    */ 
/*    */ import com.google.api.client.http.HttpIOExceptionHandler;
/*    */ import com.google.api.client.http.HttpRequest;
/*    */ import com.google.api.client.http.HttpResponse;
/*    */ import com.google.api.client.http.HttpUnsuccessfulResponseHandler;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.Preconditions;
/*    */ import java.io.IOException;
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ class MediaUploadErrorHandler
/*    */   implements HttpUnsuccessfulResponseHandler, HttpIOExceptionHandler
/*    */ {
/* 37 */   static final Logger LOGGER = Logger.getLogger(MediaUploadErrorHandler.class.getName());
/*    */ 
/*    */ 
/*    */   
/*    */   private final MediaHttpUploader uploader;
/*    */ 
/*    */   
/*    */   private final HttpIOExceptionHandler originalIOExceptionHandler;
/*    */ 
/*    */   
/*    */   private final HttpUnsuccessfulResponseHandler originalUnsuccessfulHandler;
/*    */ 
/*    */ 
/*    */   
/*    */   public MediaUploadErrorHandler(MediaHttpUploader uploader, HttpRequest request) {
/* 52 */     this.uploader = (MediaHttpUploader)Preconditions.checkNotNull(uploader);
/* 53 */     this.originalIOExceptionHandler = request.getIOExceptionHandler();
/* 54 */     this.originalUnsuccessfulHandler = request.getUnsuccessfulResponseHandler();
/*    */     
/* 56 */     request.setIOExceptionHandler(this);
/* 57 */     request.setUnsuccessfulResponseHandler(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean handleIOException(HttpRequest request, boolean supportsRetry) throws IOException {
/* 62 */     boolean handled = (this.originalIOExceptionHandler != null && this.originalIOExceptionHandler.handleIOException(request, supportsRetry));
/*    */ 
/*    */ 
/*    */     
/* 66 */     if (handled) {
/*    */       try {
/* 68 */         this.uploader.serverErrorCallback();
/* 69 */       } catch (IOException e) {
/* 70 */         LOGGER.log(Level.WARNING, "exception thrown while calling server callback", e);
/*    */       } 
/*    */     }
/* 73 */     return handled;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleResponse(HttpRequest request, HttpResponse response, boolean supportsRetry) throws IOException {
/* 79 */     boolean handled = (this.originalUnsuccessfulHandler != null && this.originalUnsuccessfulHandler.handleResponse(request, response, supportsRetry));
/*    */ 
/*    */ 
/*    */     
/* 83 */     if (handled && supportsRetry && response.getStatusCode() / 100 == 5) {
/*    */       try {
/* 85 */         this.uploader.serverErrorCallback();
/* 86 */       } catch (IOException e) {
/* 87 */         LOGGER.log(Level.WARNING, "exception thrown while calling server callback", e);
/*    */       } 
/*    */     }
/* 90 */     return handled;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\media\MediaUploadErrorHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */