/*     */ package com.google.api.client.googleapis.media;
/*     */ 
/*     */ import com.google.api.client.googleapis.MethodOverride;
/*     */ import com.google.api.client.http.AbstractInputStreamContent;
/*     */ import com.google.api.client.http.ByteArrayContent;
/*     */ import com.google.api.client.http.EmptyContent;
/*     */ import com.google.api.client.http.GZipEncoding;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.http.HttpEncoding;
/*     */ import com.google.api.client.http.HttpHeaders;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestFactory;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.InputStreamContent;
/*     */ import com.google.api.client.http.MultipartContent;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.ByteStreams;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Sleeper;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MediaHttpUploader
/*     */ {
/*     */   public static final String CONTENT_LENGTH_HEADER = "X-Upload-Content-Length";
/*     */   public static final String CONTENT_TYPE_HEADER = "X-Upload-Content-Type";
/*     */   
/*     */   public enum UploadState
/*     */   {
/* 113 */     NOT_STARTED,
/*     */ 
/*     */     
/* 116 */     INITIATION_STARTED,
/*     */ 
/*     */     
/* 119 */     INITIATION_COMPLETE,
/*     */ 
/*     */     
/* 122 */     MEDIA_IN_PROGRESS,
/*     */ 
/*     */     
/* 125 */     MEDIA_COMPLETE;
/*     */   }
/*     */ 
/*     */   
/* 129 */   private UploadState uploadState = UploadState.NOT_STARTED;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int MB = 1048576;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int KB = 1024;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MINIMUM_CHUNK_SIZE = 262144;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_CHUNK_SIZE = 10485760;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AbstractInputStreamContent mediaContent;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpRequestFactory requestFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpTransport transport;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpContent metadata;
/*     */ 
/*     */ 
/*     */   
/*     */   private long mediaContentLength;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMediaContentLengthCalculated;
/*     */ 
/*     */ 
/*     */   
/* 181 */   private String initiationRequestMethod = "POST";
/*     */ 
/*     */   
/* 184 */   private HttpHeaders initiationHeaders = new HttpHeaders();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpRequest currentRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream contentInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean directUploadEnabled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MediaHttpUploaderProgressListener progressListener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 213 */   String mediaContentLengthStr = "*";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long totalBytesServerReceived;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   private int chunkSize = 10485760;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Byte cachedByte;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long totalBytesClientSent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int currentChunkLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] currentRequestContentBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableGZipContent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 264 */   Sleeper sleeper = Sleeper.DEFAULT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploader(AbstractInputStreamContent mediaContent, HttpTransport transport, HttpRequestInitializer httpRequestInitializer) {
/* 286 */     this.mediaContent = (AbstractInputStreamContent)Preconditions.checkNotNull(mediaContent);
/* 287 */     this.transport = (HttpTransport)Preconditions.checkNotNull(transport);
/* 288 */     this
/* 289 */       .requestFactory = (httpRequestInitializer == null) ? transport.createRequestFactory() : transport.createRequestFactory(httpRequestInitializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponse upload(GenericUrl initiationRequestUrl) throws IOException {
/* 331 */     Preconditions.checkArgument((this.uploadState == UploadState.NOT_STARTED));
/*     */     
/* 333 */     if (this.directUploadEnabled) {
/* 334 */       return directUpload(initiationRequestUrl);
/*     */     }
/* 336 */     return resumableUpload(initiationRequestUrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse directUpload(GenericUrl initiationRequestUrl) throws IOException {
/*     */     MultipartContent multipartContent;
/* 346 */     updateStateAndNotifyListener(UploadState.MEDIA_IN_PROGRESS);
/*     */     
/* 348 */     AbstractInputStreamContent abstractInputStreamContent = this.mediaContent;
/* 349 */     if (this.metadata != null) {
/* 350 */       multipartContent = (new MultipartContent()).setContentParts(Arrays.asList(new HttpContent[] { this.metadata, (HttpContent)this.mediaContent }));
/* 351 */       initiationRequestUrl.put("uploadType", "multipart");
/*     */     } else {
/* 353 */       initiationRequestUrl.put("uploadType", "media");
/*     */     } 
/*     */     
/* 356 */     HttpRequest request = this.requestFactory.buildRequest(this.initiationRequestMethod, initiationRequestUrl, (HttpContent)multipartContent);
/* 357 */     request.getHeaders().putAll((Map)this.initiationHeaders);
/*     */ 
/*     */     
/* 360 */     HttpResponse response = executeCurrentRequest(request);
/* 361 */     boolean responseProcessed = false;
/*     */     try {
/* 363 */       if (isMediaLengthKnown()) {
/* 364 */         this.totalBytesServerReceived = getMediaContentLength();
/*     */       }
/* 366 */       updateStateAndNotifyListener(UploadState.MEDIA_COMPLETE);
/* 367 */       responseProcessed = true;
/*     */     } finally {
/* 369 */       if (!responseProcessed) {
/* 370 */         response.disconnect();
/*     */       }
/*     */     } 
/* 373 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse resumableUpload(GenericUrl initiationRequestUrl) throws IOException {
/*     */     GenericUrl uploadUrl;
/* 384 */     HttpResponse initialResponse = executeUploadInitiation(initiationRequestUrl);
/* 385 */     if (!initialResponse.isSuccessStatusCode())
/*     */     {
/* 387 */       return initialResponse;
/*     */     }
/*     */     
/*     */     try {
/* 391 */       uploadUrl = new GenericUrl(initialResponse.getHeaders().getLocation());
/*     */     } finally {
/* 393 */       initialResponse.disconnect();
/*     */     } 
/*     */ 
/*     */     
/* 397 */     this.contentInputStream = this.mediaContent.getInputStream();
/* 398 */     if (!this.contentInputStream.markSupported() && isMediaLengthKnown())
/*     */     {
/*     */ 
/*     */       
/* 402 */       this.contentInputStream = new BufferedInputStream(this.contentInputStream);
/*     */     }
/*     */     
/*     */     while (true) {
/*     */       HttpResponse response;
/*     */       
/* 408 */       ContentChunk contentChunk = buildContentChunk();
/* 409 */       this.currentRequest = this.requestFactory.buildPutRequest(uploadUrl, null);
/* 410 */       this.currentRequest.setContent((HttpContent)contentChunk.getContent());
/* 411 */       this.currentRequest.getHeaders().setContentRange(contentChunk.getContentRange());
/*     */ 
/*     */ 
/*     */       
/* 415 */       new MediaUploadErrorHandler(this, this.currentRequest);
/*     */       
/* 417 */       if (isMediaLengthKnown()) {
/*     */ 
/*     */         
/* 420 */         response = executeCurrentRequestWithoutGZip(this.currentRequest);
/*     */       } else {
/* 422 */         response = executeCurrentRequest(this.currentRequest);
/*     */       } 
/* 424 */       boolean returningResponse = false;
/*     */       try {
/* 426 */         if (response.isSuccessStatusCode()) {
/* 427 */           this.totalBytesServerReceived = getMediaContentLength();
/* 428 */           if (this.mediaContent.getCloseInputStream()) {
/* 429 */             this.contentInputStream.close();
/*     */           }
/* 431 */           updateStateAndNotifyListener(UploadState.MEDIA_COMPLETE);
/* 432 */           returningResponse = true;
/* 433 */           return response;
/*     */         } 
/*     */         
/* 436 */         if (response.getStatusCode() != 308) {
/* 437 */           if (this.mediaContent.getCloseInputStream()) {
/* 438 */             this.contentInputStream.close();
/*     */           }
/* 440 */           returningResponse = true;
/* 441 */           return response;
/*     */         } 
/*     */ 
/*     */         
/* 445 */         String updatedUploadUrl = response.getHeaders().getLocation();
/* 446 */         if (updatedUploadUrl != null) {
/* 447 */           uploadUrl = new GenericUrl(updatedUploadUrl);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 452 */         long newBytesServerReceived = getNextByteIndex(response.getHeaders().getRange());
/*     */         
/* 454 */         long currentBytesServerReceived = newBytesServerReceived - this.totalBytesServerReceived;
/* 455 */         Preconditions.checkState((currentBytesServerReceived >= 0L && currentBytesServerReceived <= this.currentChunkLength));
/*     */         
/* 457 */         long copyBytes = this.currentChunkLength - currentBytesServerReceived;
/* 458 */         if (isMediaLengthKnown()) {
/* 459 */           if (copyBytes > 0L) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 465 */             this.contentInputStream.reset();
/* 466 */             long actualSkipValue = this.contentInputStream.skip(currentBytesServerReceived);
/* 467 */             Preconditions.checkState((currentBytesServerReceived == actualSkipValue));
/*     */           } 
/* 469 */         } else if (copyBytes == 0L) {
/*     */ 
/*     */ 
/*     */           
/* 473 */           this.currentRequestContentBuffer = null;
/*     */         } 
/* 475 */         this.totalBytesServerReceived = newBytesServerReceived;
/*     */         
/* 477 */         updateStateAndNotifyListener(UploadState.MEDIA_IN_PROGRESS);
/*     */       } finally {
/* 479 */         if (!returningResponse) {
/* 480 */           response.disconnect();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMediaLengthKnown() throws IOException {
/* 490 */     return (getMediaContentLength() >= 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getMediaContentLength() throws IOException {
/* 501 */     if (!this.isMediaContentLengthCalculated) {
/* 502 */       this.mediaContentLength = this.mediaContent.getLength();
/* 503 */       this.isMediaContentLengthCalculated = true;
/*     */     } 
/* 505 */     return this.mediaContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse executeUploadInitiation(GenericUrl initiationRequestUrl) throws IOException {
/* 514 */     updateStateAndNotifyListener(UploadState.INITIATION_STARTED);
/*     */     
/* 516 */     initiationRequestUrl.put("uploadType", "resumable");
/* 517 */     HttpContent content = (this.metadata == null) ? (HttpContent)new EmptyContent() : this.metadata;
/*     */     
/* 519 */     HttpRequest request = this.requestFactory.buildRequest(this.initiationRequestMethod, initiationRequestUrl, content);
/* 520 */     this.initiationHeaders.set("X-Upload-Content-Type", this.mediaContent.getType());
/* 521 */     if (isMediaLengthKnown()) {
/* 522 */       this.initiationHeaders.set("X-Upload-Content-Length", Long.valueOf(getMediaContentLength()));
/*     */     }
/* 524 */     request.getHeaders().putAll((Map)this.initiationHeaders);
/* 525 */     HttpResponse response = executeCurrentRequest(request);
/* 526 */     boolean notificationCompleted = false;
/*     */     
/*     */     try {
/* 529 */       updateStateAndNotifyListener(UploadState.INITIATION_COMPLETE);
/* 530 */       notificationCompleted = true;
/*     */     } finally {
/* 532 */       if (!notificationCompleted) {
/* 533 */         response.disconnect();
/*     */       }
/*     */     } 
/* 536 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse executeCurrentRequestWithoutGZip(HttpRequest request) throws IOException {
/* 547 */     (new MethodOverride()).intercept(request);
/*     */     
/* 549 */     request.setThrowExceptionOnExecuteError(false);
/*     */     
/* 551 */     HttpResponse response = request.execute();
/* 552 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse executeCurrentRequest(HttpRequest request) throws IOException {
/* 564 */     if (!this.disableGZipContent && !(request.getContent() instanceof EmptyContent)) {
/* 565 */       request.setEncoding((HttpEncoding)new GZipEncoding());
/*     */     }
/*     */     
/* 568 */     HttpResponse response = executeCurrentRequestWithoutGZip(request);
/* 569 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ContentChunk buildContentChunk() throws IOException {
/*     */     int blockSize;
/*     */     ByteArrayContent byteArrayContent;
/*     */     String contentRange;
/* 578 */     if (isMediaLengthKnown()) {
/*     */       
/* 580 */       blockSize = (int)Math.min(this.chunkSize, getMediaContentLength() - this.totalBytesServerReceived);
/*     */     } else {
/*     */       
/* 583 */       blockSize = this.chunkSize;
/*     */     } 
/*     */ 
/*     */     
/* 587 */     int actualBlockSize = blockSize;
/* 588 */     if (isMediaLengthKnown()) {
/*     */       
/* 590 */       this.contentInputStream.mark(blockSize);
/*     */       
/* 592 */       InputStream limitInputStream = ByteStreams.limit(this.contentInputStream, blockSize);
/*     */ 
/*     */       
/* 595 */       InputStreamContent inputStreamContent = (new InputStreamContent(this.mediaContent.getType(), limitInputStream)).setRetrySupported(true).setLength(blockSize).setCloseInputStream(false);
/* 596 */       this.mediaContentLengthStr = String.valueOf(getMediaContentLength());
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 606 */       int bytesAllowedToRead, copyBytes = 0;
/* 607 */       if (this.currentRequestContentBuffer == null) {
/* 608 */         bytesAllowedToRead = (this.cachedByte == null) ? (blockSize + 1) : blockSize;
/* 609 */         this.currentRequestContentBuffer = new byte[blockSize + 1];
/* 610 */         if (this.cachedByte != null) {
/* 611 */           this.currentRequestContentBuffer[0] = this.cachedByte.byteValue();
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 622 */         copyBytes = (int)(this.totalBytesClientSent - this.totalBytesServerReceived);
/*     */ 
/*     */         
/* 625 */         System.arraycopy(this.currentRequestContentBuffer, this.currentChunkLength - copyBytes, this.currentRequestContentBuffer, 0, copyBytes);
/*     */         
/* 627 */         if (this.cachedByte != null)
/*     */         {
/* 629 */           this.currentRequestContentBuffer[copyBytes] = this.cachedByte.byteValue();
/*     */         }
/*     */         
/* 632 */         bytesAllowedToRead = blockSize - copyBytes;
/*     */       } 
/*     */       
/* 635 */       int actualBytesRead = ByteStreams.read(this.contentInputStream, this.currentRequestContentBuffer, blockSize + 1 - bytesAllowedToRead, bytesAllowedToRead);
/*     */ 
/*     */ 
/*     */       
/* 639 */       if (actualBytesRead < bytesAllowedToRead) {
/* 640 */         actualBlockSize = copyBytes + Math.max(0, actualBytesRead);
/* 641 */         if (this.cachedByte != null) {
/* 642 */           actualBlockSize++;
/* 643 */           this.cachedByte = null;
/*     */         } 
/*     */         
/* 646 */         if (this.mediaContentLengthStr.equals("*"))
/*     */         {
/*     */           
/* 649 */           this.mediaContentLengthStr = String.valueOf(this.totalBytesServerReceived + actualBlockSize);
/*     */         }
/*     */       } else {
/* 652 */         this.cachedByte = Byte.valueOf(this.currentRequestContentBuffer[blockSize]);
/*     */       } 
/*     */ 
/*     */       
/* 656 */       byteArrayContent = new ByteArrayContent(this.mediaContent.getType(), this.currentRequestContentBuffer, 0, actualBlockSize);
/* 657 */       this.totalBytesClientSent = this.totalBytesServerReceived + actualBlockSize;
/*     */     } 
/*     */     
/* 660 */     this.currentChunkLength = actualBlockSize;
/*     */ 
/*     */     
/* 663 */     if (actualBlockSize == 0) {
/*     */ 
/*     */ 
/*     */       
/* 667 */       contentRange = "bytes */" + this.mediaContentLengthStr;
/*     */     } else {
/* 669 */       contentRange = "bytes " + this.totalBytesServerReceived + "-" + (this.totalBytesServerReceived + actualBlockSize - 1L) + "/" + this.mediaContentLengthStr;
/*     */     } 
/*     */     
/* 672 */     return new ContentChunk((AbstractInputStreamContent)byteArrayContent, contentRange);
/*     */   }
/*     */   
/*     */   private static class ContentChunk {
/*     */     private final AbstractInputStreamContent content;
/*     */     private final String contentRange;
/*     */     
/*     */     ContentChunk(AbstractInputStreamContent content, String contentRange) {
/* 680 */       this.content = content;
/* 681 */       this.contentRange = contentRange;
/*     */     }
/*     */     
/*     */     AbstractInputStreamContent getContent() {
/* 685 */       return this.content;
/*     */     }
/*     */     
/*     */     String getContentRange() {
/* 689 */       return this.contentRange;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   void serverErrorCallback() throws IOException {
/* 705 */     Preconditions.checkNotNull(this.currentRequest, "The current request should not be null");
/*     */ 
/*     */     
/* 708 */     this.currentRequest.setContent((HttpContent)new EmptyContent());
/* 709 */     this.currentRequest.getHeaders().setContentRange("bytes */" + this.mediaContentLengthStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getNextByteIndex(String rangeHeader) {
/* 721 */     if (rangeHeader == null) {
/* 722 */       return 0L;
/*     */     }
/* 724 */     return Long.parseLong(rangeHeader.substring(rangeHeader.indexOf('-') + 1)) + 1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpContent getMetadata() {
/* 729 */     return this.metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setMetadata(HttpContent metadata) {
/* 734 */     this.metadata = metadata;
/* 735 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpContent getMediaContent() {
/* 740 */     return (HttpContent)this.mediaContent;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpTransport getTransport() {
/* 745 */     return this.transport;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setDirectUploadEnabled(boolean directUploadEnabled) {
/* 771 */     this.directUploadEnabled = directUploadEnabled;
/* 772 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDirectUploadEnabled() {
/* 784 */     return this.directUploadEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setProgressListener(MediaHttpUploaderProgressListener progressListener) {
/* 791 */     this.progressListener = progressListener;
/* 792 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploaderProgressListener getProgressListener() {
/* 799 */     return this.progressListener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setChunkSize(int chunkSize) {
/* 812 */     Preconditions.checkArgument((chunkSize > 0 && chunkSize % 262144 == 0), "chunkSize must be a positive multiple of 262144.");
/*     */     
/* 814 */     this.chunkSize = chunkSize;
/* 815 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChunkSize() {
/* 823 */     return this.chunkSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDisableGZipContent() {
/* 832 */     return this.disableGZipContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setDisableGZipContent(boolean disableGZipContent) {
/* 852 */     this.disableGZipContent = disableGZipContent;
/* 853 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sleeper getSleeper() {
/* 862 */     return this.sleeper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setSleeper(Sleeper sleeper) {
/* 871 */     this.sleeper = sleeper;
/* 872 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInitiationRequestMethod() {
/* 885 */     return this.initiationRequestMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setInitiationRequestMethod(String initiationRequestMethod) {
/* 899 */     Preconditions.checkArgument((initiationRequestMethod.equals("POST") || initiationRequestMethod
/* 900 */         .equals("PUT") || initiationRequestMethod
/* 901 */         .equals("PATCH")));
/* 902 */     this.initiationRequestMethod = initiationRequestMethod;
/* 903 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaHttpUploader setInitiationHeaders(HttpHeaders initiationHeaders) {
/* 908 */     this.initiationHeaders = initiationHeaders;
/* 909 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpHeaders getInitiationHeaders() {
/* 914 */     return this.initiationHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getNumBytesUploaded() {
/* 924 */     return this.totalBytesServerReceived;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateStateAndNotifyListener(UploadState uploadState) throws IOException {
/* 933 */     this.uploadState = uploadState;
/* 934 */     if (this.progressListener != null) {
/* 935 */       this.progressListener.progressChanged(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UploadState getUploadState() {
/* 945 */     return this.uploadState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getProgress() throws IOException {
/* 962 */     Preconditions.checkArgument(isMediaLengthKnown(), "Cannot call getProgress() if the specified AbstractInputStreamContent has no content length. Use  getNumBytesUploaded() to denote progress instead.");
/*     */ 
/*     */     
/* 965 */     return (getMediaContentLength() == 0L) ? 0.0D : (this.totalBytesServerReceived / 
/* 966 */       getMediaContentLength());
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\media\MediaHttpUploader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */