/*    */ package com.google.api.client.googleapis.testing;
/*    */ 
/*    */ import com.google.common.base.Splitter;
/*    */ import com.google.common.collect.Lists;
/*    */ import java.io.IOException;
/*    */ import java.net.URLDecoder;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TestUtils
/*    */ {
/*    */   private static final String UTF_8 = "UTF-8";
/*    */   
/*    */   public static Map<String, String> parseQuery(String query) throws IOException {
/* 34 */     Map<String, String> map = new HashMap<>();
/* 35 */     Iterable<String> entries = Splitter.on('&').split(query);
/* 36 */     for (String entry : entries) {
/* 37 */       List<String> sides = Lists.newArrayList(Splitter.on('=').split(entry));
/* 38 */       if (sides.size() != 2) {
/* 39 */         throw new IOException("Invalid Query String");
/*    */       }
/* 41 */       String key = URLDecoder.decode(sides.get(0), "UTF-8");
/* 42 */       String value = URLDecoder.decode(sides.get(1), "UTF-8");
/* 43 */       map.put(key, value);
/*    */     } 
/* 45 */     return map;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\TestUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */