/*    */ package com.google.api.client.googleapis.testing.json;
/*    */ 
/*    */ import com.google.api.client.googleapis.json.GoogleJsonResponseException;
/*    */ import com.google.api.client.http.HttpRequest;
/*    */ import com.google.api.client.http.HttpResponse;
/*    */ import com.google.api.client.json.JsonFactory;
/*    */ import com.google.api.client.testing.http.HttpTesting;
/*    */ import com.google.api.client.testing.http.MockHttpTransport;
/*    */ import com.google.api.client.testing.http.MockLowLevelHttpResponse;
/*    */ import com.google.api.client.util.Beta;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public final class GoogleJsonResponseExceptionFactoryTesting
/*    */ {
/*    */   public static GoogleJsonResponseException newMock(JsonFactory jsonFactory, int httpCode, String reasonPhrase) throws IOException {
/* 62 */     MockLowLevelHttpResponse otherServiceUnavaiableLowLevelResponse = (new MockLowLevelHttpResponse()).setStatusCode(httpCode).setReasonPhrase(reasonPhrase);
/*    */ 
/*    */     
/* 65 */     MockHttpTransport otherTransport = (new MockHttpTransport.Builder()).setLowLevelHttpResponse(otherServiceUnavaiableLowLevelResponse).build();
/*    */     
/* 67 */     HttpRequest otherRequest = otherTransport.createRequestFactory().buildGetRequest(HttpTesting.SIMPLE_GENERIC_URL);
/* 68 */     otherRequest.setThrowExceptionOnExecuteError(false);
/* 69 */     HttpResponse otherServiceUnavailableResponse = otherRequest.execute();
/* 70 */     return GoogleJsonResponseException.from(jsonFactory, otherServiceUnavailableResponse);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\json\GoogleJsonResponseExceptionFactoryTesting.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */