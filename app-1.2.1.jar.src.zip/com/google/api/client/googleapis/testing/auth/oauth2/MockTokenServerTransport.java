/*     */ package com.google.api.client.googleapis.testing.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.googleapis.testing.TestUtils;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.jackson2.JacksonFactory;
/*     */ import com.google.api.client.json.webtoken.JsonWebSignature;
/*     */ import com.google.api.client.testing.http.MockHttpTransport;
/*     */ import com.google.api.client.testing.http.MockLowLevelHttpRequest;
/*     */ import com.google.api.client.testing.http.MockLowLevelHttpResponse;
/*     */ import com.google.api.client.util.Beta;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockTokenServerTransport
/*     */   extends MockHttpTransport
/*     */ {
/*     */   private static final String LEGACY_TOKEN_SERVER_URL = "https://accounts.google.com/o/oauth2/token";
/*  48 */   private static final Logger LOGGER = Logger.getLogger(MockTokenServerTransport.class.getName());
/*     */   
/*     */   static final String EXPECTED_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:jwt-bearer";
/*  51 */   static final JsonFactory JSON_FACTORY = (JsonFactory)new JacksonFactory();
/*     */   final String tokenServerUrl;
/*  53 */   Map<String, String> serviceAccounts = new HashMap<>();
/*  54 */   Map<String, String> clients = new HashMap<>();
/*  55 */   Map<String, String> refreshTokens = new HashMap<>();
/*     */   
/*     */   public MockTokenServerTransport() {
/*  58 */     this("https://oauth2.googleapis.com/token");
/*     */   }
/*     */   
/*     */   public MockTokenServerTransport(String tokenServerUrl) {
/*  62 */     this.tokenServerUrl = tokenServerUrl;
/*     */   }
/*     */   
/*     */   public void addServiceAccount(String email, String accessToken) {
/*  66 */     this.serviceAccounts.put(email, accessToken);
/*     */   }
/*     */   
/*     */   public void addClient(String clientId, String clientSecret) {
/*  70 */     this.clients.put(clientId, clientSecret);
/*     */   }
/*     */   
/*     */   public void addRefreshToken(String refreshToken, String accessTokenToReturn) {
/*  74 */     this.refreshTokens.put(refreshToken, accessTokenToReturn);
/*     */   }
/*     */ 
/*     */   
/*     */   public LowLevelHttpRequest buildRequest(String method, String url) throws IOException {
/*  79 */     if (url.equals(this.tokenServerUrl))
/*  80 */       return (LowLevelHttpRequest)buildTokenRequest(url); 
/*  81 */     if (url.equals("https://accounts.google.com/o/oauth2/token")) {
/*  82 */       LOGGER.warning("Your configured token_uri is using a legacy endpoint. You may want to redownload your credentials.");
/*     */       
/*  84 */       return (LowLevelHttpRequest)buildTokenRequest(url);
/*     */     } 
/*  86 */     return super.buildRequest(method, url);
/*     */   }
/*     */   
/*     */   private MockLowLevelHttpRequest buildTokenRequest(String url) {
/*  90 */     return new MockLowLevelHttpRequest(url)
/*     */       {
/*     */         public LowLevelHttpResponse execute() throws IOException {
/*  93 */           String content = getContentAsString();
/*  94 */           Map<String, String> query = TestUtils.parseQuery(content);
/*  95 */           String accessToken = null;
/*     */           
/*  97 */           String foundId = query.get("client_id");
/*  98 */           if (foundId != null) {
/*  99 */             if (!MockTokenServerTransport.this.clients.containsKey(foundId)) {
/* 100 */               throw new IOException("Client ID not found.");
/*     */             }
/* 102 */             String foundSecret = query.get("client_secret");
/* 103 */             String expectedSecret = MockTokenServerTransport.this.clients.get(foundId);
/* 104 */             if (foundSecret == null || !foundSecret.equals(expectedSecret)) {
/* 105 */               throw new IOException("Client secret not found.");
/*     */             }
/* 107 */             String foundRefresh = query.get("refresh_token");
/* 108 */             if (!MockTokenServerTransport.this.refreshTokens.containsKey(foundRefresh)) {
/* 109 */               throw new IOException("Refresh Token not found.");
/*     */             }
/* 111 */             accessToken = MockTokenServerTransport.this.refreshTokens.get(foundRefresh);
/* 112 */           } else if (query.containsKey("grant_type")) {
/* 113 */             String grantType = query.get("grant_type");
/* 114 */             if (!"urn:ietf:params:oauth:grant-type:jwt-bearer".equals(grantType)) {
/* 115 */               throw new IOException("Unexpected Grant Type.");
/*     */             }
/* 117 */             String assertion = query.get("assertion");
/* 118 */             JsonWebSignature signature = JsonWebSignature.parse(MockTokenServerTransport.JSON_FACTORY, assertion);
/* 119 */             String foundEmail = signature.getPayload().getIssuer();
/* 120 */             if (!MockTokenServerTransport.this.serviceAccounts.containsKey(foundEmail)) {
/* 121 */               throw new IOException("Service Account Email not found as issuer.");
/*     */             }
/* 123 */             accessToken = MockTokenServerTransport.this.serviceAccounts.get(foundEmail);
/* 124 */             String foundScopes = (String)signature.getPayload().get("scope");
/* 125 */             if (foundScopes == null || foundScopes.length() == 0) {
/* 126 */               throw new IOException("Scopes not found.");
/*     */             }
/*     */           } else {
/* 129 */             throw new IOException("Unknown token type.");
/*     */           } 
/*     */ 
/*     */           
/* 133 */           GenericJson refreshContents = new GenericJson();
/* 134 */           refreshContents.setFactory(MockTokenServerTransport.JSON_FACTORY);
/* 135 */           refreshContents.put("access_token", accessToken);
/* 136 */           refreshContents.put("expires_in", Integer.valueOf(3600));
/* 137 */           refreshContents.put("token_type", "Bearer");
/* 138 */           String refreshText = refreshContents.toPrettyString();
/*     */ 
/*     */ 
/*     */           
/* 142 */           MockLowLevelHttpResponse response = (new MockLowLevelHttpResponse()).setContentType("application/json; charset=UTF-8").setContent(refreshText);
/* 143 */           return (LowLevelHttpResponse)response;
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\auth\oauth2\MockTokenServerTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */