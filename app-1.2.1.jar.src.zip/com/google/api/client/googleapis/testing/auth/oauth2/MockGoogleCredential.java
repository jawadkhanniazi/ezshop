/*     */ package com.google.api.client.googleapis.testing.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.Credential;
/*     */ import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.jackson2.JacksonFactory;
/*     */ import com.google.api.client.testing.http.MockHttpTransport;
/*     */ import com.google.api.client.testing.http.MockLowLevelHttpRequest;
/*     */ import com.google.api.client.testing.http.MockLowLevelHttpResponse;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockGoogleCredential
/*     */   extends GoogleCredential
/*     */ {
/*     */   public static final String ACCESS_TOKEN = "access_xyz";
/*     */   public static final String REFRESH_TOKEN = "refresh123";
/*     */   private static final String EXPIRES_IN_SECONDS = "3600";
/*     */   private static final String TOKEN_TYPE = "Bearer";
/*     */   private static final String TOKEN_RESPONSE = "{\"access_token\": \"%s\", \"expires_in\":  %s, \"refresh_token\": \"%s\", \"token_type\": \"%s\"}";
/*  37 */   private static final String DEFAULT_TOKEN_RESPONSE_JSON = String.format("{\"access_token\": \"%s\", \"expires_in\":  %s, \"refresh_token\": \"%s\", \"token_type\": \"%s\"}", new Object[] { "access_xyz", "3600", "refresh123", "Bearer" });
/*     */ 
/*     */   
/*     */   public MockGoogleCredential(Builder builder) {
/*  41 */     super(builder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */     extends GoogleCredential.Builder
/*     */   {
/*     */     public Builder setTransport(HttpTransport transport) {
/*  61 */       return (Builder)super.setTransport(transport);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/*  66 */       return (Builder)super.setClientAuthentication(clientAuthentication);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setJsonFactory(JsonFactory jsonFactory) {
/*  71 */       return (Builder)super.setJsonFactory(jsonFactory);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/*  76 */       return (Builder)super.setClock(clock);
/*     */     }
/*     */ 
/*     */     
/*     */     public MockGoogleCredential build() {
/*  81 */       if (getTransport() == null) {
/*  82 */         setTransport((HttpTransport)(new MockHttpTransport.Builder()).build());
/*     */       }
/*  84 */       if (getClientAuthentication() == null) {
/*  85 */         setClientAuthentication(new MockGoogleCredential.MockClientAuthentication());
/*     */       }
/*  87 */       if (getJsonFactory() == null) {
/*  88 */         setJsonFactory((JsonFactory)new JacksonFactory());
/*     */       }
/*  90 */       return new MockGoogleCredential(this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MockHttpTransport newMockHttpTransportWithSampleTokenResponse() {
/* 107 */     MockLowLevelHttpResponse mockLowLevelHttpResponse = (new MockLowLevelHttpResponse()).setContentType("application/json; charset=UTF-8").setContent(DEFAULT_TOKEN_RESPONSE_JSON);
/*     */     
/* 109 */     MockLowLevelHttpRequest request = (new MockLowLevelHttpRequest()).setResponse(mockLowLevelHttpResponse);
/* 110 */     return (new MockHttpTransport.Builder())
/* 111 */       .setLowLevelHttpRequest(request)
/* 112 */       .build();
/*     */   }
/*     */   
/*     */   @Beta
/*     */   private static class MockClientAuthentication implements HttpExecuteInterceptor {
/*     */     private MockClientAuthentication() {}
/*     */     
/*     */     public void intercept(HttpRequest request) throws IOException {}
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\auth\oauth2\MockGoogleCredential.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */