/*     */ package com.google.api.client.googleapis.testing.compute;
/*     */ 
/*     */ import com.google.api.client.googleapis.auth.oauth2.OAuth2Utils;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.jackson2.JacksonFactory;
/*     */ import com.google.api.client.testing.http.MockHttpTransport;
/*     */ import com.google.api.client.testing.http.MockLowLevelHttpRequest;
/*     */ import com.google.api.client.testing.http.MockLowLevelHttpResponse;
/*     */ import com.google.api.client.util.Beta;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockMetadataServerTransport
/*     */   extends MockHttpTransport
/*     */ {
/*  40 */   private static final String METADATA_SERVER_URL = OAuth2Utils.getMetadataServerUrl();
/*     */   
/*  42 */   private static final String METADATA_TOKEN_SERVER_URL = METADATA_SERVER_URL + "/computeMetadata/v1/instance/service-accounts/default/token";
/*     */ 
/*     */   
/*  45 */   static final JsonFactory JSON_FACTORY = (JsonFactory)new JacksonFactory();
/*     */   
/*     */   String accessToken;
/*     */   
/*     */   Integer tokenRequestStatusCode;
/*     */   
/*     */   public MockMetadataServerTransport(String accessToken) {
/*  52 */     this.accessToken = accessToken;
/*     */   }
/*     */   
/*     */   public void setTokenRequestStatusCode(Integer tokenRequestStatusCode) {
/*  56 */     this.tokenRequestStatusCode = tokenRequestStatusCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public LowLevelHttpRequest buildRequest(String method, String url) throws IOException {
/*  61 */     if (url.equals(METADATA_TOKEN_SERVER_URL)) {
/*     */       
/*  63 */       MockLowLevelHttpRequest request = new MockLowLevelHttpRequest(url)
/*     */         {
/*     */           public LowLevelHttpResponse execute() throws IOException
/*     */           {
/*  67 */             if (MockMetadataServerTransport.this.tokenRequestStatusCode != null) {
/*     */ 
/*     */               
/*  70 */               MockLowLevelHttpResponse mockLowLevelHttpResponse = (new MockLowLevelHttpResponse()).setStatusCode(MockMetadataServerTransport.this.tokenRequestStatusCode.intValue()).setContent("Token Fetch Error");
/*  71 */               return (LowLevelHttpResponse)mockLowLevelHttpResponse;
/*     */             } 
/*     */             
/*  74 */             String metadataRequestHeader = getFirstHeaderValue("Metadata-Flavor");
/*  75 */             if (!"Google".equals(metadataRequestHeader)) {
/*  76 */               throw new IOException("Metadata request header not found.");
/*     */             }
/*     */ 
/*     */             
/*  80 */             GenericJson refreshContents = new GenericJson();
/*  81 */             refreshContents.setFactory(MockMetadataServerTransport.JSON_FACTORY);
/*  82 */             refreshContents.put("access_token", MockMetadataServerTransport.this.accessToken);
/*  83 */             refreshContents.put("expires_in", Integer.valueOf(3600000));
/*  84 */             refreshContents.put("token_type", "Bearer");
/*  85 */             String refreshText = refreshContents.toPrettyString();
/*     */ 
/*     */ 
/*     */             
/*  89 */             MockLowLevelHttpResponse response = (new MockLowLevelHttpResponse()).setContentType("application/json; charset=UTF-8").setContent(refreshText);
/*  90 */             return (LowLevelHttpResponse)response;
/*     */           }
/*     */         };
/*     */       
/*  94 */       return (LowLevelHttpRequest)request;
/*  95 */     }  if (url.equals(METADATA_SERVER_URL)) {
/*  96 */       MockLowLevelHttpRequest request = new MockLowLevelHttpRequest(url)
/*     */         {
/*     */           public LowLevelHttpResponse execute() {
/*  99 */             MockLowLevelHttpResponse response = new MockLowLevelHttpResponse();
/* 100 */             response.addHeader("Metadata-Flavor", "Google");
/* 101 */             return (LowLevelHttpResponse)response;
/*     */           }
/*     */         };
/* 104 */       return (LowLevelHttpRequest)request;
/*     */     } 
/* 106 */     return super.buildRequest(method, url);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\compute\MockMetadataServerTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */