/*     */ package com.google.api.client.googleapis.testing.services.json;
/*     */ 
/*     */ import com.google.api.client.googleapis.services.AbstractGoogleClient;
/*     */ import com.google.api.client.googleapis.services.GoogleClientRequestInitializer;
/*     */ import com.google.api.client.googleapis.services.json.AbstractGoogleJsonClient;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.Beta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockGoogleJsonClient
/*     */   extends AbstractGoogleJsonClient
/*     */ {
/*     */   protected MockGoogleJsonClient(Builder builder) {
/*  38 */     super(builder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MockGoogleJsonClient(HttpTransport transport, JsonFactory jsonFactory, String rootUrl, String servicePath, HttpRequestInitializer httpRequestInitializer, boolean legacyDataWrapper) {
/*  52 */     this(new Builder(transport, jsonFactory, rootUrl, servicePath, httpRequestInitializer, legacyDataWrapper));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */     extends AbstractGoogleJsonClient.Builder
/*     */   {
/*     */     public Builder(HttpTransport transport, JsonFactory jsonFactory, String rootUrl, String servicePath, HttpRequestInitializer httpRequestInitializer, boolean legacyDataWrapper) {
/*  78 */       super(transport, jsonFactory, rootUrl, servicePath, httpRequestInitializer, legacyDataWrapper);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public MockGoogleJsonClient build() {
/*  84 */       return new MockGoogleJsonClient(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRootUrl(String rootUrl) {
/*  89 */       return (Builder)super.setRootUrl(rootUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setServicePath(String servicePath) {
/*  94 */       return (Builder)super.setServicePath(servicePath);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setGoogleClientRequestInitializer(GoogleClientRequestInitializer googleClientRequestInitializer) {
/* 100 */       return (Builder)super.setGoogleClientRequestInitializer(googleClientRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setHttpRequestInitializer(HttpRequestInitializer httpRequestInitializer) {
/* 105 */       return (Builder)super.setHttpRequestInitializer(httpRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setApplicationName(String applicationName) {
/* 110 */       return (Builder)super.setApplicationName(applicationName);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressPatternChecks(boolean suppressPatternChecks) {
/* 115 */       return (Builder)super.setSuppressPatternChecks(suppressPatternChecks);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressRequiredParameterChecks(boolean suppressRequiredParameterChecks) {
/* 120 */       return (Builder)super.setSuppressRequiredParameterChecks(suppressRequiredParameterChecks);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressAllChecks(boolean suppressAllChecks) {
/* 125 */       return (Builder)super.setSuppressAllChecks(suppressAllChecks);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\services\json\MockGoogleJsonClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */