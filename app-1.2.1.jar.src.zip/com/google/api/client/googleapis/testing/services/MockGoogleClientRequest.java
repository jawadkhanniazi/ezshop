/*    */ package com.google.api.client.googleapis.testing.services;
/*    */ 
/*    */ import com.google.api.client.googleapis.services.AbstractGoogleClient;
/*    */ import com.google.api.client.googleapis.services.AbstractGoogleClientRequest;
/*    */ import com.google.api.client.http.HttpContent;
/*    */ import com.google.api.client.http.HttpHeaders;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.GenericData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public class MockGoogleClientRequest<T>
/*    */   extends AbstractGoogleClientRequest<T>
/*    */ {
/*    */   public MockGoogleClientRequest(AbstractGoogleClient client, String method, String uriTemplate, HttpContent content, Class<T> responseClass) {
/* 45 */     super(client, method, uriTemplate, content, responseClass);
/*    */   }
/*    */ 
/*    */   
/*    */   public MockGoogleClientRequest<T> setDisableGZipContent(boolean disableGZipContent) {
/* 50 */     return (MockGoogleClientRequest<T>)super.setDisableGZipContent(disableGZipContent);
/*    */   }
/*    */ 
/*    */   
/*    */   public MockGoogleClientRequest<T> setRequestHeaders(HttpHeaders headers) {
/* 55 */     return (MockGoogleClientRequest<T>)super.setRequestHeaders(headers);
/*    */   }
/*    */ 
/*    */   
/*    */   public MockGoogleClientRequest<T> set(String fieldName, Object value) {
/* 60 */     return (MockGoogleClientRequest<T>)super.set(fieldName, value);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\services\MockGoogleClientRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */