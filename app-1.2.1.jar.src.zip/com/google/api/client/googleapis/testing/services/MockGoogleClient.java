/*     */ package com.google.api.client.googleapis.testing.services;
/*     */ 
/*     */ import com.google.api.client.googleapis.services.AbstractGoogleClient;
/*     */ import com.google.api.client.googleapis.services.GoogleClientRequestInitializer;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class MockGoogleClient
/*     */   extends AbstractGoogleClient
/*     */ {
/*     */   public MockGoogleClient(HttpTransport transport, String rootUrl, String servicePath, ObjectParser objectParser, HttpRequestInitializer httpRequestInitializer) {
/*  43 */     this(new Builder(transport, rootUrl, servicePath, objectParser, httpRequestInitializer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MockGoogleClient(Builder builder) {
/*  52 */     super(builder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */     extends AbstractGoogleClient.Builder
/*     */   {
/*     */     public Builder(HttpTransport transport, String rootUrl, String servicePath, ObjectParser objectParser, HttpRequestInitializer httpRequestInitializer) {
/*  74 */       super(transport, rootUrl, servicePath, objectParser, httpRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public MockGoogleClient build() {
/*  79 */       return new MockGoogleClient(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRootUrl(String rootUrl) {
/*  84 */       return (Builder)super.setRootUrl(rootUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setServicePath(String servicePath) {
/*  89 */       return (Builder)super.setServicePath(servicePath);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setGoogleClientRequestInitializer(GoogleClientRequestInitializer googleClientRequestInitializer) {
/*  95 */       return (Builder)super.setGoogleClientRequestInitializer(googleClientRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setHttpRequestInitializer(HttpRequestInitializer httpRequestInitializer) {
/* 100 */       return (Builder)super.setHttpRequestInitializer(httpRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setApplicationName(String applicationName) {
/* 105 */       return (Builder)super.setApplicationName(applicationName);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressPatternChecks(boolean suppressPatternChecks) {
/* 110 */       return (Builder)super.setSuppressPatternChecks(suppressPatternChecks);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressRequiredParameterChecks(boolean suppressRequiredParameterChecks) {
/* 115 */       return (Builder)super.setSuppressRequiredParameterChecks(suppressRequiredParameterChecks);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressAllChecks(boolean suppressAllChecks) {
/* 120 */       return (Builder)super.setSuppressAllChecks(suppressAllChecks);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\testing\services\MockGoogleClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */