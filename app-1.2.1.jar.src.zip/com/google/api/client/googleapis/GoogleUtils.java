/*    */ package com.google.api.client.googleapis;
/*    */ 
/*    */ import com.google.api.client.util.SecurityUtils;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.security.GeneralSecurityException;
/*    */ import java.security.KeyStore;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GoogleUtils
/*    */ {
/* 38 */   public static final Integer MAJOR_VERSION = Integer.valueOf(1);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public static final Integer MINOR_VERSION = Integer.valueOf(26);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public static final Integer BUGFIX_VERSION = Integer.valueOf(0);
/*    */ 
/*    */ 
/*    */   
/* 56 */   public static final String VERSION = (MAJOR_VERSION + "." + MINOR_VERSION + "." + BUGFIX_VERSION + "-SNAPSHOT")
/* 57 */     .toString();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static KeyStore certTrustStore;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized KeyStore getCertificateTrustStore() throws IOException, GeneralSecurityException {
/* 73 */     if (certTrustStore == null) {
/* 74 */       certTrustStore = SecurityUtils.getJavaKeyStore();
/* 75 */       InputStream keyStoreStream = GoogleUtils.class.getResourceAsStream("google.jks");
/* 76 */       SecurityUtils.loadKeyStore(certTrustStore, keyStoreStream, "notasecret");
/*    */     } 
/* 78 */     return certTrustStore;
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\GoogleUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */