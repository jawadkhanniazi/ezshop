/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.ClientParametersAuthentication;
/*     */ import com.google.api.client.auth.oauth2.RefreshTokenRequest;
/*     */ import com.google.api.client.auth.oauth2.TokenRequest;
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleRefreshTokenRequest
/*     */   extends RefreshTokenRequest
/*     */ {
/*     */   public GoogleRefreshTokenRequest(HttpTransport transport, JsonFactory jsonFactory, String refreshToken, String clientId, String clientSecret) {
/*  86 */     super(transport, jsonFactory, new GenericUrl("https://oauth2.googleapis.com/token"), refreshToken);
/*     */     
/*  88 */     setClientAuthentication((HttpExecuteInterceptor)new ClientParametersAuthentication(clientId, clientSecret));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleRefreshTokenRequest setRequestInitializer(HttpRequestInitializer requestInitializer) {
/*  94 */     return (GoogleRefreshTokenRequest)super.setRequestInitializer(requestInitializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleRefreshTokenRequest setTokenServerUrl(GenericUrl tokenServerUrl) {
/*  99 */     return (GoogleRefreshTokenRequest)super.setTokenServerUrl(tokenServerUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleRefreshTokenRequest setScopes(Collection<String> scopes) {
/* 104 */     return (GoogleRefreshTokenRequest)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleRefreshTokenRequest setGrantType(String grantType) {
/* 109 */     return (GoogleRefreshTokenRequest)super.setGrantType(grantType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleRefreshTokenRequest setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 115 */     return (GoogleRefreshTokenRequest)super.setClientAuthentication(clientAuthentication);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleRefreshTokenRequest setRefreshToken(String refreshToken) {
/* 120 */     return (GoogleRefreshTokenRequest)super.setRefreshToken(refreshToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse execute() throws IOException {
/* 125 */     return (GoogleTokenResponse)executeUnparsed().parseAs(GoogleTokenResponse.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleRefreshTokenRequest set(String fieldName, Object value) {
/* 130 */     return (GoogleRefreshTokenRequest)super.set(fieldName, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleRefreshTokenRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */