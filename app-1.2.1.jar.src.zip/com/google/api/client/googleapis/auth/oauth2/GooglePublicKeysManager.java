/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpHeaders;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonParser;
/*     */ import com.google.api.client.json.JsonToken;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.SecurityUtils;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.PublicKey;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class GooglePublicKeysManager
/*     */ {
/*     */   private static final long REFRESH_SKEW_MILLIS = 300000L;
/*  62 */   private static final Pattern MAX_AGE_PATTERN = Pattern.compile("\\s*max-age\\s*=\\s*(\\d+)\\s*");
/*     */ 
/*     */ 
/*     */   
/*     */   private final JsonFactory jsonFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   private List<PublicKey> publicKeys;
/*     */ 
/*     */ 
/*     */   
/*     */   private long expirationTimeMilliseconds;
/*     */ 
/*     */   
/*     */   private final HttpTransport transport;
/*     */ 
/*     */   
/*  80 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Clock clock;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String publicCertsEncodedUrl;
/*     */ 
/*     */ 
/*     */   
/*     */   public GooglePublicKeysManager(HttpTransport transport, JsonFactory jsonFactory) {
/*  93 */     this(new Builder(transport, jsonFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GooglePublicKeysManager(Builder builder) {
/* 100 */     this.transport = builder.transport;
/* 101 */     this.jsonFactory = builder.jsonFactory;
/* 102 */     this.clock = builder.clock;
/* 103 */     this.publicCertsEncodedUrl = builder.publicCertsEncodedUrl;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpTransport getTransport() {
/* 108 */     return this.transport;
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/* 113 */     return this.jsonFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getPublicCertsEncodedUrl() {
/* 118 */     return this.publicCertsEncodedUrl;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Clock getClock() {
/* 123 */     return this.clock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<PublicKey> getPublicKeys() throws GeneralSecurityException, IOException {
/* 136 */     this.lock.lock();
/*     */     try {
/* 138 */       if (this.publicKeys == null || this.clock
/* 139 */         .currentTimeMillis() + 300000L > this.expirationTimeMilliseconds) {
/* 140 */         refresh();
/*     */       }
/* 142 */       return this.publicKeys;
/*     */     } finally {
/* 144 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getExpirationTimeMilliseconds() {
/* 153 */     return this.expirationTimeMilliseconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GooglePublicKeysManager refresh() throws GeneralSecurityException, IOException {
/* 166 */     this.lock.lock();
/*     */     try {
/* 168 */       this.publicKeys = new ArrayList<>();
/*     */       
/* 170 */       CertificateFactory factory = SecurityUtils.getX509CertificateFactory();
/*     */       
/* 172 */       HttpResponse certsResponse = this.transport.createRequestFactory().buildGetRequest(new GenericUrl(this.publicCertsEncodedUrl)).execute();
/* 173 */       this
/* 174 */         .expirationTimeMilliseconds = this.clock.currentTimeMillis() + getCacheTimeInSec(certsResponse.getHeaders()) * 1000L;
/*     */       
/* 176 */       JsonParser parser = this.jsonFactory.createJsonParser(certsResponse.getContent());
/* 177 */       JsonToken currentToken = parser.getCurrentToken();
/*     */       
/* 179 */       if (currentToken == null) {
/* 180 */         currentToken = parser.nextToken();
/*     */       }
/* 182 */       Preconditions.checkArgument((currentToken == JsonToken.START_OBJECT));
/*     */       try {
/* 184 */         while (parser.nextToken() != JsonToken.END_OBJECT) {
/* 185 */           parser.nextToken();
/* 186 */           String certValue = parser.getText();
/* 187 */           X509Certificate x509Cert = (X509Certificate)factory.generateCertificate(new ByteArrayInputStream(
/* 188 */                 StringUtils.getBytesUtf8(certValue)));
/* 189 */           this.publicKeys.add(x509Cert.getPublicKey());
/*     */         } 
/* 191 */         this.publicKeys = Collections.unmodifiableList(this.publicKeys);
/*     */       } finally {
/* 193 */         parser.close();
/*     */       } 
/* 195 */       return this;
/*     */     } finally {
/* 197 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getCacheTimeInSec(HttpHeaders httpHeaders) {
/* 209 */     long cacheTimeInSec = 0L;
/* 210 */     if (httpHeaders.getCacheControl() != null) {
/* 211 */       for (String arg : httpHeaders.getCacheControl().split(",")) {
/* 212 */         Matcher m = MAX_AGE_PATTERN.matcher(arg);
/* 213 */         if (m.matches()) {
/* 214 */           cacheTimeInSec = Long.parseLong(m.group(1));
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 219 */     if (httpHeaders.getAge() != null) {
/* 220 */       cacheTimeInSec -= httpHeaders.getAge().longValue();
/*     */     }
/* 222 */     return Math.max(0L, cacheTimeInSec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */   {
/* 239 */     Clock clock = Clock.SYSTEM;
/*     */ 
/*     */     
/*     */     final HttpTransport transport;
/*     */ 
/*     */     
/*     */     final JsonFactory jsonFactory;
/*     */ 
/*     */     
/* 248 */     String publicCertsEncodedUrl = "https://www.googleapis.com/oauth2/v1/certs";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(HttpTransport transport, JsonFactory jsonFactory) {
/* 257 */       this.transport = (HttpTransport)Preconditions.checkNotNull(transport);
/* 258 */       this.jsonFactory = (JsonFactory)Preconditions.checkNotNull(jsonFactory);
/*     */     }
/*     */ 
/*     */     
/*     */     public GooglePublicKeysManager build() {
/* 263 */       return new GooglePublicKeysManager(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public final HttpTransport getTransport() {
/* 268 */       return this.transport;
/*     */     }
/*     */ 
/*     */     
/*     */     public final JsonFactory getJsonFactory() {
/* 273 */       return this.jsonFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     public final String getPublicCertsEncodedUrl() {
/* 278 */       return this.publicCertsEncodedUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setPublicCertsEncodedUrl(String publicCertsEncodedUrl) {
/* 294 */       this.publicCertsEncodedUrl = (String)Preconditions.checkNotNull(publicCertsEncodedUrl);
/* 295 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final Clock getClock() {
/* 300 */       return this.clock;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 312 */       this.clock = (Clock)Preconditions.checkNotNull(clock);
/* 313 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GooglePublicKeysManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */