package com.google.api.client.googleapis.auth.oauth2;

import com.google.api.client.util.Beta;

public class GoogleOAuthConstants {
  public static final String AUTHORIZATION_SERVER_URL = "https://accounts.google.com/o/oauth2/auth";
  
  public static final String TOKEN_SERVER_URL = "https://oauth2.googleapis.com/token";
  
  @Beta
  public static final String DEFAULT_PUBLIC_CERTS_ENCODED_URL = "https://www.googleapis.com/oauth2/v1/certs";
  
  public static final String OOB_REDIRECT_URI = "urn:ietf:wg:oauth:2.0:oob";
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleOAuthConstants.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */