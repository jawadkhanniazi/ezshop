/*    */ package com.google.api.client.googleapis.auth.oauth2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SystemEnvironmentProvider
/*    */ {
/* 20 */   static final SystemEnvironmentProvider INSTANCE = new SystemEnvironmentProvider();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getEnv(String name) {
/* 26 */     return System.getenv(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean getEnvEquals(String name, String value) {
/* 33 */     return (System.getenv().containsKey(name) && System.getenv(name).equals(value));
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\SystemEnvironmentProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */