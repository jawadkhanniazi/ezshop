/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.AuthorizationRequestUrl;
/*     */ import com.google.api.client.auth.oauth2.BrowserClientRequestUrl;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleBrowserClientRequestUrl
/*     */   extends BrowserClientRequestUrl
/*     */ {
/*     */   @Key("approval_prompt")
/*     */   private String approvalPrompt;
/*     */   
/*     */   public GoogleBrowserClientRequestUrl(String clientId, String redirectUri, Collection<String> scopes) {
/*  74 */     super("https://accounts.google.com/o/oauth2/auth", clientId);
/*  75 */     setRedirectUri(redirectUri);
/*  76 */     setScopes(scopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl(GoogleClientSecrets clientSecrets, String redirectUri, Collection<String> scopes) {
/*  91 */     this(clientSecrets.getDetails().getClientId(), redirectUri, scopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getApprovalPrompt() {
/* 100 */     return this.approvalPrompt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl setApprovalPrompt(String approvalPrompt) {
/* 113 */     this.approvalPrompt = approvalPrompt;
/* 114 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl setResponseTypes(Collection<String> responseTypes) {
/* 119 */     return (GoogleBrowserClientRequestUrl)super.setResponseTypes(responseTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl setRedirectUri(String redirectUri) {
/* 124 */     return (GoogleBrowserClientRequestUrl)super.setRedirectUri(redirectUri);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl setScopes(Collection<String> scopes) {
/* 129 */     Preconditions.checkArgument(scopes.iterator().hasNext());
/* 130 */     return (GoogleBrowserClientRequestUrl)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl setClientId(String clientId) {
/* 135 */     return (GoogleBrowserClientRequestUrl)super.setClientId(clientId);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl setState(String state) {
/* 140 */     return (GoogleBrowserClientRequestUrl)super.setState(state);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl set(String fieldName, Object value) {
/* 145 */     return (GoogleBrowserClientRequestUrl)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleBrowserClientRequestUrl clone() {
/* 150 */     return (GoogleBrowserClientRequestUrl)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleBrowserClientRequestUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */