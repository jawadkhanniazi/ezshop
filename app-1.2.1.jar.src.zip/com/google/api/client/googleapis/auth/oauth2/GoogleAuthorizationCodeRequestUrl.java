/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
/*     */ import com.google.api.client.auth.oauth2.AuthorizationRequestUrl;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleAuthorizationCodeRequestUrl
/*     */   extends AuthorizationCodeRequestUrl
/*     */ {
/*     */   @Key("approval_prompt")
/*     */   private String approvalPrompt;
/*     */   @Key("access_type")
/*     */   private String accessType;
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl(String clientId, String redirectUri, Collection<String> scopes) {
/*  86 */     this("https://accounts.google.com/o/oauth2/auth", clientId, redirectUri, scopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl(String authorizationServerEncodedUrl, String clientId, String redirectUri, Collection<String> scopes) {
/* 100 */     super(authorizationServerEncodedUrl, clientId);
/* 101 */     setRedirectUri(redirectUri);
/* 102 */     setScopes(scopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl(GoogleClientSecrets clientSecrets, String redirectUri, Collection<String> scopes) {
/* 117 */     this(clientSecrets.getDetails().getClientId(), redirectUri, scopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getApprovalPrompt() {
/* 126 */     return this.approvalPrompt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl setApprovalPrompt(String approvalPrompt) {
/* 139 */     this.approvalPrompt = approvalPrompt;
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getAccessType() {
/* 148 */     return this.accessType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl setAccessType(String accessType) {
/* 161 */     this.accessType = accessType;
/* 162 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl setResponseTypes(Collection<String> responseTypes) {
/* 167 */     return (GoogleAuthorizationCodeRequestUrl)super.setResponseTypes(responseTypes);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl setRedirectUri(String redirectUri) {
/* 172 */     Preconditions.checkNotNull(redirectUri);
/* 173 */     return (GoogleAuthorizationCodeRequestUrl)super.setRedirectUri(redirectUri);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl setScopes(Collection<String> scopes) {
/* 178 */     Preconditions.checkArgument(scopes.iterator().hasNext());
/* 179 */     return (GoogleAuthorizationCodeRequestUrl)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl setClientId(String clientId) {
/* 184 */     return (GoogleAuthorizationCodeRequestUrl)super.setClientId(clientId);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl setState(String state) {
/* 189 */     return (GoogleAuthorizationCodeRequestUrl)super.setState(state);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl set(String fieldName, Object value) {
/* 194 */     return (GoogleAuthorizationCodeRequestUrl)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl clone() {
/* 199 */     return (GoogleAuthorizationCodeRequestUrl)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleAuthorizationCodeRequestUrl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */