/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonObjectParser;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessControlException;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ class DefaultCredentialProvider
/*     */   extends SystemEnvironmentProvider
/*     */ {
/*     */   static final String CREDENTIAL_ENV_VAR = "GOOGLE_APPLICATION_CREDENTIALS";
/*     */   static final String WELL_KNOWN_CREDENTIALS_FILE = "application_default_credentials.json";
/*     */   static final String CLOUDSDK_CONFIG_DIRECTORY = "gcloud";
/*     */   static final String HELP_PERMALINK = "https://developers.google.com/accounts/docs/application-default-credentials";
/*     */   static final String APP_ENGINE_CREDENTIAL_CLASS = "com.google.api.client.googleapis.extensions.appengine.auth.oauth2.AppIdentityCredential$AppEngineCredentialWrapper";
/*     */   static final String CLOUD_SHELL_ENV_VAR = "DEVSHELL_CLIENT_PORT";
/*     */   
/*     */   private enum Environment
/*     */   {
/*  64 */     UNKNOWN, ENVIRONMENT_VARIABLE, WELL_KNOWN_FILE, CLOUD_SHELL, APP_ENGINE, COMPUTE_ENGINE;
/*     */   }
/*     */ 
/*     */   
/*  68 */   private GoogleCredential cachedCredential = null;
/*  69 */   private Environment detectedEnvironment = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final GoogleCredential getDefaultCredential(HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/*  89 */     synchronized (this) {
/*  90 */       if (this.cachedCredential == null) {
/*  91 */         this.cachedCredential = getDefaultCredentialUnsynchronized(transport, jsonFactory);
/*     */       }
/*  93 */       if (this.cachedCredential != null) {
/*  94 */         return this.cachedCredential;
/*     */       }
/*     */     } 
/*     */     
/*  98 */     throw new IOException(String.format("The Application Default Credentials are not available. They are available if running on Google App Engine, Google Compute Engine, or Google Cloud Shell. Otherwise, the environment variable %s must be defined pointing to a file defining the credentials. See %s for more information.", new Object[] { "GOOGLE_APPLICATION_CREDENTIALS", "https://developers.google.com/accounts/docs/application-default-credentials" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final GoogleCredential getDefaultCredentialUnsynchronized(HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 109 */     if (this.detectedEnvironment == null) {
/* 110 */       this.detectedEnvironment = detectEnvironment(transport);
/*     */     }
/*     */     
/* 113 */     switch (this.detectedEnvironment) {
/*     */       case ENVIRONMENT_VARIABLE:
/* 115 */         return getCredentialUsingEnvironmentVariable(transport, jsonFactory);
/*     */       case WELL_KNOWN_FILE:
/* 117 */         return getCredentialUsingWellKnownFile(transport, jsonFactory);
/*     */       case APP_ENGINE:
/* 119 */         return getAppEngineCredential(transport, jsonFactory);
/*     */       case CLOUD_SHELL:
/* 121 */         return getCloudShellCredential(jsonFactory);
/*     */       case COMPUTE_ENGINE:
/* 123 */         return getComputeCredential(transport, jsonFactory);
/*     */     } 
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private final File getWellKnownCredentialsFile() {
/* 130 */     File cloudConfigPath = null;
/* 131 */     String os = getProperty("os.name", "").toLowerCase(Locale.US);
/* 132 */     if (os.indexOf("windows") >= 0) {
/* 133 */       File appDataPath = new File(getEnv("APPDATA"));
/* 134 */       cloudConfigPath = new File(appDataPath, "gcloud");
/*     */     } else {
/* 136 */       File configPath = new File(getProperty("user.home", ""), ".config");
/* 137 */       cloudConfigPath = new File(configPath, "gcloud");
/*     */     } 
/* 139 */     File credentialFilePath = new File(cloudConfigPath, "application_default_credentials.json");
/* 140 */     return credentialFilePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean fileExists(File file) {
/* 147 */     return (file.exists() && !file.isDirectory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getProperty(String property, String def) {
/* 154 */     return System.getProperty(property, def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<?> forName(String className) throws ClassNotFoundException {
/* 161 */     return Class.forName(className);
/*     */   }
/*     */ 
/*     */   
/*     */   private final Environment detectEnvironment(HttpTransport transport) throws IOException {
/* 166 */     if (runningUsingEnvironmentVariable()) {
/* 167 */       return Environment.ENVIRONMENT_VARIABLE;
/*     */     }
/*     */     
/* 170 */     if (runningUsingWellKnownFile()) {
/* 171 */       return Environment.WELL_KNOWN_FILE;
/*     */     }
/*     */     
/* 174 */     if (useGAEStandardAPI()) {
/* 175 */       return Environment.APP_ENGINE;
/*     */     }
/*     */ 
/*     */     
/* 179 */     if (runningOnCloudShell()) {
/* 180 */       return Environment.CLOUD_SHELL;
/*     */     }
/*     */     
/* 183 */     if (OAuth2Utils.runningOnComputeEngine(transport, this)) {
/* 184 */       return Environment.COMPUTE_ENGINE;
/*     */     }
/*     */     
/* 187 */     return Environment.UNKNOWN;
/*     */   }
/*     */   
/*     */   private boolean runningUsingEnvironmentVariable() throws IOException {
/* 191 */     String credentialsPath = getEnv("GOOGLE_APPLICATION_CREDENTIALS");
/* 192 */     if (credentialsPath == null || credentialsPath.length() == 0) {
/* 193 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 197 */       File credentialsFile = new File(credentialsPath);
/* 198 */       if (!credentialsFile.exists() || credentialsFile.isDirectory()) {
/* 199 */         throw new IOException(
/* 200 */             String.format("Error reading credential file from environment variable %s, value '%s': File does not exist.", new Object[] { "GOOGLE_APPLICATION_CREDENTIALS", credentialsPath }));
/*     */       }
/*     */ 
/*     */       
/* 204 */       return true;
/* 205 */     } catch (AccessControlException expected) {
/*     */       
/* 207 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private GoogleCredential getCredentialUsingEnvironmentVariable(HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 213 */     String credentialsPath = getEnv("GOOGLE_APPLICATION_CREDENTIALS");
/*     */     
/* 215 */     InputStream credentialsStream = null;
/*     */     try {
/* 217 */       credentialsStream = new FileInputStream(credentialsPath);
/* 218 */       return GoogleCredential.fromStream(credentialsStream, transport, jsonFactory);
/* 219 */     } catch (IOException e) {
/*     */ 
/*     */ 
/*     */       
/* 223 */       throw (IOException)OAuth2Utils.exceptionWithCause(new IOException(String.format("Error reading credential file from environment variable %s, value '%s': %s", new Object[] { "GOOGLE_APPLICATION_CREDENTIALS", credentialsPath, e
/*     */                 
/* 225 */                 .getMessage() })), e);
/*     */     } finally {
/* 227 */       if (credentialsStream != null) {
/* 228 */         credentialsStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean runningUsingWellKnownFile() {
/* 234 */     File wellKnownFileLocation = getWellKnownCredentialsFile();
/*     */     try {
/* 236 */       return fileExists(wellKnownFileLocation);
/* 237 */     } catch (AccessControlException expected) {
/*     */       
/* 239 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private GoogleCredential getCredentialUsingWellKnownFile(HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 245 */     File wellKnownFileLocation = getWellKnownCredentialsFile();
/* 246 */     InputStream credentialsStream = null;
/*     */     try {
/* 248 */       credentialsStream = new FileInputStream(wellKnownFileLocation);
/* 249 */       return GoogleCredential.fromStream(credentialsStream, transport, jsonFactory);
/* 250 */     } catch (IOException e) {
/* 251 */       throw new IOException(String.format("Error reading credential file from location %s: %s", new Object[] { wellKnownFileLocation, e
/*     */               
/* 253 */               .getMessage() }));
/*     */     } finally {
/* 255 */       if (credentialsStream != null) {
/* 256 */         credentialsStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean useGAEStandardAPI() {
/* 262 */     Class<?> systemPropertyClass = null;
/*     */     try {
/* 264 */       systemPropertyClass = forName("com.google.appengine.api.utils.SystemProperty");
/* 265 */     } catch (ClassNotFoundException expected) {
/*     */       
/* 267 */       return false;
/*     */     } 
/* 269 */     Exception cause = null;
/*     */     
/*     */     try {
/* 272 */       Field environmentField = systemPropertyClass.getField("environment");
/* 273 */       Object environmentValue = environmentField.get(null);
/* 274 */       Class<?> environmentType = environmentField.getType();
/* 275 */       Method valueMethod = environmentType.getMethod("value", new Class[0]);
/* 276 */       Object environmentValueValue = valueMethod.invoke(environmentValue, new Object[0]);
/* 277 */       return (environmentValueValue != null);
/* 278 */     } catch (NoSuchFieldException exception) {
/* 279 */       cause = exception;
/* 280 */     } catch (SecurityException exception) {
/* 281 */       cause = exception;
/* 282 */     } catch (IllegalArgumentException exception) {
/* 283 */       cause = exception;
/* 284 */     } catch (IllegalAccessException exception) {
/* 285 */       cause = exception;
/* 286 */     } catch (NoSuchMethodException exception) {
/* 287 */       cause = exception;
/* 288 */     } catch (InvocationTargetException exception) {
/* 289 */       cause = exception;
/*     */     } 
/* 291 */     throw (RuntimeException)OAuth2Utils.exceptionWithCause(new RuntimeException(String.format("Unexpcted error trying to determine if runnning on Google App Engine: %s", new Object[] { cause
/*     */               
/* 293 */               .getMessage() })), cause);
/*     */   }
/*     */ 
/*     */   
/*     */   private final GoogleCredential getAppEngineCredential(HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 298 */     Exception innerException = null;
/*     */     try {
/* 300 */       Class<?> credentialClass = forName("com.google.api.client.googleapis.extensions.appengine.auth.oauth2.AppIdentityCredential$AppEngineCredentialWrapper");
/*     */       
/* 302 */       Constructor<?> constructor = credentialClass.getConstructor(new Class[] { HttpTransport.class, JsonFactory.class });
/* 303 */       return (GoogleCredential)constructor.newInstance(new Object[] { transport, jsonFactory });
/* 304 */     } catch (ClassNotFoundException e) {
/* 305 */       innerException = e;
/* 306 */     } catch (NoSuchMethodException e) {
/* 307 */       innerException = e;
/* 308 */     } catch (InstantiationException e) {
/* 309 */       innerException = e;
/* 310 */     } catch (IllegalAccessException e) {
/* 311 */       innerException = e;
/* 312 */     } catch (InvocationTargetException e) {
/* 313 */       innerException = e;
/*     */     } 
/* 315 */     throw (IOException)OAuth2Utils.exceptionWithCause(new IOException(String.format("Application Default Credentials failed to create the Google App Engine service account credentials class %s. Check that the component 'google-api-client-appengine' is deployed.", new Object[] { "com.google.api.client.googleapis.extensions.appengine.auth.oauth2.AppIdentityCredential$AppEngineCredentialWrapper" })), innerException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean runningOnCloudShell() {
/* 324 */     return (getEnv("DEVSHELL_CLIENT_PORT") != null);
/*     */   }
/*     */   
/*     */   private GoogleCredential getCloudShellCredential(JsonFactory jsonFactory) {
/* 328 */     String port = getEnv("DEVSHELL_CLIENT_PORT");
/* 329 */     return new CloudShellCredential(Integer.parseInt(port), jsonFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   private final GoogleCredential getComputeCredential(HttpTransport transport, JsonFactory jsonFactory) {
/* 334 */     return new ComputeGoogleCredential(transport, jsonFactory);
/*     */   }
/*     */   
/*     */   private static class ComputeGoogleCredential
/*     */     extends GoogleCredential
/*     */   {
/* 340 */     private static final String TOKEN_SERVER_ENCODED_URL = OAuth2Utils.getMetadataServerUrl() + "/computeMetadata/v1/instance/service-accounts/default/token";
/*     */ 
/*     */     
/*     */     ComputeGoogleCredential(HttpTransport transport, JsonFactory jsonFactory) {
/* 344 */       super((new GoogleCredential.Builder())
/* 345 */           .setTransport(transport)
/* 346 */           .setJsonFactory(jsonFactory)
/* 347 */           .setTokenServerEncodedUrl(TOKEN_SERVER_ENCODED_URL));
/*     */     }
/*     */ 
/*     */     
/*     */     protected TokenResponse executeRefreshToken() throws IOException {
/* 352 */       GenericUrl tokenUrl = new GenericUrl(getTokenServerEncodedUrl());
/* 353 */       HttpRequest request = getTransport().createRequestFactory().buildGetRequest(tokenUrl);
/* 354 */       JsonObjectParser parser = new JsonObjectParser(getJsonFactory());
/* 355 */       request.setParser((ObjectParser)parser);
/* 356 */       request.getHeaders().set("Metadata-Flavor", "Google");
/* 357 */       request.setThrowExceptionOnExecuteError(false);
/* 358 */       HttpResponse response = request.execute();
/* 359 */       int statusCode = response.getStatusCode();
/* 360 */       if (statusCode == 200) {
/* 361 */         InputStream content = response.getContent();
/* 362 */         if (content == null)
/*     */         {
/*     */           
/* 365 */           throw new IOException("Empty content from metadata token server request.");
/*     */         }
/* 367 */         return (TokenResponse)parser.parseAndClose(content, response.getContentCharset(), TokenResponse.class);
/*     */       } 
/* 369 */       if (statusCode == 404)
/* 370 */         throw new IOException(String.format("Error code %s trying to get security access token from Compute Engine metadata for the default service account. This may be because the virtual machine instance does not have permission scopes specified.", new Object[] {
/*     */ 
/*     */                 
/* 373 */                 Integer.valueOf(statusCode)
/*     */               })); 
/* 375 */       throw new IOException(String.format("Unexpected Error code %s trying to get security access token from Compute Engine metadata for the default service account: %s", new Object[] {
/* 376 */               Integer.valueOf(statusCode), response
/* 377 */               .parseAsString()
/*     */             }));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\DefaultCredentialProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */