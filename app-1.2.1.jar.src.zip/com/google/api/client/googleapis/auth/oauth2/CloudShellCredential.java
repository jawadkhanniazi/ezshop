/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.Socket;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class CloudShellCredential
/*     */   extends GoogleCredential
/*     */ {
/*     */   private static final int ACCESS_TOKEN_INDEX = 2;
/*     */   private static final int READ_TIMEOUT_MS = 5000;
/*     */   protected static final String GET_AUTH_TOKEN_REQUEST = "2\n[]";
/*     */   private final int authPort;
/*     */   private final JsonFactory jsonFactory;
/*     */   
/*     */   public CloudShellCredential(int authPort, JsonFactory jsonFactory) {
/*  71 */     this.authPort = authPort;
/*  72 */     this.jsonFactory = jsonFactory;
/*     */   }
/*     */   
/*     */   protected int getAuthPort() {
/*  76 */     return this.authPort;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TokenResponse executeRefreshToken() throws IOException {
/*  82 */     Socket socket = new Socket("localhost", getAuthPort());
/*  83 */     socket.setSoTimeout(5000);
/*  84 */     TokenResponse token = new TokenResponse();
/*     */     
/*     */     try {
/*  87 */       PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
/*  88 */       out.println("2\n[]");
/*     */ 
/*     */       
/*  91 */       BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
/*     */       
/*  93 */       input.readLine();
/*     */ 
/*     */       
/*  96 */       Collection<Object> messageArray = this.jsonFactory.createJsonParser(input).parseArray(LinkedList.class, Object.class);
/*  97 */       String accessToken = ((List)messageArray).get(2).toString();
/*  98 */       token.setAccessToken(accessToken);
/*     */     } finally {
/* 100 */       socket.close();
/*     */     } 
/* 102 */     return token;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\CloudShellCredential.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */