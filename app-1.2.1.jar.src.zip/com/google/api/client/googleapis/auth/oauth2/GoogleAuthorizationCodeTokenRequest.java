/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest;
/*     */ import com.google.api.client.auth.oauth2.ClientParametersAuthentication;
/*     */ import com.google.api.client.auth.oauth2.TokenRequest;
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleAuthorizationCodeTokenRequest
/*     */   extends AuthorizationCodeTokenRequest
/*     */ {
/*     */   public GoogleAuthorizationCodeTokenRequest(HttpTransport transport, JsonFactory jsonFactory, String clientId, String clientSecret, String code, String redirectUri) {
/*  92 */     this(transport, jsonFactory, "https://oauth2.googleapis.com/token", clientId, clientSecret, code, redirectUri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest(HttpTransport transport, JsonFactory jsonFactory, String tokenServerEncodedUrl, String clientId, String clientSecret, String code, String redirectUri) {
/* 111 */     super(transport, jsonFactory, new GenericUrl(tokenServerEncodedUrl), code);
/* 112 */     setClientAuthentication((HttpExecuteInterceptor)new ClientParametersAuthentication(clientId, clientSecret));
/* 113 */     setRedirectUri(redirectUri);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 119 */     return (GoogleAuthorizationCodeTokenRequest)super.setRequestInitializer(requestInitializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 124 */     return (GoogleAuthorizationCodeTokenRequest)super.setTokenServerUrl(tokenServerUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest setScopes(Collection<String> scopes) {
/* 129 */     return (GoogleAuthorizationCodeTokenRequest)super.setScopes(scopes);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest setGrantType(String grantType) {
/* 134 */     return (GoogleAuthorizationCodeTokenRequest)super.setGrantType(grantType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 140 */     Preconditions.checkNotNull(clientAuthentication);
/* 141 */     return (GoogleAuthorizationCodeTokenRequest)super.setClientAuthentication(clientAuthentication);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest setCode(String code) {
/* 147 */     return (GoogleAuthorizationCodeTokenRequest)super.setCode(code);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest setRedirectUri(String redirectUri) {
/* 152 */     Preconditions.checkNotNull(redirectUri);
/* 153 */     return (GoogleAuthorizationCodeTokenRequest)super.setRedirectUri(redirectUri);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse execute() throws IOException {
/* 158 */     return (GoogleTokenResponse)executeUnparsed().parseAs(GoogleTokenResponse.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest set(String fieldName, Object value) {
/* 163 */     return (GoogleAuthorizationCodeTokenRequest)super.set(fieldName, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleAuthorizationCodeTokenRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */