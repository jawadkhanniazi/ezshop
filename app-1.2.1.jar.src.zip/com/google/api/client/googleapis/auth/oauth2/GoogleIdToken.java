/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.openidconnect.IdToken;
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.webtoken.JsonWebSignature;
/*     */ import com.google.api.client.json.webtoken.JsonWebToken;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class GoogleIdToken
/*     */   extends IdToken
/*     */ {
/*     */   public static GoogleIdToken parse(JsonFactory jsonFactory, String idTokenString) throws IOException {
/*  58 */     JsonWebSignature jws = JsonWebSignature.parser(jsonFactory).setPayloadClass(Payload.class).parse(idTokenString);
/*  59 */     return new GoogleIdToken(jws.getHeader(), (Payload)jws.getPayload(), jws.getSignatureBytes(), jws
/*  60 */         .getSignedContentBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleIdToken(JsonWebSignature.Header header, Payload payload, byte[] signatureBytes, byte[] signedContentBytes) {
/*  71 */     super(header, payload, signatureBytes, signedContentBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verify(GoogleIdTokenVerifier verifier) throws GeneralSecurityException, IOException {
/*  79 */     return verifier.verify(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Payload getPayload() {
/*  84 */     return (Payload)super.getPayload();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Payload
/*     */     extends IdToken.Payload
/*     */   {
/*     */     @Key("hd")
/*     */     private String hostedDomain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("email")
/*     */     private String email;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Key("email_verified")
/*     */     private Object emailVerified;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public String getUserId() {
/* 120 */       return getSubject();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Payload setUserId(String userId) {
/* 130 */       return setSubject(userId);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public String getIssuee() {
/* 140 */       return getAuthorizedParty();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Payload setIssuee(String issuee) {
/* 151 */       return setAuthorizedParty(issuee);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getHostedDomain() {
/* 159 */       return this.hostedDomain;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setHostedDomain(String hostedDomain) {
/* 167 */       this.hostedDomain = hostedDomain;
/* 168 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getEmail() {
/* 181 */       return this.email;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setEmail(String email) {
/* 194 */       this.email = email;
/* 195 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Boolean getEmailVerified() {
/* 215 */       if (this.emailVerified == null) {
/* 216 */         return null;
/*     */       }
/* 218 */       if (this.emailVerified instanceof Boolean) {
/* 219 */         return (Boolean)this.emailVerified;
/*     */       }
/*     */       
/* 222 */       return Boolean.valueOf((String)this.emailVerified);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Payload setEmailVerified(Boolean emailVerified) {
/* 241 */       this.emailVerified = emailVerified;
/* 242 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setAuthorizationTimeSeconds(Long authorizationTimeSeconds) {
/* 247 */       return (Payload)super.setAuthorizationTimeSeconds(authorizationTimeSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setAuthorizedParty(String authorizedParty) {
/* 252 */       return (Payload)super.setAuthorizedParty(authorizedParty);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setNonce(String nonce) {
/* 257 */       return (Payload)super.setNonce(nonce);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setAccessTokenHash(String accessTokenHash) {
/* 262 */       return (Payload)super.setAccessTokenHash(accessTokenHash);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setClassReference(String classReference) {
/* 267 */       return (Payload)super.setClassReference(classReference);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setMethodsReferences(List<String> methodsReferences) {
/* 272 */       return (Payload)super.setMethodsReferences(methodsReferences);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setExpirationTimeSeconds(Long expirationTimeSeconds) {
/* 277 */       return (Payload)super.setExpirationTimeSeconds(expirationTimeSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setNotBeforeTimeSeconds(Long notBeforeTimeSeconds) {
/* 282 */       return (Payload)super.setNotBeforeTimeSeconds(notBeforeTimeSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setIssuedAtTimeSeconds(Long issuedAtTimeSeconds) {
/* 287 */       return (Payload)super.setIssuedAtTimeSeconds(issuedAtTimeSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setIssuer(String issuer) {
/* 292 */       return (Payload)super.setIssuer(issuer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setAudience(Object audience) {
/* 297 */       return (Payload)super.setAudience(audience);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setJwtId(String jwtId) {
/* 302 */       return (Payload)super.setJwtId(jwtId);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setType(String type) {
/* 307 */       return (Payload)super.setType(type);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload setSubject(String subject) {
/* 312 */       return (Payload)super.setSubject(subject);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload set(String fieldName, Object value) {
/* 317 */       return (Payload)super.set(fieldName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Payload clone() {
/* 322 */       return (Payload)super.clone();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleIdToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */