/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.openidconnect.IdTokenVerifier;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.PublicKey;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class GoogleIdTokenVerifier
/*     */   extends IdTokenVerifier
/*     */ {
/*     */   private final GooglePublicKeysManager publicKeys;
/*     */   
/*     */   public GoogleIdTokenVerifier(HttpTransport transport, JsonFactory jsonFactory) {
/*  66 */     this(new Builder(transport, jsonFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleIdTokenVerifier(GooglePublicKeysManager publicKeys) {
/*  75 */     this(new Builder(publicKeys));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GoogleIdTokenVerifier(Builder builder) {
/*  84 */     super(builder);
/*  85 */     this.publicKeys = builder.publicKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GooglePublicKeysManager getPublicKeysManager() {
/*  94 */     return this.publicKeys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final HttpTransport getTransport() {
/* 103 */     return this.publicKeys.getTransport();
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/* 108 */     return this.publicKeys.getJsonFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final String getPublicCertsEncodedUrl() {
/* 120 */     return this.publicKeys.getPublicCertsEncodedUrl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final List<PublicKey> getPublicKeys() throws GeneralSecurityException, IOException {
/* 137 */     return this.publicKeys.getPublicKeys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final long getExpirationTimeMilliseconds() {
/* 149 */     return this.publicKeys.getExpirationTimeMilliseconds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verify(GoogleIdToken googleIdToken) throws GeneralSecurityException, IOException {
/* 170 */     if (!verify(googleIdToken)) {
/* 171 */       return false;
/*     */     }
/*     */     
/* 174 */     for (PublicKey publicKey : this.publicKeys.getPublicKeys()) {
/* 175 */       if (googleIdToken.verifySignature(publicKey)) {
/* 176 */         return true;
/*     */       }
/*     */     } 
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleIdToken verify(String idTokenString) throws GeneralSecurityException, IOException {
/* 191 */     GoogleIdToken idToken = GoogleIdToken.parse(getJsonFactory(), idTokenString);
/* 192 */     return verify(idToken) ? idToken : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public GoogleIdTokenVerifier loadPublicCerts() throws GeneralSecurityException, IOException {
/* 210 */     this.publicKeys.refresh();
/* 211 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static class Builder
/*     */     extends IdTokenVerifier.Builder
/*     */   {
/*     */     GooglePublicKeysManager publicKeys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(HttpTransport transport, JsonFactory jsonFactory) {
/* 235 */       this(new GooglePublicKeysManager(transport, jsonFactory));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(GooglePublicKeysManager publicKeys) {
/* 244 */       this.publicKeys = (GooglePublicKeysManager)Preconditions.checkNotNull(publicKeys);
/* 245 */       setIssuers(Arrays.asList(new String[] { "accounts.google.com", "https://accounts.google.com" }));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public GoogleIdTokenVerifier build() {
/* 251 */       return new GoogleIdTokenVerifier(this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final GooglePublicKeysManager getPublicCerts() {
/* 260 */       return this.publicKeys;
/*     */     }
/*     */ 
/*     */     
/*     */     public final HttpTransport getTransport() {
/* 265 */       return this.publicKeys.getTransport();
/*     */     }
/*     */ 
/*     */     
/*     */     public final JsonFactory getJsonFactory() {
/* 270 */       return this.publicKeys.getJsonFactory();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public final String getPublicCertsEncodedUrl() {
/* 282 */       return this.publicKeys.getPublicCertsEncodedUrl();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Builder setPublicCertsEncodedUrl(String publicKeysEncodedUrl) {
/* 304 */       this
/*     */         
/* 306 */         .publicKeys = (new GooglePublicKeysManager.Builder(getTransport(), getJsonFactory())).setPublicCertsEncodedUrl(publicKeysEncodedUrl).setClock(this.publicKeys.getClock()).build();
/* 307 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setIssuer(String issuer) {
/* 312 */       return (Builder)super.setIssuer(issuer);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setIssuers(Collection<String> issuers) {
/* 320 */       return (Builder)super.setIssuers(issuers);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setAudience(Collection<String> audience) {
/* 325 */       return (Builder)super.setAudience(audience);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setAcceptableTimeSkewSeconds(long acceptableTimeSkewSeconds) {
/* 330 */       return (Builder)super.setAcceptableTimeSkewSeconds(acceptableTimeSkewSeconds);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 335 */       return (Builder)super.setClock(clock);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleIdTokenVerifier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */