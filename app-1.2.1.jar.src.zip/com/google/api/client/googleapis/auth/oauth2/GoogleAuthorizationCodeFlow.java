/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.AuthorizationCodeFlow;
/*     */ import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
/*     */ import com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest;
/*     */ import com.google.api.client.auth.oauth2.BearerToken;
/*     */ import com.google.api.client.auth.oauth2.ClientParametersAuthentication;
/*     */ import com.google.api.client.auth.oauth2.Credential;
/*     */ import com.google.api.client.auth.oauth2.CredentialRefreshListener;
/*     */ import com.google.api.client.auth.oauth2.CredentialStore;
/*     */ import com.google.api.client.auth.oauth2.StoredCredential;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.store.DataStore;
/*     */ import com.google.api.client.util.store.DataStoreFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleAuthorizationCodeFlow
/*     */   extends AuthorizationCodeFlow
/*     */ {
/*     */   private final String approvalPrompt;
/*     */   private final String accessType;
/*     */   
/*     */   public GoogleAuthorizationCodeFlow(HttpTransport transport, JsonFactory jsonFactory, String clientId, String clientSecret, Collection<String> scopes) {
/*  96 */     this(new Builder(transport, jsonFactory, clientId, clientSecret, scopes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GoogleAuthorizationCodeFlow(Builder builder) {
/* 105 */     super(builder);
/* 106 */     this.accessType = builder.accessType;
/* 107 */     this.approvalPrompt = builder.approvalPrompt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeTokenRequest newTokenRequest(String authorizationCode) {
/* 114 */     return (new GoogleAuthorizationCodeTokenRequest(getTransport(), getJsonFactory(), 
/* 115 */         getTokenServerEncodedUrl(), "", "", authorizationCode, "")).setClientAuthentication(
/* 116 */         getClientAuthentication())
/* 117 */       .setRequestInitializer(getRequestInitializer()).setScopes(getScopes());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleAuthorizationCodeRequestUrl newAuthorizationUrl() {
/* 123 */     return (new GoogleAuthorizationCodeRequestUrl(
/* 124 */         getAuthorizationServerEncodedUrl(), getClientId(), "", getScopes())).setAccessType(this.accessType)
/* 125 */       .setApprovalPrompt(this.approvalPrompt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getApprovalPrompt() {
/* 134 */     return this.approvalPrompt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getAccessType() {
/* 142 */     return this.accessType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     extends AuthorizationCodeFlow.Builder
/*     */   {
/*     */     String approvalPrompt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String accessType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(HttpTransport transport, JsonFactory jsonFactory, String clientId, String clientSecret, Collection<String> scopes) {
/* 179 */       super(BearerToken.authorizationHeaderAccessMethod(), transport, jsonFactory, new GenericUrl("https://oauth2.googleapis.com/token"), (HttpExecuteInterceptor)new ClientParametersAuthentication(clientId, clientSecret), clientId, "https://accounts.google.com/o/oauth2/auth");
/*     */ 
/*     */       
/* 182 */       setScopes(scopes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(HttpTransport transport, JsonFactory jsonFactory, GoogleClientSecrets clientSecrets, Collection<String> scopes) {
/* 195 */       super(BearerToken.authorizationHeaderAccessMethod(), transport, jsonFactory, new GenericUrl("https://oauth2.googleapis.com/token"), (HttpExecuteInterceptor)new ClientParametersAuthentication(clientSecrets
/*     */             
/* 197 */             .getDetails().getClientId(), clientSecrets.getDetails().getClientSecret()), clientSecrets
/* 198 */           .getDetails().getClientId(), "https://accounts.google.com/o/oauth2/auth");
/* 199 */       setScopes(scopes);
/*     */     }
/*     */ 
/*     */     
/*     */     public GoogleAuthorizationCodeFlow build() {
/* 204 */       return new GoogleAuthorizationCodeFlow(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setDataStoreFactory(DataStoreFactory dataStore) throws IOException {
/* 209 */       return (Builder)super.setDataStoreFactory(dataStore);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setCredentialDataStore(DataStore<StoredCredential> typedDataStore) {
/* 214 */       return (Builder)super.setCredentialDataStore(typedDataStore);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setCredentialCreatedListener(AuthorizationCodeFlow.CredentialCreatedListener credentialCreatedListener) {
/* 220 */       return (Builder)super.setCredentialCreatedListener(credentialCreatedListener);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     @Beta
/*     */     public Builder setCredentialStore(CredentialStore credentialStore) {
/* 227 */       return (Builder)super.setCredentialStore(credentialStore);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 232 */       return (Builder)super.setRequestInitializer(requestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setScopes(Collection<String> scopes) {
/* 237 */       Preconditions.checkState(!scopes.isEmpty());
/* 238 */       return (Builder)super.setScopes(scopes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setMethod(Credential.AccessMethod method) {
/* 246 */       return (Builder)super.setMethod(method);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setTransport(HttpTransport transport) {
/* 254 */       return (Builder)super.setTransport(transport);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setJsonFactory(JsonFactory jsonFactory) {
/* 262 */       return (Builder)super.setJsonFactory(jsonFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 270 */       return (Builder)super.setTokenServerUrl(tokenServerUrl);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 278 */       return (Builder)super.setClientAuthentication(clientAuthentication);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClientId(String clientId) {
/* 286 */       return (Builder)super.setClientId(clientId);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setAuthorizationServerEncodedUrl(String authorizationServerEncodedUrl) {
/* 294 */       return (Builder)super.setAuthorizationServerEncodedUrl(authorizationServerEncodedUrl);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 302 */       return (Builder)super.setClock(clock);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addRefreshListener(CredentialRefreshListener refreshListener) {
/* 307 */       return (Builder)super.addRefreshListener(refreshListener);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRefreshListeners(Collection<CredentialRefreshListener> refreshListeners) {
/* 312 */       return (Builder)super.setRefreshListeners(refreshListeners);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setApprovalPrompt(String approvalPrompt) {
/* 330 */       this.approvalPrompt = approvalPrompt;
/* 331 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getApprovalPrompt() {
/* 340 */       return this.approvalPrompt;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setAccessType(String accessType) {
/* 358 */       this.accessType = accessType;
/* 359 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getAccessType() {
/* 367 */       return this.accessType;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleAuthorizationCodeFlow.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */