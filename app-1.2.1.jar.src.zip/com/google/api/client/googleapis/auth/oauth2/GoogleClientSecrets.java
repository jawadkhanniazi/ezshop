/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GoogleClientSecrets
/*     */   extends GenericJson
/*     */ {
/*     */   @Key
/*     */   private Details installed;
/*     */   @Key
/*     */   private Details web;
/*     */   
/*     */   public Details getInstalled() {
/*  59 */     return this.installed;
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleClientSecrets setInstalled(Details installed) {
/*  64 */     this.installed = installed;
/*  65 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Details getWeb() {
/*  70 */     return this.web;
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleClientSecrets setWeb(Details web) {
/*  75 */     this.web = web;
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Details getDetails() {
/*  82 */     Preconditions.checkArgument((((this.web == null) ? true : false) != ((this.installed == null) ? true : false)));
/*  83 */     return (this.web == null) ? this.installed : this.web;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Details
/*     */     extends GenericJson
/*     */   {
/*     */     @Key("client_id")
/*     */     private String clientId;
/*     */ 
/*     */     
/*     */     @Key("client_secret")
/*     */     private String clientSecret;
/*     */ 
/*     */     
/*     */     @Key("redirect_uris")
/*     */     private List<String> redirectUris;
/*     */ 
/*     */     
/*     */     @Key("auth_uri")
/*     */     private String authUri;
/*     */     
/*     */     @Key("token_uri")
/*     */     private String tokenUri;
/*     */ 
/*     */     
/*     */     public String getClientId() {
/* 111 */       return this.clientId;
/*     */     }
/*     */ 
/*     */     
/*     */     public Details setClientId(String clientId) {
/* 116 */       this.clientId = clientId;
/* 117 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getClientSecret() {
/* 122 */       return this.clientSecret;
/*     */     }
/*     */ 
/*     */     
/*     */     public Details setClientSecret(String clientSecret) {
/* 127 */       this.clientSecret = clientSecret;
/* 128 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public List<String> getRedirectUris() {
/* 133 */       return this.redirectUris;
/*     */     }
/*     */ 
/*     */     
/*     */     public Details setRedirectUris(List<String> redirectUris) {
/* 138 */       this.redirectUris = redirectUris;
/* 139 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getAuthUri() {
/* 144 */       return this.authUri;
/*     */     }
/*     */ 
/*     */     
/*     */     public Details setAuthUri(String authUri) {
/* 149 */       this.authUri = authUri;
/* 150 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getTokenUri() {
/* 155 */       return this.tokenUri;
/*     */     }
/*     */ 
/*     */     
/*     */     public Details setTokenUri(String tokenUri) {
/* 160 */       this.tokenUri = tokenUri;
/* 161 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Details set(String fieldName, Object value) {
/* 166 */       return (Details)super.set(fieldName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Details clone() {
/* 171 */       return (Details)super.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleClientSecrets set(String fieldName, Object value) {
/* 177 */     return (GoogleClientSecrets)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleClientSecrets clone() {
/* 182 */     return (GoogleClientSecrets)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GoogleClientSecrets load(JsonFactory jsonFactory, Reader reader) throws IOException {
/* 192 */     return (GoogleClientSecrets)jsonFactory.fromReader(reader, GoogleClientSecrets.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleClientSecrets.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */