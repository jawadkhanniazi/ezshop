/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleTokenResponse
/*     */   extends TokenResponse
/*     */ {
/*     */   @Key("id_token")
/*     */   private String idToken;
/*     */   
/*     */   public GoogleTokenResponse setAccessToken(String accessToken) {
/*  52 */     return (GoogleTokenResponse)super.setAccessToken(accessToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse setTokenType(String tokenType) {
/*  57 */     return (GoogleTokenResponse)super.setTokenType(tokenType);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse setExpiresInSeconds(Long expiresIn) {
/*  62 */     return (GoogleTokenResponse)super.setExpiresInSeconds(expiresIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse setRefreshToken(String refreshToken) {
/*  67 */     return (GoogleTokenResponse)super.setRefreshToken(refreshToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse setScope(String scope) {
/*  72 */     return (GoogleTokenResponse)super.setScope(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final String getIdToken() {
/*  81 */     return this.idToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public GoogleTokenResponse setIdToken(String idToken) {
/*  95 */     this.idToken = (String)Preconditions.checkNotNull(idToken);
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public GoogleIdToken parseIdToken() throws IOException {
/* 106 */     return GoogleIdToken.parse(getFactory(), getIdToken());
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse set(String fieldName, Object value) {
/* 111 */     return (GoogleTokenResponse)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleTokenResponse clone() {
/* 116 */     return (GoogleTokenResponse)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleTokenResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */