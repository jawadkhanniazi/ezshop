/*     */ package com.google.api.client.googleapis.auth.oauth2;
/*     */ 
/*     */ import com.google.api.client.auth.oauth2.BearerToken;
/*     */ import com.google.api.client.auth.oauth2.ClientParametersAuthentication;
/*     */ import com.google.api.client.auth.oauth2.Credential;
/*     */ import com.google.api.client.auth.oauth2.CredentialRefreshListener;
/*     */ import com.google.api.client.auth.oauth2.TokenRequest;
/*     */ import com.google.api.client.auth.oauth2.TokenResponse;
/*     */ import com.google.api.client.googleapis.util.Utils;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonObjectParser;
/*     */ import com.google.api.client.json.webtoken.JsonWebSignature;
/*     */ import com.google.api.client.json.webtoken.JsonWebToken;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Clock;
/*     */ import com.google.api.client.util.Joiner;
/*     */ import com.google.api.client.util.PemReader;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.SecurityUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class GoogleCredential
/*     */   extends Credential
/*     */ {
/*     */   static final String USER_FILE_TYPE = "authorized_user";
/*     */   static final String SERVICE_ACCOUNT_FILE_TYPE = "service_account";
/*     */   @Beta
/* 178 */   private static DefaultCredentialProvider defaultCredentialProvider = new DefaultCredentialProvider();
/*     */   
/*     */   private String serviceAccountId;
/*     */   
/*     */   private String serviceAccountProjectId;
/*     */   
/*     */   private Collection<String> serviceAccountScopes;
/*     */   
/*     */   private PrivateKey serviceAccountPrivateKey;
/*     */   
/*     */   private String serviceAccountPrivateKeyId;
/*     */   
/*     */   private String serviceAccountUser;
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static GoogleCredential getApplicationDefault() throws IOException {
/* 195 */     return getApplicationDefault(Utils.getDefaultTransport(), Utils.getDefaultJsonFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static GoogleCredential getApplicationDefault(HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 215 */     Preconditions.checkNotNull(transport);
/* 216 */     Preconditions.checkNotNull(jsonFactory);
/* 217 */     return defaultCredentialProvider.getDefaultCredential(transport, jsonFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static GoogleCredential fromStream(InputStream credentialStream) throws IOException {
/* 230 */     return fromStream(credentialStream, 
/*     */         
/* 232 */         Utils.getDefaultTransport(), 
/* 233 */         Utils.getDefaultJsonFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public static GoogleCredential fromStream(InputStream credentialStream, HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 249 */     Preconditions.checkNotNull(credentialStream);
/* 250 */     Preconditions.checkNotNull(transport);
/* 251 */     Preconditions.checkNotNull(jsonFactory);
/*     */     
/* 253 */     JsonObjectParser parser = new JsonObjectParser(jsonFactory);
/* 254 */     GenericJson fileContents = (GenericJson)parser.parseAndClose(credentialStream, OAuth2Utils.UTF_8, GenericJson.class);
/*     */     
/* 256 */     String fileType = (String)fileContents.get("type");
/* 257 */     if (fileType == null) {
/* 258 */       throw new IOException("Error reading credentials from stream, 'type' field not specified.");
/*     */     }
/* 260 */     if ("authorized_user".equals(fileType)) {
/* 261 */       return fromStreamUser(fileContents, transport, jsonFactory);
/*     */     }
/* 263 */     if ("service_account".equals(fileType)) {
/* 264 */       return fromStreamServiceAccount(fileContents, transport, jsonFactory);
/*     */     }
/* 266 */     throw new IOException(String.format("Error reading credentials from stream, 'type' value '%s' not recognized. Expecting '%s' or '%s'.", new Object[] { fileType, "authorized_user", "service_account" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GoogleCredential() {
/* 316 */     this(new Builder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GoogleCredential(Builder builder) {
/* 325 */     super(builder);
/* 326 */     if (builder.serviceAccountPrivateKey == null) {
/* 327 */       Preconditions.checkArgument((builder.serviceAccountId == null && builder.serviceAccountScopes == null && builder.serviceAccountUser == null));
/*     */     } else {
/*     */       
/* 330 */       this.serviceAccountId = (String)Preconditions.checkNotNull(builder.serviceAccountId);
/* 331 */       this.serviceAccountProjectId = builder.serviceAccountProjectId;
/* 332 */       this
/*     */ 
/*     */         
/* 335 */         .serviceAccountScopes = (builder.serviceAccountScopes == null) ? Collections.<String>emptyList() : Collections.<String>unmodifiableCollection(builder.serviceAccountScopes);
/* 336 */       this.serviceAccountPrivateKey = builder.serviceAccountPrivateKey;
/* 337 */       this.serviceAccountPrivateKeyId = builder.serviceAccountPrivateKeyId;
/* 338 */       this.serviceAccountUser = builder.serviceAccountUser;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleCredential setAccessToken(String accessToken) {
/* 344 */     return (GoogleCredential)super.setAccessToken(accessToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleCredential setRefreshToken(String refreshToken) {
/* 349 */     if (refreshToken != null) {
/* 350 */       Preconditions.checkArgument((
/* 351 */           getJsonFactory() != null && getTransport() != null && getClientAuthentication() != null), "Please use the Builder and call setJsonFactory, setTransport and setClientSecrets");
/*     */     }
/*     */     
/* 354 */     return (GoogleCredential)super.setRefreshToken(refreshToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleCredential setExpirationTimeMilliseconds(Long expirationTimeMilliseconds) {
/* 359 */     return (GoogleCredential)super.setExpirationTimeMilliseconds(expirationTimeMilliseconds);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleCredential setExpiresInSeconds(Long expiresIn) {
/* 364 */     return (GoogleCredential)super.setExpiresInSeconds(expiresIn);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleCredential setFromTokenResponse(TokenResponse tokenResponse) {
/* 369 */     return (GoogleCredential)super.setFromTokenResponse(tokenResponse);
/*     */   }
/*     */ 
/*     */   
/*     */   @Beta
/*     */   protected TokenResponse executeRefreshToken() throws IOException {
/* 375 */     if (this.serviceAccountPrivateKey == null) {
/* 376 */       return super.executeRefreshToken();
/*     */     }
/*     */     
/* 379 */     JsonWebSignature.Header header = new JsonWebSignature.Header();
/* 380 */     header.setAlgorithm("RS256");
/* 381 */     header.setType("JWT");
/* 382 */     header.setKeyId(this.serviceAccountPrivateKeyId);
/* 383 */     JsonWebToken.Payload payload = new JsonWebToken.Payload();
/* 384 */     long currentTime = getClock().currentTimeMillis();
/* 385 */     payload.setIssuer(this.serviceAccountId);
/* 386 */     payload.setAudience(getTokenServerEncodedUrl());
/* 387 */     payload.setIssuedAtTimeSeconds(Long.valueOf(currentTime / 1000L));
/* 388 */     payload.setExpirationTimeSeconds(Long.valueOf(currentTime / 1000L + 3600L));
/* 389 */     payload.setSubject(this.serviceAccountUser);
/* 390 */     payload.put("scope", Joiner.on(' ').join(this.serviceAccountScopes));
/*     */     try {
/* 392 */       String assertion = JsonWebSignature.signUsingRsaSha256(this.serviceAccountPrivateKey, 
/* 393 */           getJsonFactory(), header, payload);
/*     */       
/* 395 */       TokenRequest request = new TokenRequest(getTransport(), getJsonFactory(), new GenericUrl(getTokenServerEncodedUrl()), "urn:ietf:params:oauth:grant-type:jwt-bearer");
/*     */       
/* 397 */       request.put("assertion", assertion);
/* 398 */       return request.execute();
/* 399 */     } catch (GeneralSecurityException exception) {
/* 400 */       IOException e = new IOException();
/* 401 */       e.initCause(exception);
/* 402 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getServiceAccountId() {
/* 411 */     return this.serviceAccountId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getServiceAccountProjectId() {
/* 420 */     return this.serviceAccountProjectId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Collection<String> getServiceAccountScopes() {
/* 428 */     return this.serviceAccountScopes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getServiceAccountScopesAsString() {
/* 438 */     return (this.serviceAccountScopes == null) ? null : Joiner.on(' ').join(this.serviceAccountScopes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PrivateKey getServiceAccountPrivateKey() {
/* 446 */     return this.serviceAccountPrivateKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public final String getServiceAccountPrivateKeyId() {
/* 456 */     return this.serviceAccountPrivateKeyId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getServiceAccountUser() {
/* 464 */     return this.serviceAccountUser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public boolean createScopedRequired() {
/* 474 */     if (this.serviceAccountPrivateKey == null) {
/* 475 */       return false;
/*     */     }
/* 477 */     return (this.serviceAccountScopes == null || this.serviceAccountScopes.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public GoogleCredential createScoped(Collection<String> scopes) {
/* 487 */     if (this.serviceAccountPrivateKey == null) {
/* 488 */       return this;
/*     */     }
/* 490 */     return toBuilder()
/* 491 */       .setServiceAccountScopes(scopes)
/* 492 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public GoogleCredential createDelegated(String user) {
/* 502 */     if (this.serviceAccountPrivateKey == null) {
/* 503 */       return this;
/*     */     }
/* 505 */     return toBuilder()
/* 506 */       .setServiceAccountUser(user)
/* 507 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Beta
/*     */   public Builder toBuilder() {
/* 526 */     Builder builder = (new Builder()).setServiceAccountPrivateKey(this.serviceAccountPrivateKey).setServiceAccountPrivateKeyId(this.serviceAccountPrivateKeyId).setServiceAccountId(this.serviceAccountId).setServiceAccountProjectId(this.serviceAccountProjectId).setServiceAccountUser(this.serviceAccountUser).setServiceAccountScopes(this.serviceAccountScopes).setTokenServerEncodedUrl(getTokenServerEncodedUrl()).setTransport(getTransport()).setJsonFactory(getJsonFactory()).setClock(getClock());
/*     */     
/* 528 */     builder.setClientAuthentication(getClientAuthentication());
/*     */     
/* 530 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     extends Credential.Builder
/*     */   {
/*     */     String serviceAccountId;
/*     */ 
/*     */ 
/*     */     
/*     */     Collection<String> serviceAccountScopes;
/*     */ 
/*     */ 
/*     */     
/*     */     PrivateKey serviceAccountPrivateKey;
/*     */ 
/*     */ 
/*     */     
/*     */     String serviceAccountPrivateKeyId;
/*     */ 
/*     */ 
/*     */     
/*     */     String serviceAccountProjectId;
/*     */ 
/*     */ 
/*     */     
/*     */     String serviceAccountUser;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder() {
/* 566 */       super(BearerToken.authorizationHeaderAccessMethod());
/* 567 */       setTokenServerEncodedUrl("https://oauth2.googleapis.com/token");
/*     */     }
/*     */ 
/*     */     
/*     */     public GoogleCredential build() {
/* 572 */       return new GoogleCredential(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setTransport(HttpTransport transport) {
/* 577 */       return (Builder)super.setTransport(transport);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setJsonFactory(JsonFactory jsonFactory) {
/* 582 */       return (Builder)super.setJsonFactory(jsonFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClock(Clock clock) {
/* 590 */       return (Builder)super.setClock(clock);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClientSecrets(String clientId, String clientSecret) {
/* 602 */       setClientAuthentication((HttpExecuteInterceptor)new ClientParametersAuthentication(clientId, clientSecret));
/* 603 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setClientSecrets(GoogleClientSecrets clientSecrets) {
/* 615 */       GoogleClientSecrets.Details details = clientSecrets.getDetails();
/* 616 */       setClientAuthentication((HttpExecuteInterceptor)new ClientParametersAuthentication(details
/* 617 */             .getClientId(), details.getClientSecret()));
/* 618 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getServiceAccountId() {
/* 625 */       return this.serviceAccountId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServiceAccountId(String serviceAccountId) {
/* 637 */       this.serviceAccountId = serviceAccountId;
/* 638 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getServiceAccountProjectId() {
/* 645 */       return this.serviceAccountProjectId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServiceAccountProjectId(String serviceAccountProjectId) {
/* 657 */       this.serviceAccountProjectId = serviceAccountProjectId;
/* 658 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Collection<String> getServiceAccountScopes() {
/* 666 */       return this.serviceAccountScopes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServiceAccountScopes(Collection<String> serviceAccountScopes) {
/* 683 */       this.serviceAccountScopes = serviceAccountScopes;
/* 684 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final PrivateKey getServiceAccountPrivateKey() {
/* 691 */       return this.serviceAccountPrivateKey;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServiceAccountPrivateKey(PrivateKey serviceAccountPrivateKey) {
/* 703 */       this.serviceAccountPrivateKey = serviceAccountPrivateKey;
/* 704 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public final String getServiceAccountPrivateKeyId() {
/* 714 */       return this.serviceAccountPrivateKeyId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public Builder setServiceAccountPrivateKeyId(String serviceAccountPrivateKeyId) {
/* 729 */       this.serviceAccountPrivateKeyId = serviceAccountPrivateKeyId;
/* 730 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServiceAccountPrivateKeyFromP12File(File p12File) throws GeneralSecurityException, IOException {
/* 746 */       setServiceAccountPrivateKeyFromP12File(new FileInputStream(p12File));
/* 747 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServiceAccountPrivateKeyFromP12File(InputStream p12FileInputStream) throws GeneralSecurityException, IOException {
/* 763 */       this.serviceAccountPrivateKey = SecurityUtils.loadPrivateKeyFromKeyStore(
/* 764 */           SecurityUtils.getPkcs12KeyStore(), p12FileInputStream, "notasecret", "privatekey", "notasecret");
/*     */       
/* 766 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Beta
/*     */     public Builder setServiceAccountPrivateKeyFromPemFile(File pemFile) throws GeneralSecurityException, IOException {
/* 786 */       byte[] bytes = PemReader.readFirstSectionAndClose(new FileReader(pemFile), "PRIVATE KEY").getBase64DecodedBytes();
/* 787 */       this
/* 788 */         .serviceAccountPrivateKey = SecurityUtils.getRsaKeyFactory().generatePrivate(new PKCS8EncodedKeySpec(bytes));
/* 789 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getServiceAccountUser() {
/* 797 */       return this.serviceAccountUser;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServiceAccountUser(String serviceAccountUser) {
/* 810 */       this.serviceAccountUser = serviceAccountUser;
/* 811 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRequestInitializer(HttpRequestInitializer requestInitializer) {
/* 816 */       return (Builder)super.setRequestInitializer(requestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder addRefreshListener(CredentialRefreshListener refreshListener) {
/* 821 */       return (Builder)super.addRefreshListener(refreshListener);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setRefreshListeners(Collection<CredentialRefreshListener> refreshListeners) {
/* 826 */       return (Builder)super.setRefreshListeners(refreshListeners);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setTokenServerUrl(GenericUrl tokenServerUrl) {
/* 831 */       return (Builder)super.setTokenServerUrl(tokenServerUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setTokenServerEncodedUrl(String tokenServerEncodedUrl) {
/* 836 */       return (Builder)super.setTokenServerEncodedUrl(tokenServerEncodedUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setClientAuthentication(HttpExecuteInterceptor clientAuthentication) {
/* 841 */       return (Builder)super.setClientAuthentication(clientAuthentication);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Beta
/*     */   private static GoogleCredential fromStreamUser(GenericJson fileContents, HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 848 */     String clientId = (String)fileContents.get("client_id");
/* 849 */     String clientSecret = (String)fileContents.get("client_secret");
/* 850 */     String refreshToken = (String)fileContents.get("refresh_token");
/* 851 */     if (clientId == null || clientSecret == null || refreshToken == null) {
/* 852 */       throw new IOException("Error reading user credential from stream,  expecting 'client_id', 'client_secret' and 'refresh_token'.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 860 */     GoogleCredential credential = (new Builder()).setClientSecrets(clientId, clientSecret).setTransport(transport).setJsonFactory(jsonFactory).build();
/* 861 */     credential.setRefreshToken(refreshToken);
/*     */ 
/*     */     
/* 864 */     credential.refreshToken();
/* 865 */     return credential;
/*     */   }
/*     */ 
/*     */   
/*     */   @Beta
/*     */   private static GoogleCredential fromStreamServiceAccount(GenericJson fileContents, HttpTransport transport, JsonFactory jsonFactory) throws IOException {
/* 871 */     String clientId = (String)fileContents.get("client_id");
/* 872 */     String clientEmail = (String)fileContents.get("client_email");
/* 873 */     String privateKeyPem = (String)fileContents.get("private_key");
/* 874 */     String privateKeyId = (String)fileContents.get("private_key_id");
/* 875 */     if (clientId == null || clientEmail == null || privateKeyPem == null || privateKeyId == null)
/*     */     {
/* 877 */       throw new IOException("Error reading service account credential from stream, expecting  'client_id', 'client_email', 'private_key' and 'private_key_id'.");
/*     */     }
/*     */ 
/*     */     
/* 881 */     PrivateKey privateKey = privateKeyFromPkcs8(privateKeyPem);
/*     */     
/* 883 */     Collection<String> emptyScopes = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 891 */     Builder credentialBuilder = (new Builder()).setTransport(transport).setJsonFactory(jsonFactory).setServiceAccountId(clientEmail).setServiceAccountScopes(emptyScopes).setServiceAccountPrivateKey(privateKey).setServiceAccountPrivateKeyId(privateKeyId);
/* 892 */     String tokenUri = (String)fileContents.get("token_uri");
/* 893 */     if (tokenUri != null) {
/* 894 */       credentialBuilder.setTokenServerEncodedUrl(tokenUri);
/*     */     }
/* 896 */     String projectId = (String)fileContents.get("project_id");
/* 897 */     if (projectId != null) {
/* 898 */       credentialBuilder.setServiceAccountProjectId(projectId);
/*     */     }
/*     */ 
/*     */     
/* 902 */     return credentialBuilder.build();
/*     */   }
/*     */   
/*     */   @Beta
/*     */   private static PrivateKey privateKeyFromPkcs8(String privateKeyPem) throws IOException {
/* 907 */     Reader reader = new StringReader(privateKeyPem);
/* 908 */     PemReader.Section section = PemReader.readFirstSectionAndClose(reader, "PRIVATE KEY");
/* 909 */     if (section == null) {
/* 910 */       throw new IOException("Invalid PKCS8 data.");
/*     */     }
/* 912 */     byte[] bytes = section.getBase64DecodedBytes();
/* 913 */     PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(bytes);
/* 914 */     Exception unexpectedException = null;
/*     */     try {
/* 916 */       KeyFactory keyFactory = SecurityUtils.getRsaKeyFactory();
/* 917 */       PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
/* 918 */       return privateKey;
/* 919 */     } catch (NoSuchAlgorithmException exception) {
/* 920 */       unexpectedException = exception;
/* 921 */     } catch (InvalidKeySpecException exception) {
/* 922 */       unexpectedException = exception;
/*     */     } 
/* 924 */     throw (IOException)OAuth2Utils.exceptionWithCause(new IOException("Unexpected exception reading PKCS data"), unexpectedException);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\auth\oauth2\GoogleCredential.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */