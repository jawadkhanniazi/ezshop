/*    */ package com.google.api.client.googleapis.javanet;
/*    */ 
/*    */ import com.google.api.client.googleapis.GoogleUtils;
/*    */ import com.google.api.client.http.javanet.NetHttpTransport;
/*    */ import java.io.IOException;
/*    */ import java.security.GeneralSecurityException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoogleNetHttpTransport
/*    */ {
/*    */   public static NetHttpTransport newTrustedTransport() throws GeneralSecurityException, IOException {
/* 55 */     return (new NetHttpTransport.Builder()).trustCertificates(GoogleUtils.getCertificateTrustStore())
/* 56 */       .build();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\javanet\GoogleNetHttpTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */