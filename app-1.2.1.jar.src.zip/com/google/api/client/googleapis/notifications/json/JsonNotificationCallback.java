/*    */ package com.google.api.client.googleapis.notifications.json;
/*    */ 
/*    */ import com.google.api.client.googleapis.notifications.TypedNotificationCallback;
/*    */ import com.google.api.client.json.JsonFactory;
/*    */ import com.google.api.client.json.JsonObjectParser;
/*    */ import com.google.api.client.util.Beta;
/*    */ import com.google.api.client.util.ObjectParser;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Beta
/*    */ public abstract class JsonNotificationCallback<T>
/*    */   extends TypedNotificationCallback<T>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected abstract JsonFactory getJsonFactory() throws IOException;
/*    */   
/*    */   protected final JsonObjectParser getObjectParser() throws IOException {
/* 81 */     return new JsonObjectParser(getJsonFactory());
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\json\JsonNotificationCallback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */