/*     */ package com.google.api.client.googleapis.notifications;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Objects;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.store.DataStore;
/*     */ import com.google.api.client.util.store.DataStoreFactory;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public final class StoredChannel
/*     */   implements Serializable
/*     */ {
/*  44 */   public static final String DEFAULT_DATA_STORE_ID = StoredChannel.class.getSimpleName();
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*  49 */   private final Lock lock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final UnparsedNotificationCallback notificationCallback;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String clientToken;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Long expiration;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String id;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String topicId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredChannel(UnparsedNotificationCallback notificationCallback) {
/*  82 */     this(notificationCallback, NotificationUtils.randomUuidString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredChannel(UnparsedNotificationCallback notificationCallback, String id) {
/*  93 */     this.notificationCallback = (UnparsedNotificationCallback)Preconditions.checkNotNull(notificationCallback);
/*  94 */     this.id = (String)Preconditions.checkNotNull(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredChannel store(DataStoreFactory dataStoreFactory) throws IOException {
/* 109 */     return store(getDefaultDataStore(dataStoreFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredChannel store(DataStore<StoredChannel> dataStore) throws IOException {
/* 123 */     this.lock.lock();
/*     */     try {
/* 125 */       dataStore.set(getId(), this);
/* 126 */       return this;
/*     */     } finally {
/* 128 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnparsedNotificationCallback getNotificationCallback() {
/* 136 */     this.lock.lock();
/*     */     try {
/* 138 */       return this.notificationCallback;
/*     */     } finally {
/* 140 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClientToken() {
/* 149 */     this.lock.lock();
/*     */     try {
/* 151 */       return this.clientToken;
/*     */     } finally {
/* 153 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredChannel setClientToken(String clientToken) {
/* 162 */     this.lock.lock();
/*     */     try {
/* 164 */       this.clientToken = clientToken;
/*     */     } finally {
/* 166 */       this.lock.unlock();
/*     */     } 
/* 168 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Long getExpiration() {
/* 176 */     this.lock.lock();
/*     */     try {
/* 178 */       return this.expiration;
/*     */     } finally {
/* 180 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredChannel setExpiration(Long expiration) {
/* 189 */     this.lock.lock();
/*     */     try {
/* 191 */       this.expiration = expiration;
/*     */     } finally {
/* 193 */       this.lock.unlock();
/*     */     } 
/* 195 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 200 */     this.lock.lock();
/*     */     try {
/* 202 */       return this.id;
/*     */     } finally {
/* 204 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTopicId() {
/* 213 */     this.lock.lock();
/*     */     try {
/* 215 */       return this.topicId;
/*     */     } finally {
/* 217 */       this.lock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StoredChannel setTopicId(String topicId) {
/* 226 */     this.lock.lock();
/*     */     try {
/* 228 */       this.topicId = topicId;
/*     */     } finally {
/* 230 */       this.lock.unlock();
/*     */     } 
/* 232 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 237 */     return Objects.toStringHelper(StoredChannel.class)
/* 238 */       .add("notificationCallback", getNotificationCallback()).add("clientToken", getClientToken())
/* 239 */       .add("expiration", getExpiration()).add("id", getId()).add("topicId", getTopicId())
/* 240 */       .toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 245 */     if (this == other) {
/* 246 */       return true;
/*     */     }
/* 248 */     if (!(other instanceof StoredChannel)) {
/* 249 */       return false;
/*     */     }
/* 251 */     StoredChannel o = (StoredChannel)other;
/* 252 */     return getId().equals(o.getId());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 257 */     return getId().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataStore<StoredChannel> getDefaultDataStore(DataStoreFactory dataStoreFactory) throws IOException {
/* 268 */     return dataStoreFactory.getDataStore(DEFAULT_DATA_STORE_ID);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\StoredChannel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */