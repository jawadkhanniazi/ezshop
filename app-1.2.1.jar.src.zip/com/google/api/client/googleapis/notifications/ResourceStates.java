package com.google.api.client.googleapis.notifications;

import com.google.api.client.util.Beta;

@Beta
public final class ResourceStates {
  public static final String SYNC = "SYNC";
  
  public static final String EXISTS = "EXISTS";
  
  public static final String NOT_EXISTS = "NOT_EXISTS";
}


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\ResourceStates.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */