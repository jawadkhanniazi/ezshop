/*     */ package com.google.api.client.googleapis.notifications;
/*     */ 
/*     */ import com.google.api.client.http.HttpMediaType;
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public abstract class TypedNotificationCallback<T>
/*     */   implements UnparsedNotificationCallback
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected abstract void onNotification(StoredChannel paramStoredChannel, TypedNotification<T> paramTypedNotification) throws IOException;
/*     */   
/*     */   protected abstract ObjectParser getObjectParser() throws IOException;
/*     */   
/*     */   protected abstract Class<T> getDataClass() throws IOException;
/*     */   
/*     */   public final void onNotification(StoredChannel storedChannel, UnparsedNotification notification) throws IOException {
/* 101 */     TypedNotification<T> typedNotification = new TypedNotification<>(notification);
/*     */     
/* 103 */     String contentType = notification.getContentType();
/* 104 */     if (contentType != null) {
/* 105 */       Charset charset = (new HttpMediaType(contentType)).getCharsetParameter();
/* 106 */       Class<T> dataClass = (Class<T>)Preconditions.checkNotNull(getDataClass());
/* 107 */       typedNotification.setContent((T)
/* 108 */           getObjectParser().parseAndClose(notification.getContentStream(), charset, dataClass));
/*     */     } 
/* 110 */     onNotification(storedChannel, typedNotification);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\TypedNotificationCallback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */