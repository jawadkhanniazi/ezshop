/*     */ package com.google.api.client.googleapis.notifications;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class UnparsedNotification
/*     */   extends AbstractNotification
/*     */ {
/*     */   private String contentType;
/*     */   private InputStream contentStream;
/*     */   
/*     */   public UnparsedNotification(long messageNumber, String resourceState, String resourceId, String resourceUri, String channelId) {
/*  52 */     super(messageNumber, resourceState, resourceId, resourceUri, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getContentType() {
/*  60 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnparsedNotification setContentType(String contentType) {
/*  73 */     this.contentType = contentType;
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final InputStream getContentStream() {
/*  81 */     return this.contentStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnparsedNotification setContentStream(InputStream contentStream) {
/*  93 */     this.contentStream = contentStream;
/*  94 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setMessageNumber(long messageNumber) {
/*  99 */     return (UnparsedNotification)super.setMessageNumber(messageNumber);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setResourceState(String resourceState) {
/* 104 */     return (UnparsedNotification)super.setResourceState(resourceState);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setResourceId(String resourceId) {
/* 109 */     return (UnparsedNotification)super.setResourceId(resourceId);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setResourceUri(String resourceUri) {
/* 114 */     return (UnparsedNotification)super.setResourceUri(resourceUri);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setChannelId(String channelId) {
/* 119 */     return (UnparsedNotification)super.setChannelId(channelId);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setChannelExpiration(String channelExpiration) {
/* 124 */     return (UnparsedNotification)super.setChannelExpiration(channelExpiration);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setChannelToken(String channelToken) {
/* 129 */     return (UnparsedNotification)super.setChannelToken(channelToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public UnparsedNotification setChanged(String changed) {
/* 134 */     return (UnparsedNotification)super.setChanged(changed);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 139 */     return toStringHelper().add("contentType", this.contentType).toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\UnparsedNotification.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */