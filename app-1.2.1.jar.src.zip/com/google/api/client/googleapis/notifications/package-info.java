package com.google.api.client.googleapis.notifications;

import com.google.api.client.util.Beta;



/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\package-info.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */