/*     */ package com.google.api.client.googleapis.notifications;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public class TypedNotification<T>
/*     */   extends AbstractNotification
/*     */ {
/*     */   private T content;
/*     */   
/*     */   public TypedNotification(long messageNumber, String resourceState, String resourceId, String resourceUri, String channelId) {
/*  49 */     super(messageNumber, resourceState, resourceId, resourceUri, channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification(UnparsedNotification sourceNotification) {
/*  56 */     super(sourceNotification);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T getContent() {
/*  63 */     return this.content;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setContent(T content) {
/*  75 */     this.content = content;
/*  76 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setMessageNumber(long messageNumber) {
/*  82 */     return (TypedNotification<T>)super.setMessageNumber(messageNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setResourceState(String resourceState) {
/*  88 */     return (TypedNotification<T>)super.setResourceState(resourceState);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setResourceId(String resourceId) {
/*  94 */     return (TypedNotification<T>)super.setResourceId(resourceId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setResourceUri(String resourceUri) {
/* 100 */     return (TypedNotification<T>)super.setResourceUri(resourceUri);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setChannelId(String channelId) {
/* 106 */     return (TypedNotification<T>)super.setChannelId(channelId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setChannelExpiration(String channelExpiration) {
/* 112 */     return (TypedNotification<T>)super.setChannelExpiration(channelExpiration);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setChannelToken(String channelToken) {
/* 118 */     return (TypedNotification<T>)super.setChannelToken(channelToken);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedNotification<T> setChanged(String changed) {
/* 124 */     return (TypedNotification<T>)super.setChanged(changed);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 129 */     return toStringHelper().add("content", this.content).toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\TypedNotification.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */