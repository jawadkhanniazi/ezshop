/*     */ package com.google.api.client.googleapis.notifications;
/*     */ 
/*     */ import com.google.api.client.util.Beta;
/*     */ import com.google.api.client.util.Objects;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Beta
/*     */ public abstract class AbstractNotification
/*     */ {
/*     */   private long messageNumber;
/*     */   private String resourceState;
/*     */   private String resourceId;
/*     */   private String resourceUri;
/*     */   private String channelId;
/*     */   private String channelExpiration;
/*     */   private String channelToken;
/*     */   private String changed;
/*     */   
/*     */   protected AbstractNotification(long messageNumber, String resourceState, String resourceId, String resourceUri, String channelId) {
/*  76 */     setMessageNumber(messageNumber);
/*  77 */     setResourceState(resourceState);
/*  78 */     setResourceId(resourceId);
/*  79 */     setResourceUri(resourceUri);
/*  80 */     setChannelId(channelId);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractNotification(AbstractNotification source) {
/*  85 */     this(source.getMessageNumber(), source.getResourceState(), source.getResourceId(), source
/*  86 */         .getResourceUri(), source.getChannelId());
/*  87 */     setChannelExpiration(source.getChannelExpiration());
/*  88 */     setChannelToken(source.getChannelToken());
/*  89 */     setChanged(source.getChanged());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  94 */     return toStringHelper().toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Objects.ToStringHelper toStringHelper() {
/*  99 */     return Objects.toStringHelper(this).add("messageNumber", Long.valueOf(this.messageNumber))
/* 100 */       .add("resourceState", this.resourceState).add("resourceId", this.resourceId)
/* 101 */       .add("resourceUri", this.resourceUri).add("channelId", this.channelId)
/* 102 */       .add("channelExpiration", this.channelExpiration).add("channelToken", this.channelToken)
/* 103 */       .add("changed", this.changed);
/*     */   }
/*     */ 
/*     */   
/*     */   public final long getMessageNumber() {
/* 108 */     return this.messageNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setMessageNumber(long messageNumber) {
/* 120 */     Preconditions.checkArgument((messageNumber >= 1L));
/* 121 */     this.messageNumber = messageNumber;
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getResourceState() {
/* 127 */     return this.resourceState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setResourceState(String resourceState) {
/* 139 */     this.resourceState = (String)Preconditions.checkNotNull(resourceState);
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getResourceId() {
/* 145 */     return this.resourceId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setResourceId(String resourceId) {
/* 157 */     this.resourceId = (String)Preconditions.checkNotNull(resourceId);
/* 158 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getResourceUri() {
/* 166 */     return this.resourceUri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setResourceUri(String resourceUri) {
/* 179 */     this.resourceUri = (String)Preconditions.checkNotNull(resourceUri);
/* 180 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getChannelId() {
/* 185 */     return this.channelId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setChannelId(String channelId) {
/* 197 */     this.channelId = (String)Preconditions.checkNotNull(channelId);
/* 198 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getChannelExpiration() {
/* 203 */     return this.channelExpiration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setChannelExpiration(String channelExpiration) {
/* 215 */     this.channelExpiration = channelExpiration;
/* 216 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getChannelToken() {
/* 224 */     return this.channelToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setChannelToken(String channelToken) {
/* 237 */     this.channelToken = channelToken;
/* 238 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getChanged() {
/* 245 */     return this.changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractNotification setChanged(String changed) {
/* 257 */     this.changed = changed;
/* 258 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\notifications\AbstractNotification.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */