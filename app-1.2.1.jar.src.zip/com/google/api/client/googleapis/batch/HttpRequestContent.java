/*    */ package com.google.api.client.googleapis.batch;
/*    */ 
/*    */ import com.google.api.client.http.AbstractHttpContent;
/*    */ import com.google.api.client.http.HttpContent;
/*    */ import com.google.api.client.http.HttpHeaders;
/*    */ import com.google.api.client.http.HttpRequest;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Writer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HttpRequestContent
/*    */   extends AbstractHttpContent
/*    */ {
/*    */   static final String NEWLINE = "\r\n";
/*    */   private final HttpRequest request;
/*    */   private static final String HTTP_VERSION = "HTTP/1.1";
/*    */   
/*    */   HttpRequestContent(HttpRequest request) {
/* 40 */     super("application/http");
/* 41 */     this.request = request;
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 46 */     Writer writer = new OutputStreamWriter(out, getCharset());
/*    */     
/* 48 */     writer.write(this.request.getRequestMethod());
/* 49 */     writer.write(" ");
/* 50 */     writer.write(this.request.getUrl().build());
/* 51 */     writer.write(" ");
/* 52 */     writer.write("HTTP/1.1");
/* 53 */     writer.write("\r\n");
/*    */ 
/*    */     
/* 56 */     HttpHeaders headers = new HttpHeaders();
/* 57 */     headers.fromHttpHeaders(this.request.getHeaders());
/* 58 */     headers.setAcceptEncoding(null).setUserAgent(null)
/* 59 */       .setContentEncoding(null).setContentType(null).setContentLength(null);
/*    */     
/* 61 */     HttpContent content = this.request.getContent();
/* 62 */     if (content != null) {
/* 63 */       headers.setContentType(content.getType());
/*    */       
/* 65 */       long contentLength = content.getLength();
/* 66 */       if (contentLength != -1L) {
/* 67 */         headers.setContentLength(Long.valueOf(contentLength));
/*    */       }
/*    */     } 
/* 70 */     HttpHeaders.serializeHeadersForMultipartRequests(headers, null, null, writer);
/*    */     
/* 72 */     writer.write("\r\n");
/* 73 */     writer.flush();
/*    */     
/* 75 */     if (content != null)
/* 76 */       content.writeTo(out); 
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\batch\HttpRequestContent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */