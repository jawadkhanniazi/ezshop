/*     */ package com.google.api.client.googleapis.batch;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.http.HttpExecuteInterceptor;
/*     */ import com.google.api.client.http.HttpHeaders;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestFactory;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.MultipartContent;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Sleeper;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BatchRequest
/*     */ {
/*     */   private static final String GLOBAL_BATCH_ENDPOINT = "https://www.googleapis.com/batch";
/*     */   private static final String GLOBAL_BATCH_ENDPOINT_WARNING = "You are using the global batch endpoint which will soon be shut down. Please instantiate your BatchRequest via your service client's `batch(HttpRequestInitializer)` method. For an example, please see https://github.com/googleapis/google-api-java-client#batching.";
/* 110 */   private static final Logger LOGGER = Logger.getLogger(BatchRequest.class.getName());
/*     */ 
/*     */   
/* 113 */   private GenericUrl batchUrl = new GenericUrl("https://www.googleapis.com/batch");
/*     */ 
/*     */   
/*     */   private final HttpRequestFactory requestFactory;
/*     */ 
/*     */   
/* 119 */   List<RequestInfo<?, ?>> requestInfos = new ArrayList<>();
/*     */ 
/*     */   
/* 122 */   private Sleeper sleeper = Sleeper.DEFAULT;
/*     */ 
/*     */   
/*     */   static class RequestInfo<T, E>
/*     */   {
/*     */     final BatchCallback<T, E> callback;
/*     */     final Class<T> dataClass;
/*     */     final Class<E> errorClass;
/*     */     final HttpRequest request;
/*     */     
/*     */     RequestInfo(BatchCallback<T, E> callback, Class<T> dataClass, Class<E> errorClass, HttpRequest request) {
/* 133 */       this.callback = callback;
/* 134 */       this.dataClass = dataClass;
/* 135 */       this.errorClass = errorClass;
/* 136 */       this.request = request;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BatchRequest(HttpTransport transport, HttpRequestInitializer httpRequestInitializer) {
/* 151 */     this
/* 152 */       .requestFactory = (httpRequestInitializer == null) ? transport.createRequestFactory() : transport.createRequestFactory(httpRequestInitializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BatchRequest setBatchUrl(GenericUrl batchUrl) {
/* 160 */     this.batchUrl = batchUrl;
/* 161 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public GenericUrl getBatchUrl() {
/* 166 */     return this.batchUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sleeper getSleeper() {
/* 175 */     return this.sleeper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BatchRequest setSleeper(Sleeper sleeper) {
/* 184 */     this.sleeper = (Sleeper)Preconditions.checkNotNull(sleeper);
/* 185 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T, E> BatchRequest queue(HttpRequest httpRequest, Class<T> dataClass, Class<E> errorClass, BatchCallback<T, E> callback) throws IOException {
/* 205 */     Preconditions.checkNotNull(httpRequest);
/*     */     
/* 207 */     Preconditions.checkNotNull(callback);
/* 208 */     Preconditions.checkNotNull(dataClass);
/* 209 */     Preconditions.checkNotNull(errorClass);
/*     */     
/* 211 */     this.requestInfos.add(new RequestInfo<>(callback, dataClass, errorClass, httpRequest));
/* 212 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 219 */     return this.requestInfos.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() throws IOException {
/* 233 */     Preconditions.checkState(!this.requestInfos.isEmpty());
/*     */ 
/*     */ 
/*     */     
/* 237 */     if ("https://www.googleapis.com/batch".equals(this.batchUrl.toString())) {
/* 238 */       LOGGER.log(Level.WARNING, "You are using the global batch endpoint which will soon be shut down. Please instantiate your BatchRequest via your service client's `batch(HttpRequestInitializer)` method. For an example, please see https://github.com/googleapis/google-api-java-client#batching.");
/*     */     }
/*     */     
/* 241 */     HttpRequest batchRequest = this.requestFactory.buildPostRequest(this.batchUrl, null);
/*     */     
/* 243 */     HttpExecuteInterceptor originalInterceptor = batchRequest.getInterceptor();
/* 244 */     batchRequest.setInterceptor(new BatchInterceptor(originalInterceptor));
/* 245 */     int retriesRemaining = batchRequest.getNumberOfRetries();
/*     */     while (true)
/*     */     { BatchUnparsedResponse batchResponse;
/* 248 */       boolean retryAllowed = (retriesRemaining > 0);
/* 249 */       MultipartContent batchContent = new MultipartContent();
/* 250 */       batchContent.getMediaType().setSubType("mixed");
/* 251 */       int contentId = 1;
/* 252 */       for (RequestInfo<?, ?> requestInfo : this.requestInfos) {
/* 253 */         batchContent.addPart(new MultipartContent.Part((new HttpHeaders())
/* 254 */               .setAcceptEncoding(null).set("Content-ID", Integer.valueOf(contentId++)), (HttpContent)new HttpRequestContent(requestInfo.request)));
/*     */       }
/*     */       
/* 257 */       batchRequest.setContent((HttpContent)batchContent);
/* 258 */       HttpResponse response = batchRequest.execute();
/*     */ 
/*     */       
/*     */       try {
/* 262 */         String boundary = "--" + response.getMediaType().getParameter("boundary");
/*     */ 
/*     */         
/* 265 */         InputStream contentStream = response.getContent();
/* 266 */         batchResponse = new BatchUnparsedResponse(contentStream, boundary, this.requestInfos, retryAllowed);
/*     */ 
/*     */         
/* 269 */         while (batchResponse.hasNext) {
/* 270 */           batchResponse.parseNextResponse();
/*     */         }
/*     */       } finally {
/* 273 */         response.disconnect();
/*     */       } 
/*     */       
/* 276 */       List<RequestInfo<?, ?>> unsuccessfulRequestInfos = batchResponse.unsuccessfulRequestInfos;
/* 277 */       if (!unsuccessfulRequestInfos.isEmpty())
/* 278 */       { this.requestInfos = unsuccessfulRequestInfos;
/*     */ 
/*     */ 
/*     */         
/* 282 */         retriesRemaining--;
/* 283 */         if (!retryAllowed)
/* 284 */           break;  continue; }  break; }  this.requestInfos.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class BatchInterceptor
/*     */     implements HttpExecuteInterceptor
/*     */   {
/*     */     private HttpExecuteInterceptor originalInterceptor;
/*     */ 
/*     */     
/*     */     BatchInterceptor(HttpExecuteInterceptor originalInterceptor) {
/* 296 */       this.originalInterceptor = originalInterceptor;
/*     */     }
/*     */     
/*     */     public void intercept(HttpRequest batchRequest) throws IOException {
/* 300 */       if (this.originalInterceptor != null) {
/* 301 */         this.originalInterceptor.intercept(batchRequest);
/*     */       }
/* 303 */       for (BatchRequest.RequestInfo<?, ?> requestInfo : BatchRequest.this.requestInfos) {
/* 304 */         HttpExecuteInterceptor interceptor = requestInfo.request.getInterceptor();
/* 305 */         if (interceptor != null)
/* 306 */           interceptor.intercept(requestInfo.request); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\batch\BatchRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */