/*     */ package com.google.api.client.googleapis.batch;
/*     */ 
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.http.HttpHeaders;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpStatusCodes;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.http.HttpUnsuccessfulResponseHandler;
/*     */ import com.google.api.client.http.LowLevelHttpRequest;
/*     */ import com.google.api.client.http.LowLevelHttpResponse;
/*     */ import com.google.api.client.util.ByteStreams;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BatchUnparsedResponse
/*     */ {
/*     */   private final String boundary;
/*     */   private final List<BatchRequest.RequestInfo<?, ?>> requestInfos;
/*     */   private final InputStream inputStream;
/*     */   boolean hasNext = true;
/*  59 */   List<BatchRequest.RequestInfo<?, ?>> unsuccessfulRequestInfos = new ArrayList<>();
/*     */ 
/*     */   
/*  62 */   private int contentId = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean retryAllowed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BatchUnparsedResponse(InputStream inputStream, String boundary, List<BatchRequest.RequestInfo<?, ?>> requestInfos, boolean retryAllowed) throws IOException {
/*  78 */     this.boundary = boundary;
/*  79 */     this.requestInfos = requestInfos;
/*  80 */     this.retryAllowed = retryAllowed;
/*  81 */     this.inputStream = inputStream;
/*     */     
/*  83 */     checkForFinalBoundary(readLine());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parseNextResponse() throws IOException {
/*     */     InputStream body;
/*  94 */     this.contentId++;
/*     */     
/*     */     String line;
/*     */     
/*  98 */     while ((line = readLine()) != null && !line.equals(""));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     String statusLine = readLine();
/* 104 */     String[] statusParts = statusLine.split(" ");
/* 105 */     int statusCode = Integer.parseInt(statusParts[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     List<String> headerNames = new ArrayList<>();
/* 111 */     List<String> headerValues = new ArrayList<>();
/* 112 */     long contentLength = -1L;
/* 113 */     while ((line = readLine()) != null && !line.equals("")) {
/* 114 */       String[] headerParts = line.split(": ", 2);
/* 115 */       String headerName = headerParts[0];
/* 116 */       String headerValue = headerParts[1];
/* 117 */       headerNames.add(headerName);
/* 118 */       headerValues.add(headerValue);
/* 119 */       if ("Content-Length".equalsIgnoreCase(headerName.trim())) {
/* 120 */         contentLength = Long.parseLong(headerValue);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 125 */     if (contentLength == -1L) {
/*     */       
/* 127 */       ByteArrayOutputStream buffer = new ByteArrayOutputStream();
/* 128 */       while ((line = readRawLine()) != null && !line.startsWith(this.boundary))
/*     */       {
/* 130 */         buffer.write(line.getBytes("ISO-8859-1"));
/*     */       }
/*     */ 
/*     */       
/* 134 */       body = trimCrlf(buffer.toByteArray());
/*     */ 
/*     */       
/* 137 */       line = trimCrlf(line);
/*     */     } else {
/* 139 */       body = new FilterInputStream(ByteStreams.limit(this.inputStream, contentLength))
/*     */         {
/*     */           public void close() {}
/*     */         };
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     HttpResponse response = getFakeResponse(statusCode, body, headerNames, headerValues);
/*     */     
/* 150 */     parseAndCallback(this.requestInfos.get(this.contentId - 1), statusCode, response);
/*     */ 
/*     */     
/* 153 */     while (body.skip(contentLength) > 0L || body.read() != -1);
/*     */ 
/*     */     
/* 156 */     if (contentLength != -1L) {
/* 157 */       line = readLine();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 162 */     while (line != null && line.length() == 0) {
/* 163 */       line = readLine();
/*     */     }
/*     */     
/* 166 */     checkForFinalBoundary(line);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T, E> void parseAndCallback(BatchRequest.RequestInfo<T, E> requestInfo, int statusCode, HttpResponse response) throws IOException {
/* 176 */     BatchCallback<T, E> callback = requestInfo.callback;
/*     */     
/* 178 */     HttpHeaders responseHeaders = response.getHeaders();
/*     */     
/* 180 */     HttpUnsuccessfulResponseHandler unsuccessfulResponseHandler = requestInfo.request.getUnsuccessfulResponseHandler();
/*     */     
/* 182 */     if (HttpStatusCodes.isSuccess(statusCode)) {
/* 183 */       if (callback == null) {
/*     */         return;
/*     */       }
/*     */       
/* 187 */       T parsed = getParsedDataClass(requestInfo.dataClass, response, requestInfo);
/* 188 */       callback.onSuccess(parsed, responseHeaders);
/*     */     } else {
/* 190 */       HttpContent content = requestInfo.request.getContent();
/* 191 */       boolean retrySupported = (this.retryAllowed && (content == null || content.retrySupported()));
/* 192 */       boolean errorHandled = false;
/* 193 */       boolean redirectRequest = false;
/* 194 */       if (unsuccessfulResponseHandler != null) {
/* 195 */         errorHandled = unsuccessfulResponseHandler.handleResponse(requestInfo.request, response, retrySupported);
/*     */       }
/*     */       
/* 198 */       if (!errorHandled && 
/* 199 */         requestInfo.request.handleRedirect(response.getStatusCode(), response.getHeaders())) {
/* 200 */         redirectRequest = true;
/*     */       }
/*     */       
/* 203 */       if (retrySupported && (errorHandled || redirectRequest)) {
/* 204 */         this.unsuccessfulRequestInfos.add(requestInfo);
/*     */       } else {
/* 206 */         if (callback == null) {
/*     */           return;
/*     */         }
/*     */         
/* 210 */         E parsed = getParsedDataClass(requestInfo.errorClass, response, requestInfo);
/* 211 */         callback.onFailure(parsed, responseHeaders);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <A, T, E> A getParsedDataClass(Class<A> dataClass, HttpResponse response, BatchRequest.RequestInfo<T, E> requestInfo) throws IOException {
/* 219 */     if (dataClass == Void.class) {
/* 220 */       return null;
/*     */     }
/* 222 */     return (A)requestInfo.request.getParser().parseAndClose(response
/* 223 */         .getContent(), response.getContentCharset(), dataClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse getFakeResponse(int statusCode, InputStream partContent, List<String> headerNames, List<String> headerValues) throws IOException {
/* 232 */     HttpRequest request = (new FakeResponseHttpTransport(statusCode, partContent, headerNames, headerValues)).createRequestFactory().buildPostRequest(new GenericUrl("http://google.com/"), null);
/* 233 */     request.setLoggingEnabled(false);
/* 234 */     request.setThrowExceptionOnExecuteError(false);
/* 235 */     return request.execute();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String readRawLine() throws IOException {
/* 244 */     int b = this.inputStream.read();
/* 245 */     if (b == -1) {
/* 246 */       return null;
/*     */     }
/* 248 */     StringBuilder buffer = new StringBuilder();
/* 249 */     for (; b != -1; b = this.inputStream.read()) {
/* 250 */       buffer.append((char)b);
/* 251 */       if (b == 10) {
/*     */         break;
/*     */       }
/*     */     } 
/* 255 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String readLine() throws IOException {
/* 268 */     return trimCrlf(readRawLine());
/*     */   }
/*     */   
/*     */   private static String trimCrlf(String input) {
/* 272 */     if (input.endsWith("\r\n"))
/* 273 */       return input.substring(0, input.length() - 2); 
/* 274 */     if (input.endsWith("\n")) {
/* 275 */       return input.substring(0, input.length() - 1);
/*     */     }
/* 277 */     return input;
/*     */   }
/*     */ 
/*     */   
/*     */   private static InputStream trimCrlf(byte[] bytes) {
/* 282 */     int length = bytes.length;
/* 283 */     if (length > 0 && bytes[length - 1] == 10) {
/* 284 */       length--;
/*     */     }
/* 286 */     if (length > 0 && bytes[length - 1] == 13) {
/* 287 */       length--;
/*     */     }
/* 289 */     return new ByteArrayInputStream(bytes, 0, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkForFinalBoundary(String boundaryLine) throws IOException {
/* 297 */     if (boundaryLine.equals(this.boundary + "--")) {
/* 298 */       this.hasNext = false;
/* 299 */       this.inputStream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class FakeResponseHttpTransport
/*     */     extends HttpTransport
/*     */   {
/*     */     private int statusCode;
/*     */     private InputStream partContent;
/*     */     private List<String> headerNames;
/*     */     private List<String> headerValues;
/*     */     
/*     */     FakeResponseHttpTransport(int statusCode, InputStream partContent, List<String> headerNames, List<String> headerValues) {
/* 313 */       this.statusCode = statusCode;
/* 314 */       this.partContent = partContent;
/* 315 */       this.headerNames = headerNames;
/* 316 */       this.headerValues = headerValues;
/*     */     }
/*     */ 
/*     */     
/*     */     protected LowLevelHttpRequest buildRequest(String method, String url) {
/* 321 */       return new BatchUnparsedResponse.FakeLowLevelHttpRequest(this.partContent, this.statusCode, this.headerNames, this.headerValues);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FakeLowLevelHttpRequest
/*     */     extends LowLevelHttpRequest
/*     */   {
/*     */     private InputStream partContent;
/*     */     private int statusCode;
/*     */     private List<String> headerNames;
/*     */     private List<String> headerValues;
/*     */     
/*     */     FakeLowLevelHttpRequest(InputStream partContent, int statusCode, List<String> headerNames, List<String> headerValues) {
/* 334 */       this.partContent = partContent;
/* 335 */       this.statusCode = statusCode;
/* 336 */       this.headerNames = headerNames;
/* 337 */       this.headerValues = headerValues;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void addHeader(String name, String value) {}
/*     */ 
/*     */     
/*     */     public LowLevelHttpResponse execute() {
/* 346 */       BatchUnparsedResponse.FakeLowLevelHttpResponse response = new BatchUnparsedResponse.FakeLowLevelHttpResponse(this.partContent, this.statusCode, this.headerNames, this.headerValues);
/*     */       
/* 348 */       return response;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FakeLowLevelHttpResponse
/*     */     extends LowLevelHttpResponse {
/*     */     private InputStream partContent;
/*     */     private int statusCode;
/* 356 */     private List<String> headerNames = new ArrayList<>();
/* 357 */     private List<String> headerValues = new ArrayList<>();
/*     */ 
/*     */     
/*     */     FakeLowLevelHttpResponse(InputStream partContent, int statusCode, List<String> headerNames, List<String> headerValues) {
/* 361 */       this.partContent = partContent;
/* 362 */       this.statusCode = statusCode;
/* 363 */       this.headerNames = headerNames;
/* 364 */       this.headerValues = headerValues;
/*     */     }
/*     */ 
/*     */     
/*     */     public InputStream getContent() {
/* 369 */       return this.partContent;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getStatusCode() {
/* 374 */       return this.statusCode;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContentEncoding() {
/* 379 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getContentLength() {
/* 384 */       return 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getContentType() {
/* 389 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getStatusLine() {
/* 394 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getReasonPhrase() {
/* 399 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getHeaderCount() {
/* 404 */       return this.headerNames.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getHeaderName(int index) {
/* 409 */       return this.headerNames.get(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getHeaderValue(int index) {
/* 414 */       return this.headerValues.get(index);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\batch\BatchUnparsedResponse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */