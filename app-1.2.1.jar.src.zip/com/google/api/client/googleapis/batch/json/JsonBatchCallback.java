/*    */ package com.google.api.client.googleapis.batch.json;
/*    */ 
/*    */ import com.google.api.client.googleapis.batch.BatchCallback;
/*    */ import com.google.api.client.googleapis.json.GoogleJsonError;
/*    */ import com.google.api.client.googleapis.json.GoogleJsonErrorContainer;
/*    */ import com.google.api.client.http.HttpHeaders;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JsonBatchCallback<T>
/*    */   implements BatchCallback<T, GoogleJsonErrorContainer>
/*    */ {
/*    */   public abstract void onFailure(GoogleJsonError paramGoogleJsonError, HttpHeaders paramHttpHeaders) throws IOException;
/*    */   
/*    */   public final void onFailure(GoogleJsonErrorContainer e, HttpHeaders responseHeaders) throws IOException {
/* 54 */     onFailure(e.getError(), responseHeaders);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\batch\json\JsonBatchCallback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */