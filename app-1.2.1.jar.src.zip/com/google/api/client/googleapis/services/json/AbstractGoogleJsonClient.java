/*     */ package com.google.api.client.googleapis.services.json;
/*     */ 
/*     */ import com.google.api.client.googleapis.services.AbstractGoogleClient;
/*     */ import com.google.api.client.googleapis.services.GoogleClientRequestInitializer;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonObjectParser;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGoogleJsonClient
/*     */   extends AbstractGoogleClient
/*     */ {
/*     */   protected AbstractGoogleJsonClient(Builder builder) {
/*  41 */     super(builder);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonObjectParser getObjectParser() {
/*  46 */     return (JsonObjectParser)super.getObjectParser();
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFactory getJsonFactory() {
/*  51 */     return getObjectParser().getJsonFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Builder
/*     */     extends AbstractGoogleClient.Builder
/*     */   {
/*     */     protected Builder(HttpTransport transport, JsonFactory jsonFactory, String rootUrl, String servicePath, HttpRequestInitializer httpRequestInitializer, boolean legacyDataWrapper) {
/*  74 */       super(transport, rootUrl, servicePath, (ObjectParser)(new JsonObjectParser.Builder(jsonFactory))
/*  75 */           .setWrapperKeys(legacyDataWrapper ? 
/*  76 */             Arrays.<String>asList(new String[] { "data", "error" }, ) : Collections.emptySet())
/*  77 */           .build(), httpRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public final JsonObjectParser getObjectParser() {
/*  82 */       return (JsonObjectParser)super.getObjectParser();
/*     */     }
/*     */ 
/*     */     
/*     */     public final JsonFactory getJsonFactory() {
/*  87 */       return getObjectParser().getJsonFactory();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRootUrl(String rootUrl) {
/*  95 */       return (Builder)super.setRootUrl(rootUrl);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setServicePath(String servicePath) {
/* 100 */       return (Builder)super.setServicePath(servicePath);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setGoogleClientRequestInitializer(GoogleClientRequestInitializer googleClientRequestInitializer) {
/* 106 */       return (Builder)super.setGoogleClientRequestInitializer(googleClientRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setHttpRequestInitializer(HttpRequestInitializer httpRequestInitializer) {
/* 111 */       return (Builder)super.setHttpRequestInitializer(httpRequestInitializer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setApplicationName(String applicationName) {
/* 116 */       return (Builder)super.setApplicationName(applicationName);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressPatternChecks(boolean suppressPatternChecks) {
/* 121 */       return (Builder)super.setSuppressPatternChecks(suppressPatternChecks);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressRequiredParameterChecks(boolean suppressRequiredParameterChecks) {
/* 126 */       return (Builder)super.setSuppressRequiredParameterChecks(suppressRequiredParameterChecks);
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder setSuppressAllChecks(boolean suppressAllChecks) {
/* 131 */       return (Builder)super.setSuppressAllChecks(suppressAllChecks);
/*     */     }
/*     */     
/*     */     public abstract AbstractGoogleJsonClient build();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\services\json\AbstractGoogleJsonClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */