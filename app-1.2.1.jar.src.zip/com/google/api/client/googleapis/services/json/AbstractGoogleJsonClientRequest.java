/*     */ package com.google.api.client.googleapis.services.json;
/*     */ 
/*     */ import com.google.api.client.googleapis.batch.BatchCallback;
/*     */ import com.google.api.client.googleapis.batch.BatchRequest;
/*     */ import com.google.api.client.googleapis.batch.json.JsonBatchCallback;
/*     */ import com.google.api.client.googleapis.json.GoogleJsonErrorContainer;
/*     */ import com.google.api.client.googleapis.json.GoogleJsonResponseException;
/*     */ import com.google.api.client.googleapis.services.AbstractGoogleClient;
/*     */ import com.google.api.client.googleapis.services.AbstractGoogleClientRequest;
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.http.HttpHeaders;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.json.JsonHttpContent;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGoogleJsonClientRequest<T>
/*     */   extends AbstractGoogleClientRequest<T>
/*     */ {
/*     */   private final Object jsonContent;
/*     */   
/*     */   protected AbstractGoogleJsonClientRequest(AbstractGoogleJsonClient abstractGoogleJsonClient, String requestMethod, String uriTemplate, Object jsonContent, Class<T> responseClass) {
/*  57 */     super(abstractGoogleJsonClient, requestMethod, uriTemplate, (jsonContent == null) ? null : (HttpContent)(new JsonHttpContent(abstractGoogleJsonClient
/*  58 */           .getJsonFactory(), jsonContent))
/*  59 */         .setWrapperKey(abstractGoogleJsonClient.getObjectParser().getWrapperKeys().isEmpty() ? null : "data"), responseClass);
/*     */     
/*  61 */     this.jsonContent = jsonContent;
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractGoogleJsonClient getAbstractGoogleClient() {
/*  66 */     return (AbstractGoogleJsonClient)super.getAbstractGoogleClient();
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractGoogleJsonClientRequest<T> setDisableGZipContent(boolean disableGZipContent) {
/*  71 */     return (AbstractGoogleJsonClientRequest<T>)super.setDisableGZipContent(disableGZipContent);
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractGoogleJsonClientRequest<T> setRequestHeaders(HttpHeaders headers) {
/*  76 */     return (AbstractGoogleJsonClientRequest<T>)super.setRequestHeaders(headers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void queue(BatchRequest batchRequest, JsonBatchCallback<T> callback) throws IOException {
/* 108 */     queue(batchRequest, GoogleJsonErrorContainer.class, (BatchCallback)callback);
/*     */   }
/*     */ 
/*     */   
/*     */   protected GoogleJsonResponseException newExceptionOnError(HttpResponse response) {
/* 113 */     return GoogleJsonResponseException.from(getAbstractGoogleClient().getJsonFactory(), response);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getJsonContent() {
/* 118 */     return this.jsonContent;
/*     */   }
/*     */ 
/*     */   
/*     */   public AbstractGoogleJsonClientRequest<T> set(String fieldName, Object value) {
/* 123 */     return (AbstractGoogleJsonClientRequest<T>)super.set(fieldName, value);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\services\json\AbstractGoogleJsonClientRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */