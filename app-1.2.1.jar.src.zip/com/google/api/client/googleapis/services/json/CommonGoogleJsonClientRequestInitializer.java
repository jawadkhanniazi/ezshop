/*     */ package com.google.api.client.googleapis.services.json;
/*     */ 
/*     */ import com.google.api.client.googleapis.services.AbstractGoogleClientRequest;
/*     */ import com.google.api.client.googleapis.services.CommonGoogleClientRequestInitializer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonGoogleJsonClientRequestInitializer
/*     */   extends CommonGoogleClientRequestInitializer
/*     */ {
/*     */   @Deprecated
/*     */   public CommonGoogleJsonClientRequestInitializer() {}
/*     */   
/*     */   @Deprecated
/*     */   public CommonGoogleJsonClientRequestInitializer(String key) {
/* 105 */     super(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public CommonGoogleJsonClientRequestInitializer(String key, String userIp) {
/* 115 */     super(key, userIp);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void initialize(AbstractGoogleClientRequest<?> request) throws IOException {
/* 120 */     super.initialize(request);
/* 121 */     initializeJsonRequest((AbstractGoogleJsonClientRequest)request);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initializeJsonRequest(AbstractGoogleJsonClientRequest<?> request) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */     extends CommonGoogleClientRequestInitializer.Builder
/*     */   {
/*     */     protected Builder self() {
/* 146 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\services\json\CommonGoogleJsonClientRequestInitializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */