/*     */ package com.google.api.client.googleapis.services;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonGoogleClientRequestInitializer
/*     */   implements GoogleClientRequestInitializer
/*     */ {
/*     */   private static final String REQUEST_REASON_HEADER_NAME = "X-Goog-Request-Reason";
/*     */   private static final String USER_PROJECT_HEADER_NAME = "X-Goog-User-Project";
/*     */   private final String key;
/*     */   private final String userIp;
/*     */   private final String userAgent;
/*     */   private final String requestReason;
/*     */   private final String userProject;
/*     */   
/*     */   @Deprecated
/*     */   public CommonGoogleClientRequestInitializer() {
/* 121 */     this(newBuilder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public CommonGoogleClientRequestInitializer(String key) {
/* 130 */     this(key, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public CommonGoogleClientRequestInitializer(String key, String userIp) {
/* 140 */     this(newBuilder().setKey(key).setUserIp(userIp));
/*     */   }
/*     */   
/*     */   protected CommonGoogleClientRequestInitializer(Builder builder) {
/* 144 */     this.key = builder.getKey();
/* 145 */     this.userIp = builder.getUserIp();
/* 146 */     this.userAgent = builder.getUserAgent();
/* 147 */     this.requestReason = builder.getRequestReason();
/* 148 */     this.userProject = builder.getUserProject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder newBuilder() {
/* 157 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(AbstractGoogleClientRequest<?> request) throws IOException {
/* 166 */     if (this.key != null) {
/* 167 */       request.put("key", this.key);
/*     */     }
/* 169 */     if (this.userIp != null) {
/* 170 */       request.put("userIp", this.userIp);
/*     */     }
/* 172 */     if (this.userAgent != null) {
/* 173 */       request.getRequestHeaders().setUserAgent(this.userAgent);
/*     */     }
/* 175 */     if (this.requestReason != null) {
/* 176 */       request.getRequestHeaders().set("X-Goog-Request-Reason", this.requestReason);
/*     */     }
/* 178 */     if (this.userProject != null) {
/* 179 */       request.getRequestHeaders().set("X-Goog-User-Project", this.userProject);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getKey() {
/* 185 */     return this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getUserIp() {
/* 190 */     return this.userIp;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getUserAgent() {
/* 195 */     return this.userAgent;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getRequestReason() {
/* 200 */     return this.requestReason;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getUserProject() {
/* 205 */     return this.userProject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private String key;
/*     */ 
/*     */     
/*     */     private String userIp;
/*     */ 
/*     */     
/*     */     private String userAgent;
/*     */ 
/*     */     
/*     */     private String requestReason;
/*     */     
/*     */     private String userProject;
/*     */ 
/*     */     
/*     */     public Builder setKey(String key) {
/* 227 */       this.key = key;
/* 228 */       return self();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 237 */       return this.key;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setUserIp(String userIp) {
/* 247 */       this.userIp = userIp;
/* 248 */       return self();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUserIp() {
/* 257 */       return this.userIp;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setUserAgent(String userAgent) {
/* 267 */       this.userAgent = userAgent;
/* 268 */       return self();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUserAgent() {
/* 277 */       return this.userAgent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRequestReason(String requestReason) {
/* 288 */       this.requestReason = requestReason;
/* 289 */       return self();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getRequestReason() {
/* 298 */       return this.requestReason;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setUserProject(String userProject) {
/* 309 */       this.userProject = userProject;
/* 310 */       return self();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getUserProject() {
/* 319 */       return this.userProject;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CommonGoogleClientRequestInitializer build() {
/* 328 */       return new CommonGoogleClientRequestInitializer(this);
/*     */     }
/*     */     
/*     */     protected Builder self() {
/* 332 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\services\CommonGoogleClientRequestInitializer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */