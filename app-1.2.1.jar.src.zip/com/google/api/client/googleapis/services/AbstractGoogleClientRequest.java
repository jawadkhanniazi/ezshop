/*     */ package com.google.api.client.googleapis.services;
/*     */ 
/*     */ import com.google.api.client.googleapis.GoogleUtils;
/*     */ import com.google.api.client.googleapis.MethodOverride;
/*     */ import com.google.api.client.googleapis.batch.BatchCallback;
/*     */ import com.google.api.client.googleapis.batch.BatchRequest;
/*     */ import com.google.api.client.googleapis.media.MediaHttpDownloader;
/*     */ import com.google.api.client.googleapis.media.MediaHttpUploader;
/*     */ import com.google.api.client.http.AbstractInputStreamContent;
/*     */ import com.google.api.client.http.EmptyContent;
/*     */ import com.google.api.client.http.GZipEncoding;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpContent;
/*     */ import com.google.api.client.http.HttpEncoding;
/*     */ import com.google.api.client.http.HttpHeaders;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpRequestFactory;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpResponseException;
/*     */ import com.google.api.client.http.HttpResponseInterceptor;
/*     */ import com.google.api.client.http.UriTemplate;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.common.base.StandardSystemProperty;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGoogleClientRequest<T>
/*     */   extends GenericData
/*     */ {
/*     */   public static final String USER_AGENT_SUFFIX = "Google-API-Java-Client";
/*     */   private static final String API_VERSION_HEADER = "X-Goog-Api-Client";
/*     */   private final AbstractGoogleClient abstractGoogleClient;
/*     */   private final String requestMethod;
/*     */   private final String uriTemplate;
/*     */   private final HttpContent httpContent;
/*  83 */   private HttpHeaders requestHeaders = new HttpHeaders();
/*     */ 
/*     */   
/*     */   private HttpHeaders lastResponseHeaders;
/*     */ 
/*     */   
/*  89 */   private int lastStatusCode = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String lastStatusMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean disableGZipContent;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean returnRawInputStream;
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<T> responseClass;
/*     */ 
/*     */ 
/*     */   
/*     */   private MediaHttpUploader uploader;
/*     */ 
/*     */ 
/*     */   
/*     */   private MediaHttpDownloader downloader;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractGoogleClientRequest(AbstractGoogleClient abstractGoogleClient, String requestMethod, String uriTemplate, HttpContent httpContent, Class<T> responseClass) {
/* 121 */     this.responseClass = (Class<T>)Preconditions.checkNotNull(responseClass);
/* 122 */     this.abstractGoogleClient = (AbstractGoogleClient)Preconditions.checkNotNull(abstractGoogleClient);
/* 123 */     this.requestMethod = (String)Preconditions.checkNotNull(requestMethod);
/* 124 */     this.uriTemplate = (String)Preconditions.checkNotNull(uriTemplate);
/* 125 */     this.httpContent = httpContent;
/*     */     
/* 127 */     String applicationName = abstractGoogleClient.getApplicationName();
/* 128 */     if (applicationName != null) {
/* 129 */       this.requestHeaders.setUserAgent(applicationName + " " + "Google-API-Java-Client");
/*     */     } else {
/* 131 */       this.requestHeaders.setUserAgent("Google-API-Java-Client");
/*     */     } 
/*     */     
/* 134 */     this.requestHeaders.set("X-Goog-Api-Client", ApiClientVersion
/*     */         
/* 136 */         .getDefault().build(abstractGoogleClient.getClass().getSimpleName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ApiClientVersion
/*     */   {
/* 148 */     private static final ApiClientVersion DEFAULT_VERSION = new ApiClientVersion();
/*     */     private final String headerTemplate;
/*     */     
/*     */     ApiClientVersion() {
/* 152 */       this(getJavaVersion(), StandardSystemProperty.OS_NAME.value(), StandardSystemProperty.OS_VERSION.value(), GoogleUtils.VERSION);
/*     */     }
/*     */     
/*     */     ApiClientVersion(String javaVersion, String osName, String osVersion, String clientVersion) {
/* 156 */       StringBuilder sb = new StringBuilder("java/");
/* 157 */       sb.append(formatSemver(javaVersion));
/* 158 */       sb.append(" http-google-%s/");
/* 159 */       sb.append(formatSemver(clientVersion));
/* 160 */       if (osName != null && osVersion != null) {
/* 161 */         sb.append(" ");
/* 162 */         sb.append(formatName(osName));
/* 163 */         sb.append("/");
/* 164 */         sb.append(formatSemver(osVersion));
/*     */       } 
/* 166 */       this.headerTemplate = sb.toString();
/*     */     }
/*     */     
/*     */     String build(String clientName) {
/* 170 */       return String.format(this.headerTemplate, new Object[] { formatName(clientName) });
/*     */     }
/*     */     
/*     */     private static ApiClientVersion getDefault() {
/* 174 */       return DEFAULT_VERSION;
/*     */     }
/*     */     
/*     */     private static String getJavaVersion() {
/* 178 */       String version = System.getProperty("java.version");
/* 179 */       if (version == null) {
/* 180 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 184 */       String formatted = formatSemver(version, null);
/* 185 */       if (formatted != null) {
/* 186 */         return formatted;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 191 */       Matcher m = Pattern.compile("^(\\d+)[^\\d]?").matcher(version);
/* 192 */       if (m.find()) {
/* 193 */         return m.group(1) + ".0.0";
/*     */       }
/*     */       
/* 196 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     private static String formatName(String name) {
/* 201 */       return name.toLowerCase().replaceAll("[^\\w\\d\\-]", "-");
/*     */     }
/*     */     
/*     */     private static String formatSemver(String version) {
/* 205 */       return formatSemver(version, version);
/*     */     }
/*     */     
/*     */     private static String formatSemver(String version, String defaultValue) {
/* 209 */       if (version == null) {
/* 210 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 214 */       Matcher m = Pattern.compile("(\\d+\\.\\d+\\.\\d+).*").matcher(version);
/* 215 */       if (m.find()) {
/* 216 */         return m.group(1);
/*     */       }
/* 218 */       return defaultValue;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getDisableGZipContent() {
/* 225 */     return this.disableGZipContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getReturnRawInputSteam() {
/* 234 */     return this.returnRawInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractGoogleClientRequest<T> setDisableGZipContent(boolean disableGZipContent) {
/* 250 */     this.disableGZipContent = disableGZipContent;
/* 251 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractGoogleClientRequest<T> setReturnRawInputStream(boolean returnRawInputStream) {
/* 271 */     this.returnRawInputStream = returnRawInputStream;
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getRequestMethod() {
/* 277 */     return this.requestMethod;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getUriTemplate() {
/* 282 */     return this.uriTemplate;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpContent getHttpContent() {
/* 287 */     return this.httpContent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractGoogleClient getAbstractGoogleClient() {
/* 299 */     return this.abstractGoogleClient;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpHeaders getRequestHeaders() {
/* 304 */     return this.requestHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractGoogleClientRequest<T> setRequestHeaders(HttpHeaders headers) {
/* 321 */     this.requestHeaders = headers;
/* 322 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final HttpHeaders getLastResponseHeaders() {
/* 329 */     return this.lastResponseHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLastStatusCode() {
/* 336 */     return this.lastStatusCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLastStatusMessage() {
/* 344 */     return this.lastStatusMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Class<T> getResponseClass() {
/* 349 */     return this.responseClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MediaHttpUploader getMediaHttpUploader() {
/* 354 */     return this.uploader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void initializeMediaUpload(AbstractInputStreamContent mediaContent) {
/* 363 */     HttpRequestFactory requestFactory = this.abstractGoogleClient.getRequestFactory();
/* 364 */     this
/* 365 */       .uploader = new MediaHttpUploader(mediaContent, requestFactory.getTransport(), requestFactory.getInitializer());
/* 366 */     this.uploader.setInitiationRequestMethod(this.requestMethod);
/* 367 */     if (this.httpContent != null) {
/* 368 */       this.uploader.setMetadata(this.httpContent);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public final MediaHttpDownloader getMediaHttpDownloader() {
/* 374 */     return this.downloader;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void initializeMediaDownload() {
/* 379 */     HttpRequestFactory requestFactory = this.abstractGoogleClient.getRequestFactory();
/* 380 */     this
/* 381 */       .downloader = new MediaHttpDownloader(requestFactory.getTransport(), requestFactory.getInitializer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericUrl buildHttpRequestUrl() {
/* 394 */     return new GenericUrl(
/* 395 */         UriTemplate.expand(this.abstractGoogleClient.getBaseUrl(), this.uriTemplate, this, true));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpRequest buildHttpRequest() throws IOException {
/* 406 */     return buildHttpRequest(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpRequest buildHttpRequestUsingHead() throws IOException {
/* 421 */     return buildHttpRequest(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private HttpRequest buildHttpRequest(boolean usingHead) throws IOException {
/* 426 */     Preconditions.checkArgument((this.uploader == null));
/* 427 */     Preconditions.checkArgument((!usingHead || this.requestMethod.equals("GET")));
/* 428 */     String requestMethodToUse = usingHead ? "HEAD" : this.requestMethod;
/*     */     
/* 430 */     final HttpRequest httpRequest = getAbstractGoogleClient().getRequestFactory().buildRequest(requestMethodToUse, buildHttpRequestUrl(), this.httpContent);
/* 431 */     (new MethodOverride()).intercept(httpRequest);
/* 432 */     httpRequest.setParser(getAbstractGoogleClient().getObjectParser());
/*     */     
/* 434 */     if (this.httpContent == null && (this.requestMethod.equals("POST") || this.requestMethod
/* 435 */       .equals("PUT") || this.requestMethod.equals("PATCH"))) {
/* 436 */       httpRequest.setContent((HttpContent)new EmptyContent());
/*     */     }
/* 438 */     httpRequest.getHeaders().putAll((Map)this.requestHeaders);
/* 439 */     if (!this.disableGZipContent) {
/* 440 */       httpRequest.setEncoding((HttpEncoding)new GZipEncoding());
/*     */     }
/* 442 */     httpRequest.setResponseReturnRawInputStream(this.returnRawInputStream);
/* 443 */     final HttpResponseInterceptor responseInterceptor = httpRequest.getResponseInterceptor();
/* 444 */     httpRequest.setResponseInterceptor(new HttpResponseInterceptor()
/*     */         {
/*     */           public void interceptResponse(HttpResponse response) throws IOException {
/* 447 */             if (responseInterceptor != null) {
/* 448 */               responseInterceptor.interceptResponse(response);
/*     */             }
/* 450 */             if (!response.isSuccessStatusCode() && httpRequest.getThrowExceptionOnExecuteError()) {
/* 451 */               throw AbstractGoogleClientRequest.this.newExceptionOnError(response);
/*     */             }
/*     */           }
/*     */         });
/* 455 */     return httpRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpResponse executeUnparsed() throws IOException {
/* 482 */     return executeUnparsed(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpResponse executeMedia() throws IOException {
/* 509 */     set("alt", "media");
/* 510 */     return executeUnparsed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HttpResponse executeUsingHead() throws IOException {
/* 535 */     Preconditions.checkArgument((this.uploader == null));
/* 536 */     HttpResponse response = executeUnparsed(true);
/* 537 */     response.ignore();
/* 538 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HttpResponse executeUnparsed(boolean usingHead) throws IOException {
/*     */     HttpResponse response;
/* 547 */     if (this.uploader == null) {
/*     */       
/* 549 */       response = buildHttpRequest(usingHead).execute();
/*     */     } else {
/*     */       
/* 552 */       GenericUrl httpRequestUrl = buildHttpRequestUrl();
/*     */       
/* 554 */       HttpRequest httpRequest = getAbstractGoogleClient().getRequestFactory().buildRequest(this.requestMethod, httpRequestUrl, this.httpContent);
/* 555 */       boolean throwExceptionOnExecuteError = httpRequest.getThrowExceptionOnExecuteError();
/*     */ 
/*     */       
/* 558 */       response = this.uploader.setInitiationHeaders(this.requestHeaders).setDisableGZipContent(this.disableGZipContent).upload(httpRequestUrl);
/* 559 */       response.getRequest().setParser(getAbstractGoogleClient().getObjectParser());
/*     */       
/* 561 */       if (throwExceptionOnExecuteError && !response.isSuccessStatusCode()) {
/* 562 */         throw newExceptionOnError(response);
/*     */       }
/*     */     } 
/*     */     
/* 566 */     this.lastResponseHeaders = response.getHeaders();
/* 567 */     this.lastStatusCode = response.getStatusCode();
/* 568 */     this.lastStatusMessage = response.getStatusMessage();
/* 569 */     return response;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IOException newExceptionOnError(HttpResponse response) {
/* 586 */     return (IOException)new HttpResponseException(response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T execute() throws IOException {
/* 599 */     return (T)executeUnparsed().parseAs(this.responseClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream executeAsInputStream() throws IOException {
/* 626 */     return executeUnparsed().getContent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream executeMediaAsInputStream() throws IOException {
/* 653 */     return executeMedia().getContent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void executeAndDownloadTo(OutputStream outputStream) throws IOException {
/* 671 */     executeUnparsed().download(outputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void executeMediaAndDownloadTo(OutputStream outputStream) throws IOException {
/* 689 */     if (this.downloader == null) {
/* 690 */       executeMedia().download(outputStream);
/*     */     } else {
/* 692 */       this.downloader.download(buildHttpRequestUrl(), this.requestHeaders, outputStream);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <E> void queue(BatchRequest batchRequest, Class<E> errorClass, BatchCallback<T, E> callback) throws IOException {
/* 711 */     Preconditions.checkArgument((this.uploader == null), "Batching media requests is not supported");
/* 712 */     batchRequest.queue(buildHttpRequest(), getResponseClass(), errorClass, callback);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractGoogleClientRequest<T> set(String fieldName, Object value) {
/* 722 */     return (AbstractGoogleClientRequest<T>)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void checkRequiredParameter(Object value, String name) {
/* 736 */     Preconditions.checkArgument((this.abstractGoogleClient
/* 737 */         .getSuppressRequiredParameterChecks() || value != null), "Required parameter %s must be specified", new Object[] { name });
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\services\AbstractGoogleClientRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */