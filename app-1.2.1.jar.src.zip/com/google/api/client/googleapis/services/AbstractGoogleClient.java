/*     */ package com.google.api.client.googleapis.services;
/*     */ 
/*     */ import com.google.api.client.googleapis.batch.BatchRequest;
/*     */ import com.google.api.client.http.GenericUrl;
/*     */ import com.google.api.client.http.HttpRequestFactory;
/*     */ import com.google.api.client.http.HttpRequestInitializer;
/*     */ import com.google.api.client.http.HttpTransport;
/*     */ import com.google.api.client.util.ObjectParser;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.Strings;
/*     */ import java.io.IOException;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGoogleClient
/*     */ {
/*  34 */   private static final Logger logger = Logger.getLogger(AbstractGoogleClient.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final HttpRequestFactory requestFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final GoogleClientRequestInitializer googleClientRequestInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String rootUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String servicePath;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String batchPath;
/*     */ 
/*     */ 
/*     */   
/*     */   private final String applicationName;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ObjectParser objectParser;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean suppressPatternChecks;
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean suppressRequiredParameterChecks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractGoogleClient(Builder builder) {
/*  81 */     this.googleClientRequestInitializer = builder.googleClientRequestInitializer;
/*  82 */     this.rootUrl = normalizeRootUrl(builder.rootUrl);
/*  83 */     this.servicePath = normalizeServicePath(builder.servicePath);
/*  84 */     this.batchPath = builder.batchPath;
/*  85 */     if (Strings.isNullOrEmpty(builder.applicationName)) {
/*  86 */       logger.warning("Application name is not set. Call Builder#setApplicationName.");
/*     */     }
/*  88 */     this.applicationName = builder.applicationName;
/*  89 */     this
/*     */       
/*  91 */       .requestFactory = (builder.httpRequestInitializer == null) ? builder.transport.createRequestFactory() : builder.transport.createRequestFactory(builder.httpRequestInitializer);
/*  92 */     this.objectParser = builder.objectParser;
/*  93 */     this.suppressPatternChecks = builder.suppressPatternChecks;
/*  94 */     this.suppressRequiredParameterChecks = builder.suppressRequiredParameterChecks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getRootUrl() {
/* 106 */     return this.rootUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getServicePath() {
/* 118 */     return this.servicePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getBaseUrl() {
/* 130 */     return this.rootUrl + this.servicePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getApplicationName() {
/* 138 */     return this.applicationName;
/*     */   }
/*     */ 
/*     */   
/*     */   public final HttpRequestFactory getRequestFactory() {
/* 143 */     return this.requestFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public final GoogleClientRequestInitializer getGoogleClientRequestInitializer() {
/* 148 */     return this.googleClientRequestInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectParser getObjectParser() {
/* 160 */     return this.objectParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize(AbstractGoogleClientRequest<?> httpClientRequest) throws IOException {
/* 191 */     if (getGoogleClientRequestInitializer() != null) {
/* 192 */       getGoogleClientRequestInitializer().initialize(httpClientRequest);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BatchRequest batch() {
/* 213 */     return batch(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BatchRequest batch(HttpRequestInitializer httpRequestInitializer) {
/* 237 */     BatchRequest batch = new BatchRequest(getRequestFactory().getTransport(), httpRequestInitializer);
/* 238 */     if (Strings.isNullOrEmpty(this.batchPath)) {
/* 239 */       batch.setBatchUrl(new GenericUrl(getRootUrl() + "batch"));
/*     */     } else {
/* 241 */       batch.setBatchUrl(new GenericUrl(getRootUrl() + this.batchPath));
/*     */     } 
/* 243 */     return batch;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean getSuppressPatternChecks() {
/* 248 */     return this.suppressPatternChecks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getSuppressRequiredParameterChecks() {
/* 257 */     return this.suppressRequiredParameterChecks;
/*     */   }
/*     */ 
/*     */   
/*     */   static String normalizeRootUrl(String rootUrl) {
/* 262 */     Preconditions.checkNotNull(rootUrl, "root URL cannot be null.");
/* 263 */     if (!rootUrl.endsWith("/")) {
/* 264 */       rootUrl = rootUrl + "/";
/*     */     }
/* 266 */     return rootUrl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String normalizeServicePath(String servicePath) {
/* 274 */     Preconditions.checkNotNull(servicePath, "service path cannot be null");
/* 275 */     if (servicePath.length() == 1) {
/* 276 */       Preconditions.checkArgument("/"
/* 277 */           .equals(servicePath), "service path must equal \"/\" if it is of length 1.");
/* 278 */       servicePath = "";
/* 279 */     } else if (servicePath.length() > 0) {
/* 280 */       if (!servicePath.endsWith("/")) {
/* 281 */         servicePath = servicePath + "/";
/*     */       }
/* 283 */       if (servicePath.startsWith("/")) {
/* 284 */         servicePath = servicePath.substring(1);
/*     */       }
/*     */     } 
/* 287 */     return servicePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Builder
/*     */   {
/*     */     final HttpTransport transport;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     GoogleClientRequestInitializer googleClientRequestInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     HttpRequestInitializer httpRequestInitializer;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final ObjectParser objectParser;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String rootUrl;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String servicePath;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String batchPath;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String applicationName;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean suppressPatternChecks;
/*     */ 
/*     */ 
/*     */     
/*     */     boolean suppressRequiredParameterChecks;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Builder(HttpTransport transport, String rootUrl, String servicePath, ObjectParser objectParser, HttpRequestInitializer httpRequestInitializer) {
/* 346 */       this.transport = (HttpTransport)Preconditions.checkNotNull(transport);
/* 347 */       this.objectParser = objectParser;
/* 348 */       setRootUrl(rootUrl);
/* 349 */       setServicePath(servicePath);
/* 350 */       this.httpRequestInitializer = httpRequestInitializer;
/*     */     }
/*     */ 
/*     */     
/*     */     public abstract AbstractGoogleClient build();
/*     */ 
/*     */     
/*     */     public final HttpTransport getTransport() {
/* 358 */       return this.transport;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ObjectParser getObjectParser() {
/* 370 */       return this.objectParser;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getRootUrl() {
/* 382 */       return this.rootUrl;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setRootUrl(String rootUrl) {
/* 398 */       this.rootUrl = AbstractGoogleClient.normalizeRootUrl(rootUrl);
/* 399 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getServicePath() {
/* 411 */       return this.servicePath;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setServicePath(String servicePath) {
/* 434 */       this.servicePath = AbstractGoogleClient.normalizeServicePath(servicePath);
/* 435 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setBatchPath(String batchPath) {
/* 442 */       this.batchPath = batchPath;
/* 443 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final GoogleClientRequestInitializer getGoogleClientRequestInitializer() {
/* 448 */       return this.googleClientRequestInitializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setGoogleClientRequestInitializer(GoogleClientRequestInitializer googleClientRequestInitializer) {
/* 461 */       this.googleClientRequestInitializer = googleClientRequestInitializer;
/* 462 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final HttpRequestInitializer getHttpRequestInitializer() {
/* 467 */       return this.httpRequestInitializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setHttpRequestInitializer(HttpRequestInitializer httpRequestInitializer) {
/* 479 */       this.httpRequestInitializer = httpRequestInitializer;
/* 480 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getApplicationName() {
/* 488 */       return this.applicationName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setApplicationName(String applicationName) {
/* 501 */       this.applicationName = applicationName;
/* 502 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public final boolean getSuppressPatternChecks() {
/* 507 */       return this.suppressPatternChecks;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setSuppressPatternChecks(boolean suppressPatternChecks) {
/* 523 */       this.suppressPatternChecks = suppressPatternChecks;
/* 524 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final boolean getSuppressRequiredParameterChecks() {
/* 533 */       return this.suppressRequiredParameterChecks;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setSuppressRequiredParameterChecks(boolean suppressRequiredParameterChecks) {
/* 551 */       this.suppressRequiredParameterChecks = suppressRequiredParameterChecks;
/* 552 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder setSuppressAllChecks(boolean suppressAllChecks) {
/* 566 */       return setSuppressPatternChecks(true).setSuppressRequiredParameterChecks(true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\services\AbstractGoogleClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */