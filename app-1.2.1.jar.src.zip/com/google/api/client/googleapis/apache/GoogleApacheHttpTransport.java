/*    */ package com.google.api.client.googleapis.apache;
/*    */ 
/*    */ import com.google.api.client.googleapis.GoogleUtils;
/*    */ import com.google.api.client.http.apache.ApacheHttpTransport;
/*    */ import com.google.api.client.util.SslUtils;
/*    */ import java.io.IOException;
/*    */ import java.net.ProxySelector;
/*    */ import java.security.GeneralSecurityException;
/*    */ import java.security.KeyStore;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import javax.net.ssl.SSLContext;
/*    */ import org.apache.http.client.HttpClient;
/*    */ import org.apache.http.config.SocketConfig;
/*    */ import org.apache.http.conn.HttpClientConnectionManager;
/*    */ import org.apache.http.conn.routing.HttpRoutePlanner;
/*    */ import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
/*    */ import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
/*    */ import org.apache.http.impl.client.CloseableHttpClient;
/*    */ import org.apache.http.impl.client.HttpClientBuilder;
/*    */ import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
/*    */ import org.apache.http.impl.conn.SystemDefaultRoutePlanner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GoogleApacheHttpTransport
/*    */ {
/*    */   public static ApacheHttpTransport newTrustedTransport() throws GeneralSecurityException, IOException {
/* 54 */     SocketConfig socketConfig = SocketConfig.custom().setRcvBufSize(8192).setSndBufSize(8192).build();
/*    */     
/* 56 */     PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(-1L, TimeUnit.MILLISECONDS);
/*    */ 
/*    */ 
/*    */     
/* 60 */     connectionManager.setValidateAfterInactivity(-1);
/*    */ 
/*    */     
/* 63 */     KeyStore trustStore = GoogleUtils.getCertificateTrustStore();
/* 64 */     SSLContext sslContext = SslUtils.getTlsSslContext();
/* 65 */     SslUtils.initSslContext(sslContext, trustStore, SslUtils.getPkixTrustManagerFactory());
/* 66 */     SSLConnectionSocketFactory sSLConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 78 */     CloseableHttpClient closeableHttpClient = HttpClientBuilder.create().useSystemProperties().setSSLSocketFactory((LayeredConnectionSocketFactory)sSLConnectionSocketFactory).setDefaultSocketConfig(socketConfig).setMaxConnTotal(200).setMaxConnPerRoute(20).setRoutePlanner((HttpRoutePlanner)new SystemDefaultRoutePlanner(ProxySelector.getDefault())).setConnectionManager((HttpClientConnectionManager)connectionManager).disableRedirectHandling().disableAutomaticRetries().build();
/* 79 */     return new ApacheHttpTransport((HttpClient)closeableHttpClient);
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\apache\GoogleApacheHttpTransport.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */