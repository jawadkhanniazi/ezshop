/*     */ package com.google.api.client.googleapis.json;
/*     */ 
/*     */ import com.google.api.client.http.HttpMediaType;
/*     */ import com.google.api.client.http.HttpRequest;
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.http.HttpResponseException;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonParser;
/*     */ import com.google.api.client.json.JsonToken;
/*     */ import com.google.api.client.util.Preconditions;
/*     */ import com.google.api.client.util.StringUtils;
/*     */ import com.google.api.client.util.Strings;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleJsonResponseException
/*     */   extends HttpResponseException
/*     */ {
/*     */   private static final long serialVersionUID = 409811126989994864L;
/*     */   private final transient GoogleJsonError details;
/*     */   
/*     */   public GoogleJsonResponseException(HttpResponseException.Builder builder, GoogleJsonError details) {
/*  68 */     super(builder);
/*  69 */     this.details = details;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final GoogleJsonError getDetails() {
/*  77 */     return this.details;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GoogleJsonResponseException from(JsonFactory jsonFactory, HttpResponse response) {
/*  95 */     HttpResponseException.Builder builder = new HttpResponseException.Builder(response.getStatusCode(), response.getStatusMessage(), response.getHeaders());
/*     */     
/*  97 */     Preconditions.checkNotNull(jsonFactory);
/*  98 */     GoogleJsonError details = null;
/*  99 */     String detailString = null;
/*     */     try {
/* 101 */       if (!response.isSuccessStatusCode() && 
/* 102 */         HttpMediaType.equalsIgnoreParameters("application/json; charset=UTF-8", response.getContentType()) && response
/* 103 */         .getContent() != null) {
/* 104 */         JsonParser parser = null;
/*     */         try {
/* 106 */           parser = jsonFactory.createJsonParser(response.getContent());
/* 107 */           JsonToken currentToken = parser.getCurrentToken();
/*     */           
/* 109 */           if (currentToken == null) {
/* 110 */             currentToken = parser.nextToken();
/*     */           }
/*     */           
/* 113 */           if (currentToken != null) {
/*     */             
/* 115 */             parser.skipToKey("error");
/*     */ 
/*     */             
/* 118 */             if (parser.getCurrentToken() == JsonToken.VALUE_STRING) {
/* 119 */               detailString = parser.getText();
/* 120 */             } else if (parser.getCurrentToken() == JsonToken.START_OBJECT) {
/* 121 */               details = (GoogleJsonError)parser.parseAndClose(GoogleJsonError.class);
/* 122 */               detailString = details.toPrettyString();
/*     */             } 
/*     */           } 
/* 125 */         } catch (IOException exception) {
/*     */           
/* 127 */           exception.printStackTrace();
/*     */         } finally {
/* 129 */           if (parser == null) {
/* 130 */             response.ignore();
/* 131 */           } else if (details == null) {
/* 132 */             parser.close();
/*     */           } 
/*     */         } 
/*     */       } else {
/* 136 */         detailString = response.parseAsString();
/*     */       } 
/* 138 */     } catch (IOException exception) {
/*     */       
/* 140 */       exception.printStackTrace();
/*     */     } 
/*     */     
/* 143 */     StringBuilder message = HttpResponseException.computeMessageBuffer(response);
/* 144 */     if (!Strings.isNullOrEmpty(detailString)) {
/* 145 */       message.append(StringUtils.LINE_SEPARATOR).append(detailString);
/* 146 */       builder.setContent(detailString);
/*     */     } 
/* 148 */     builder.setMessage(message.toString());
/*     */     
/* 150 */     return new GoogleJsonResponseException(builder, details);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResponse execute(JsonFactory jsonFactory, HttpRequest request) throws GoogleJsonResponseException, IOException {
/* 183 */     Preconditions.checkNotNull(jsonFactory);
/* 184 */     boolean originalThrowExceptionOnExecuteError = request.getThrowExceptionOnExecuteError();
/* 185 */     if (originalThrowExceptionOnExecuteError) {
/* 186 */       request.setThrowExceptionOnExecuteError(false);
/*     */     }
/* 188 */     HttpResponse response = request.execute();
/* 189 */     request.setThrowExceptionOnExecuteError(originalThrowExceptionOnExecuteError);
/* 190 */     if (!originalThrowExceptionOnExecuteError || response.isSuccessStatusCode()) {
/* 191 */       return response;
/*     */     }
/* 193 */     throw from(jsonFactory, response);
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\json\GoogleJsonResponseException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */