/*     */ package com.google.api.client.googleapis.json;
/*     */ 
/*     */ import com.google.api.client.http.HttpResponse;
/*     */ import com.google.api.client.json.GenericJson;
/*     */ import com.google.api.client.json.JsonFactory;
/*     */ import com.google.api.client.json.JsonObjectParser;
/*     */ import com.google.api.client.util.Data;
/*     */ import com.google.api.client.util.GenericData;
/*     */ import com.google.api.client.util.Key;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GoogleJsonError
/*     */   extends GenericJson
/*     */ {
/*     */   @Key
/*     */   private List<ErrorInfo> errors;
/*     */   @Key
/*     */   private int code;
/*     */   @Key
/*     */   private String message;
/*     */   
/*     */   public static GoogleJsonError parse(JsonFactory jsonFactory, HttpResponse response) throws IOException {
/*  51 */     JsonObjectParser jsonObjectParser = (new JsonObjectParser.Builder(jsonFactory)).setWrapperKeys(Collections.singleton("error")).build();
/*  52 */     return (GoogleJsonError)jsonObjectParser.parseAndClose(response
/*  53 */         .getContent(), response.getContentCharset(), GoogleJsonError.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  59 */     Data.nullOf(ErrorInfo.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ErrorInfo
/*     */     extends GenericJson
/*     */   {
/*     */     @Key
/*     */     private String domain;
/*     */ 
/*     */ 
/*     */     
/*     */     @Key
/*     */     private String reason;
/*     */ 
/*     */ 
/*     */     
/*     */     @Key
/*     */     private String message;
/*     */ 
/*     */ 
/*     */     
/*     */     @Key
/*     */     private String location;
/*     */ 
/*     */ 
/*     */     
/*     */     @Key
/*     */     private String locationType;
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getDomain() {
/*  94 */       return this.domain;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setDomain(String domain) {
/* 103 */       this.domain = domain;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getReason() {
/* 112 */       return this.reason;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setReason(String reason) {
/* 121 */       this.reason = reason;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getMessage() {
/* 130 */       return this.message;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setMessage(String message) {
/* 139 */       this.message = message;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getLocation() {
/* 149 */       return this.location;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setLocation(String location) {
/* 159 */       this.location = location;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String getLocationType() {
/* 168 */       return this.locationType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void setLocationType(String locationType) {
/* 177 */       this.locationType = locationType;
/*     */     }
/*     */ 
/*     */     
/*     */     public ErrorInfo set(String fieldName, Object value) {
/* 182 */       return (ErrorInfo)super.set(fieldName, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public ErrorInfo clone() {
/* 187 */       return (ErrorInfo)super.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<ErrorInfo> getErrors() {
/* 209 */     return this.errors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setErrors(List<ErrorInfo> errors) {
/* 218 */     this.errors = errors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getCode() {
/* 227 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCode(int code) {
/* 236 */     this.code = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getMessage() {
/* 245 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMessage(String message) {
/* 254 */     this.message = message;
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleJsonError set(String fieldName, Object value) {
/* 259 */     return (GoogleJsonError)super.set(fieldName, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public GoogleJsonError clone() {
/* 264 */     return (GoogleJsonError)super.clone();
/*     */   }
/*     */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\json\GoogleJsonError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */