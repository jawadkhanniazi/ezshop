/*    */ package com.google.api.client.googleapis.json;
/*    */ 
/*    */ import com.google.api.client.json.GenericJson;
/*    */ import com.google.api.client.util.GenericData;
/*    */ import com.google.api.client.util.Key;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GoogleJsonErrorContainer
/*    */   extends GenericJson
/*    */ {
/*    */   @Key
/*    */   private GoogleJsonError error;
/*    */   
/*    */   public final GoogleJsonError getError() {
/* 33 */     return this.error;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void setError(GoogleJsonError error) {
/* 38 */     this.error = error;
/*    */   }
/*    */ 
/*    */   
/*    */   public GoogleJsonErrorContainer set(String fieldName, Object value) {
/* 43 */     return (GoogleJsonErrorContainer)super.set(fieldName, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public GoogleJsonErrorContainer clone() {
/* 48 */     return (GoogleJsonErrorContainer)super.clone();
/*    */   }
/*    */ }


/* Location:              C:\Users\kaka\Documents\NetBeansProjects\EasyShop\my-jar\temp\jd-gui-windows-1.6.6\app-1.2.1.jar!\com\google\api\client\googleapis\json\GoogleJsonErrorContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */